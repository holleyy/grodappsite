/* Connected civic blocks and a planted entrance square, in the hall's world.
   All construction is prepared into the existing scenery layers. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallCivicDistrict=api;})(globalThis,function(){
 'use strict';
 const volume=(id,x0,y0,z0,x1,y1,z1)=>({id,x0,y0,z0,x1,y1,z1});
 const building=(id,x0,y0,x1,y1,z1,front,tone,label='')=>({...volume(id,x0,y0,-12,x1,y1,z1),front,tone,label});
 const apron=(id,x0,y0,x1,y1)=>volume(id,x0,y0,-14,x1,y1,-12);
 function layout(){return {
  frontages:[{axis:'y',ids:['records-wing','library-wing','civic-library']},{axis:'x',ids:['archive','archive-annex','civic-registry','town-houses']}],
  buildings:[building('records-wing',-138,-86,-70,-32,18,'left',1),building('library-wing',-138,-32,-70,28,34,'left',2),building('civic-library',-138,28,-70,100,58,'left',0,'CIVIC LIBRARY'),building('archive',-32,-190,42,-144,34,'rear',0,'CITY RECORDS'),building('archive-annex',42,-190,102,-144,38,'rear',1),building('civic-registry',102,-190,155,-144,34,'rear',2),building('town-houses',155,-190,211,-144,43,'rear',1),building('east-offices',308,-59,356,-12,42,'rear',2)],
  footways:[apron('library-apron',-152,-100,-58,120),apron('library-walk',-70,94,-38,118),apron('archive-apron',-46,-203,226,-129),apron('archive-walk',-20,-129,4,-38),apron('town-walk',180,-129,202,-38),apron('office-apron',292,-78,370,14)],
  streets:[apron('library-street',-58,-105,-38,148),apron('records-street',-46,-129,236,-96)],
  gardens:[volume('west-garden',-80,260,-14,68,338,-11.2),volume('arrival-garden',168,258,-14,360,298,-11.2)],
  trees:[volume('west-square-tree',-64,290,-12,-40,314,41),volume('east-square-tree',316,266,-12,340,290,37)],
  bounds:{left:-460,right:440,top:70,bottom:420}
 };}
 function door(b){const m=b.front==='left'?(b.y0+b.y1)/2:(b.x0+b.x1)/2;return b.front==='left'?{x0:b.x1,y0:m-8,x1:b.x1+8,y1:m+8}:{x0:m-8,y0:b.y1,x1:m+8,y1:b.y1+8};}
 const at=(axis,u,d,z)=>axis==='rear'?[u,d,z]:[d,u,z];
 function box(p,x,y,z,w,d,h,kind='stone'){CityHallClockBay.paperBox(p,x,y,z,w,d,h,kind);}
 function wallBox(p,axis,u,d,z,w,depth,h,kind='stone'){if(axis==='rear')box(p,u,d,z,w,depth,h,kind);else box(p,d,u,z,depth,w,h,kind);}
 function plane(p,axis,u,d,z,w,h,fill){p.face([at(axis,u,d,z),at(axis,u+w,d,z),at(axis,u+w,d,z+h),at(axis,u,d,z+h)],fill,null);}
 function surface(p,b,colour,edge){
  p.face([[b.x0,b.y0,-13.9],[b.x1,b.y0,-13.9],[b.x1,b.y1,-13.9],[b.x0,b.y1,-13.9]],colour,null);
  for(let y=b.y0;y<b.y1;y+=8)for(let x=b.x0;x<b.x1;x+=16){const r=Math.min(x+16,b.x1),s=Math.min(y+8,b.y1);p.line([x,y,-13.85],[r,y,-13.85],edge,.22);p.line([x,y,-13.85],[x,s,-13.85],edge,.18);}
 }
 function paving(p){
  for(const b of layout().streets){surface(p,b,'#aaa999','#929782');for(const x of [b.x0+.5,b.x1-.5])p.line([x,b.y0,-13.7],[x,b.y1,-13.7],'#d8cfb8',.5);}
  // A broad paved threshold joins the six steps to the planted square.
  const b={x0:-36,y0:218,x1:263,y1:258};p.face([[b.x0,b.y0,-12],[b.x1,b.y0,-12],[b.x1,b.y1,-12],[b.x0,b.y1,-12]],'#d5c7a9',null);
  for(let y=222;y<=258;y+=12)for(let x=-36;x<263;x+=22){const r=Math.min(263,x+22);p.line([x,y,-11.95],[r,y,-11.95],'#b9ae96',.25);p.line([x,y-12,-11.95],[x,y,-11.95],'#b9ae96',.22);}
  for(const y of [248,251])p.line([-36,y,-11.9],[263,y,-11.9],y===248?'#9e9e85':'#e7d8b9',1.1);
 }
 function window(p,axis,u,d,z,w,h,lit=false){
  const pos=(v,q,dep=d+.35)=>at(axis,v,dep,q);
  plane(p,axis,u-.5,d+.1,z-.4,w+1,h+1,'#6c705e');plane(p,axis,u,d+.2,z,w,h,lit?'#c2b48a':'#9ba99a');
  // Recessed lintel, thick cheeks and a projecting stone sill.
  for(const v of [u-1.25,u+w])wallBox(p,axis,v,d+.1,z-1,1.25,1.5,h+2);
  wallBox(p,axis,u-1.4,d+.1,z+h,w+2.8,1.8,1.2);wallBox(p,axis,u-1.8,d-.2,z-1.5,w+3.6,2.7,1.5);
  p.line(pos(u+.7,z+h-.8),pos(u+w-.7,z+h-.8),'#7b8370',.8);
  p.line(pos(u+w/2,z+.6),pos(u+w/2,z+h-.6),'#ede0c4',.7);p.line(pos(u+.5,z+h*.5),pos(u+w-.5,z+h*.5),'#ede0c4',.7);
 }
 function roofFace(p,pts,shade=0){
  const P=CityHallProjection,c=p.c,a=P.project(...pts[0]),b=P.project(...pts[1]),d=P.project(...pts[3]);
  c.save();c.beginPath();for(let i=0;i<pts.length;i++){const q=P.project(...pts[i]);if(i)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);}c.closePath();c.clip();c.transform(b.x-a.x,b.y-a.y,d.x-a.x,d.y-a.y,a.x,a.y);c.drawImage(p.images['vault-slate'],0,0,1,1);if(shade){c.globalAlpha=Math.abs(shade);c.fillStyle=shade>0?'#eee5c7':'#244f45';c.fillRect(0,0,1,1);}c.restore();
 }
 function roof(p,b){
  const x=b.x0-2,y=b.y0-2,w=b.x1-b.x0+4,d=b.y1-b.y0+4,z=b.z1+3,h=b.id==='civic-library'?19:14,alongY=b.front==='left';
  if(alongY){
   const m=x+w/2;p.face([[x,y+d,z],[x+w,y+d,z],[m,y+d,z+h]],'#c8b89a','#aa9b7f',.3);
   roofFace(p,[[x,y,z],[m,y,z+h],[m,y+d,z+h],[x,y+d,z]],.1);roofFace(p,[[m,y,z+h],[x+w,y,z],[x+w,y+d,z],[m,y+d,z+h]],-.08);
   for(let j=0;j<=6;j++){const t=j/6;p.line([m+w/2*t,y,z+h*(1-t)],[m+w/2*t,y+d,z+h*(1-t)],'#aec0ad',.26);}
   for(let k=0;k<=6;k++)p.line([m,y+k*d/6,z+h],[x+w,y+k*d/6,z],'#516e62',.28);
   p.line([m,y,z+h+.5],[m,y+d,z+h+.5],'#b9bd9b',1.2);box(p,m-3,y+d*.62,z+h-3,5,5,11,'wood');box(p,m-4,y+d*.62-1,z+h+7,7,7,1.2);
  }else{
   const m=y+d/2;p.face([[x+w,y,z],[x+w,y+d,z],[x+w,m,z+h]],'#b8aa8c','#aa9b7f',.3);
   roofFace(p,[[x,y,z],[x+w,y,z],[x+w,m,z+h],[x,m,z+h]],.12);roofFace(p,[[x,m,z+h],[x+w,m,z+h],[x+w,y+d,z],[x,y+d,z]],-.08);
   for(let j=0;j<=5;j++){const t=j/5;p.line([x,m+d/2*t,z+h*(1-t)],[x+w,m+d/2*t,z+h*(1-t)],'#aab69e',.26);}
   for(let k=0;k<=6;k++)p.line([x+k*w/6,m,z+h],[x+k*w/6,y+d,z],'#526e60',.28);
   p.line([x,m,z+h+.5],[x+w,m,z+h+.5],'#bbc2a4',1.1);box(p,x+w*.25,m-2,z+h-3,5,5,10,'wood');box(p,x+w*.25-1,m-3,z+h+6,7,7,1.2);
  }
 }
 function drawBuilding(p,b,index){
  const x=b.x0,y=b.y0,w=b.x1-x,d=b.y1-y,z=b.z0,h=b.z1-z;
  const tones=[['#d8c6a7','#bbaa8c'],['#bb9177','#9b7e67'],['#c4b99a','#a59f85']],colour=tones[b.tone];
  CityHallDaylight.townShadow(p,b);box(p,x-2,y-2,-14,w+4,d+4,2);p.box(x,y,z,w,d,h,['#e1cfad',colour[0],colour[1]]);
  for(const [axis,start,len,depth]of [['rear',x,w,y+d+.05],['left',y,d,x+w+.05]]){
   const front=axis===b.front,m=start+len/2;
   for(let k=z;k<b.z1;k+=5){const top=Math.min(b.z1,k+5);p.line(at(axis,start,depth,k),at(axis,start+len,depth,k),'#8f81694a',.2);for(let u=start+((k-z)/5%2)*6;u<start+len;u+=12)p.line(at(axis,u,depth,k),at(axis,u,depth,top),'#8f816938',.17);}
   for(let k=z+7;k<b.z1-18;k+=23)for(let u=start+8;u<start+len-14;u+=18){if(front&&k<z+24&&u<m+8&&u+10>m-8)continue;window(p,axis,u,depth,k,10,16,(index+Math.floor(u/18))%4===0);}
   for(const u of [start,start+len-3])for(let k=z;k<b.z1;k+=7)wallBox(p,axis,u,depth,k,3,1,Math.min(4,b.z1-k));
   for(const k of [z+3,z+27,b.z1-2])wallBox(p,axis,start-1,depth-.3,k,len+2,1.8,1.3);
   if(front){
    plane(p,axis,m-6,depth+.2,z,12,22,'#365c4d');plane(p,axis,m-4.8,depth+.3,z+1,4.2,16,'#4b7058');plane(p,axis,m+.6,depth+.3,z+1,4.2,16,'#4b7058');
    for(const u of [m-7.3,m+6])wallBox(p,axis,u,depth,z,1.3,2,23);wallBox(p,axis,m-7.5,depth-.3,z+22,15,2.6,1.8);wallBox(p,axis,m-8,depth,z,16,5,.7);
    p.line(at(axis,m,depth+.6,z+7),at(axis,m,depth+.6,z+11),'#dbbf77',.6);
    if(b.label){wallBox(p,axis,m-15,depth,z+27,30,1.2,5,'green');const q=CityHallProjection.project(...at(axis,m,depth+1.3,z+29)),c=p.c;c.save();c.transform(axis==='rear'?1:-1,.5,0,1,q.x,q.y);if(axis==='left')c.scale(-1,1);c.font='2.4px Georgia';c.fillStyle='#ead7a3';c.textAlign='center';c.fillText(b.label,0,0);c.restore();}
   }
  }
  box(p,x-1,y-1,b.z1,w+2,d+2,1.4);box(p,x-2,y-2,b.z1+1.4,w+4,d+4,1.6);roof(p,b);CityHallDaylight.townAir(p,b,index===0?1:2);
 }
 return {layout,door,paving,building:drawBuilding};
});
