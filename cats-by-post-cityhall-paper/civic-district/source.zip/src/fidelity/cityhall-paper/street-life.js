/* Prepared town footways and postal fixtures; one deterministic outdoor worker.
   Ground contacts use the same projection as the hall, with verticals upright. */
(function(root,factory){const D=typeof module==='object'&&module.exports?require('./civic-district'):root.CityHallCivicDistrict,api=factory(D);if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallStreetLife=api;})(globalThis,function(D){
 'use strict';
 const box=(id,x0,y0,x1,y1)=>({id,x0,y0,z0:-14,x1,y1,z1:-12});
 function layout(){return {
  postalBay:box('postal-bay',263,168,337,245),
  footways:[box('hall-pavement',-38,-38,263,245),box('east-walk',263,-38,292,245),box('postal-bay',263,168,337,245),...D.layout().footways],
  fixtures:[{id:'street-noticeboard',x0:296,y0:171,x1:328,y1:177,contacts:[[298,174,-12],[326,174,-12]]},{id:'street-bicycle',x0:263,y0:202,x1:312,y1:213,contacts:[[274,206,-12],[304,206,-12]]}]
 };}
 const points=[[320,228],[330,228],[330,194],[319,194]],segments=[[8,11,0,1,0],[11,18,1,2,3],[18,21,2,3,2],[29,32,3,2,0],[32,39,2,1,1],[39,42,1,0,2]];
 function makeOut(){return {x:320,y:228,z:-12,face:3,action:'check',walk:-1,carry:false,gripWeight:0};}
 function sample(time,chapter,out,motion=true){
  const t=motion&&!chapter?.mode?((time%48)+48)%48:0;
  out.x=320;out.y=228;out.z=-12;out.face=3;out.action='check';out.walk=-1;
  if(t>=21&&t<29){out.x=319;out.y=194;out.action='read';}
  for(let i=0;i<segments.length;i++){const s=segments[i];if(t<s[0]||t>=s[1])continue;const a=points[s[2]],b=points[s[3]],v=(t-s[0])/(s[1]-s[0]),u=v*v*(3-2*v);out.x=a[0]+(b[0]-a[0])*u;out.y=a[1]+(b[1]-a[1])*u;out.face=s[4];out.action='walk';out.walk=Math.floor(u*Math.hypot(b[0]-a[0],b[1]-a[1])/4)%4;break;}
  return out;
 }
 function registration(source,target){const a=source[0],b=source[1],q=target[0],r=target[1],sx=(r[0]-q[0])/(b[0]-a[0]),sy=sx,shear=(r[1]-q[1]-sy*(b[1]-a[1]))/(b[0]-a[0]);return [sx,shear,0,sy,q[0]-sx*a[0],q[1]-shear*a[0]-sy*a[1]];}
 function paving(p){
  const rects=layout().footways,P=CityHallProjection,c=p.c,inside=(x,y)=>rects.some(b=>x>b.x0&&x<b.x1&&y>b.y0&&y<b.y1),xs=[...new Set([...rects.flatMap(b=>[b.x0,b.x1]),86,142])].sort((a,b)=>a-b),ys=[...new Set(rects.flatMap(b=>[b.y0,b.y1]))].sort((a,b)=>a-b);
  for(const b of rects)CityHallClockBay.paperBox(p,b.x0,b.y0,-14,b.x1-b.x0,b.y1-b.y0,2,'stone');
  c.save();c.beginPath();for(const b of rects){const pts=[[b.x0,b.y0],[b.x1,b.y0],[b.x1,b.y1],[b.x0,b.y1]];for(let i=0;i<4;i++){const q=P.project(pts[i][0],pts[i][1],-11.95);if(i)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);}c.closePath();}c.clip();
  for(let y=-214;y<245;y+=16)for(let x=-158;x<370;x+=24)p.face([[x,y,-11.95],[x+24,y,-11.95],[x+24,y+16,-11.95],[x,y+16,-11.95]],((x+38)/24+(y+38)/16)%3?'#d2c7af':'#d9ceb6','#b9ae96',.25);c.restore();
  // Only the outer boundary receives a kerb. Joined aprons remain step-free.
  for(let i=0;i<xs.length-1;i++)for(let j=0;j<ys.length-1;j++){
   const x=xs[i],y=ys[j],w=xs[i+1]-x,d=ys[j+1]-y;if(!inside(x+w/2,y+d/2))continue;
   if(!inside(x+w/2,y+d+.01)&&!(y+d===245&&x>=86&&x+w<=142))CityHallClockBay.paperBox(p,x,y+d-1.3,-12.3,w,1.3,1,'stone');
   if(!inside(x+w+.01,y+d/2))CityHallClockBay.paperBox(p,x+w-1.3,y,-12.3,1.3,d,1,'stone');
  }
 }
 function fixture(p,b){
  const meta=CityHallAssets.registration[b.id],P=CityHallProjection,target=b.contacts.map(a=>{const q=P.project(...a);return [q.x,q.y];}),m=registration(meta.registration.contacts,target),c=p.c;
  for(const a of b.contacts)p.shadow(a[0]+.7,a[1]+.7,a[2],b.id==='street-bicycle'?3.2:2.4,1.1,.2);
  c.save();c.transform(...m);c.drawImage(p.images[b.id],0,0);c.restore();
 }
 function create(r){
  const fixtures=layout().fixtures,layers=fixtures.map(b=>({depth:(b.x0+b.x1+b.y0+b.y1)/2,...r.layer({left:40,right:190,top:180,bottom:310},p=>fixture(p,b),3)})),out=makeOut();
  return {layers,out,draw(f,worker){sample(f.sceneTime,f.chapter,out,f.motion);let drawn=false;for(let i=0;i<layers.length;i++){if(!drawn&&out.x+out.y<layers[i].depth){worker(out);drawn=true;}r.composite(layers[i]);}if(!drawn)worker(out);},dispose(){for(const l of layers)l.canvas.width=l.canvas.height=0;layers.length=0;}};
 }
 return {layout,makeOut,sample,registration,paving,create};
});
