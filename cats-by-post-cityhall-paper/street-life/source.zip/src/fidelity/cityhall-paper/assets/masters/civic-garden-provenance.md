# Civic garden shrub

`civic-shrub.png` is the complete unmodified1672×941 RGBA output from OpenAI
Image Gen, directed by an Astra asset agent. The brief specified a broad low
clipped sage/olive shrub, a few small cream/blush flowers, matte fibrous paper,
upper-left light, elevated orthographic view, transparent surroundings, and
no pot, trunk, ground plane or scene. Raw output:
`exec-110f31fd-76ed-4d33-947f-4a95ee6acba5.png`.

Actual alpha spans0–255. The root anchor is(836,857), normalised(.500,.911).
The full native WebP derivative uses quality94/method6 and preserves alpha.
Source and derivative hashes/dimensions are in the asset manifest. No crop,
repaint, recolouring or reconstruction is applied. Existing tree and flower
masters remain exact. Planted beds, seats and setts use retained materials
on measured world geometry, prepared once.
