/* Original human workers and Postmistress artwork. Prepared names and source
   contacts keep all live draws allocation-free and registered to one floor. */
(function(root){
 'use strict';
 const P=CityHallProjection;
 const front={check:[2299990393],walk:[1959033690,31647630,1959033690,893344609],read:[3666716670],sort:[3183875845],wave:[3656661081]},back={check:[415458812],walk:[3527031261,1041685833,3527031261,156213455],read:[143669321],sort:[3393869830],wave:[112304194]};
 const pmNames=['pm-notice','pm-reach','pm-tap','pm-settle'];
 // Accepted Office anatomical calibration: fixed eye/head scale across poses,
 // rather than forcing long tails and stretched legs into one crop width.
 const catWidths={'ginger-nap':42,'ginger-puzzled':41.8,'ginger-push-front':46,'ginger-walk-front-0':48,'ginger-walk-front-1':49};
 class Actors{
  constructor(r){this.streetWorker=this.worker.bind(this);this.r=r;this.c=r.ctx;this.motion=CityHallMotion.create(CITYHALL,r.layout);this.out=this.motion.makeOut();this.point={x:0,y:0};this.pigeon=this.bakePigeon();this.carriers=r.carriers;this.workerImages={};this.rigs={};this.baseImages={};this.gripPoint={x:0,y:0};this.armPoint={x:0,y:0};this.cart=r.layer({left:-22,right:22,top:-26,bottom:18},p=>CityHallArchitecture.trolley(p,0,0));this.parcel=r.layer({left:-8,right:8,top:-7,bottom:5},p=>{p.box(-3.5,-2.5,0,7,5,5,'wood');p.line([0,-2.5,5.1],[0,2.5,5.1],'#efddba',.65);p.planeImage('letters',1,-1,5.2,1.6,1.4);});for(const table of [front,back])for(const action of Object.keys(table))for(const hash of table[action])if(!this.workerImages[hash])this.workerImages[hash]=[r.images['worker-'+hash],r.images['worker-carry-'+hash+'-plain'],r.images['worker-carry-'+hash+'-mirrored']];for(const key of Object.keys(r.assets.registration))if(key.startsWith('worker-base-')){const hash=key.slice(12);this.baseImages[hash]=r.images[key];this.rigs[hash]=r.assets.registration[key].rig;}}
  bakePigeon(){const canvas=document.createElement('canvas');canvas.width=128;canvas.height=96;const c=canvas.getContext('2d');c.scale(4,4);c.fillStyle='#646b76';c.beginPath();c.ellipse(14,12,6,4,-.4,0,Math.PI*2);c.fill();c.fillStyle='#858b90';c.beginPath();c.ellipse(17,8,3,4,0,0,Math.PI*2);c.fill();c.fillStyle='#adb3af';c.beginPath();c.ellipse(11,12,5,2.4,-.4,0,Math.PI*2);c.fill();c.fillStyle='#c4ae77';c.beginPath();c.moveTo(19,7);c.lineTo(22,8);c.lineTo(19,9);c.fill();c.fillStyle='#283c3e';c.beginPath();c.arc(18,6.8,.55,0,Math.PI*2);c.fill();c.strokeStyle='#b69b73';c.lineWidth=.7;for(const x of [12,16]){c.beginPath();c.moveTo(x,15);c.lineTo(x,18);c.lineTo(x+2,18);c.stroke();}return canvas;}
  worker(a){
   const c=this.c,r=this.r,p=P.project(a.x,a.y,a.z,this.point),away=a.face===2||a.face===3,table=away?back:front,action=a.action in table?a.action:'check',hash=table[action][action==='walk'?Math.max(0,a.walk):0],mirror=CITYHALL.staffMirror(a.face);
   const images=this.workerImages[hash],im=a.gripWeight>0?this.baseImages[hash]:images[a.carry?mirror?2:1:0]||images[0];if(a.gripWeight>0){this.activeRig=this.rigs[hash];this.activeMirror=mirror;}
   r.shadow(p.x,p.y,5,2,.16);c.save();c.translate(p.x,p.y);if(mirror)c.scale(-1,1);c.drawImage(im,-16,-35.5,32,36);c.restore();
  }
  at(layer,x,y,z){const p=P.project(x,y,z,this.point);this.c.drawImage(layer.canvas,p.x+layer.left,p.y+layer.top,layer.width,layer.height);}
  wheels(t){const c=this.c;for(let i=0;i<4;i++){const x=t.x+(i&1?6:-6),y=t.y+(i&2?7:-7),p=P.project(x,y,2,this.point),dx=1.5*Math.cos(t.angle),dy=1.5*Math.sin(t.angle);c.beginPath();c.moveTo(p.x-dx,p.y-dy);c.lineTo(p.x+dx,p.y+dy);c.strokeStyle='#c5aa61';c.lineWidth=.5;c.stroke();}}
  limb(x0,y0,x1,y1,width){const c=this.c,dx=x1-x0,dy=y1-y0,length=Math.hypot(dx,dy);c.save();c.translate(x0,y0);c.rotate(Math.atan2(dy,dx)-Math.PI/2);c.drawImage(this.r.images['joint-sleeve'],-width/2,-.4,width,length+.8);c.restore();}
  arm(sx,sy,wx,wy,side){const c=this.c,ex=sx+(wx-sx)*.5+side*.8,ey=sy+(wy-sy)*.5+.8;this.limb(sx,sy,ex,ey,2.8);this.limb(ex,ey,wx,wy,2.5);c.drawImage(this.r.images['joint-hand'],wx-1.5,wy-1.5,3,3.25);}
  grip(a){const c=this.c,rig=this.activeRig,mirror=this.activeMirror,p=P.project(a.x,a.y,a.z,this.point),g=P.project(a.grip.x,a.grip.y,a.grip.z,this.gripPoint),gx=g.x-p.x,gy=g.y-p.y,side=gx<0?-1:1;
   c.save();c.translate(p.x,p.y);
   for(let i=0;i<2;i++){const source=i?1:-1,sign=source*(mirror?-1:1),sx=sign*4,sy=rig.shoulder[1]-1.5;let wx=i?4.3:rig.wrist[0],wy=(i?rig.shoulder[1]+9:rig.wrist[1])-1.5;if(mirror)wx=-wx;
    if(sign===side){wx+=(gx-wx)*a.gripWeight;wy+=(gy-wy)*a.gripWeight;}this.arm(sx,sy,wx,wy,sign);
   }c.restore();
  }
  draw(f){
   const r=this.r,c=this.c,o=this.motion.sample(f.sceneTime,f.chapter,this.out,f.motion);
   this.at(this.cart,o.trolley.x,o.trolley.y,0);this.wheels(o.trolley);for(let i=0;i<3;i++)this.worker(o.workers[i]);
   this.at(this.parcel,o.parcel.x,o.parcel.y,o.parcel.z);if(o.workers[0].gripWeight>0)this.grip(o.workers[0]);
   const p=P.project(o.pm.x,o.pm.y,o.pm.z,this.point);r.shadow(p.x,p.y,4.4,1.7,.13);c.drawImage(r.images[pmNames[o.pm.pose]],p.x-16,p.y-35.5,32,36);
   const cat=o.cat,at=P.project(cat.x,cat.y,cat.z,this.point);r.shadow(at.x,at.y+1,6,2,.11);const sprites=r.assets.acting.sprites;
   const name=cat.pose==='nap'?'ginger-nap':cat.pose==='sit'?'ginger-puzzled':cat.pose==='jump'?'ginger-push-front':Math.floor(cat.phase*7)%2?'ginger-walk-front-1':'ginger-walk-front-0',s=sprites[name],rect=s.rect,width=catWidths[name]*17/42,height=width*rect[3]/rect[2];
   c.save();c.translate(at.x,at.y);if(cat.dir===2)c.scale(-1,1);c.drawImage(r.images.acting,rect[0],rect[1],rect[2],rect[3],-width*(cat.pose==='jump'?.94:.5),-height*(cat.pose==='jump'?.75:1),width,height);c.restore();
   const b=o.pigeon,bp=P.project(b.x,b.y,b.z,this.point);c.save();c.translate(bp.x,bp.y);if(b.face)c.scale(-1,1);c.drawImage(this.pigeon,-8,-9,16,12);c.restore();
   if(r.street)r.street.draw(f,this.streetWorker);
   if(f.chapter?.mode==='exit'){const d=f.chapter.dispatch,sp=P.project(d.bagX,d.bagY,d.bagZ,this.point);c.drawImage(r.images['dispatch-mailbag'],sp.x-16,sp.y-35.5,32,36);}
  }
  dispose(){this.pigeon.width=this.pigeon.height=0;this.cart.canvas.width=this.cart.canvas.height=this.parcel.canvas.width=this.parcel.canvas.height=0;this.workerImages=this.baseImages=this.rigs={};this.streetWorker=this.carriers=this.r=this.c=this.out=this.motion=null;}
 }
 root.CityHallActors=Actors;
})(globalThis);
