/* One high sun and one continuous paper square. Material preparation happens
   once; the live background only fills the visible world rectangle. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallDaylight=api;})(globalThis,function(){
 'use strict';
 const sun={x:.46,y:.25};
 function layout(){return {sun,walk:[{x0:86,y0:245,x1:142,y1:355,z:-12},{x0:142,y0:319,x1:360,y1:355,z:-12}]};}
 function shadowPoint(p,z){const h=Math.max(0,p[2]-z);return[p[0]+sun.x*h,p[1]+sun.y*h,z];}
 function hull(points){const a=points.map(p=>[p[0],p[1],p[2]]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]),cross=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]),lower=[],upper=[];for(const p of a){while(lower.length>1&&cross(lower.at(-2),lower.at(-1),p)<=0)lower.pop();lower.push(p);}for(let i=a.length-1;i>=0;i--){const p=a[i];while(upper.length>1&&cross(upper.at(-2),upper.at(-1),p)<=0)upper.pop();upper.push(p);}return lower.slice(0,-1).concat(upper.slice(0,-1));}
 function caster(p,b,top,z,alpha=.13,blur=1){const base=[[b.x0,b.y0,z],[b.x1,b.y0,z],[b.x1,b.y1,z],[b.x0,b.y1,z]],end=base.map(v=>shadowPoint([v[0],v[1],top],z)),c=p.c;c.save();c.globalAlpha=alpha;c.filter='blur('+blur+'px)';p.face(hull(base.concat(end)),'#344c45',null);c.restore();}
 function prepare(ctx,images){
  const tile=document.createElement('canvas');tile.width=480;tile.height=240;const c=tile.getContext('2d');c.scale(2,2);const p=new CityHallMaterials.Painter(c,images),colours=['#c4b69c','#cbbda3','#beb197','#c9b99d','#c1b39a'];
  c.fillStyle=colours[0];c.fillRect(0,0,240,120);
  for(let y=-360;y<=360;y+=6)for(let x=-240;x<=480;x+=12){const n=((x/12)*7+(y/6)*11)%5,u=x+(Math.abs(y/6)%2)*6;p.face([[u+.35,y+.3,0],[u+11.65,y+.3,0],[u+11.65,y+5.7,0],[u+.35,y+5.7,0]],colours[(n+5)%5],'#aa9c81',.2);p.line([u+.6,y+.5,.01],[u+11.4,y+.5,.01],'#dfd1b6',.2);}
  p.fibre({left:0,right:240,top:0,bottom:120},.045);
  const ground=ctx.createPattern(tile,'repeat');ground.setTransform(new DOMMatrix([.5,0,0,.5,0,14]));
  const sky=ctx.createPattern(images['daylight-sky'],'repeat');sky.setTransform(new DOMMatrix([.3,0,0,.3,0,0]));
  const source=images['civic-skyline'],skyline=document.createElement('canvas');skyline.width=source.width;skyline.height=source.height;const s=skyline.getContext('2d');s.drawImage(source,0,0);const fade=s.createLinearGradient(0,0,0,100);fade.addColorStop(0,'#ffffff00');fade.addColorStop(1,'#ffffff');s.globalCompositeOperation='destination-in';s.fillStyle=fade;s.fillRect(0,0,skyline.width,skyline.height);
  images['daylight-ground']=tile;images['daylight-skyline']=skyline;return{tile,skyline,ground,sky};
 }
 function background(c,b,cam,v){const x=-cam.tx/cam.scale,y=-cam.ty/cam.scale,w=v.width/cam.scale,h=v.height/cam.scale;c.fillStyle=b.sky;c.fillRect(x,y,w,h);const groundY=Math.max(-70,y);if(y+h>groundY){c.fillStyle=b.ground;c.fillRect(x,groundY,w,y+h-groundY);}}
 function paving(p){const c=p.c,g=c.createPattern(p.images['daylight-ground'],'repeat');g.setTransform(new DOMMatrix([.5,0,0,.5,0,14]));c.fillStyle=g;c.fillRect(-700,-70,1400,520);}
 function forecourt(p){
  for(const b of layout().walk){
   caster(p,b,-12,-14,.09,.7);CityHallClockBay.paperBox(p,b.x0,b.y0,-14,b.x1-b.x0,b.y1-b.y0,2,'stone');
   for(let y=b.y0;y<b.y1;y+=18)for(let x=b.x0;x<b.x1;x+=14){const x1=Math.min(b.x1,x+14),y1=Math.min(b.y1,y+18);p.face([[x,y,-11.95],[x1,y,-11.95],[x1,y1,-11.95],[x,y1,-11.95]],((x-b.x0)/14+(y-b.y0)/18)%3?'#d8cfb9':'#ddd3bd','#bfb69e',.2);p.planeImage('material-marble',x,y,-11.94,x1-x,y1-y,'floor',.075);}
   for(const x of [b.x0,b.x1])p.line([x,b.y0,-11.9],[x,b.y1,-11.9],'#eee1c6',.7);
  }
 }
 function plinth(p){caster(p,{x0:-4,y0:-4,x1:228,y1:196},0,-12,.22,1.3);}
 function floor(p,L){
  const c=p.c;c.save();p.face([[0,0,.68],[224,0,.68],[224,192,.68],[0,192,.68]],null,null);c.clip();
  const glow=c.createLinearGradient(-65,-25,160,190);glow.addColorStop(0,'#fff1c340');glow.addColorStop(.6,'#ffe9ba12');glow.addColorStop(1,'#fff0cc00');c.fillStyle=glow;c.fillRect(-200,-30,450,260);
  caster(p,{x0:0,y0:0,x1:224,y1:23},42,.7,.13,1.2);caster(p,{x0:0,y0:23,x1:23,y1:192},42,.7,.13,1.2);
  for(const b of L.columns)caster(p,b,Math.min(80,b.z1),.7,.085,1.1);
  for(const y of [114,178])caster(p,{x0:19,y0:y-2,x1:23,y1:y+2},42,.7,.14,.7);
  c.restore();
 }
 function wall(p,axis,length){const c=p.c;c.save();if(axis==='rear')c.transform(1,.5,0,-1,0,0);else c.transform(-1,.5,0,-1,0,0);const g=c.createLinearGradient(0,138,length,0);g.addColorStop(0,'#fff0cb38');g.addColorStop(.65,'#fff0cb04');g.addColorStop(1,'#4f645e12');c.fillStyle=g;c.fillRect(0,0,length,138);c.restore();}
 function townShadow(p,b){caster(p,b,b.z1+12,-14,.16,2);}
 function townAir(p,b,index){const a=index===1?.14:index===2?.1:.045,col='#f2dec4',c=p.c;c.save();c.globalAlpha=a;p.face([[b.x0,b.y1+.8,b.z1],[b.x1,b.y1+.8,b.z1],[b.x1,b.y1+.8,b.z0],[b.x0,b.y1+.8,b.z0]],col,null);p.face([[b.x1+.8,b.y0,b.z1],[b.x1+.8,b.y1,b.z1],[b.x1+.8,b.y1,b.z0],[b.x1+.8,b.y0,b.z0]],col,null);c.restore();}
 return {layout,shadowPoint,prepare,background,paving,forecourt,plinth,floor,wall,townShadow,townAir};
});
