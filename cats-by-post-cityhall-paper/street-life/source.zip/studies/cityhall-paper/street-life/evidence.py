"""Native-size actual-renderer captures and preservation receipts."""
from pathlib import Path
from PIL import Image
import json,hashlib,shutil
root=Path(__file__).resolve().parents[3];work=root/'work/cityhall-paper/street-life';out=root/'docs/review-images/cityhall-paper/street-life';out.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
build=read(root/'studies/cityhall-paper/build.json');protected=read(root/'work/cityhall-paper/protected.json')
for f,h in build['inputs'].items():assert sha(root/f)==h,f
for f,h in protected.items():assert sha(root/f)==h,f
for f in [root/'work/cityhall-paper/browser-report.json',root/'work/cityhall-paper/qualification-report.json',work/'phone-report.json']:assert f.stat().st_mtime>(root/'studies/cityhall-paper/index.html').stat().st_mtime,f
before=read(work/'before-rasters.json');after=read(work/'after-rasters.json');assert before==after==read(out.parent/'phone-and-light/after-rasters.json')
browser=read(root/'work/cityhall-paper/browser-report.json');qualify=read(root/'work/cityhall-paper/qualification-report.json');phone=read(work/'phone-report.json')
assert not browser['errors'] and not qualify['errors'] and not phone['errors'] and not phone['failures']
assert len(browser['checks'])==72 and len(qualify['checks'])==26 and len(phone['checks'])==44
captures={};views=['phone-first','phone','phone-tall','phone-short','phone-hall','hall','square','light','detail','board','gray']
for name in [f'{side}-{view}' for side in ['before','after'] for view in views]+['qa-concept','qa-detail','qa-phone','route-0','route-24','route-35.5']:
 source=work/(name+'.png');target=out/(name+'.webp')
 with Image.open(source) as im:
  im.save(target,'WEBP',quality=94,method=6);captures[target.name]={'width':im.width,'height':im.height,'sourceSha256':sha(source),'sha256':sha(target)}
for src,name in [(root/'studies/cityhall-paper/build.json','build-manifest.json'),(work/'before-build.json','before-build.json'),(root/'work/cityhall-paper/browser-report.json','browser-report.json'),(root/'work/cityhall-paper/qualification-report.json','qualification-report.json')]+[(work/f,f) for f in ['phone-report.json','before-rasters.json','after-rasters.json','before-canopy.json','after-canopy.json','phone-life.webm','street-life.webm','street-report.json']]:shutil.copyfile(src,out/name)
write('capture-hashes.json',{'runtimeSha256':build['sha256'],'ambientSeconds':8,'images':captures})
write('preservation.json',{'protectedFiles':protected,'allExact':True,'boardRasters':after,'previousRuntime':read(work/'before-build.json')['sha256']})
write('verification.json',{'runtimeSha256':build['sha256'],'bytes':build['bytes'],'focusedTests':43,'browserChecks':72,'qualificationChecks':26,'phoneChecks':44,'streetChecks':6,'canonicalWins':len(browser['wins']),'protectedFiles':len(protected),'buildInputs':len(build['inputs']),'boardRastersExact':3,'crown':read(work/'after-canopy.json'),'errors':[],'warm':qualify['warm'],'street':read(work/'street-report.json'),'scope':'Actual cloud Chromium with phone/DPR2 emulation, not physical-device/Safari performance'})
print('Evidence complete',build['sha256'],len(captures),'captures')
