const {chromium}=require('/opt/codex/cua_node/lib/node_modules/playwright'),fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']}),p=await b.newPage({viewport:{width:1440,height:1000}}),report={checks:[],errors:[],poses:[]};p.on('pageerror',e=>report.errors.push(e.message));
try{
 await p.goto('http://127.0.0.1:8807/studies/cityhall-paper/',{timeout:120000});await p.waitForFunction(()=>window.CityHallStudy?.ready,null,{timeout:120000});await p.evaluate(()=>document.fonts.ready);
 const check=(name,value)=>{report.checks.push({name,passed:!!value});assert.ok(value,name);};
 await p.evaluate(()=>{update=function(){};const S=CityHallStudy;S.view('hall');S.viewport.zoom=2.2;S.app.draw();S.viewport.panX=(15-111)*S.renderer.cam.scale;S.viewport.panY=(23-253)*S.renderer.cam.scale;S.app.draw();});
 for(const t of [0,9.5,14.5,19.5,24,30.5,35.5,40.5,48]){const pose=await p.evaluate(t=>{CityHallStudy.seekAmbient(t);CityHallStudy.app.draw();return {...CityHallStudy.renderer.street.out};},t);report.poses.push({t,...pose});await p.screenshot({path:`work/cityhall-paper/street-life/route-${t}.png`});}
 check('48-second route returns exactly to its original pose',JSON.stringify(report.poses[0]).replace('"t":0','"t":48')===JSON.stringify(report.poses.at(-1)));
 check('courier pauses to consult the civic noticeboard',report.poses.find(p=>p.t===24).action==='read');
 report.warm=await p.evaluate(()=>{const S=CityHallStudy,r=S.renderer,before={...r.resources()},old=document.createElement;let created=0;document.createElement=function(name,...args){if(name==='canvas')created++;return old.call(this,name,...args);};try{for(let i=0;i<480;i++){S.seekAmbient(i/10);S.app.draw();}}finally{document.createElement=old;}return{before,after:{...r.resources()},created};});
 check('complete warm route creates zero canvases',report.warm.created===0);check('retained backing census remains stable',JSON.stringify(report.warm.before)===JSON.stringify(report.warm.after));
 check('both fixture layers and their owner are released',await p.evaluate(()=>{const r=CityHallStudy.renderer,layers=r.street.layers.slice();CityHallStudy.dispose();return r.street===null&&layers.every(l=>l.canvas.width===0&&l.canvas.height===0)&&r.resources().buffers===0;}));
 check('no browser errors',report.errors.length===0);
}finally{fs.writeFileSync('work/cityhall-paper/street-life/street-report.json',JSON.stringify(report,null,2)+'\n');await b.close();}console.log(JSON.stringify(report));
})().catch(e=>{console.error(e);process.exitCode=1;});
