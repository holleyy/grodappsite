# SDD ledger — plan: studies/cityhall-paper/street-life/plan.md

Baseline: source 1dbd64bf; runtime1610cfe14171c5a07d00f3cc88954c0361b826741593327c180758a1853652fe.
Existing isolated codex/cityhall-paper-fidelity checkout; only work/ untracked.
The user's approval includes the previously authorised additive grodappsite
publication. Canonical/native/shared files and source-repository remote remain
read-only. Owned study paths contain the plan, ledger and evidence.

Pre-flight: fixture registrations feed prepared layers; pavement bounds support
the courier sampler; renderer census/disposal must own the two new layers.
Original indoor actors and the board are independent and remain unchanged.
The bicycle asset agent completed; the noticeboard agent is creating the second
complete asset. Both use Astra as requested. Implementation remains inline.

Task 1 complete: motion/registration tests first failed with the missing module;
then passed. Full loop sampled at 100Hz remains continuous, on z−12 pavement,
and clear of both fixtures. Motion-off and chapter states hold still. Connected
support check covers all four neighbouring buildings and both fixtures.

Task 2 complete: two full native assets retained and registered by their ground
contacts with upright verticals. Connected paving is baked once; kerbs occur at
outer edges, with the arrival opening clear. Retained planting now uses loose
clusters and varied heights. Original worker poses provide the quiet courier.
No canonical camera, gameplay, art or storage keys changed.

Task 3 verification: 43 focused tests, 72 gameplay checks with 15 actual wins,
26 qualification checks, 44 phone checks, 6 street checks pass. Complete 480-draw
route creates zero canvases and holds 55 buffers/13 bakes. The two fixture layers
add 1,404,000 owned backing bytes; this excludes decoded images and browser/GPU
memory. Disposal releases their buffers and owner. Tree crown remains
11,259/11,259 visible samples. Matched before/after views use the same camera;
the Wider square evidence view is panned/zoomed to include the full garden and
postal corner without altering the game's camera defaults.

Fresh Astra whole-checkpoint review is in progress. Native PNGs and actual
renderer recordings remain retained alongside the evidence; no scratch cleanup
will remove review material.

Final review complete: fresh Astra reports no Critical, Important or actionable
Minor findings. It reviewed code, retained asset hashes, route/phone/square
captures and completed test reports; no independent video replay or suite rerun
is claimed. No source fix or additional reviewer required. All intended overlap
states are on the authored route in front of both fixtures.
