# City Hall street life

The user approved the next checkpoint: a postal arrival area with a delivery
bicycle and civic noticeboard, connected pavements around the neighbouring
buildings, less repeated planting and one restrained outdoor activity. Keep
the selected grand hall, camera, board, full-height phone host and game rules.

1. Preserve the civic-garden runtime and matched captures. Specify a grounded,
   deterministic courier route with a quiet stop to consult the noticeboard.
   Prove support, continuity, frozen motion and fixture registration in tests.
2. Integrate two complete Astra-directed original assets, prepare connected
   pavements and fixture layers once, and vary the retained garden planting.
   Reuse the original worker poses. Keep every live draw allocation-free.
3. Inspect whole scene, arrival detail, phone and grayscale in Chromium; verify
   board rasters, protected inputs, gameplay, lifecycle and a complete route.
   Obtain one fresh Astra review of the whole checkpoint and fix blockers.
4. Publish an additive street-life child to the already authorised grodappsite
   review, retaining every existing public file, with evidence and source.

Review focus: tyre/post grounding and scale; actor/fixture depth throughout the
loop; no obstacle across the arrival route; readable board in full-height phone
views; retained canvas accounting, disposal and no warm canvas allocation.

Swift/Metal mapping: pavement and fixture bounds become static world geometry;
original complete sprites retain two measured ground contacts; deterministic
48-second actor sampling maps to a small value struct and prepared draw layers.
