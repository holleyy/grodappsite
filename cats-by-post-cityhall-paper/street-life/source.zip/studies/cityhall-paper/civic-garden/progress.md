# Ledger — plan: studies/cityhall-paper/civic-garden/plan.md

Ruling: this is a requested refinement within the approved scene direction,
not a new concept selection. Existing authorisation covers implementation and
an isolated new public checkpoint; no repeated approval gate is needed.
Ruling: use the existing owned worktree and study/evidence folders. Preserve
all earlier review material. Measured world geometry and retained full art
remain the approved renderer approach.
Pre-flight: the east tree is outside x228 but previously painted behind the
hall; foreground layer bounds must also contain the new gardens. Planting
shares the existing arrival path and retained front tree root contact.
Task1: preserved runtime4e9ae07e. Capturing before and canopy regression.
Task1 complete: actual-renderer crown test failed at42.046% visible, then
passed at100% (11259 samples). Near trees sort with foreground civic items.
Task2 complete: two grounded low beds, retained front tree, mixed original
flowers/new full shrub artwork, one bench and warm staggered stone setts.
Route/support regression failed before beds existed, then all7 affected cases
passed. Foreground bounds grow50 world units to include the entire planting.
Task3 complete:39 focused,72 browser,26 qualification and44 phone checks pass;
all15 deliveries win; all195 protected files,238 inputs and three board rasters
are exact. Fresh Astra review found no Critical/Important/actionable Minor
issues. Independent120 warm draws create no canvases; disposal releases all.
Task4: prepare isolated civic-garden public child with22 matched captures,
actual32-second motion, source and receipts. Preserve prior public files.
Task4 complete, 16 November2026: source d6d3a0a1, runtime1610cfe1;
public packet c1def520, PR7 merged at e97fd60e. Pages43780279682 succeeded.
All 2487 prior entries are exact; 44 additions belong only to civic-garden.
All 43 merged payload hashes and 26 public packet browser checks pass.
Deployment is qualified by the exact local Chromium packet, merged Git payload
and successful Pages workflow; direct live-host browsing remains unqualified.
Receipt: docs/review-images/cityhall-paper/civic-garden/deployment.json.
