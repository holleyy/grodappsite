# Ledger — plan: studies/cityhall-paper/phone-and-light/plan.md

Pre-flight: camera receives the complete canvas dimensions plus control-safe
insets; backdrop must cover the resulting view at every supported zoom. Source
and public ownership remain scoped as in prior checkpoints.

Ruling: use the existing owned checkout and studies/work folders for the ledger
and evidence, preserving prior evidence. Shared production UI is read-only;
the user authorised its footprint in the review, not a shared UI replacement.
Ruling: retain the project's actual world geometry and generated material art.
This is an approved game-scene refinement, not a new generic webpage scaffold.
Task1: measuring production UI and capturing baseline.
Task1: full-height phone canvas and production-sized 167 px working tray are
implemented. Header/queue measurements come from the tracked production page
in isolated Chromium; its missing sparse-checkout engine/assets were served
read-only from Git objects. An ephemeral test profile unlocks only6-15 for
measurement; user saves and production sources are untouched.
Camera-safe-region test failed, then passed after inset-aware fitting. Its new
pinch regression exposed centre drift and passed after using the same inset
centre. All7 affected camera/input/geometry tests pass. Browser full-height
check failed at374×438, then passed at390×844.
Task2: baseline scenery preserved in corrected framing; extending coverage and
composing the arrival foreground, followed by receiving light/shadows.
Task2 complete: generated full sky stock and world-phase paving cover minimum
zoom; connected stone approach and soft receiving light are prepared once.
Eleven matched views retain identical controls/cameras/time. A separate old
phone capture shows the earlier restricted scene rectangle.
Task3: camera/pinch, coverage and phone behaviour regressions passed RED→GREEN.
The phone checks caught queue wrapping, text overflow, modal key leakage,
chapter clearance and hidden legacy-fit recursion. The owned adapter bypasses
that unused fit only while active, restoring it on unmount/other rooms.
Task3 review: one fresh Astra whole-checkpoint review, no Critical/Important
findings. Two Minor restoration defects were reproduced, then corrected:
original queue sources restore on rotation/disposal; rotation with open tools
returns focus to the visible selector. No second independent review claimed.
Task4: prepare full-resolution gallery, actual motion, exact source/asset
receipts and add-only public child. Prior checkpoints stay intact.
Task4 complete,16 November2026: source869594a6, runtime4e9ae07e;
public packet663e6bab, PR6 merged atd476e940. Pages43777625182 completed
successfully. All2441 previous entries and all45 payload hashes are exact;
46 additions belong only to the new prefix. All27 packet browser checks pass.
A final320×568 DPR2 initial/saved-finale reload passes without browser errors.
The environment proxy blocks direct Pages HTTP; deployment is qualified by
exact local Chromium packet, remote merged payload and successful workflow.
Publication receipt: docs/review-images/cityhall-paper/phone-and-light/deployment.json.
