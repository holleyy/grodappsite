const test=require('node:test'),assert=require('node:assert/strict'),C=require('../src/fidelity/cityhall-paper/civic-square'),E=require('../src/fidelity/cityhall-paper/environment'),D=require('../src/fidelity/cityhall-paper/daylight');
const overlap=(a,b)=>a.x0<b.x1&&a.x1>b.x0&&a.y0<b.y1&&a.y1>b.y0;
test('planted beds and seating leave the whole connected arrival route unobstructed',()=>{
 const c=C.layout(),e=E.layout(),route=[e.approach,...e.steps,...D.layout().walk];assert.equal(c.gardens.length,2);
 for(const b of [...c.gardens,...c.benches])for(const path of route)assert.ok(!overlap({x0:b.x0-2,x1:b.x1+2,y0:b.y0-2,y1:b.y1+2},path),b.id+' blocks '+(path.id||'walk'));
 const tree=e.trees.find(b=>b.id==='square-tree-front'),bed=c.gardens.find(b=>overlap(b,tree));assert.ok(bed&&tree.x0>bed.x0&&tree.x1<bed.x1&&tree.y0>bed.y0&&tree.y1<bed.y1);
 for(const s of c.shrubs){const bed=c.gardens.find(b=>s.x0>b.x0&&s.x1<b.x1&&s.y0>b.y0&&s.y1<b.y1);assert.ok(bed,s.id+' unsupported');assert.equal(s.z0,-11.2);assert.ok(s.z1<=8,'planting obstructs the entrance');}
});
