const test=require('node:test'),assert=require('node:assert/strict'),S=require('../src/fidelity/cityhall-paper/street-life');
test('courier loop is continuous, grounded, clear of fixtures and supported by the postal pavement',()=>{
 const out=S.makeOut(),p=S.layout().postalBay,fixtures=S.layout().fixtures;let last=null;
 for(let i=0;i<=4800;i++){
  assert.equal(S.sample(i/100,null,out,true),out);assert.equal(out.z,-12);
  assert.ok(out.x-4>=p.x0&&out.x+4<=p.x1&&out.y-4>=p.y0&&out.y+4<=p.y1,'feet leave pavement');
  for(const b of fixtures)assert.ok(out.x+4<b.x0||out.x-4>b.x1||out.y+4<b.y0||out.y-4>b.y1,'courier intersects '+b.id);
  if(last)assert.ok(Math.hypot(out.x-last.x,out.y-last.y)<.1,'route jumps');last={x:out.x,y:out.y};
 }
 const a=S.sample(0,null,S.makeOut()),b=S.sample(48,null,S.makeOut());assert.deepEqual(a,b);
 assert.equal(S.sample(24,null,out).action,'read');
});
test('motion off and chapter presentations hold a quiet stationary courier',()=>{
 const rest=S.sample(0,null,S.makeOut(),false),out=S.makeOut();
 for(const time of [0,9,17,24,38,47,60]){assert.deepEqual(S.sample(time,null,out,false),rest);assert.deepEqual(S.sample(time,{mode:'enter'},out,true),rest);}
});
test('two-contact registration grounds both feet without tilting verticals',()=>{
 const source=[[521,664],[1260,933]],target=[[68,252],[98,267]],m=S.registration(source,target);
 for(let i=0;i<2;i++){const [x,y]=source[i];assert.ok(Math.abs(m[0]*x+m[2]*y+m[4]-target[i][0])<1e-9);assert.ok(Math.abs(m[1]*x+m[3]*y+m[5]-target[i][1])<1e-9);}
 assert.equal(m[2],0);assert.ok(m[0]>0&&m[3]>0);
});
test('every neighbouring building and postal fixture has a connected receiving pavement',()=>{
 const {footways,fixtures}=S.layout(),buildings=require('../src/fidelity/cityhall-paper/environment').layout().buildings;
 const contains=(p,b)=>p.x0<=b.x0&&p.x1>=b.x1&&p.y0<=b.y0&&p.y1>=b.y1;
 for(const b of [...buildings,...fixtures])assert.ok(footways.some(p=>contains(p,b)),b.id+' lacks support');
 const reached=new Set([0]);for(let pass=0;pass<footways.length;pass++)for(let i=0;i<footways.length;i++)for(const j of reached){const a=footways[i],b=footways[j],dx=Math.min(a.x1,b.x1)-Math.max(a.x0,b.x0),dy=Math.min(a.y1,b.y1)-Math.max(a.y0,b.y0);if(dx>=0&&dy>=0&&(dx>0||dy>0))reached.add(i);}
 assert.equal(reached.size,footways.length,'an apron is isolated from the hall');
});
