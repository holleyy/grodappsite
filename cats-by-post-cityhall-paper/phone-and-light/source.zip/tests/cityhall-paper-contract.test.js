const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const file=path.join(__dirname,'../src/fidelity/cityhall-paper/adapter.js');
const {levels}=require('../src/data/levels');
function api(){assert.ok(fs.existsSync(file),'City Hall presentation adapter exists');return require(file);}
function fixture(){
 const state={level:levels.find(l=>l.id==='6-1'),turns:[],traces:[],gateTrace:null,time:0,sceneTime:1,mode:'edit',originX:64,originY:64,selected:null,partner:null,gray:false,motion:true,chapter:{mode:'none',frame:0,stage:0,demo:null,growth:null,dispatch:null}};
 let installed=null,disposed=0,listeners=0;
 const renderer={load:async()=>{},prepare(){},draw(){},dispose(){disposed++;},resources(){return {bytes:0};}};
 const host={read(out){Object.assign(out,state);return out;},viewport:{width:800,height:600,dpr:1,view:'hall'},renderer,check(){},install(value){installed=value;return()=>{installed=null;};},subscribe(){listeners++;return()=>{listeners--;};}};
 return {host,state,get installed(){return installed;},get disposed(){return disposed;},get listeners(){return listeners;}};
}
test('read-only capture reuses its frame and retains exact canonical payloads',async()=>{
 const f=fixture(),original=JSON.stringify(f.state),a=api().createCityHallPaper(f.host);
 await a.mount();const first=a.capture();for(let i=0;i<50;i++)assert.equal(a.capture(),first);
 assert.equal(first.level,f.state.level);assert.equal(first.turns,f.state.turns);assert.equal(first.traces,f.state.traces);
 assert.equal(JSON.stringify(f.state),original);a.dispose();
});
test('dispose reverses installation and listeners exactly once',async()=>{
 const f=fixture(),a=api().createCityHallPaper(f.host);await a.mount();assert.ok(f.installed);assert.equal(f.listeners,1);
 a.dispose();a.dispose();assert.equal(f.installed,null);assert.equal(f.listeners,0);assert.equal(f.disposed,1);
 assert.equal(a.resources().bytes,0);assert.equal(a.capture(),null);
});
test('a cancelled load never installs stale output',async()=>{
 const f=fixture();let finish;f.host.renderer.load=()=>new Promise(r=>{finish=r;});
 const a=api().createCityHallPaper(f.host),pending=a.mount();a.dispose();finish();await pending;
 assert.equal(f.installed,null);assert.equal(f.listeners,0);assert.equal(f.disposed,1);
});
test('failed loading releases its renderer without hiding the error',async()=>{
 const f=fixture();f.host.renderer.load=async()=>{throw Error('bad artwork');};const a=api().createCityHallPaper(f.host);
 await assert.rejects(a.mount(),/bad artwork/);assert.equal(f.disposed,1);assert.equal(f.installed,null);
});
