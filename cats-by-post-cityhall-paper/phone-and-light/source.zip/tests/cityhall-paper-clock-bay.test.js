const test=require('node:test'),assert=require('node:assert/strict');
test('clock-bay pipe casings leave the occupied gallery route clear',()=>{
 const b=require('../src/fidelity/cityhall-paper/clock-bay').layout(),r=require('../src/fidelity/cityhall-paper/layout').create().routes.find(r=>r.id==='worker-back');
 // Conservative 6-unit wide, 36-unit high swept worker envelope.
 const y=r.points[0][1],z=r.points[0][2];
 for(const path of b.pipes)for(const point of path)assert.ok(point[1]+b.pipeRadius<y-3||point[2]-b.pipeRadius>z+36,'pipe intrudes into the gallery worker');
 for(const lamp of b.lamps)assert.ok(lamp.y+2.5<y-3||lamp.y-2.5>y+3||lamp.z-1.5>z+36,'lantern intersects the retained worker silhouette');
 for(const mount of b.mounts)assert.ok(mount.y1<y-3||mount.z0>z+36,'wall mount intrudes into the gallery worker');
});
test('clock has a receiving wall and clears the adjacent window and gallery floor',()=>{
 const b=require('../src/fidelity/cityhall-paper/clock-bay').layout(),c=b.clock;
 assert.ok(c.x-c.width/2>115&&c.x+c.width/2<176);
 assert.ok(c.z-c.height/2>46+20&&c.z+c.height/2<133);
 assert.ok(c.y>8&&c.y<12,'clock mounts in front of rear columns, behind gallery walk');
});
