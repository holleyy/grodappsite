const test=require('node:test'),assert=require('node:assert/strict');
function input(){return require('../src/fidelity/cityhall-paper/input');}
test('resize/view cancellation never places a queued pointer-up on a new board',()=>{
 const v={width:400,height:600,zoom:1,panX:0,panY:0};let taps=0;const g=input().create(v,()=>taps++,()=>{},()=>{});
 g.down(1,100,100);g.cancel();g.up(1,100,100);assert.equal(taps,0);g.down(2,100,100);g.up(2,100,100);assert.equal(taps,1);
});
test('drag and two-finger zoom preserve the pinch centre and never place an arrow',()=>{
 const v={width:400,height:600,zoom:1,panX:0,panY:0};let taps=0;const g=input().create(v,()=>taps++,()=>{},()=>{});
 g.down(1,100,200);g.down(2,200,200);g.move(2,300,200);assert.equal(v.zoom,2);assert.equal(v.panX,100);assert.equal(v.panY,100);
 g.up(2,300,200);g.up(1,100,200);assert.equal(taps,0);g.down(3,40,40);g.move(3,80,60);g.up(3,80,60);assert.equal(taps,0);assert.equal(v.panX,140);
});
