const test=require('node:test'),assert=require('node:assert/strict');
const V=require('../src/fidelity/cityhall-paper/vault-and-walls'),C=require('../src/fidelity/cityhall-paper/clock-bay'),L=require('../src/fidelity/cityhall-paper/layout').create();
const overlaps=(a,b)=>['x','y','z'].every(k=>a[k+'0']<b[k+'1']&&a[k+'1']>b[k+'0']);
const extent=(a,b,r=0)=>Object.fromEntries(['x','y','z'].flatMap((k,i)=>[[k+'0',Math.min(a[i],b[i])-r],[k+'1',Math.max(a[i],b[i])+r]]));
test('service pipe has a receiving case and connects exactly to the retained clock network',()=>{
 const a=V.layout(),start=a.pipe[0],end=a.pipe.at(-1);
 for(const [i,k]of ['x','y','z'].entries())assert.ok(start[i]>a.service[k+'0']&&start[i]<a.service[k+'1']);
 assert.deepEqual(end,C.layout().pipes[0][0]);
 for(let i=1;i<a.pipe.length;i++)assert.equal(a.pipe[i].filter((v,k)=>v!==a.pipe[i-1][k]).length,1,'pipe segment must follow one world axis');
});
test('entire pipe segments, case and lanterns clear both occupied gallery sweeps',()=>{
 const a=V.layout();
 for(const id of ['worker-left','worker-back']){
  const route=L.routes.find(v=>v.id===id);assert.ok(route,id);
  const box=Object.fromEntries(['x','y','z'].flatMap((k,i)=>[[k+'0',Math.min(...route.points.map(p=>p[i]))],[k+'1',Math.max(...route.points.map(p=>p[i]))]]));box.x0-=3;box.x1+=3;box.y0-=3;box.y1+=3;box.z1+=36;
  for(let i=1;i<a.pipe.length;i++)assert.ok(!overlaps(box,extent(a.pipe[i-1],a.pipe[i],a.pipeRadius)),id+' pipe segment '+i);
  assert.ok(!overlaps(box,a.service),id+' service case');
  for(const lamp of a.lamps)assert.ok(lamp.z-1.5>box.z1,'complete lantern must clear worker head');
  for(const m of a.mounts)assert.ok(m.z-2>box.z1,'pipe mounts clear worker head');
 }
});
test('gallery support feet leave the existing desk and waiting bench clear',()=>{
 const civic=require('../src/fidelity/cityhall-paper/civic-square').layout();
 for(const foot of V.layout().supportFeet){
  assert.ok(!overlaps(foot,civic.desk));assert.ok(!overlaps(foot,civic.indoorSeat));
 }
});
