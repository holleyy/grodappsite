const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {levels}=require('../src/data/levels');
const hall=levels.filter(l=>/^6-/.test(l.id)),views=[[1440,1000],[390,844],[402,874],[844,390],[1024,600]];
function modules(){for(const n of ['projection','layout'])assert.ok(fs.existsSync(require('node:path').join(__dirname,'../src/fidelity/cityhall-paper/'+n+'.js')),n+' exists');return {P:require('../src/fidelity/cityhall-paper/projection'),L:require('../src/fidelity/cityhall-paper/layout').create()};}
test('the board plane is exactly 2:1 and has an inverse at every height',()=>{
 const {P}=modules();for(let x=-64;x<256;x+=13)for(let y=-64;y<256;y+=17)for(const z of [0,46,138,180]){
  const p=P.project(x,y,z),q=P.unproject(p.x,p.y,z);assert.equal(q.x,x);assert.equal(q.y,y);
 }
 const a=P.project(0,0),b=P.project(16,0),c=P.project(0,16);assert.equal((b.y-a.y)/(b.x-a.x),.5);assert.equal((c.y-a.y)/(c.x-a.x),-.5);
});
test('all fifteen board centres and boundaries pick exactly through every camera and DPR',()=>{
 const {P,L}=modules();for(const level of hall)for(const [width,height]of views)for(const dpr of [1,2])for(const view of ['hall','play']){
  const board={x:64+(level.board.roomX||0)*16,y:64+(level.board.roomY||0)*16,w:level.board.w,h:level.board.h};
  const cam=P.camera({width,height,dpr,view,zoom:1},L,board);
  for(let y=0;y<board.h;y++)for(let x=0;x<board.w;x++){
   const p=P.project(board.x+x*16+8,board.y+y*16+8),sx=p.x*cam.scale+cam.tx,sy=p.y*cam.scale+cam.ty;
   assert.deepEqual(P.pick(sx,sy,board,cam),{x,y});assert.ok(sx>=0&&sx<=width&&sy>=0&&sy<=height);
  }
  for(const [x,y]of [[-.001,4],[board.w*16+.001,4],[4,-.001],[4,board.h*16+.001]]){const p=P.project(board.x+x,board.y+y);assert.equal(P.pick(p.x*cam.scale+cam.tx,p.y*cam.scale+cam.ty,board,cam),null);}
 }
});
test('stairs join a supported landing, every vault rib seats on beams and furniture clears the maximum board',()=>{
 const {L}=modules();assert.equal(L.vault.spring,138);assert.equal(L.vault.crown,180);
 const s=L.stairs;assert.equal(s.steps[0].z0,0);assert.equal(s.steps.at(-1).z1,L.gallery.z);assert.equal(s.steps.at(-1).y0,s.landing.y1);
 for(let i=1;i<s.steps.length;i++)assert.equal(s.steps[i].z0,s.steps[i-1].z1);
 assert.ok(s.approach.y0>=s.steps[0].y1);assert.equal(s.landing.z1,L.gallery.z);
 for(const rib of L.vault.ribs)for(const end of [rib[0],rib.at(-1)])assert.ok(L.vault.beams.some(b=>end[0]>=b.x0&&end[0]<=b.x1&&end[1]>=b.y0&&end[1]<=b.y1&&end[2]===b.z1),'rib floating');
 for(const col of L.columns){assert.equal(col.z0,0);assert.equal(col.z1,L.vault.spring);}
 for(const b of L.solids)assert.ok(b.x1<=64||b.x0>=192||b.y1<=64||b.y0>=160,'solid intersects tile cores: '+b.id);
 for(const r of L.routes)for(const p of r.points)assert.ok(p[0]<64||p[0]>192||p[1]<64||p[1]>160,'ambient route enters board');
});
