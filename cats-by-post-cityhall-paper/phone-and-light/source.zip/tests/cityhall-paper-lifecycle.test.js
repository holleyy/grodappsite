const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
function Renderer(){const context={CityHallProjection:require('../src/fidelity/cityhall-paper/projection')};context.globalThis=context;vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../src/fidelity/cityhall-paper/renderer.js'),'utf8'),context);return context.CityHallRenderer;}
test('renderer disposal releases every live owner, actor cache and retained image',()=>{
 const R=Renderer(),canvas={width:100,height:100},cached={width:20,height:30};let actorClosed=0;
 // Exercise disposal of actual resource fields without introducing a fake DOM
 // or Canvas implementation. Browser tests separately cover real construction.
 const r=Object.create(R.prototype);Object.assign(r,{closed:false,ready:true,images:{worker:{}},canvas,exterior:{canvas:cached},architecture:null,foreground:null,boardLayers:new Map(),carriers:{carriers:[]},actors:{dispose(){actorClosed++;}},traces:[{}],traceViews:[{}],traceSources:[{}],resourcesRecord:{bytes:42400,buffers:2}});
 r.dispose();r.dispose();assert.equal(actorClosed,1);assert.equal(r.actors,null);assert.equal(Object.keys(r.images).length,0);assert.equal(cached.width,0);assert.equal(canvas.height,0);assert.equal(r.resources().bytes,0);assert.equal(r.traceSources.length,0);
});
test('actor disposal zeros its prepared layers and never prepares replacement caches',()=>{
 const ctx={CityHallProjection:require('../src/fidelity/cityhall-paper/projection')};ctx.globalThis=ctx;vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../src/fidelity/cityhall-paper/actors.js'),'utf8'),ctx);
 const a=Object.create(ctx.CityHallActors.prototype),cart={width:176,height:176},parcel={width:64,height:48};Object.assign(a,{pigeon:{width:128,height:96},cart:{canvas:cart},parcel:{canvas:parcel},workerImages:{1:{}},baseImages:{1:{}},rigs:{1:{}},r:{}});
 a.dispose();assert.equal(cart.width,0);assert.equal(parcel.height,0);assert.equal(a.r,null);assert.equal(Object.keys(a.workerImages).length,0);
});
