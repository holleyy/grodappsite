const test=require('node:test'),assert=require('node:assert/strict');
const P=require('../src/fidelity/cityhall-paper/projection'),L=require('../src/fidelity/cityhall-paper/layout').create();
test('full-canvas camera keeps every board corner inside the control-safe rectangle',()=>{
 for(const [width,height,top,bottom]of [[390,844,152,178],[430,932,199,212],[320,568,144,170],[844,390,70,20]])for(const [w,h]of [[7,5],[7,6],[8,6]]){
  const right=width>height?240:12,insets={top,bottom,left:12,right},b={x:64,y:64,w,h};
  const c=P.camera({width,height,zoom:1,view:'play',insets},L,b);
  for(const x of [0,w*16])for(const y of [0,h*16]){
   const p=P.project(b.x+x,b.y+y),sx=p.x*c.scale+c.tx,sy=p.y*c.scale+c.ty;
   assert.ok(sx>=12&&sx<=width-right,'board enters side controls');
   assert.ok(sy>=top&&sy<=height-bottom,'board enters header/dock');
  }
 }
});
test('pinch retains its world anchor when controls shift the camera centre',()=>{
 const v={width:390,height:844,zoom:1,view:'play',panX:0,panY:0,insets:{top:190,bottom:170,left:12,right:12}},b={x:64,y:64,w:8,h:6};
 const c=P.camera(v,L,b),world=P.unproject((180-c.tx)/c.scale,(400-c.ty)/c.scale);
 const g=require('../src/fidelity/cityhall-paper/input').create(v,()=>{},()=>{},()=>{});
 g.down(1,130,400);g.down(2,230,400);g.move(2,330,400);
 const after=P.camera(v,L,b),q=P.project(world.x,world.y);
 assert.ok(Math.abs(q.x*after.scale+after.tx-230)<1e-9);
 assert.ok(Math.abs(q.y*after.scale+after.ty-400)<1e-9);
});
test('daylight shadows land on their receiver and the new walk meets the existing arrival',()=>{
 const fs=require('node:fs'),file=require('node:path').join(__dirname,'../src/fidelity/cityhall-paper/daylight.js');assert.ok(fs.existsSync(file),'measured daylight and approach module exists');
 const D=require(file),e=require('../src/fidelity/cityhall-paper/environment').layout(),s=D.layout();
 assert.deepEqual(D.shadowPoint([14,25,-12],-12),[14,25,-12]);
 const low=D.shadowPoint([14,25,0],-12),high=D.shadowPoint([14,25,12],-12);
 assert.equal(high[2],-12);assert.ok(Math.abs(high[0]-14-2*(low[0]-14))<1e-9);assert.ok(Math.abs(high[1]-25-2*(low[1]-25))<1e-9);
 const a=s.walk[0],b=s.walk[1];assert.equal(a.y0,e.approach.y1);assert.equal(a.x0,e.approach.x0);assert.equal(a.x1,e.approach.x1);assert.equal(a.z,e.ground);assert.equal(a.x1,b.x0);assert.equal(a.y1,b.y1);assert.equal(b.z,e.ground);
 for(const p of s.walk)assert.ok(p.y0>=e.pavement.y1,'walk alters existing hall or receiving steps');
});
