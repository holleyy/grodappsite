const test=require('node:test'),assert=require('node:assert/strict');
const L=require('../src/fidelity/cityhall-paper/layout').create();
test('sorting props sit on the worktop and keep the service pipe and floor aisle clear',()=>{
 const s=require('../src/fidelity/cityhall-paper/sorting-floor').layout();
 for(const p of s.props){assert.equal(p.z,s.counter.z1);assert.ok(p.x-p.radius>s.counter.x0&&p.x+p.radius<s.counter.x1);assert.ok(p.y-p.radius>=35&&p.y+p.radius<s.counter.y1);}
 assert.ok(s.counter.y1<49,'counter enters the worker circulation aisle');
});
test('new palm clears the gallery slab, full board and moving trolley envelope',()=>{
 const s=require('../src/fidelity/cityhall-paper/sorting-floor').layout(),p=s.palm;
 assert.ok(p.y0>23.5&&p.x0>199&&p.z1<43.7,'palm enters gallery, board or trolley sweep');assert.equal(p.z0,0);
 const m=L.furniture.find(v=>v.id==='palm-back');assert.deepEqual(m,{id:'palm-back',...p});
});
test('shelving contents meet shelf surfaces and remain inside their compartments',()=>{
 const s=require('../src/fidelity/cityhall-paper/sorting-floor').layout();
 for(const v of s.contents){const shelf=s.shelves[v.row];assert.equal(v.z0,shelf.z1);assert.ok(v.z1<=shelf.z1+7);assert.ok(v.y0>=s.cabinet.y1-s.cabinet.cavityDepth&&v.y1<=s.cabinet.y1);assert.ok(v.x0>s.cabinet.x0&&v.x1<s.cabinet.x1);}
});
