const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const H=require('../src/sim/19i_cityhall'),layout=require('../src/fidelity/cityhall-paper/layout').create();
function motion(){const p=path.join(__dirname,'../src/fidelity/cityhall-paper/motion.js');assert.ok(fs.existsSync(p),'room motion exists');return require(p).create(H,layout);}
test('canonical staff routes sample smoothly with fixed floor contacts and reused outputs',()=>{
 const m=motion(),o=m.makeOut(),staff=o.workers.slice(),s=H.create(H.CFG);let last=m.makeOut();
 for(let f=0;f<=2880;f+=.5){assert.equal(m.sample(f/60,null,o),o);H.step(s,f);
  for(let i=0;i<3;i++){const a=o.workers[i];assert.equal(a,staff[i]);assert.equal(a.z,i?46:0);assert.ok(a.x<64||a.x>192||a.y<64||a.y>160);if(f)assert.ok(Math.hypot(a.x-last.workers[i].x,a.y-last.workers[i].y)<1,'route discontinuity');}
  for(let i=0;i<3;i++)Object.assign(last.workers[i],o.workers[i]);
 }
 const a=m.makeOut(),b=m.makeOut();m.sample(0,null,a);m.sample(48,null,b);assert.deepEqual(a.workers,b.workers);
});
test('one ambient cat leaves an empty bench and retains rig dimensions through every pose',()=>{
 const m=motion(),o=m.makeOut();let outing=0,rest=0;
 for(let t=0;t<48;t+=.025){m.sample(t,null,o);assert.equal(o.cat.length,13);assert.equal(o.cat.height,9);assert.equal(o.cat.count,1);assert.equal(o.cat.restVisible,!o.cat.away);assert.ok(o.cat.x<64&&o.cat.y>160);if(o.cat.away)outing++;else rest++;}
 assert.ok(outing>0&&rest>0);
});
test('reduced motion stays supported and does not rewrite the supplied chapter clock',()=>{
 const m=motion(),o=m.makeOut(),chapter={mode:'growth',frame:124,stage:1,growth:{x:120,y:132,z:0,face:1,walk:2}};const before=JSON.stringify(chapter);
 m.sample(21,chapter,o,false);assert.equal(o.workers[0].z,0);assert.equal(o.workers[0].walk,-1);assert.equal(o.cat.z,6);assert.equal(JSON.stringify(chapter),before);
});
test('one parcel has continuous ownership and a real grip; trolley wheels follow travelled distance',()=>{
 const m=motion(),o=m.makeOut();let previous=null,rolling=0,held=0;
 for(let frame=0;frame<=2880;frame++){
  m.sample(frame/60,null,o);const p=o.parcel,t=o.trolley,w=o.workers[0];
  assert.deepEqual([p.w,p.d,p.h],[7,5,5]);assert.equal(p.count,1);assert.ok(['left-cart','right-cart','worker'].includes(p.owner));
  if(previous)assert.ok(Math.hypot(p.x-previous.x,p.y-previous.y,p.z-previous.z)<1,'parcel jumped during transfer');
  if(p.owner==='worker'){held++;assert.ok(w.grip);assert.deepEqual([w.grip.x,w.grip.y,w.grip.z],[p.x+3.5,p.y+2.5,p.z+5]);}
  if(p.owner==='right-cart')assert.deepEqual([p.x,p.y,p.z],[t.x,t.y,20]);
  if(t.distance){rolling++;assert.ok(w.push);assert.equal(t.angle,t.distance/2);assert.equal(w.grip.x,t.x-4);assert.equal(w.grip.y,t.y+7);assert.equal(w.grip.z,16);}
  assert.ok(t.y+8<64,'trolley entered the board');previous={x:p.x,y:p.y,z:p.z};
 }
 assert.ok(rolling>100&&held>1000);
});
