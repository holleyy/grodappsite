const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const R=require('../src/sim/10_rules'),BA=require('../src/sim/12_boardanim'),{levels}=require('../src/data/levels'),{level}=require('./fixtures/tunnels');
function acting(){const p=path.join(__dirname,'../src/fidelity/cityhall-paper/acting.js');assert.ok(fs.existsSync(p),'registered acting exists');return require(p).create(BA);}
test('all fifteen authored answers remain legal and win under actual rules',()=>{for(const L of levels.filter(l=>/^6-/.test(l.id))){assert.deepEqual(R.grValidate(L,L.solution),[],L.id);assert.equal(R.grRun(L,L.solution).outcome,R.GO_WON,L.id);}});
test('paper sampling keeps entry and exit local, hidden transit and heading, including reversed bounce entry',()=>{
 const a=acting();for(const L of [level(),level({hatches:[{x:3,y:0,dir:'D',cats:['ginger']}],dogs:[{x:4,y:2}],tunnels:[{a:{x:2,y:2},b:{x:6,y:2},symbol:'triangle'}],baskets:[{x:5,y:2,coat:'ginger'}],solution:[{x:3,y:2,type:'plain',dir:'R'}]})]){
  const tr=BA.makeTrace(100);BA.runRules(R,L,L.solution||[],'ginger',.3,1,tr);const original=JSON.stringify(tr),o=a.makeOut();let tunnels=0,hidden=0;
  for(let k=0;k<tr.n;k++)if(tr.ev[k]===R.GE_TUNNEL){tunnels++;for(let i=0;i<120;i++){
   const f=(i+.5)/120;a.sample(tr,tr.rel+(k+f)*tr.tick,o);assert.equal(o.dir,tr.bn[k]&&f<.15?tr.d0[k]:tr.d1[k]);assert.equal(o.tunnelPair,tr.tunnel[k]);
   if(!o.cat.visible){hidden++;continue;}const ex=tr.entryX[k]*16+8,ey=tr.entryY[k]*16+8,xx=tr.x1[k]*16+8,xy=tr.y1[k]*16+8;
   assert.ok(Math.hypot(o.x-ex,o.y-ey)<=20||Math.hypot(o.x-xx,o.y-xy)<1,'cat flew between endpoints');
  }}assert.ok(tunnels>0&&hidden>0);assert.equal(JSON.stringify(tr),original);
 }
});
test('two simultaneous users retain separate samples rather than overwriting a shared effect',()=>{
 const a=acting(),L=level(),tr=BA.makeTrace(40);BA.runRules(R,L,[],'ginger',.3,1,tr);const one=a.makeOut(),two=a.makeOut();
 a.sample(tr,1.4,one);const before=JSON.stringify(one);a.sample(tr,1.57,two);assert.equal(JSON.stringify(one),before);assert.notEqual(one.tunnelPhase,two.tunnelPhase);
});
test('shared-rule traces cover both directions, opposite simultaneous traffic, blocked exits, re-entry and sequential links',()=>{
 const cases=require('./fixtures/tunnel-cases'),a=acting();let opposite=0,hidden=0;
 for(const example of cases){const L=example.level,s=R.grCreate(L,L.solution||[]),traces=Array.from({length:s.n},(_,i)=>{const t=BA.makeTrace(100);t.tick=t.pop=.3;t.coat=s.coat[i];return t;});
  while(s.outcome===R.GO_RUNNING){const time=(s.tick+1)*.3;R.grTick(s);for(let i=0;i<s.n;i++){const t=traces[i];if(s.ev[i]===R.GE_RELEASED)t.rel=time;else if(s.ev[i]>=R.GE_MOVED){BA.record(t,s.px[i],s.py[i],s.pdir[i],s.x[i],s.y[i],s.dir[i],s.ev[i],s.bounced[i]);BA.recordDestination(t,s,i);}}}
  const outputs=traces.map(()=>a.makeOut());
  for(let i=0;i<traces.length;i++){const t=traces[i],o=outputs[i];for(let k=0;k<t.n;k++)if(t.ev[k]===R.GE_TUNNEL)for(let j=0;j<60;j++){
   const f=(j+.5)/60,time=t.rel+(k+f)*.3;a.sample(t,time,o);assert.equal(o.tunnelPair,t.tunnel[k]);
   if(!o.cat.visible){hidden++;continue;}
   const entry=Math.hypot(o.x-(t.entryX[k]*16+8),o.y-(t.entryY[k]*16+8)),exit=Math.hypot(o.x-(t.x1[k]*16+8),o.y-(t.y1[k]*16+8));assert.ok(entry<=20||exit<1,example.title);
   if(L.id==='tunnel-opposite'){const other=1-i,before=JSON.stringify(o);a.sample(traces[other],time,outputs[other]);assert.equal(JSON.stringify(o),before);assert.equal(outputs[other].tunnelPair,o.tunnelPair);assert.equal((outputs[other].dir+2)%4,o.dir);opposite++;}
  }}
 }
 assert.ok(opposite>20&&hidden>50);
});
