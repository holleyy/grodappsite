const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const B=require('../src/sim/12_boardanim'),A=require('../src/fidelity/cityhall-paper/acting');
const ctx={BOARDANIM:B,BA:B.A,EDGE_PORTAL_DATA:require('../src/data/edge_portals.json'),TILE:16,TAKEOFF_DX:[1,0,-1,0],TAKEOFF_DY:[0,1,0,-1],clamp:(v,a,b)=>Math.max(a,Math.min(b,v)),lerp:(a,b,t)=>a+(b-a)*t,takeoffQ:v=>Math.round(v*2)/2,takeoffEase:v=>{v=Math.max(0,Math.min(1,v));return v*v*(3-2*v);}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(require.resolve('../src/render/27b_paper_flap.js'),'utf8').split('function buildPaperFlapCat')[0],ctx);
function trace(coat,side,wrong=false){const t=B.makeTrace(2);t.rel=t.tick=.3;t.coat=coat;t.homeKind='flap';t.homeSide=side;t.homeFlap=0;B.record(t,2,2,side,2,2,side,wrong?B.EV_WRONG:B.EV_DELIVERED,0);return t;}
test('owned sampler delegates flap presentation, tail clearance and empty box to the canonical clock',()=>{
 const a=A.create(B,ctx.paperBoardFlapPose),o=a.makeOut();
 for(const coat of [1,2])for(let d=0;d<4;d++)for(const t of [.0,.25,.49,.7,1.1,1.19,1.31,1.61,2.11]){
  const tr=trace(coat,d),now=.6+t,expected=B.makeOut();B.pose(tr,now+1e-9,expected);ctx.paperBoardFlapPose(expected,tr,now+1e-9);a.sample(tr,now,o);
  for(const key of ['flapPose','flapClipSide','flapClipAt','x','y','boxFold','boxX','boxY','anim'])assert.equal(o[key],expected[key],key+' side '+d+' at '+t);
  if(t>=1.19&&t<2.1){assert.equal(o.cat.visible,false);assert.equal(o.box.visible,true,'empty box vanished with the cat');}
  if(t<1.18)assert.equal(o.cat.boxed,false,'passing cat is still boxed');
 }
});
test('wrong flap remains boxed and all pose fields reset after a replay',()=>{
 const a=A.create(B,ctx.paperBoardFlapPose),o=a.makeOut();a.sample(trace(1,1),1.3,o);a.sample(trace(1,1,true),1.3,o);assert.equal(o.flapPose,-1);assert.equal(o.cat.boxed,true);assert.equal(o.box.occupied,true);
});
