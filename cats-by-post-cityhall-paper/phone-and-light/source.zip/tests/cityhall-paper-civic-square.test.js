const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/fidelity/cityhall-paper/civic-square'),L=require('../src/fidelity/cityhall-paper/layout').create(),E=require('../src/fidelity/cityhall-paper/environment').layout();
const overlap=(a,b)=>a.x0<b.x1&&a.x1>b.x0&&a.y0<b.y1&&a.y1>b.y0;
test('postmistress retains her receiving surface while the desk clears the gallery support',()=>{
 const d=C.layout().desk,support={x0:19,y0:112,x1:23,y1:116};
 assert.ok(!overlap(d,support));assert.ok(d.x0<34&&d.x1>34&&d.y0<119&&d.y1>119);assert.equal(d.z1,28);
 assert.deepEqual(L.furniture.find(v=>v.id===d.id),d);assert.ok(d.x1<51,'desk intrudes on worker aisle');
});
test('civic planting and benches leave the hall, fountain and complete arrival approach open',()=>{
 const s=C.layout(),hall={x0:-4,y0:-4,x1:228,y1:218};
 assert.ok(!overlap(E.fountain,hall),'fountain rim enters the hall plinth');
 for(const b of [...s.planters,...s.benches]){
  assert.equal(b.z0,E.ground,b.id+' footing');assert.ok(!overlap(b,hall),b.id+' hall');assert.ok(!overlap(b,E.approach),b.id+' arrival');assert.ok(!overlap(b,E.fountain),b.id+' fountain');
 }
 for(const p of s.planters)for(const b of s.benches)assert.ok(!overlap(p,b),p.id+' seat');
});
test('left palm is below the gallery and outside board, desk and cat walking envelope',()=>{
 const s=C.layout(),p=s.palm,a=s.palmAnchor;
 assert.deepEqual(L.furniture.find(v=>v.id===p.id),p);assert.ok(p.z1<42);assert.ok(p.x1<64&&p.y1<172);assert.ok(!overlap(p,s.desk));
 assert.ok(a.z+(1214-18)/1254*a.height<42,'full retained foliage reaches the gallery slab');
});
test('waiting bench clears the gallery post and keeps the retained cat landing supported',()=>{
 const b=C.layout().indoorSeat,post={x0:19,y0:176,x1:23,y1:180};
 assert.deepEqual(L.furniture.find(v=>v.id===b.id),b);assert.ok(!overlap(b,post));
 assert.ok(31-4.25>=b.x0&&31+4.25<=b.x1&&181-4.25>=b.y0&&181+4.25<=b.y1,'retained nap footprint leaves seat');
 assert.ok(b.y1<190,'bench obstructs cat floor walk');
});
