const test=require('node:test'),assert=require('node:assert/strict');
test('civic forecourt connects the hall plinth to the pavement with continuous steps',()=>{
 const e=require('../src/fidelity/cityhall-paper/environment').layout();
 assert.equal(e.foundation.z0,e.ground);assert.equal(e.foundation.z1,-10);
 const steps=e.steps;assert.equal(steps[0].z1,0);assert.equal(steps[0].y0,194);
 for(let i=1;i<steps.length;i++){assert.equal(steps[i].y0,steps[i-1].y1);assert.equal(steps[i].z1,steps[i-1].z1-2);}
 assert.equal(steps.at(-1).z1-2,e.ground);assert.equal(steps.at(-1).y1,e.approach.y0);
 assert.ok(e.approach.y1<=e.pavement.y1);assert.ok(e.approach.x0>=e.pavement.x0&&e.approach.x1<=e.pavement.x1);
});
test('near town solids rest on their receiving pavement and clear the hall and its approach',()=>{
 const e=require('../src/fidelity/cityhall-paper/environment').layout();
 for(const b of [...e.buildings,...e.trees,...e.lamps,e.fountain]){
  assert.equal(b.z0,e.ground,b.id+' support');
  assert.ok(b.x1<0||b.x0>228||b.y1<0||b.y0>218,b.id+' enters hall or steps');
 }
 for(const t of e.trees)assert.ok(t.x1<e.approach.x0||t.x0>e.approach.x1||t.y1<e.approach.y0||t.y0>e.approach.y1,t.id+' blocks arrival');
});
