/* Deterministic browser-rendered motion samples, deliberately not an FPS test. */
const {chromium}=require('/opt/codex/cua_node/lib/node_modules/playwright'),fs=require('node:fs');
const out='docs/review-images/cityhall-paper/implemented';let browser;
(async()=>{
 fs.mkdirSync(out,{recursive:true});browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:1440,height:1000}});
 page.on('pageerror',e=>{throw e;});await page.goto('http://127.0.0.1:8798/studies/cityhall-paper/',{timeout:120000});await page.waitForFunction(()=>window.CityHallStudy?.ready,{timeout:120000});
 await page.evaluate(()=>{CityHallStudy.view('hall');CityHallStudy.seekAmbient(0);});await page.waitForTimeout(100);await page.screenshot({path:out+'/hall.png'});
 await page.evaluate(()=>{CityHallStudy.select('6-15');CityHallStudy.view('play');});await page.waitForTimeout(100);await page.screenshot({path:out+'/finale.png'});
 for(const [name,kind,seconds]of [['hall-life','ambient',48],['tunnel-demo','demo',15],['satchel-dispatch','dispatch',15]]){
  await page.evaluate(kind=>{cpCancel();CityHallStudy.view(kind==='ambient'?'hall':'play');if(kind==='demo'){CityHallStudy.demo();}if(kind==='dispatch'){CityHallStudy.select('6-15');CityHallStudy.fixtureAnswer();gSend();while(gm.mode==='running')gUpdate();gNext();}},kind);
  const data=await page.evaluate(async({kind,seconds})=>{
   const canvas=CityHallStudy.renderer.canvas,stream=canvas.captureStream(12),chunks=[],recorder=new MediaRecorder(stream,{mimeType:'video/webm;codecs=vp9',videoBitsPerSecond:900000});
   const ended=new Promise(resolve=>recorder.onstop=resolve);recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};recorder.start();const started=performance.now();
   await new Promise(resolve=>{const timer=setInterval(()=>{const t=Math.min(seconds,(performance.now()-started)/1000);if(kind==='ambient')CityHallStudy.seekAmbient(t);else {CP.frame=Math.floor(t*60);cpWorld();}CityHallStudy.app.draw();if(t>=seconds){clearInterval(timer);resolve();}},1000/12);});
   recorder.stop();await ended;stream.getTracks().forEach(t=>t.stop());return await new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result.split(',')[1]);reader.readAsDataURL(new Blob(chunks,{type:'video/webm'}));});
  },{kind,seconds});fs.writeFileSync(out+'/'+name+'.webm',Buffer.from(data,'base64'));console.log('Recorded',name);
 }
 await browser.close();
})().catch(async e=>{console.error(e);if(browser)await browser.close();process.exitCode=1;});
