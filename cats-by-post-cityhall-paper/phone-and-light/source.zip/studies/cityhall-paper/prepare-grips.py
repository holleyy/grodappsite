"""Compose armless bases from accepted components for room-local articulated grips."""
from pathlib import Path
import importlib.util, json, hashlib, subprocess
ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'docs/experiments/office-fidelity/cityhall'
DEST=ROOT/'src/fidelity/cityhall-paper/assets'
spec=importlib.util.spec_from_file_location('hall_character',SOURCE/'character.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
depot=SOURCE.parent/'depot/bespoke/assets'
paths=m.component_paths(depot)
if any(not p.exists() for p in paths.values()):
 # Sparse worktrees can omit the accepted component family. Materialise exact
 # base blobs in scratch; never overwrite the other room's files.
 scratch=ROOT/'work/cityhall-paper/components'
 for path in paths.values():
  target=scratch/path.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True)
  raw=path.read_bytes() if path.exists() else subprocess.check_output(['git','show','923b40d7c3ef2b9e4fab49d290267f0094a1a9bb:'+str(path.relative_to(ROOT))],cwd=ROOT)
  target.write_bytes(raw)
 depot=scratch/depot.relative_to(ROOT)
components=m.load_components(depot)
manifest=json.loads((DEST/'manifest.json').read_text())
sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [SOURCE/'character.py',SOURCE/'actor-poses.json']}
sources.update({str(paths[k].relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for k,p in m.component_paths(depot).items()})
def save(name,image,rig=None):
 path=DEST/(name+'.png');image.save(path)
 manifest['assets'][name]={'file':path.name,'width':image.width,'height':image.height,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source':'accepted component composition; original head, coat and feet','componentSources':sources,'rig':rig}
for name in ('hand','sleeve'):
 save('joint-'+name,components[name]);components[name]=components[name].copy();components[name].putalpha(0)
poses=json.loads((SOURCE/'actor-poses.json').read_text())
if isinstance(poses,dict):poses=poses['sprites']
for pose in poses:
 image,rig=m.compose_actor(pose,components);save('worker-base-'+str(pose['sourceHash']),image,rig)
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared original component bases and articulated hands')
