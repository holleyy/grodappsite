"""Assemble full-resolution review captures and exact preservation receipts."""
from pathlib import Path
from PIL import Image
import json,hashlib,shutil
root=Path(__file__).resolve().parents[3]
work=root/'work/cityhall-paper/phone-and-light';out=root/'docs/review-images/cityhall-paper/phone-and-light'
out.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
build=read(root/'studies/cityhall-paper/build.json')
for f,h in build['inputs'].items():assert sha(root/f)==h,f
protected=read(root/'work/cityhall-paper/protected.json')
for f,h in protected.items():assert sha(root/f)==h,f
before=read(work/'before-rasters.json');after=read(work/'after-rasters.json')
assert before==after==read(out.parent/'vault-and-walls/after-rasters.json')
browser=read(root/'work/cityhall-paper/browser-report.json');qualify=read(root/'work/cityhall-paper/qualification-report.json');phone=read(work/'phone-report.json')
assert not browser['errors'] and not qualify['errors'] and not phone['errors'] and not phone['failures']
assert len(browser['checks'])==72 and len(qualify['checks'])==26 and len(phone['checks'])==44
captures={}
views=['phone-first','phone','phone-tall','phone-short','phone-hall','hall','square','light','detail','board','gray']
for name in [f'{side}-{view}' for side in ['before','after'] for view in views]+['old-framing','production-phone']:
    source=work/(name+'.png');target=out/(name+'.webp')
    with Image.open(source) as im:
        im.save(target,'WEBP',quality=94,method=6)
        captures[target.name]={'width':im.width,'height':im.height,'sourceSha256':sha(source),'sha256':sha(target)}
for src,name in [(root/'studies/cityhall-paper/build.json','build-manifest.json'),(work/'before-build.json','previous-build.json'),(work/'framed-before-build.json','comparison-build.json'),(work/'production-footprint.json','production-footprint.json'),(root/'work/cityhall-paper/browser-report.json','browser-report.json'),(root/'work/cityhall-paper/qualification-report.json','qualification-report.json'),(work/'phone-report.json','phone-report.json'),(work/'before-rasters.json','before-rasters.json'),(work/'after-rasters.json','after-rasters.json'),(work/'phone-life.webm','phone-life.webm')]:shutil.copyfile(src,out/name)
write('capture-hashes.json',{'runtimeSha256':build['sha256'],'ambientSeconds':8,'images':captures})
write('preservation.json',{'protectedFiles':protected,'allExact':True,'boardRasters':after,'retainedPreviousRuntime':'c76abd4cd3674b04188f0efc5f80a2990d046bcab13f6c0c216c8a59d92e1d5c'})
write('verification.json',{'runtimeSha256':build['sha256'],'bytes':build['bytes'],'focusedTests':38,'browserChecks':len(browser['checks']),'qualificationChecks':len(qualify['checks']),'phoneChecks':len(phone['checks']),'canonicalWins':len(browser['wins']),'protectedFiles':len(protected),'buildInputs':len(build['inputs']),'boardRastersExact':3,'errors':[],'scope':'Cloud Chromium including DPR2 touch and phone viewport/safe-area emulation; no physical-device/Safari performance claim','warm':qualify['warm']})
print('Evidence complete:',build['sha256'],len(captures),'full-resolution captures')
