"""Keep previous scene artwork, match current review controls for art comparisons."""
from pathlib import Path
import hashlib,json
p=Path('work/cityhall-paper/phone-and-light')
old=(p/'framed-before-ui-v1.html').read_text()
new=Path('studies/cityhall-paper/index.html').read_text()
for start,end in [('@font-face{font-family:VaultBalthazar','</style>'),('/* Sparse review controls','})(globalThis);'),('/* Review binding to the unchanged host.','})();')]:
    a=old.index(start);b=old.index(end,a);c=new.index(start);d=new.index(end,c)
    old=old[:a]+new[c:d]+old[b:]
(p/'framed-before.html').write_text(old)
(p/'framed-before-build.json').write_text(json.dumps({'sha256':hashlib.sha256(old.encode()).hexdigest(),'bytes':len(old.encode()),'sceneryRuntime':'c76abd4cd3674b04188f0efc5f80a2990d046bcab13f6c0c216c8a59d92e1d5c','framingBaseline':'dcc4af3090e73c99638d4f76efc99c547324c25e5d3569e54018f62c446be413','controlsFromRuntime':hashlib.sha256(new.encode()).hexdigest(),'method':'Previous scenery in the same corrected framing and review controls; no old scene artwork changed.'},indent=2)+'\n')
