# Full-height phone framing, scene depth and light

Approved in conversation: replace the cramped phone study framing with the
actual game's sparse control footprint and safe areas; compose the newly
visible sky and foreground; soften daylight and strengthen receiving shadows
without obscuring the board. Source baseline aaa1bfec, runtime c76abd4c.
The selected Great Postal Vault image and supplied Lantern Quay/Town Depot
references remain the visual targets. No new composition selection is needed.

1. Measure the existing production game UI in Chromium at phone widths.
   Capture the current study and preserve its exact runtime. In the owned
   study, use full-viewport scenery and compact functional overlays with the
   measured production footprint, accessible queue/tools, safe areas and
   unobstructed puzzle interaction. Keep diagnostic controls in a disclosure.
2. Capture the previous scenery in the corrected framing. Extend sky and
   ground coverage for tall phones/zoom; compose a connected, quieter approach
   and near town without moving the hall, board or established contacts.
3. Apply consistent soft directional daylight and receiving shadows to the
   architecture/environment. Retain all original art and board rasters. Verify
   exact gameplay, input/lifecycle, phone sizes/safe areas/landscape, grayscale,
   moving workers and scene edges. Obtain one fresh Astra checkpoint review.
4. Publish a new phone-and-light child on the authorised grodappsite preview.
   Retain every earlier checkpoint and other room. Supply matched old framing,
   same-framing scenery comparisons, playable build and actual motion evidence.

Working ledger: studies/cityhall-paper/phone-and-light/progress.md.
Browser: actual cloud Chromium/Playwright. No physical-device claim.
Production UI is measured read-only; only the owned study changes. The new
preview represents its footprint, not a production/native integration claim.
