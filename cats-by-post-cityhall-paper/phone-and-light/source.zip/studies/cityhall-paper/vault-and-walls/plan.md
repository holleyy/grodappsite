# Consistent vault, walls and service pipework

The user identified the left pipes as poor and the wall as blue, noted that the
right side looks better, and authorised fixing this alongside the previously
proposed roof and nearby façade refinement. Start at source 1dcaee86, runtime
5f87ab671f8c4c799e939dbda24d88257d12079366844e6faafdfa720cf4d073.

1. Capture matched wall/pipe detail, whole hall, wider square, largest board,
   grayscale and phone views before changing the renderer-owned scene.
2. Replace flat blue-grey wall paint with the right bay's warm ivory paper
   masonry. Give each opening measured reveals and sills, preserving the actual
   opening/horizon registration and exterior visible through it.
3. Replace the disconnected upper pipes with a continuous mounted run from a
   left-wall service case into the existing clock-bay network. Keep the pipe,
   mounts and replacement wall lanterns clear of the full worker silhouette.
   Match left gallery rails and fascia to the finished right bay.
4. Give the retained vault ribs real paper faces, cap edges, joints and seated
   feet. Preserve all rib centre lines, spring/crown heights and roof cutaway.
   Refine near façades with paper stone, window depth and quieter slate roofs;
   keep building masses, window scenery and the connected square unchanged.
5. Inspect actual captures and motion; preserve all board rasters, gameplay,
   canonical files and shared renderer/camera. Run focused/browser checks and
   independent Astra review. Publish only a new vault-and-walls child beneath
   the authorised City Hall preview, preserving earlier checkpoints and rooms.

The right-hand finish supplies the material standard. This is consolidation
of the approved design, not a new composition. Retained paper stock and art
are reused; one newly generated raw slate paper texture supplies roof facets.
