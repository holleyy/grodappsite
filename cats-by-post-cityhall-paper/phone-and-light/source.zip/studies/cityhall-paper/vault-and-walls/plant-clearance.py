"""Every retained blade is checked against the new gallery fascia and lip."""
from pathlib import Path
import hashlib,json,subprocess
from PIL import Image
root=Path(__file__).resolve().parents[3]
asset=root/'src/fidelity/cityhall-paper/assets/masters/sorting-palm.png'
im=Image.open(asset).convert('RGBA');pixels=im.load()
layout=json.loads(subprocess.check_output(['node','-e',"console.log(JSON.stringify(require('./src/fidelity/cityhall-paper/vault-and-walls').layout()))"],cwd=root,text=True))
volumes={'fascia':layout['leftFascia'],'lip':layout['leftLip'],'slab':dict(x0=0,y0=23,z0=42,x1=23,y1=192,z1=46)}
hits=dict.fromkeys(volumes,0);count=0;maximum=-1
for py in range(im.height):
 for px in range(im.width):
  if pixels[px,py][3]<=128:continue
  count+=1;dx=(px-607)/1254*29
  point={'x':17+dx/2,'y':156-dx/2,'z':13+(1214-py)/1254*29};maximum=max(maximum,point['z'])
  for name,v in volumes.items():hits[name]+=int(all(v[k+'0']<=point[k]<=v[k+'1'] for k in point))
assert not any(hits.values()),hits
print(json.dumps({'assetSha256':hashlib.sha256(asset.read_bytes()).hexdigest(),'anchor':[17,156,13],'height':29,'opaqueSamples':count,'maximumWorldZ':maximum,'volumes':volumes,'intersections':hits,'method':'Every alpha>128 pixel mapped using full retained artwork registration; checked in world space against actual exported fascia/lip and original slab.'},indent=2))
