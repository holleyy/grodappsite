# Vault, walls and pipework checkpoint

Run the owned builder with `python3 studies/cityhall-paper/build.py`.
Serve the repository at port 8805 for this checkpoint's capture tools.
`capture.cjs before` reads the preserved prior runtime from the owned scratch
folder; `capture.cjs after` reads the current study. Seven matched views and
all three board-raster hashes are saved under `work/cityhall-paper/vault-and-walls`.
`record.cjs` records 32 seconds of the actual renderer at ambient times 16–48.
`plant-clearance.py` checks all 615, 349 opaque palm pixels against the measured
new fascia and lip and the unchanged gallery slab.

The user asked for the left pipes and blue wall to match the stronger right
side, alongside the next roof and nearby façade refinement. The pipe now runs
from a receiving service case into the existing clock network; the walls use
warm ivory paper. Gallery finish, mounted lanterns, vault rib faces and near
stone/slate façades share that construction language. Board projection,
geometry, authored levels, workers and shared backdrop are preserved.

Review evidence belongs in `docs/review-images/cityhall-paper/vault-and-walls`.
Whole-room artistic acceptance and physical-device qualification remain open.
