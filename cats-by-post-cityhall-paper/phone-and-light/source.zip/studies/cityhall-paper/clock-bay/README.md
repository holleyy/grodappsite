# Reproducing the clock-bay checkpoint

Build from the repository root with `python studies/cityhall-paper/build.py`.
Serve the root at 127.0.0.1:8799. The capture/record scripts use installed
Playwright at /opt/codex/cua_node/lib/node_modules/playwright and Chromium at
/usr/bin/chromium; change those tooling paths for another machine.

Run `node studies/cityhall-paper/clock-bay/capture.cjs after` and
`node studies/cityhall-paper/clock-bay/record.cjs`. Output goes under
work/cityhall-paper/clock-bay. The capture script freezes the host update only
inside its browser session, then sets the ambient scene to 8 seconds. It captures
1440×1000 and 390×844 views and hashes all three board raster caches.
The recording advances the same actual renderer from scene time 8 to 28 seconds.

For the baseline, copy the first published City Hall packet's playable.html to
work/cityhall-paper/clock-bay/before.html, then run capture.cjs before. That
self-contained baseline is SHA-256
a33263a0a0096c386f1ee7c8f2808a39acb1dd1a7215635f0ff8b59d1c02871e.
Its build-manifest.json is retained in the checkpoint evidence as before-build.json.

Focused tests: `node --test tests/cityhall-paper-*.test.js`.
Browser checks: set CITYHALL_STUDY_URL to the served study URL and run
studies/cityhall-paper/verify.cjs, then qualify.cjs.
The source zip overlays cosysortie base923b40d7c3ef2b9e4fab49d290267f0094a1a9bb;
the original canonical sorting_office.html at that base is required for rebuilding.
