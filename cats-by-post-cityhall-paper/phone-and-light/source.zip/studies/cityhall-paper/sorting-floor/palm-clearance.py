"""Check the complete retained palm silhouette against the gallery, not its bounds."""
from pathlib import Path
import hashlib
import json
from PIL import Image

root = Path(__file__).resolve().parents[3]
asset = root / 'src/fidelity/cityhall-paper/assets/masters/sorting-palm.png'
im = Image.open(asset).convert('RGBA')
assert im.size == (1254, 1254)
volumes = {
    'gallery-deck': (0, 224, 0, 23, 42, 46),
    'gallery-fascia': (112, 224, 21, 23.5, 37.5, 42.5),
    'gallery-lip': (112, 224, 21, 25, 43.7, 46),
}
hits = dict.fromkeys(volumes, 0)
minimum = float('inf')
count = 0
for py in range(im.height):
    for px in range(im.width):
        if im.getpixel((px, py))[3] <= 128:
            continue
        count += 1
        dx = (px - 607) / 1254 * 30
        x, y, z = 220 + dx / 2, 28 - dx / 2, 14 + (1214 - py) / 1254 * 30
        minimum = min(minimum, x - y)
        for name, (x0, x1, y0, y1, z0, z1) in volumes.items():
            hits[name] += int(x0 <= x <= x1 and y0 <= y <= y1 and z0 <= z <= z1)
assert not any(hits.values()), hits
assert minimum > 175, minimum
print(json.dumps({
    'assetSha256': hashlib.sha256(asset.read_bytes()).hexdigest(),
    'anchor': [220, 28, 14], 'height': 30, 'opaqueSamples': count,
    'galleryIntersections': hits, 'minimumProjectedX': minimum,
    'frontPierMaximumProjectedXBelowCanopy': 175,
    'method': 'Alpha>128 pixels mapped onto the upright billboard plane; full authored blade silhouette tested against measured gallery slab, fascia and lip.'
}, indent=2))
