# Reproducing the sorting-floor checkpoint

Build from the repository root with `python3 studies/cityhall-paper/build.py`.
Serve the root at 127.0.0.1:8799. Capture and recording scripts use Playwright
at /opt/codex/cua_node/lib/node_modules/playwright and Chromium at
/usr/bin/chromium; adjust those tooling paths on another machine.

Run `node studies/cityhall-paper/sorting-floor/capture.cjs after` and
`node studies/cityhall-paper/sorting-floor/record.cjs`. Output goes under
work/cityhall-paper/sorting-floor. Captures use the actual renderer paused at
ambient time 8 seconds, at 1440×1000 and 390×844. The clip advances ambient
time from 16 to 48 seconds, including the worker and trolley routine.

For the baseline, copy the published clock-bay playable.html to
work/cityhall-paper/sorting-floor/before.html, then run capture.cjs before.
Its SHA-256 is e64e10ccfdd0e7ef2b075d3dcc376a5ebdd6de95932ab9e947c4bfb7f94842a4.
The original build manifest is retained as before-build.json.

Focused tests: `node --test tests/cityhall-paper-*.test.js`.
Browser checks: set CITYHALL_STUDY_URL to the served study URL and run
studies/cityhall-paper/verify.cjs, then qualify.cjs.
`python3 studies/cityhall-paper/sorting-floor/palm-clearance.py` checks every
opaque pixel of the retained foliage against the gallery and front pier.

The source archive overlays cosysortie base
923b40d7c3ef2b9e4fab49d290267f0094a1a9bb. The original canonical
sorting_office.html at that base is required for rebuilding.
