# Sorting floor checkpoint

Continuation authorised by the user after the clock-bay checkpoint. Keep the
selected Great Postal Vault and the exact board/camera. Starting source 73147026,
runtime e64e10ccfdd0e7ef2b075d3dcc376a5ebdd6de95932ab9e947c4bfb7f94842a4.
The existing design and refinement plan remain the governing direction.

This checkpoint finishes the rear sorting counter/pigeonholes, the adjacent
stair joinery and the right-hand indoor planting. It does not start a new room
composition or a whole-square rework. Implementation decisions below are the
builder's choices within the authorised next checkpoint.

1. Capture the current runtime at a fixed camera/time and all three boards.
2. Correct rear-to-front drawing: recessed cabinets behind gallery supports;
   the foreground sorting counter in front of them. Build real shelves, dividers,
   cabinet panels and receiving shadows from retained paper stock. Add varied
   letters/parcels at their actual receiving shelf heights.
3. Refine the sorting counter with a darker timber body, ivory worktop and postal
   plaque. Integrate separately generated paper lamp/flowers and retained letters.
   Keep the circulation aisle and existing parcel/trolley routine unchanged.
4. Give the stair deeper stringers, timber/stone layers, substantial newel posts
   and continuous brass handrails without changing its 15 treads or gallery height.
5. Replace the right palm's angular placeholder canopy with generated paper
   foliage. Its old placement intersects the gallery deck; move it into the
   clear right-hand apron, with measured footing outside the board/worker routes.
6. Compare actual full/close/grayscale/phone captures and a motion loop. Check
   shelf/counter occlusion, feet/contacts, plants and props at moving-worker
   positions. Keep all 3 board rasters and 195 protected inputs exact. Run focused,
   browser and qualification checks and independent Astra review.
7. Publish an add-only sorting-floor/ child of the authorised City Hall preview,
   preserving both earlier checkpoints and every other room. Return this
   checkpoint for visual review before expanding the treatment elsewhere.

The main visual test is whether the sorting area gains readable depth and warm
paper character at whole-hall scale, while the board remains the clearest plane.
Technical passes are required but do not establish whole-room artistic finish.
