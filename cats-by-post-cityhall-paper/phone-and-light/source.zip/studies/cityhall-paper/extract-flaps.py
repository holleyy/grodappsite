"""Exact palette decoding of existing export art; no newly painted flap poses."""
from pathlib import Path
import json, base64, hashlib
from PIL import Image
ROOT=Path(__file__).resolve().parents[2]
DEST=ROOT/'src/fidelity/cityhall-paper/assets'
s=(ROOT/'sorting_office.html').read_text()
i=s.index('const PAPER_SPRITE_DATA')
data,_=json.JSONDecoder().raw_decode(s[s.index('=',i)+1:].lstrip())
palette=json.loads((ROOT/'src/data/palette.json').read_text())['colours']
colours=[tuple(bytes.fromhex(c[1]))+(255,) for c in palette]
manifest=json.loads((DEST/'manifest.json').read_text())
count=0
for kind in ('sprites','pieces'):
 for r in data[kind]:
  if not ('flapIndex' in r or r.get('family','').startswith(('edge_flap_','edge_approach_'))): continue
  name=r['id'].replace('/','-');rect=r['rect'];im=Image.new('RGBA',(rect['w']*4,rect['h']*4))
  im.putdata([(0,0,0,0) if n==255 else colours[n&127] for n in base64.b64decode(r['pixels'])])
  file=DEST/(name+'.png');im.save(file)
  meta={k:v for k,v in r.items() if k not in ('source','pixels','depth','faces')}
  manifest['assets'][name]={'file':file.name,'width':im.width,'height':im.height,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'sourceFile':'sorting_office.html','source':'PAPER_SPRITE_DATA.'+kind,'registration':meta}
  count+=1
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Decoded',count,'original flap assets')
