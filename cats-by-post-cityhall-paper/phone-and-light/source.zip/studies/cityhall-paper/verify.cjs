/* Actual canonical-host browser checks. Run from repository root. */
const {chromium}=require('/opt/codex/cua_node/lib/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict');
const out='work/cityhall-paper';fs.mkdirSync(out,{recursive:true});
let browser;
(async()=>{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[],report={checks:[],viewports:[],wins:[],errors};
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 await page.goto((process.env.CITYHALL_STUDY_URL||'http://127.0.0.1:8798/studies/cityhall-paper/'),{waitUntil:'load',timeout:120000});await page.waitForFunction(()=>window.CityHallStudy?.ready,{timeout:120000});
 const check=(name,value)=>{assert.ok(value,name);report.checks.push(name);};
 check('initial puzzle is unfilled',await page.evaluate(()=>gm.chutes.length===0&&gm.mode==='edit'));
 check('private save keys only',await page.evaluate(()=>Object.keys(localStorage).every(k=>k.startsWith('catsByPost.cityhallPaper.study.v1.'))));
 for(let n=1;n<=15;n++){
  await page.evaluate(n=>CityHallStudy.select('6-'+n),n);
  await page.evaluate(()=>CityHallStudy.app.draw());
  const picks=await page.evaluate(()=>{let count=0;const S=CityHallStudy;for(let y=0;y<gm.L.board.h;y++)for(let x=0;x<gm.L.board.w;x++){const p=S.screenCell(x,y);if(S.pick(p.x,p.y)!==y*gm.L.board.w+x)throw Error('pick '+x+','+y);count++;}return count;});check('picks 6-'+n,picks===await page.evaluate(()=>gm.L.board.w*gm.L.board.h));
  await page.evaluate(()=>CityHallStudy.fixtureAnswer());await page.click('#btnSend');
  const result=await page.evaluate(()=>{let n=0;while(gm.mode==='running'&&n++<12000)gUpdate();for(let i=0;i<180;i++)gUpdate();CityHallStudy.app.draw();return {id:gm.L.id,outcome:gm.mode,ticks:gm.sim.endTick};});check('solution '+result.id,result.outcome==='won');report.wins.push(result);
 }
 await page.evaluate(()=>CityHallStudy.select('6-1'));const point=await page.evaluate(()=>{CityHallStudy.app.draw();return CityHallStudy.screenCell(6,2);});await page.mouse.click(point.x,point.y);
 check('trusted click reaches canonical placement',await page.evaluate(()=>gm.chutes.some(t=>t.x===6&&t.y===2)));
 await page.evaluate(()=>{gm.cx=2;gm.cy=2;gm.cursor=true;CityHallStudy.app.draw();});
 check('keyboard preserves selected partner',await page.evaluate(()=>CityHallStudy.app.capture().selected.x===2));
 const before=await page.evaluate(()=>JSON.stringify({turns:gm.chutes,tray:gm.tray,attempts:gm.attempts,progress:PROGRESS.serialize(progress),time:gm.t}));
 await page.evaluate(()=>CityHallStudy.demo());const demo=await page.evaluate(()=>CityHallStudy.app.capture());check('actual three-cat shared demo',demo.level.id==='cityhall-chapter-demo'&&demo.traces.length===3);
 check('chapter card stays outside the desktop scene',await page.evaluate(()=>{const a=document.getElementById('chapterCard').getBoundingClientRect(),b=document.getElementById('vaultScene').getBoundingClientRect();return a.left>=b.right&&a.bottom<innerHeight;}));
 await page.evaluate(()=>{CP.frame=250;cpWorld();CityHallStudy.app.draw();cpCancel();});
 check('demo preserves suspended live state',before===await page.evaluate(()=>JSON.stringify({turns:gm.chutes,tray:gm.tray,attempts:gm.attempts,progress:PROGRESS.serialize(progress),time:gm.t})));
 for(const level of ['6-3','6-7']){
  await page.evaluate(id=>{CityHallStudy.select(id);CityHallStudy.fixtureAnswer();gSend();while(gm.mode==='running')gUpdate();gNext();CityHallStudy.app.draw();},level);
  check('growth '+level+' is real controller',await page.evaluate(()=>CP.hall&&CP.mode==='growth'));
  check('growth has no active puzzle pieces',await page.evaluate(()=>{const f=CityHallStudy.app.capture();return f.turns.length===0&&f.traces.length===0&&f.presentation==='growth';}));
  await page.evaluate(()=>{CP.frame=140;cpWorld();CityHallStudy.app.draw();});await page.screenshot({path:out+'/growth-'+level+'.png'});await page.evaluate(()=>{cpBegin();cpFinishEntry();});
 }
 for(const size of [[1440,1000],[390,844],[402,874],[844,390],[1024,600]]){
  await page.setViewportSize({width:size[0],height:size[1]});
  for(const id of ['6-1','6-6','6-15']){await page.evaluate(id=>{CityHallStudy.select(id);CityHallStudy.view('play');},id);await page.waitForTimeout(100);
   const v=await page.evaluate(()=>{const S=CityHallStudy,b=gm.L.board,r=document.getElementById('vaultCanvas').getBoundingClientRect();let ok=true;for(let y=0;y<b.h;y++)for(let x=0;x<b.w;x++){const p=S.screenCell(x,y);if(p.x<r.left||p.x>r.right||p.y<r.top||p.y>r.bottom||S.pick(p.x,p.y)!==y*b.w+x)ok=false;}return{id:gm.L.id,ok,tileWidth:32*S.renderer.cam.scale,tileHeight:16*S.renderer.cam.scale};});check('viewport '+size+' '+id,v.ok);report.viewports.push({width:size[0],height:size[1],...v});
   check('ordered queues remain available '+size+' '+id,await page.evaluate(()=>{const q=document.getElementById('catQueue'),items=q.querySelectorAll('.queue-cat');return getComputedStyle(q).display!=='none'&&items.length===gm.L.hatches.reduce((n,h)=>n+h.cats.length,0)&&[...items].every(c=>c.getAttribute('aria-label'));}));
   await page.screenshot({path:out+'/'+id+'-'+size.join('x')+'.png'});
  }
 }
 check('no browser errors',errors.length===0);fs.writeFileSync(out+'/browser-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();
})().catch(async e=>{console.error(e);if(browser)await browser.close();process.exitCode=1;});
