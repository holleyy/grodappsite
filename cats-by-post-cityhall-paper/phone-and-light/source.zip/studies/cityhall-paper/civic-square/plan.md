# Left desk and civic square checkpoint

Continuation authorised after the sorting-floor checkpoint. Starting source
f1af2082; baseline runtime 61322e74397b48c0144efb96383290e8a27d0e81ff5e593bf887506757595269.
Keep the selected Great Postal Vault, height and board projection. This extends
the previously approved refinement sequence into the left working station and
the public space immediately outside the hall.

1. Capture the unchanged runtime with matched left-detail, hall, wider square,
   maximum board, grayscale and portrait views.
2. Rebuild the postmistress desk with paper timber panels and ivory worktop.
   Move its rear edge clear of the gallery support while retaining the original
   postmistress foot position and worktop height. Replace the angular left palm
   with the retained full foliage and keep it below the gallery.
3. Replace the remaining flat tree canopies with the retained paper tree, using
   the same measured footings and one connected world. Add flower planters,
   municipal lamps and fountain seating around the existing approach; enrich
   fountain stone and the hall's receiving plinth. Leave routes and board clear.
4. Use actual renderer captures and continuous ambient motion to check depth,
   receiving surfaces and full artwork silhouettes. Preserve all three board
   rasters and 195 protected source files. Run focused and browser checks plus
   an independent Astra review; fix substantive findings.
5. Publish an add-only civic-square child beneath the authorised City Hall
   preview, retaining every earlier checkpoint and other room. Return a visual
   checkpoint; whole-room artistic acceptance remains with the user.

Geometry is built on the existing 2:1 projection. ImageGen supplies complete
transparent flower and lantern assets; existing paper stock, palm, flowers and
tree masters are reused. No shared camera, renderer, gameplay, native code or
canonical outputs are changed. Browser verification uses the established local
Chromium harness and exact nested public packet.
