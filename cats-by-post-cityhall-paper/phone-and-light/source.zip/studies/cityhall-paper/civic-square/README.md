# Reproducing the civic-square checkpoint

Build from the repository root with `python3 studies/cityhall-paper/build.py`.
Serve the root at 127.0.0.1:8803. Capture and recording scripts use Playwright
at /opt/codex/cua_node/lib/node_modules/playwright and Chromium at
/usr/bin/chromium; adjust those tooling paths on another machine.

Run `node studies/cityhall-paper/civic-square/capture.cjs after` and
`node studies/cityhall-paper/civic-square/record.cjs`. Output goes under
work/cityhall-paper/civic-square. Captures use the actual renderer paused at
ambient time 8 seconds, at 1440×1000 and 390×844. The square view uses zoom0.8; the detail view centres the left working station at zoom1.65. The clip advances ambient
time from 16 to 48 seconds, including the worker and trolley routine.

For the baseline, copy the published sorting-floor playable.html to
work/cityhall-paper/civic-square/before.html, then run capture.cjs before.
Its SHA-256 is 61322e74397b48c0144efb96383290e8a27d0e81ff5e593bf887506757595269.
The original build manifest is retained as before-build.json.

Focused tests: `node --test tests/cityhall-paper-*.test.js`.
Browser checks: set CITYHALL_STUDY_URL to the served study URL and run
studies/cityhall-paper/verify.cjs, then qualify.cjs.
The source archive overlays cosysortie base
923b40d7c3ef2b9e4fab49d290267f0094a1a9bb. The original canonical
sorting_office.html at that base is required for rebuilding.
