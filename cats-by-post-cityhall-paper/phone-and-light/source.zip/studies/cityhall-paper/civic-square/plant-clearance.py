"""Check the complete left palm silhouette against the measured gallery slab."""
from pathlib import Path
import hashlib
import json
from PIL import Image

root = Path(__file__).resolve().parents[3]
asset = root / 'src/fidelity/cityhall-paper/assets/masters/sorting-palm.png'
im = Image.open(asset).convert('RGBA')
assert im.size == (1254, 1254)
count, hits, maximum = 0, 0, -1
for py in range(im.height):
    for px in range(im.width):
        if im.getpixel((px, py))[3] <= 128:
            continue
        count += 1
        dx = (px - 607) / 1254 * 29
        x, y, z = 17 + dx / 2, 156 - dx / 2, 13 + (1214 - py) / 1254 * 29
        maximum = max(maximum, z)
        hits += int(0 <= x <= 23 and 23 <= y <= 192 and 42 <= z <= 46)
assert hits == 0 and maximum < 42
print(json.dumps({
    'assetSha256': hashlib.sha256(asset.read_bytes()).hexdigest(),
    'anchor': [17, 156, 13], 'height': 29, 'opaqueSamples': count,
    'maximumWorldZ': maximum, 'galleryBottomZ': 42, 'galleryIntersections': hits,
    'method': 'Every alpha>128 pixel projected onto the upright cutout plane using the full-image registration; tested against left gallery slab.'
}, indent=2))
