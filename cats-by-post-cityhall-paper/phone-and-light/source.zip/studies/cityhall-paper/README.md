# The Great Postal Vault

Standalone City Hall presentation study on `codex/cityhall-paper-fidelity`, based
on `923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`. Open `index.html` through a local
HTTP server. All art, code and the existing canonical game are embedded.

```sh
python studies/cityhall-paper/build.py
python -m http.server 8798 --directory .
```

Visit `http://localhost:8798/studies/cityhall-paper/`. Start with an empty 6-1
puzzle, or select any of the fifteen existing Hall deliveries. Explore hall
shows the entire vault; Return to board restores the closer playable framing.
Drag to pan, use +/− or pinch to zoom. Arrow keys select cells, Enter places or
rotates a turntable, Space sends the post. Motion and G expose reduced ambient
motion and grayscale. System reduced-motion preferences also apply.

The game owns the actual rules, 300 ms ticks, authored answers, inventory, hints,
stars, chapter presentations and progress. The study changes the two save keys
to `catsByPost.cityhallPaper.study.v1.*`; normal campaign saves remain untouched.
The chapter buttons retain the real Train→Hall→Parcel navigation. Other rooms
use the unchanged canonical host when the Hall presentation is inactive.

## Reproduce verification

```sh
node --test tests/cityhall-paper-*.test.js
node studies/cityhall-paper/verify.cjs
node studies/cityhall-paper/qualify.cjs
npm test
```

The browser scripts use this cloud environment's Playwright installation at
`/opt/codex/cua_node/lib/node_modules/playwright` and `/usr/bin/chromium`.
Adjust those two paths on another machine. The local server above must be
running. Logs and intermediate captures go to `work/cityhall-paper/`.
`record.cjs` records deterministic ambient, shared-demo and dispatch samples
from the real Canvas in Chromium. These are presentation evidence, not FPS
measurements. Review evidence is under
`docs/review-images/cityhall-paper/implemented/`.

`CityHallStudy.fixtureAnswer()` is an explicit test-only fixture used by the
verifiers. The normal UI never pre-fills an answer. The review API also exposes
the renderer, snapshots and chapter/ambient seeks for reproducible inspection.
None of this study toolbar or diagnostic API belongs in production integration.

## Source and assets

Room-owned implementation: `src/fidelity/cityhall-paper/`. The selected reference
is `docs/review-images/cityhall-paper/refinement/great-postal-vault.webp` (the
second **height** study). Architecture is measured Canvas construction with a
single `(x-y, (x+y)/2-z)` projection, 16-unit tiles, gallery soles at z46,
vault spring z138 and crown z180. The front roof is cut away for the board.

The backdrop combines a measured civic square with one distant Image Gen skyline.
Paving, kerbs, six entrance steps, neighbouring buildings, fountain, lamps and
trees share the board's 2:1 projection. The plinth meets pavement z−12; stairs
connect floor z0 to that square. Foreground steps and lamps are separately baked
so the plinth cannot incorrectly hide them. Every window reveals this same world.
The skyline retains its complete 2:1 image and sits behind the construction;
its raw master, prompt and hashes are preserved in assets/masters and manifest.

Workers, Postmistress, cats, dogs, carriers and flap art derive from the project's
accepted artwork. `extract-flaps.py` decodes original exported palette pixels;
`prepare-grips.py` composes armless worker bases from accepted head/coat/boot
components for articulated sleeves and hands. It hydrates missing sparse blobs
into scratch, without overwriting another room's files. Both retain source
hashes and registration. Live parcel dimensions and ownership stay constant;
the trolley's wheel angle follows its displacement. There is one ambient ginger
cat through sleep, walk, jump and return.

`build.json` records exact source hashes, the two allowlisted save-key
substitutions, HTML bytes and SHA-256. Rebuilding twice must produce identical
HTML and report bytes. No shared or production build output is generated.

## Qualification limits

Cloud Chromium emulates desktop, portrait, landscape, DPR2 and touch. Physical
iPhone/Safari performance, thermal behavior and sustained battery use remain
unqualified. Smallest fitted finale tile diamonds are about 45.3×22.7 CSS pixels
at 390×844; pinch/zoom provides larger targets. Accurate centre picking is not a
claim that every fitted diamond meets a 44-pixel minimum target dimension.

Resource reports count owned Canvas backing stores only. They exclude decoded
images, the canonical host, browser/GPU copies and process peak. Warm timings
measure synchronous draw calls, not presented FPS. Managed Chromium blocks
`file://` navigation; offline verification supplies only the document in memory
with networking disabled and checks that no subresource requests occur. Direct
file opening is not qualified in this environment.

Shared manager, camera, interface, bridge and production build integration is
proposed in `docs/rooms/progress/cityhall-paper-integration.md`; it has not been
installed or merged. The standalone preview packet is separate from production
integration and carries its own ownership, payload manifest and source archive.
