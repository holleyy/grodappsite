/* Sparse review controls use the measured production footprint. Canonical
   buttons and queues move intact, so their state and listeners stay authoritative. */
(function(root){
 'use strict';
 function create(o){
  const el=(tag,id)=>{const n=document.createElement(tag);n.id=id;return n;},button=(id,label,icon)=>{const n=el('button',id);n.type='button';n.setAttribute('aria-label',label);n.title=label;n.innerHTML='<img alt="" src="'+CityHallUIAssets[icon]+'">';return n;};
  const menu=button('vaultMenu','Hall controls','menu'),more=button('vaultMore','More sorting tools','tools'),identity=el('div','vaultPhoneIdentity'),arrivals=el('aside','vaultArrivals'),options=el('dialog','vaultOptions');
  identity.innerHTML='<h1></h1><small></small>';arrivals.innerHTML='<div class="arrival-heading"><span>Arrivals</span><span id="vaultArrivalCount"></span></div>';arrivals.setAttribute('aria-label','Upcoming cats by hatch');
  options.innerHTML='<div class="options-heading"><h2>Hall controls</h2><button id="vaultClose" aria-label="Close hall controls">Close</button></div><label id="vaultChoose">Delivery</label><div id="vaultSortingTools"></div>';
  options.setAttribute('aria-labelledby','vaultOptionsTitle');options.querySelector('h2').id='vaultOptionsTitle';
  o.header.prepend(identity);o.header.prepend(menu);o.hud.send.parentNode.append(more);document.body.append(arrivals,options);
  document.getElementById('tray').parentNode.classList.add('vault-tray-row');o.hud.send.parentNode.classList.add('vault-action-row');
  const clearImage=document.createElement('img');clearImage.src=CityHallUIAssets.reset;clearImage.alt='';o.hud.clear.prepend(clearImage);o.hud.clear.setAttribute('aria-label','Clear turntables');o.hud.clear.title='Clear turntables';
  const nodes=[o.selector,o.tools,o.hud.queue,o.hud.hint,o.story].filter(Boolean),slots=nodes.map(node=>{const mark=document.createComment('phone control home');node.before(mark);return{node,mark};});
  const art={};function sprite(name,kind){if(art[name])return art[name];const s=PAPER_SPRITE_DATA[kind].find(s=>s.id===name);if(!s)return '';const c=document.createElement('canvas');c.width=s.rect.w*4;c.height=s.rect.h*4;const ctx=c.getContext('2d'),frame=ctx.createImageData(c.width,c.height),out=new Uint32Array(frame.data.buffer),raw=atob(s.pixels);for(let i=0;i<raw.length;i++){const colour=raw.charCodeAt(i);out[i]=colour===255?0:PAL32[colour];}ctx.putImageData(frame,0,0);return art[name]=c.toDataURL();}
  for(const b of o.hud.tray){const im=document.createElement('img');im.className='vault-piece';im.alt='';im.src=sprite('turntable_'+b.dataset.type+'_E/idle','pieces');b.prepend(im);}
  const originalFaces=new WeakMap();
  function queueArt(){for(const item of o.hud.queue.querySelectorAll('.queue-cat')){const coat=item.getAttribute('aria-label').includes('ginger')?'ginger':'blue',im=item.querySelector('img');if(!originalFaces.has(im))originalFaces.set(im,im.src);im.src=sprite('cat_'+coat+'_box_towards/idle0','sprites');}}
  function restoreQueueArt(){for(const im of o.hud.queue.querySelectorAll('img'))if(originalFaces.has(im)){im.src=originalFaces.get(im);originalFaces.delete(im);}}
  const queueObserver=new MutationObserver(()=>{if(compact)queueArt();});queueObserver.observe(o.hud.queue,{childList:true,subtree:true});
  const query=matchMedia('(max-width:700px) and (orientation:portrait)');let compact=false,opener=null,lastTitle='',lastMode='';
  const close=()=>{if(!options.open)return;options.close();if(!document.getElementById('chapterScene').hidden)document.getElementById('chapterPrimary').focus({preventScroll:true});else if(opener?.isConnected)opener.focus({preventScroll:true});};
  const open=e=>{opener=e.currentTarget;options.showModal();options.querySelector('#vaultClose').focus();};menu.onclick=more.onclick=open;options.querySelector('#vaultClose').onclick=close;
  options.addEventListener('cancel',e=>{e.preventDefault();close();});options.addEventListener('click',e=>{if(e.target===options){const r=options.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)close();}else if(e.target.closest('button')&&[o.hud.hint,o.story].includes(e.target.closest('button')))close();});
  options.addEventListener('keydown',e=>e.stopPropagation());
  o.selector.addEventListener('change',close);
  function reconcile(on){
   const next=on&&query.matches;if(next===compact)return;const returnFocus=options.open||document.activeElement===menu||document.activeElement===more;compact=next;close();document.body.classList.toggle('vault-phone',compact);
   if(compact){queueArt();options.querySelector('#vaultChoose').append(o.selector);options.append(o.tools);arrivals.append(o.hud.queue);options.querySelector('#vaultSortingTools').append(o.hud.hint);if(o.story)options.querySelector('#vaultSortingTools').append(o.story);}
   else{restoreQueueArt();for(const s of slots)s.mark.before(s.node);if(on&&returnFocus)o.selector.focus({preventScroll:true});}
   o.invalidate();
  }
  function sync(level,mode){
   if(lastTitle!==level.id){lastTitle=level.id;const count=level.hatches.reduce((n,h)=>n+h.cats.length,0);document.getElementById('vaultArrivalCount').textContent=count+(count===1?' cat':' cats');identity.querySelector('h1').textContent=level.title;identity.querySelector('small').textContent=level.id+' · City Hall';}
   if(mode!==lastMode){lastMode=mode;document.body.classList.toggle('vault-won',mode==='won');}
  }
  function measure(v){
   if(!compact){v.insets=null;return;}
   const head=o.header.getBoundingClientRect();arrivals.style.top=(head.bottom+8)+'px';
   const showing=o.hud.root.classList.contains('on'),chapter=document.getElementById('chapterCard'),chapterOn=chapter&&!document.getElementById('chapterScene').hidden;
   arrivals.hidden=!showing;const top=showing?arrivals.getBoundingClientRect().bottom+10:head.bottom+10,bottom=chapterOn?innerHeight-chapter.getBoundingClientRect().top+12:showing?innerHeight-o.hud.root.getBoundingClientRect().top+12:16;
   if(!v.insets)v.insets={top:0,bottom:0,left:12,right:12};v.insets.top=Math.ceil(top);v.insets.bottom=Math.ceil(bottom);
  }
  function restoreFocus(mode){if(!compact)return;const active=document.activeElement;if(active?.tagName==='BUTTON'&&!active.disabled&&active.getClientRects().length&&!active.closest('[inert]'))return;(mode==='won'?o.hud.next:o.hud.send).focus({preventScroll:true});}
  const observer=new ResizeObserver(()=>o.invalidate());for(const n of [o.header,o.hud.root,o.hud.queue,document.getElementById('chapterCard')])observer.observe(n);
  const changed=()=>reconcile(document.body.classList.contains('cityhall-paper'));query.addEventListener('change',changed);
  return {reconcile,sync,measure,restoreFocus,dispose(){observer.disconnect();queueObserver.disconnect();restoreQueueArt();for(const im of document.querySelectorAll('.vault-piece'))im.remove();query.removeEventListener('change',changed);o.selector.removeEventListener('change',close);close();for(const s of slots){s.mark.before(s.node);s.mark.remove();}menu.remove();more.remove();identity.remove();arrivals.remove();options.remove();clearImage.remove();document.body.classList.remove('vault-phone','vault-won');}};
 }
 root.CityHallPhone={create};
})(globalThis);
