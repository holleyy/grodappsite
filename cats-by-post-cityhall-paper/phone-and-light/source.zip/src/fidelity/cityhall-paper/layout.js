/* Measured room-owned volumes. No canonical scene, puzzle or route is modified. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallLayout=api;})(globalThis,function(){
 'use strict';
 const volume=(id,x0,y0,z0,x1,y1,z1)=>({id,x0,y0,z0,x1,y1,z1});
 function create(){
  const gallery={z:46,width:22,rail:13},spring=138,crown=180;
  const columns=[];for(const x of [4,58,112,166,220])columns.push(volume('rear-column',x-3,1,0,x+3,8,spring));
  for(const y of [56,116,180])columns.push(volume('left-column',1,y-3,0,8,y+3,spring));
  columns.push(volume('vault-pier',217,51,0,224,58,spring));
  const beams=[volume('left-vault-beam',0,0,134,8,192,spring),volume('right-vault-beam',216,0,134,224,58,spring)];
  const ribs=[];for(const y of [4,21,38,55]){const points=[];for(let i=0;i<=40;i++){const x=4+216*i/40;points.push([x,y,spring+(crown-spring)*Math.sin(Math.PI*i/40)]);}points[0][2]=points.at(-1)[2]=spring;ribs.push(points);}
  const steps=[];for(let i=0;i<15;i++)steps.push(volume('tread-'+i,30,96-(i+1)*4,i*46/15,49,96-i*4,(i+1)*46/15));
  const stairs={steps,landing:volume('landing',18,22,44,49,36,46),approach:volume('approach',30,96,0,49,108,0)};
  const furniture=[volume('sorting-table',77,24,0,156,42,29),volume('tube-bank',162,2,0,207,22,31),volume('postmistress-desk',10,117,0,43,137,28),volume('bench',26,172,0,54,186,16),volume('palm-left',13,152,0,21,160,41),volume('palm-back',216,24,0,224,32,43),volume('trolley-left',42,138,0,56,154,22),volume('trolley-back',169,39,0,183,55,22)];
  const routes=[{id:'sorter',points:[[58,140,0],[58,54,0],[136,52,0],[172,52,0],[58,54,0],[58,140,0]]},{id:'worker-back',points:[[132,15.75,46],[180,15.75,46],[132,15.75,46]]},{id:'worker-left',points:[[15.75,118,46],[15.75,72,46],[15.75,118,46]]}];
  return {room:{w:224,d:192},gallery,columns,stairs,furniture,routes,vault:{spring,crown,ribs,beams},solids:[...columns,...steps,stairs.landing,...furniture],bounds:{left:-218,right:248,top:-186,bottom:232}};
 }
 return {create};
});
