# City Hall · Great Postal Vault

Room-owned Canvas presentation for the existing fifteen Hall deliveries. The
canonical host owns rules, traces, timing, placements, saves and chapter state.
The adapter only reads them. `createCityHallPaper(host)` installs a reversible
presentation and releases it even when loading is cancelled or fails.

All geometry uses world units: one tile is 16×16, projected with
`(x-y, (x+y)/2-z)`. A camera may translate and scale uniformly. No independent
simulation or progression controller belongs here.

Selected visual: `docs/review-images/cityhall-paper/refinement/great-postal-vault.webp`.
Reproduction and qualification are recorded in `studies/cityhall-paper/README.md`.
The study is separate from the production build; integration owns installation.
