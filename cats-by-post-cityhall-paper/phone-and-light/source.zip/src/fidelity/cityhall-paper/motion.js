/* Sample source postal routines with fractional-frame interpolation. Only
   presentation height changes: gallery soles sit on the measured z46 deck. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallMotion=api;})(globalThis,function(){
 'use strict';
 const ease=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
 function create(H,layout){
  const a=H.create(H.CFG),b=H.create(H.CFG);
  function makeOut(){return {workers:Array.from({length:3},()=>({x:0,y:0,z:0,face:0,action:'check',walk:-1,frame:0,carry:false,push:false,gripWeight:0,grip:{x:0,y:0,z:0}})),pm:{x:34,y:119,z:28,pose:0},pigeon:{x:8,y:40,z:140,face:0,peck:false},cat:{x:31,y:181,z:6,length:13,height:9,count:1,away:false,restVisible:true,pose:'nap',dir:0,phase:0},trolley:{x:176,y:47,z:0,distance:0,angle:0},parcel:{owner:'left-cart',x:49,y:146,z:20,w:7,d:5,h:5,count:1}};}
  function sample(time,chapter,out,motion=true){
   const sourceFrame=chapter?.mode==='exit'&&chapter.dispatch?chapter.dispatch.worldFrame:chapter?.mode&&chapter.mode!=='enter'?chapter.frame+(chapter.mode==='growth'?1200:600):time*60;
   const frame=motion?((sourceFrame)%2880+2880)%2880:0,lo=Math.floor(frame),t=frame-lo;H.step(a,lo);H.step(b,(lo+1)%2880);
   for(let i=0;i<3;i++){const q=out.workers[i],v=a.workers[i],n=b.workers[i];q.x=v.x+(n.x-v.x)*t;q.y=v.y+(n.y-v.y)*t;q.z=i?layout.gallery.z:0;q.face=v.face;q.action=v.action;q.walk=motion&&v.action==='walk'?v.frame:-1;q.frame=v.frame;q.carry=false;q.push=false;q.gripWeight=0;}
   const p=out.pm;p.pose=a.pm.bat<0?0:a.pm.bat;
   const bird=out.pigeon;bird.x=a.pigeon.x;bird.y=a.pigeon.y+(b.pigeon.y-a.pigeon.y)*t;bird.z=140;bird.face=a.pigeon.face;bird.peck=motion&&a.pigeon.state==='peck';
   const cat=out.cat,u=frame/60;cat.away=motion&&u>=22&&u<36;cat.restVisible=!cat.away;cat.pose='nap';cat.x=31;cat.y=181;cat.z=6;cat.dir=0;cat.phase=0;
   if(cat.away){const t=u-22;cat.pose='walk';cat.phase=t;
    if(t<1){const s=ease(t);cat.x=31;cat.y=181+9*s;cat.z=6*(1-s)+Math.sin(Math.PI*s)*5;cat.pose='jump';}
    else if(t<6){cat.x=31+14*ease((t-1)/5);cat.y=190;cat.z=0;cat.dir=0;}
    else if(t<8){cat.x=45;cat.y=190;cat.z=0;cat.pose='sit';}
    else if(t<13){cat.x=45-14*ease((t-8)/5);cat.y=190;cat.z=0;cat.dir=2;}
    else {const s=ease(t-13);cat.x=31;cat.y=190-9*s;cat.z=6*s+Math.sin(Math.PI*s)*5;cat.pose='jump';cat.dir=2;}
   }
   const parcel=out.parcel,cart=out.trolley,q=out.workers[0];
   cart.distance=0;cart.angle=0;cart.x=176;cart.y=47;
   parcel.owner='left-cart';parcel.x=49;parcel.y=146;parcel.z=20;
   if(motion&&!chapter?.mode){
    let fromX=49,fromY=146,toX=q.x+2,toY=q.y+3,toZ=13,t=0;
    if(frame<30){q.gripWeight=ease(frame/30);}
    else if(frame<90){parcel.owner='worker';q.gripWeight=1;t=ease((frame-30)/60);}
    else if(frame<1452){parcel.owner='worker';q.gripWeight=1;t=1;}
    else if(frame<1512){parcel.owner='worker';q.gripWeight=1;fromX=q.x+2;fromY=q.y+3;parcel.z=13;toX=176;toY=47;toZ=20;t=ease((frame-1452)/60);}
    else if(frame<1908){fromX=176;fromY=47;toX=176;toY=47;toZ=20;parcel.owner='right-cart';
     q.gripWeight=frame<1542?1-ease((frame-1512)/30):frame>=1878?ease((frame-1878)/30):0;
    }else if(frame<1944){parcel.owner='worker';q.gripWeight=1;fromX=176;fromY=47;t=ease((frame-1908)/36);}
    else if(frame<2796){parcel.owner='worker';q.gripWeight=1;t=1;}
    else if(frame<2856){parcel.owner='worker';q.gripWeight=1;fromX=q.x+2;fromY=q.y+3;parcel.z=13;toX=49;toY=146;toZ=20;t=ease((frame-2796)/60);}
    else {q.gripWeight=1-ease((frame-2856)/24);}
    parcel.x=fromX+(toX-fromX)*t;parcel.y=fromY+(toY-fromY)*t;parcel.z+=(toZ-parcel.z)*t;
    if(frame>=1542&&frame<1842){
     const u=(frame-1542)/300;cart.distance=12*Math.sin(Math.PI*u)**2;cart.angle=cart.distance/2;cart.x+=cart.distance;
     parcel.x=cart.x;parcel.y=cart.y;q.x+=cart.distance;q.push=true;q.action='walk';q.walk=Math.floor(cart.distance/4)%4;q.face=u<.5?1:2;
     q.gripWeight=ease(Math.min(frame-1542,1842-frame)/18);
    }
    q.grip.x=q.push?cart.x-4:parcel.x+3.5;q.grip.y=q.push?cart.y+7:parcel.y+2.5;q.grip.z=q.push?16:parcel.z+5;
   }
   // Dispatch and growth come directly from the chapter controller. No chapter
   // event, transition, result or rules tick is produced by this sampler.
   if(chapter?.mode==='exit'&&chapter.dispatch){const d=chapter.dispatch,q=out.workers[0];q.x=d.x;q.y=d.y;q.z=0;q.face=d.face;q.action=d.stopped?'check':'walk';q.walk=motion&&!d.stopped?a.workers[0].frame:-1;q.carry=true;}
   if(chapter?.mode==='growth'&&chapter.growth){const d=chapter.growth,q=out.workers[0];q.x=d.x;q.y=d.y;q.z=0;q.face=d.face;q.walk=motion?d.walk:-1;q.action=q.walk<0?'check':'walk';}
   return out;
  }
  return {makeOut,sample};
 }
 return {create};
});
