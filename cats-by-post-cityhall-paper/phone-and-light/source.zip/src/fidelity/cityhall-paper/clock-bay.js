/* One finished bay. Artwork receives measured faces; all work runs at bake time.
   The wall service chase is behind the gallery's occupied walking envelope. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallClockBay=api;})(globalThis,function(){
 'use strict';
 const quadrants={stone:[0,0],green:[627,0],gold:[0,627],wood:[627,627]};
 function layout(){return {
  lamps:[{x:166,y:15,z:90},{x:220,y:15,z:90}],
  clock:{x:140,y:9.5,z:93.8,width:41,height:41*4/3},pipeRadius:3.1,
  pipes:[[[108,5,116],[119,5,116],[119,5,64],[173,5,64],[173,5,130],[214,5,130],[214,5,32]]],
  mounts:[{x0:116,y0:0,z0:56,x1:131,y1:9,z1:68},{x0:211,y0:0,z0:52,x1:217,y1:9,z1:56}]
 };}
 function face(p,pts,kind,shade=0){
  const c=p.c,P=CityHallProjection,a=P.project(...pts[0]),b=P.project(...pts[1]),d=P.project(...pts[3]),uv=quadrants[kind];
  c.save();c.beginPath();for(let i=0;i<pts.length;i++){const q=P.project(...pts[i]);if(i)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);}c.closePath();c.clip();
  c.transform(b.x-a.x,b.y-a.y,d.x-a.x,d.y-a.y,a.x,a.y);c.drawImage(p.images['clock-bay-stock'],uv[0]+1,uv[1]+1,625,625,0,0,1,1);
  if(shade){c.fillStyle=shade>0?'#fff9e9':'#142a24';c.globalAlpha=Math.abs(shade);c.fillRect(0,0,1,1);}c.restore();
 }
 function box(p,x,y,z,w,d,h,kind='stone'){
  face(p,[[x,y+d,z+h],[x+w,y+d,z+h],[x+w,y+d,z],[x,y+d,z]],kind,-.06);
  face(p,[[x+w,y+d,z+h],[x+w,y,z+h],[x+w,y,z],[x+w,y+d,z]],kind,-.23);
  face(p,[[x,y,z+h],[x+w,y,z+h],[x+w,y+d,z+h],[x,y+d,z+h]],kind,.12);
  p.line([x,y+d,z+h],[x+w,y+d,z+h],'#fff0ca',.22);
 }
 function rearImage(p,name,x,y,z,w,h,alpha=1){const a=CityHallProjection.project(x-w/2,y,z+h/2),c=p.c;c.save();c.transform(1,.5,0,1,a.x,a.y);c.globalAlpha=alpha;c.drawImage(p.images[name],0,0,w,h);c.restore();}
 function wall(p){
  // Each ivory course is a receiving wall face, not a second window backdrop.
  for(let z=52;z<133;z+=9)for(let x=116;x<162;x+=23){const x1=Math.min(162,x+23);face(p,[[x,0.4,z+8.8],[x1,0.4,z+8.8],[x1,0.4,z],[x,0.4,z]],'stone',(z/9)%2?.03:0);p.line([x,.6,z],[x1,.6,z],'#b7a78d',.18);}
  const u0=176,u1=211,r=(u1-u0)/2,mid=(u0+u1)/2,spring=127-r;
  for(const x of [u0-3.7,u1]){box(p,x,0,55,3.7,4.7,spring-55);box(p,x-.5,-.3,54,4.7,5.7,2);}
  for(let i=0;i<14;i++){
   const a=i*Math.PI/14,b=(i+1)*Math.PI/14,at=(v,rr,y)=>[mid+Math.cos(v)*rr,y,spring+Math.sin(v)*rr];
   face(p,[at(a,r+3.7,4.7),at(b,r+3.7,4.7),at(b,r,4.7),at(a,r,4.7)],'stone',i<7?-.06:.03);
   face(p,[at(a,r,4.7),at(b,r,4.7),at(b,r,0),at(a,r,0)],'stone',-.25);
   p.line(at(a,r,4.8),at(a,r+3.7,4.8),'#c1af8c',.22);
  }
  box(p,mid-2,1,125.5,4,5.5,6,'stone');box(p,u0-4,-1,51,u1-u0+8,8,3);box(p,u0-4.5,-1.3,53.5,u1-u0+9,8.8,.8,'gold');
  for(const x of [166,220]){
   box(p,x-2.8,7.9,61,5.6,.6,65,'green');
   for(const dx of [-1.65,0,1.65]){p.line([x+dx,8.7,64],[x+dx,8.7,122],'#173c31',.5);p.line([x+dx-.27,8.7,64],[x+dx-.27,8.7,122],'#b0b783',.23);}
   box(p,x-4,0,126,8,9,1.5,'gold');box(p,x-4.7,-.4,127.5,9.4,10,3,'green');box(p,x-5.5,-1,130.5,11,11,1.2,'gold');
   for(let k=-3;k<=3;k+=2)box(p,x+k-.5,9,128,.9,1.1,2.1,'gold');
  }
  box(p,116,-1,132,108,6,2,'gold');box(p,116,-2,134,108,7.5,3.5);box(p,116,-2.6,137.5,108,8.6,.8);
  for(let x=118;x<224;x+=5)box(p,x,3.7,130.5,2.2,1.6,1.7);
 }
 function gallery(p){
  box(p,112,21,37.5,112,2.5,5,'green');box(p,112,20.8,42.5,112,3.4,1.2,'gold');box(p,112,21,43.7,112,4,2.3);
  for(let x=116;x<222;x+=5)box(p,x,23.6,39.6,1.8,.8,1.8,'gold');
  for(const x of [112,164,218]){
   box(p,x-2.5,18.5,0,5,5,36.5,'green');box(p,x-3.5,18,0,7,6,3);box(p,x-3.5,18,34,7,6,2,'gold');
   for(const sign of [-1,1]){const points=[[x,24,36],[x+sign*10,24,40],[x+sign*7,24,36],[x,24,29]];face(p,points,'green');p.line(points[1],points[2],'#e5c57a',.5);p.line(points[2],points[3],'#e5c57a',.5);}
  }
 }
 function rail(p){
  const y=23.4;
  for(let x=114;x<224;x+=5.3){box(p,x,y,47,.8,1,10.8,'green');box(p,x-.2,y-.1,52,1.2,1.2,.9,'gold');}
  box(p,112,y,47,112,1.3,1.3,'green');box(p,112,y,56.8,112,1.6,1.5,'green');box(p,111.5,y-.5,58.3,113,2.6,1.1,'gold');box(p,111.5,y-.65,59.4,113,2.9,.6,'gold');
  for(const x of [112,140,168,196,224]){box(p,x-1,y-.6,46,2,2.6,14,'green');box(p,x-1.4,y-.9,59.7,2.8,3.2,1,'gold');p.ellipse(x,y+.6,62,1.25,1.25,'#e5c775','#94723d',.25);}
  // Full retained crest on two small plaques; open balusters retain the worker.
  for(const x of [140,196]){box(p,x-5,y+.8,49,10,1,7.6,'green');rearImage(p,'crest',x,y+1.9,52.8,8.8,5.65);}
 }
 function pipe(p,points){
  const c=p.c,q=points.map(a=>CityHallProjection.project(...a)),path=new Path2D();path.moveTo(q[0].x,q[0].y);
  for(let i=1;i<q.length-1;i++){const a=q[i-1],b=q[i],d=q[i+1],l=Math.hypot(a.x-b.x,a.y-b.y),m=Math.hypot(d.x-b.x,d.y-b.y),r=Math.min(4,l*.3,m*.3);path.lineTo(b.x+(a.x-b.x)/l*r,b.y+(a.y-b.y)/l*r);path.quadraticCurveTo(b.x,b.y,b.x+(d.x-b.x)/m*r,b.y+(d.y-b.y)/m*r);}path.lineTo(q.at(-1).x,q.at(-1).y);
  c.save();c.translate(1.2,1.3);c.strokeStyle='#30433738';c.lineWidth=7.8;c.stroke(path);c.restore();
  for(const [w,col]of [[6.2,'#876233'],[5.3,'#b18a41'],[3.7,'#d6b262'],[1.8,'#e5c777']]){c.strokeStyle=col;c.lineWidth=w;c.lineCap='round';c.stroke(path);}
  c.save();c.translate(-.7,-.7);c.lineWidth=.55;c.strokeStyle='#fff0bc';c.stroke(path);c.restore();
  for(let i=1;i<q.length;i++){const a=q[i-1],b=q[i],len=Math.hypot(b.x-a.x,b.y-a.y),dx=(b.x-a.x)/len,dy=(b.y-a.y)/len,n=Math.max(1,Math.floor(len/14));for(let j=0;j<n;j++){const t=(j+.5)/n,x=a.x+(b.x-a.x)*t,y=a.y+(b.y-a.y)*t;c.beginPath();c.moveTo(x-dy*3.3,y+dx*3.3);c.lineTo(x+dy*3.3,y-dx*3.3);c.lineWidth=1.6;c.strokeStyle='#9c783e';c.stroke();c.lineWidth=.7;c.strokeStyle='#e8cd87';c.stroke();}}
 }
 function pipes(p){
  const b=layout();for(const path of b.pipes)pipe(p,path);
  // Wall feet support the service body and the lower return. No gallery post.
  for(const m of b.mounts){box(p,m.x0,m.y0,m.z0,m.x1-m.x0,1,m.z1-m.z0,'green');box(p,m.x0+1,1,m.z0+1,m.x1-m.x0-2,m.y1-1,1.5,'gold');}
  box(p,116.5,2,57,13,6.5,10,'gold');for(const z of [57,66])box(p,116,1.7,z,14,7.1,1,'gold');
  for(const x of [120,126]){const a=CityHallProjection.project(x,9,62),c=p.c;c.save();c.transform(1,.5,0,1,a.x,a.y);c.beginPath();c.arc(0,0,2.8,0,Math.PI*2);c.fillStyle='#e8c775';c.fill();c.strokeStyle='#8e6d36';c.lineWidth=.5;c.stroke();c.beginPath();c.arc(0,0,2.1,0,Math.PI*2);c.fillStyle='#f9edcf';c.fill();for(let i=0;i<8;i++){const a=i*Math.PI/4;c.beginPath();c.moveTo(Math.sin(a)*1.55,Math.cos(a)*1.55);c.lineTo(Math.sin(a)*1.85,Math.cos(a)*1.85);c.strokeStyle='#335d4c';c.lineWidth=.15;c.stroke();}c.beginPath();c.moveTo(0,0);c.lineTo(-.6,-1.2);c.lineWidth=.3;c.stroke();c.restore();}
  for(const [x,z]of [[119,98],[173,91],[214,99]]){box(p,x-2,0,z-2,4,1,4,'green');box(p,x-1,1,z-1,2,5,1.5,'gold');}
 }
 function lamps(p){
  for(const {x,z}of layout().lamps){
   // The small warm pool is received by the column, behind the physical lamp.
   const a=CityHallProjection.project(x,8.8,z+2),c=p.c;c.save();c.translate(a.x,a.y);c.transform(1,.5,0,1,0,0);const g=c.createRadialGradient(0,0,1,0,0,10);g.addColorStop(0,'#ffdc7c55');g.addColorStop(1,'#ffdc7c00');c.fillStyle=g;c.fillRect(-10,-10,20,20);c.restore();
   box(p,x-1.7,8,z+7,3.4,1.2,4,'gold');box(p,x-.6,9,z+9,1.2,7,1.3,'gold');p.line([x,15,z+9],[x,15,z+6],'#d3aa52',.85);
   p.box(x-2,13,z-1,4,4,6,['#fff0b5','#ffe19b','#ebc576']);
   for(const dx of [-2,2])for(const dy of [13,17])p.line([x+dx,dy,z-1],[x+dx,dy,z+5],'#a87932',.45);
   box(p,x-2.4,12.6,z-1.5,4.8,4.8,.8,'gold');box(p,x-2.5,12.5,z+5,5,5,.7,'gold');
   p.face([[x-2.5,12.5,z+5.7],[x+2.5,12.5,z+5.7],[x,15,z+7.3]],'#efce78','#c09542',.2);p.face([[x+2.5,12.5,z+5.7],[x+2.5,17.5,z+5.7],[x,15,z+7.3]],'#b98d41','#c09542',.2);
  }
 }
 function clock(p){
  const a=layout().clock,c=p.c;
  // A real projecting mount and opaque card layers hold the original full art.
  box(p,a.x-8,0,80,16,8,20,'green');
  c.save();c.shadowColor='#253a3466';c.shadowBlur=1.2;c.shadowOffsetX=1.4;c.shadowOffsetY=1.8;rearImage(p,'clock-bay-clock',a.x,8.6,a.z-.6,a.width,a.height);c.restore();
  rearImage(p,'clock-bay-clock',a.x,a.y,a.z,a.width,a.height);
 }
 return {layout,wall,gallery,rail,pipes,clock,lamps,paperBox:box,paperFace:face,paperPipe:pipe,rearImage};
});
