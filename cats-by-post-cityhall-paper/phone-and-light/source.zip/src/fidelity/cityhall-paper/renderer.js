/* Prepared scenery and board, live registered pieces; no game session here. */
(function(root){
 'use strict';
 const P=CityHallProjection,K=16/(380/6),sort=(a,b)=>a.depth-b.depth||a.order-b.order;
 class CityHallRenderer{
  constructor(canvas,assets,layout){
   this.canvas=canvas;this.ctx=canvas.getContext('2d');this.assets=assets;this.layout=layout;this.images={};this.ready=false;this.closed=false;this.bakes=0;this.cam={scale:1,tx:0,ty:0};this.board={x:64,y:64,w:7,h:5};this.vp={width:1,height:1,dpr:1,view:'hall'};this.level=null;this.traces=[];this.traceSources=[];this.traceViews=[];this.items=[];this.pool=[];this.poses=[];this.acting=CityHallActing.create(BOARDANIM,paperBoardFlapPose);this.posePool=Array.from({length:32},()=>this.acting.makeOut());this.tmp={x:0,y:0};this.selectedPoints=Array.from({length:4},()=>({x:0,y:0}));this.fonts=Array.from({length:64},(_,i)=>i+'px Trebuchet MS,sans-serif');this.growthPortals=[[{x:0,y:5,symbol:'circle',pair:0},{x:1,y:1,symbol:'circle',pair:0}],[{x:7,y:0,symbol:'square',pair:0},{x:1,y:1,symbol:'square',pair:0}]];this.countLabels=Array.from({length:33},(_,i)=>String(i));this.resourcesRecord={bytes:0,buffers:0,bakes:0,scope:'owned canvas backing estimate only; excludes decoded images, host, browser/GPU and process peak'};for(let i=0;i<180;i++)this.pool.push({kind:'',index:0,depth:0,order:0});
  }
  async load(){
   await Promise.all(Object.keys(this.assets.images).map(async name=>{const image=new Image();image.src=this.assets.images[name];await image.decode();if(!this.closed)this.images[name]=image;}));
   if(this.closed)return;this.carriers=new CityHallCarriers(this);this.flaps=new CityHallFlaps(this);this.flapSource={n:0,traces:this.traces,times:[]};this.bake();if(typeof CityHallActors!=='undefined')this.actors=new CityHallActors(this);this.ready=true;this.census();
  }
  layer(bounds,draw,density=4){const canvas=document.createElement('canvas');canvas.width=Math.ceil((bounds.right-bounds.left)*density);canvas.height=Math.ceil((bounds.bottom-bounds.top)*density);const ctx=canvas.getContext('2d');ctx.setTransform(density,0,0,density,-bounds.left*density,-bounds.top*density);draw(new CityHallMaterials.Painter(ctx,this.images));this.bakes++;return {canvas,left:bounds.left,top:bounds.top,width:canvas.width/density,height:canvas.height/density};}
  bake(){this.background=CityHallDaylight.prepare(this.ctx,this.images);this.bakes+=2;this.exterior=this.layer({left:-700,right:700,top:-570,bottom:450},p=>CityHallBackdrop.draw(p),2);this.exteriorFront=this.layer({left:-350,right:350,top:70,bottom:340},p=>CityHallEnvironment.foreground(p),2);this.architecture=this.layer(this.layout.bounds,p=>CityHallArchitecture.draw(p,this.layout));this.foreground=this.layer(this.layout.bounds,p=>CityHallArchitecture.foreground(p));this.boardLayers=new Map();for(const [w,h]of [[7,5],[7,6],[8,6]])this.boardLayers.set(w*16+h,this.layer({left:-h*16-3,right:w*16+3,top:-3,bottom:(w+h)*8+5},p=>this.paintBoard(p,w,h)));}
  paintBoard(p,w,h){
   p.box(-1,-1,-1,w*16+2,h*16+2,1.4,'green');
   for(let y=0;y<h;y++)for(let x=0;x<w;x++){p.face([[x*16,y*16,.45],[(x+1)*16,y*16,.45],[(x+1)*16,(y+1)*16,.45],[x*16,(y+1)*16,.45]],'#f4e7ce','#bea986',.25);p.planeImage('material-marble',x*16,y*16,.46,16,16,'floor',.42);}
   for(let x=1;x<w;x++)p.line([x*16,0,.5],[x*16,h*16,.5],'#b9a783',.25);for(let y=1;y<h;y++)p.line([0,y*16,.5],[w*16,y*16,.5],'#b9a783',.25);
   for(const [x,y]of [[-1,-1],[w*16-3,-1],[-1,h*16-3],[w*16-3,h*16-3]])p.box(x,y,.5,4,4,.6,'gold');
  }
  prepare(f,viewport){
   if(!this.ready)return;
   if(this.level!==f.level){this.level=f.level;this.board.w=f.level.board.w;this.board.h=f.level.board.h;this.board.x=f.originX;this.board.y=f.originY;
    let first=0;this.hatches=f.level.hatches.map(h=>{const a={...h,first};first+=h.cats.length;return a;});this.hatchStates=this.hatches.map(()=>this.acting.makeHatchOut());this.dogStates=(f.level.dogs||[]).map(()=>this.acting.makeDogOut());
    this.preview=this.hatches.map(h=>{const o=this.acting.makeOut();o.anim=BOARDANIM.A.IDLE;o.x=h.x*16+8;o.y=h.y*16+8;o.dir=o.head=CityHallRules.GR_DIR[h.dir];return o;});this.previewTraces=this.hatches.map(h=>({coat:(typeof h.cats[0]==='string'?h.cats[0]:h.cats[0].coat)==='blue'?2:1}));
    this.portals=[];for(let i=0;i<(f.level.tunnels||[]).length;i++){const t=f.level.tunnels[i];this.portals.push({x:t.a.x,y:t.a.y,symbol:t.symbol,pair:i,open:false},{x:t.b.x,y:t.b.y,symbol:t.symbol,pair:i,open:false});}this.gateStates=(f.level.gates||[]).map(()=>BOARDANIM.makeGateOut());this.edgeFlaps=(f.level.flaps||[]).map(v=>({...v,side:CityHallRules.GR_DIR[v.side],coat:v.coat==='blue'?2:1}));this.flapStates=this.edgeFlaps.map(()=>0);this.carriers.prepareBoard(this.board.w,this.board.h);
   }
   const dpr=Math.min(2,viewport.dpr||1),w=Math.round(viewport.width*dpr),h=Math.round(viewport.height*dpr);
   if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;this.census();}
   this.vp=viewport;this.dpr=dpr;P.camera(viewport,this.layout,this.board,this.cam);
   if(f.chapter?.mode){
    if(!this.chapterCamera){this.chapterCamera={scale:1,tx:0,ty:0};this.chapterViewport={width:0,height:0,view:'hall',zoom:1,panX:0,panY:0};}
    this.chapterViewport.width=viewport.width;this.chapterViewport.height=viewport.height;this.chapterViewport.insets=viewport.insets;P.camera(this.chapterViewport,this.layout,this.board,this.chapterCamera);
    const t=f.chapter.mode==='enter'?Math.min(1,f.chapter.frame/72):0,u=t*t*(3-2*t);this.cam.scale=this.chapterCamera.scale+(this.cam.scale-this.chapterCamera.scale)*u;this.cam.tx=this.chapterCamera.tx+(this.cam.tx-this.chapterCamera.tx)*u;this.cam.ty=this.chapterCamera.ty+(this.cam.ty-this.chapterCamera.ty)*u;
   }
   this.selectedPair=-1;if(f.selected)for(let i=0;i<(f.level.tunnels?.length||0);i++){const a=f.level.tunnels[i],s=f.selected;if(a.a.x===s.x&&a.a.y===s.y||a.b.x===s.x&&a.b.y===s.y){this.selectedPair=i;break;}}
   const n=f.traces?f.traces.length:0;this.traces.length=this.poses.length=n;
   for(let i=0;i<n;i++){const tr=f.traces[i];if(this.traceSources[i]!==tr){this.traceSources[i]=tr;const v=this.traceViews[i]=Object.create(tr);v.ox=v.oy=0;}this.traces[i]=this.traceViews[i];this.poses[i]=this.posePool[i];this.acting.sample(this.traces[i],f.time,this.poses[i]);}
   for(const p of this.portals){p.open=false;for(let i=0;i<n;i++){const o=this.poses[i],tr=this.traces[i];if(o.tunnelPair!==p.pair)continue;const k=Math.floor((f.time+1e-9-tr.rel)/tr.tick);if(k<0||k>=tr.n)continue;if(o.tunnelPhase===1||o.tunnelPhase===0&&tr.entryX[k]===p.x&&tr.entryY[k]===p.y||o.tunnelPhase===2&&tr.x1[k]===p.x&&tr.y1[k]===p.y){p.open=true;break;}}}
   for(let i=0;i<this.hatches.length;i++)this.acting.hatch(this.hatches[i],this.traces,f.time,this.hatchStates[i]);
   for(let i=0;i<this.dogStates.length;i++)this.acting.dog(f.level.dogs[i],i,this.poses,f.motion?f.sceneTime:0,this.dogStates[i]);
   for(let i=0;i<this.gateStates.length;i++)BOARDANIM.gatePose(f.gateTrace,i,f.time,this.gateStates[i]);
   this.flapSource.n=n;this.flapSource.times.length=n;for(let i=0;i<n;i++)this.flapSource.times[i]=f.time;for(let i=0;i<this.edgeFlaps.length;i++)this.flapStates[i]=paperFlapDoorState(this.flapSource,this.edgeFlaps[i]);
   this.carriers.motion=f.motion;this.carriers.beginFrame();
  }
  path(points,fill,stroke,width=1){const c=this.ctx;c.beginPath();for(let i=0;i<points.length;i++){const p=points[i];if(i)c.lineTo(p.x,p.y);else c.moveTo(p.x,p.y);}c.closePath();if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=width;c.stroke();}}
  shadow(x,y,rx,ry,alpha=.13){const c=this.ctx;c.save();c.globalAlpha*=alpha;c.fillStyle='#453b30';c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fill();c.restore();}
  label(text,p,color,size){const c=this.ctx;c.font=this.fonts[size];c.textAlign='center';c.fillStyle=color;c.fillText(text,p.x,p.y);}
  composite(layer){this.ctx.drawImage(layer.canvas,layer.left,layer.top,layer.width,layer.height);}
  item(kind,index,depth,order=0){const q=this.pool[this.items.length];q.kind=kind;q.index=index;q.depth=depth;q.order=order;this.items.push(q);}
  draw(f){
   if(!this.ready)return;const c=this.ctx,cam=this.cam,B=this.board,L=f.level;
   c.setTransform(this.dpr,0,0,this.dpr,0,0);c.clearRect(0,0,this.vp.width,this.vp.height);c.save();if(f.gray)c.filter='grayscale(1)';c.translate(cam.tx,cam.ty);c.scale(cam.scale,cam.scale);CityHallDaylight.background(c,this.background,cam,this.vp);this.composite(this.exterior);this.composite(this.architecture);this.composite(this.exteriorFront);
   c.save();c.translate(B.x-B.y,(B.x+B.y)*.5);this.composite(this.boardLayers.get(B.w*16+B.h));
   if(f.selected){const x=f.selected.x*16,y=f.selected.y*16,q=this.selectedPoints;P.project(x,y,0,q[0]);P.project(x+16,y,0,q[1]);P.project(x+16,y+16,0,q[2]);P.project(x,y+16,0,q[3]);this.path(q,'#fff9dc44','#39766c',.75);}
   if(f.presentation==='growth'){
    this.growth(f);c.restore();if(this.actors)this.actors.draw(f);this.composite(this.foreground);c.restore();return;
   }
   c.scale(K,K);for(const t of f.turns||[])this.carriers.table(t,0);for(let i=0;i<this.hatches.length;i++)this.carriers.hatch(this.hatches[i],this.hatchStates[i]);for(let i=0;i<this.hatches.length;i++)this.queue(this.hatchStates[i],f.mode==='edit');
   this.items.length=0;for(const f of this.edgeFlaps)this.flaps.band(f);
   for(let i=0;i<L.baskets.length;i++){const b=L.baskets[i],d=(b.x+b.y+1)*8;this.item('basket',i,d-1);this.item('basket-front',i,d+6,5);}
   for(let i=0;i<(L.dogs||[]).length;i++)this.item('dog',i,(L.dogs[i].x+L.dogs[i].y+1)*8+1);
   for(let i=0;i<this.portals.length;i++){const p=this.portals[i],d=(p.x+p.y+1)*8;this.item('portal',i,d-5);this.item('portal-front',i,d+6,6);}
   for(let i=0;i<(L.gates||[]).length;i++)this.item('gate',i,(L.gates[i].x+L.gates[i].y+1)*8);
   for(let i=0;i<this.edgeFlaps.length;i++){const f=this.edgeFlaps[i];this.item('flap',i,(f.x+f.y+1)*8+(f.side<2?20:-12));}
   if(f.mode==='edit')for(let i=0;i<this.hatches.length;i++)this.item('preview',i,(this.hatches[i].x+this.hatches[i].y+1)*8+1);
   else for(let i=0;i<this.poses.length;i++){const o=this.poses[i];if(o.box.visible&&!o.box.occupied)this.item('box',i,(o.boxX+o.boxY)*.5+1);if(!o.cat.visible)continue;this.item(o.flapPose>=0?'flap-cat':o.cat.boxed?'boxed':'cat',i,(o.x+o.y)*.5+2,1);}
   this.items.sort(sort);for(const it of this.items){const i=it.index,o=this.poses[i],tr=this.traces[i];switch(it.kind){
    case 'basket':this.carriers.basket(L.baskets[i]);break;case 'basket-front':this.carriers.basket(L.baskets[i],true);break;case 'dog':this.carriers.dog(L.dogs[i],i,this.dogStates[i]);break;
    case 'preview':this.carriers.boxed(this.preview[i],this.previewTraces[i],f.sceneTime);break;case 'box':this.carriers.carrier(o.boxX,o.boxY,tr.d0[tr.n-1],o.boxFold,o.boxFade);break;
    case 'boxed':this.boxed(o,tr,f.time);break;case 'cat':this.carriers.loose(o,tr,f.time);break;case 'flap-cat':this.flaps.cat(o,tr);break;
    case 'portal':case 'portal-front':this.portal(this.portals[i],it.kind==='portal-front',f);break;
    case 'gate':this.gate(L.gates[i],this.gateStates[i]);break;case 'flap':this.flaps.door(this.edgeFlaps[i],this.flapStates[i]);break;
   }}
   for(let i=0;i<this.hatches.length;i++)if(this.hatchStates[i].open)this.carriers.hatchFront(this.hatches[i]);c.restore();
   if(this.actors)this.actors.draw(f);this.composite(this.foreground);c.restore();
  }
  queue(s,preview){const c=this.ctx;for(let i=s.n-1;i>=(preview?1:0);i--){const q=s.queue[i],p=this.carriers.point(q.x,q.y,.5);c.save();c.translate(p.x,p.y);c.fillStyle='#efe0b9';c.strokeStyle='#a98d5d';c.lineWidth=1;c.beginPath();c.roundRect(-11,-12,22,15,2);c.fill();c.stroke();this.carriers.asset(q.coat===2?'blue-bust-front':'ginger-bust-front',0,0,17);c.restore();}if(s.waiting>4){const p=this.carriers.point(s.x,s.y);this.label(this.countLabels[s.waiting],p,'#355c50',14);}}
  boxed(o,tr,time){const c=this.ctx;let clip=false;if(o.tunnelPair>=0&&o.z<0){clip=true;const p=this.carriers.point(o.x,o.y);c.save();c.beginPath();c.moveTo(p.x-43,p.y-400);c.lineTo(p.x+43,p.y-400);c.lineTo(p.x+43,p.y);c.quadraticCurveTo(p.x,p.y+30,p.x-43,p.y);c.closePath();c.clip();}this.carriers.boxed(o,tr,time);if(clip)c.restore();}
  portal(t,front,f){const c=this.ctx,p=this.carriers.centre(t.x,t.y),active=this.selectedPair===t.pair;c.save();c.translate(p.x,p.y);c.lineWidth=2;c.strokeStyle=active?'#2c766f':'#aa8846';
   if(!front){this.shadow(0,3,45,20,.15);c.fillStyle='#b18c45';c.beginPath();c.ellipse(0,0,43,21.5,0,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='#efcf85';c.beginPath();c.ellipse(0,-7,43,21.5,0,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='#3e5c52';c.beginPath();c.ellipse(0,-7,31,15.5,0,0,Math.PI*2);c.fill();c.fillStyle=t.open?'#253c36':'#f4e8cb';c.beginPath();c.ellipse(0,-7,26,13,0,0,Math.PI*2);c.fill();if(t.open){c.fillStyle='#efcf85';c.beginPath();c.ellipse(32,10,12,6,0,0,Math.PI*2);c.fill();this.symbol(t.symbol,32,10,7,'#315e57');}else this.symbol(t.symbol,0,-7,18,'#315e57');}
   else{c.beginPath();c.ellipse(0,-7,43,21.5,0,0,Math.PI);c.strokeStyle=active?'#3c8d7d':'#f5dc9b';c.lineWidth=3;c.stroke();}c.restore();}
  symbol(name,x,y,r,color){const c=this.ctx;c.save();c.translate(x,y);c.scale(1,.5);c.strokeStyle=color;c.lineWidth=3;c.beginPath();if(name==='circle')c.arc(0,0,r,0,Math.PI*2);else if(name==='square')c.rect(-r*.8,-r*.8,r*1.6,r*1.6);else if(name==='triangle'){c.moveTo(0,-r);c.lineTo(r,r*.8);c.lineTo(-r,r*.8);c.closePath();}else{c.moveTo(0,-r);c.lineTo(r,0);c.lineTo(0,r);c.lineTo(-r,0);c.closePath();}c.stroke();c.restore();}
  gate(g,state){
   const c=this.ctx,pcs=this.carriers,q=this.selectedPoints;
   for(let i=0;i<4;i++){const x=g.x+(i===1||i===2?.84:.16),y=g.y+(i>=2?.84:.16),p=pcs.project(x,y,2);q[i].x=p.x;q[i].y=p.y;}this.path(q,'#c4a364','#f4dfad',2);
   for(let i=0;i<2;i++)pcs.arrow(g.x,g.y,CityHallRules.GR_DIR[g.exits[i]],3,i===state.state?'#285c50':'#ac9063');
   const from=CityHallRules.GR_DIR[g.exits[state.from]],to=CityHallRules.GR_DIR[g.exits[state.state]],delta=((to-from+6)%4)-2,t=Math.min(1,(state.frame+1)/3),a=(from+delta*t)*Math.PI/2;
   const p=pcs.centre(g.x,g.y),end=pcs.project(g.x+.5+Math.cos(a)*.27,g.y+.5+Math.sin(a)*.27,6);
   c.beginPath();c.moveTo(p.x,p.y-6);c.lineTo(end.x,end.y);c.strokeStyle='#edd8a1';c.lineWidth=9;c.lineCap='round';c.stroke();c.strokeStyle='#4c7160';c.lineWidth=5;c.stroke();
   c.fillStyle='#efdbab';c.beginPath();c.arc(p.x,p.y-6,4,0,Math.PI*2);c.fill();
  }
  growth(f){
   const m=f.chapter.growth,stage=f.chapter.stage;this.ctx.save();this.ctx.scale(K,K);for(const p of this.growthPortals[stage-1]){this.portal(p,false,f);this.portal(p,true,f);}this.ctx.restore();if(!m||!m.visible)return;
   const c=this.ctx,q=this.selectedPoints,u=m.u;
   // Same measured runner origin/length as drawHallChapter: (84,144)+92u
   // or (176,84)+76u, relative to the board's (64,64) origin.
   const x0=stage===1?20+92*u:112,y0=stage===1?80:20+76*u,x1=stage===1?112:128,y1=96;
   P.project(x0,y0,.8,q[0]);P.project(x1,y0,.8,q[1]);P.project(x1,y1,.8,q[2]);P.project(x0,y1,.8,q[3]);this.path(q,'#b36350','#e4bd8b',.7);
   const a=P.project(x0,y0,2,this.tmp);c.beginPath();c.moveTo(a.x,a.y);const b=P.project(stage===1?x0:x1,stage===1?y1:y0,2,this.tmp);c.lineTo(b.x,b.y);c.strokeStyle='#ad8160';c.lineWidth=4;c.lineCap='round';c.stroke();c.strokeStyle='#e0b18a';c.lineWidth=2.6;c.stroke();
   const strap=P.project(stage===1?x0:x0+1,stage===1?y0+1:y0,2,this.tmp);c.beginPath();c.moveTo(strap.x,strap.y);const hand=P.project(stage===1?x0+10:x0-10,stage===1?y0-10:y0+10,11,this.tmp);c.lineTo(hand.x,hand.y);c.strokeStyle='#c39b52';c.lineWidth=1;c.stroke();
  }
  census(){let bytes=this.canvas.width*this.canvas.height*4,buffers=1;for(const layer of [this.exterior,this.exteriorFront,this.architecture,this.foreground,...(this.boardLayers?this.boardLayers.values():[])])if(layer){bytes+=layer.canvas.width*layer.canvas.height*4;buffers++;}if(this.carriers)for(const canvas of this.carriers.carriers){bytes+=canvas.width*canvas.height*4;buffers++;}if(this.actors){bytes+=this.actors.pigeon.width*this.actors.pigeon.height*4;buffers++;for(const layer of [this.actors.cart,this.actors.parcel]){bytes+=layer.canvas.width*layer.canvas.height*4;buffers++;}}if(this.background)for(const canvas of [this.background.tile,this.background.skyline]){bytes+=canvas.width*canvas.height*4;buffers++;}this.resourcesRecord.bytes=bytes;this.resourcesRecord.buffers=buffers;this.resourcesRecord.bakes=this.bakes;}
  resources(){return this.resourcesRecord;}
  dispose(){if(this.closed)return;this.closed=true;this.ready=false;if(this.background){for(const c of [this.background.tile,this.background.skyline])c.width=c.height=0;this.background=null;}this.images={};if(this.flaps)this.flaps.dispose();this.flaps=null;if(this.actors)this.actors.dispose();this.actors=null;for(const layer of [this.exterior,this.exteriorFront,this.architecture,this.foreground,...(this.boardLayers?this.boardLayers.values():[])])if(layer){layer.canvas.width=layer.canvas.height=0;}if(this.carriers)for(const canvas of this.carriers.carriers)canvas.width=canvas.height=0;this.boardLayers?.clear();this.canvas.width=this.canvas.height=0;this.traces.length=this.traceViews.length=this.traceSources.length=0;this.resourcesRecord.bytes=this.resourcesRecord.buffers=0;}
 }
 root.CityHallRenderer=CityHallRenderer;
})(globalThis);
