/* Room-local gestures. The host still decides what a tap does. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallInput=api;})(globalThis,function(){
 function create(v,tap,hover,invalidate){
  const a={id:-1,x:0,y:0,startX:0,startY:0},b={id:-1,x:0,y:0};let dragged=false;
  function cancel(){a.id=b.id=-1;dragged=false;}
  function down(id,x,y){if(a.id<0){a.id=id;a.x=a.startX=x;a.y=a.startY=y;dragged=false;}else if(b.id<0){b.id=id;b.x=x;b.y=y;dragged=true;}}
  function move(id,x,y){const p=id===a.id?a:id===b.id?b:null;if(!p){hover(x,y);return;}
   if(b.id>=0){const distance=Math.hypot(a.x-b.x,a.y-b.y),cx=(a.x+b.x)/2,cy=(a.y+b.y)/2;p.x=x;p.y=y;
    if(distance>0){const next=Math.max(.7,Math.min(2.5,v.zoom*Math.hypot(a.x-b.x,a.y-b.y)/distance)),ratio=next/v.zoom,nx=(a.x+b.x)/2,ny=(a.y+b.y)/2,i=v.insets,ox=(v.width+(i?i.left-i.right:0))/2,oy=(v.height+(i?i.top-i.bottom:0))/2;v.panX=nx-ox-ratio*(cx-ox-v.panX);v.panY=ny-oy-ratio*(cy-oy-v.panY);v.zoom=next;invalidate();}return;
   }
   if(Math.hypot(x-a.startX,y-a.startY)>6)dragged=true;if(dragged){v.panX+=x-a.x;v.panY+=y-a.y;invalidate();}else hover(x,y);a.x=x;a.y=y;
  }
  function up(id,x,y){if(id===b.id){b.id=-1;dragged=true;return;}if(id!==a.id)return;if(b.id>=0){a.id=b.id;a.x=a.startX=b.x;a.y=a.startY=b.y;b.id=-1;dragged=true;return;}const place=!dragged;cancel();if(place)tap(x,y);}
  return {down,move,up,cancel};
 }
 return {create};
});
