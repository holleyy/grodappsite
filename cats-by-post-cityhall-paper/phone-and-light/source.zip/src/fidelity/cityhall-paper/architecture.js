/* Cutaway vault, receiving beams and supported working gallery. */
(function(root){
 'use strict';
 const P=CityHallProjection,cream='#f7ebd3',green='#335d4c',gold='#d9b45e';
 function windows(p,axis,length,bays){CityHallVaultAndWalls.windows(p,axis,length,bays);}
 function column(p,b){CityHallVaultAndWalls.column(p,b);}
 function rail(p,axis,start,end,z=46){
  const at=(u,h)=>axis==='rear'?[u,23,h]:[23,u,h];
  for(let u=start;u<=end;u+=6){p.line(at(u,z+1),at(u,z+12),green,1);p.line(at(u+.65,z+1),at(u+.65,z+12),'#7c9678',.25);}
  p.line(at(start,z+2),at(end,z+2),green,1.4);p.line(at(start,z+10.5),at(end,z+10.5),green,1);
  p.line(at(start,z+13),at(end,z+13),'#a47d38',1.7);p.line(at(start,z+13.8),at(end,z+13.8),'#e9ce83',1);
  for(let u=start;u<=end;u+=30){p.line(at(u,z),at(u,z+14),green,2);const a=at(u,z+15);p.ellipse(a[0],a[1],a[2],1.4,1.4,gold);}
 }
 function gallery(p,L){
  p.box(0,0,42,224,23,4,'stone');p.box(0,23,42,23,169,4,'stone');p.box(0,21,40,224,2,2,'green');p.box(21,23,40,2,169,2,'green');
  for(const x of [60,112,164,218]){p.box(x-2,19,0,4,4,42,'green');p.face([[x-10,22,41],[x,22,41],[x,22,31]],green,'#9ab093',.5);p.face([[x,22,41],[x+10,22,41],[x,22,31]],green,'#9ab093',.5);}
  for(const y of [114,178]){p.box(19,y-2,0,4,4,42,'green');p.face([[22,y-10,41],[22,y,41],[22,y,31]],green,'#9ab093',.5);p.face([[22,y,41],[22,y+10,41],[22,y,31]],green,'#9ab093',.5);}
  // Stair flight descends towards the free floor aisle; the rear rail has an
  // actual 19-unit opening and a receiving landing, rather than crossing it.
  const s=L.stairs;p.box(s.landing.x0,s.landing.y0,42,31,14,4,'stone');
  for(const b of s.steps){p.box(b.x0,b.y0,0,b.x1-b.x0,b.y1-b.y0,b.z1);p.box(b.x0-.25,b.y0,b.z1-.7,b.x1-b.x0+.5,b.y1-b.y0+.5,.7);}
  for(const x of [30,49]){p.face([[x,96,0],[x,36,43],[x,36,46],[x,96,3]],green,'#d9caab',.45);p.line([x,96,13],[x,36,59],gold,1.2);p.line([x,36,59],[x,23,59],gold,1.2);for(let i=0;i<=5;i++)p.line([x,96-i*12,i*46/5],[x,96-i*12,i*46/5+13],gold,.7);}
 }
 function tubes(p){CityHallClockBay.paperPipe(p,[[77,31,27],[77,31,34],[153,31,34],[153,9,34]]);CityHallVaultAndWalls.pipes(p);CityHallClockBay.pipes(p);}
 function furniture(p,L){

  p.planeImage('map',0.2,136,14,27,21,'left');
  p.face([[.2,66,0],[.2,94,0],[.2,94,38],[.2,66,38]],'#856548','#efdfbd',1.2);
  for(const y of [68,81])p.face([[.3,y,4],[.3,y+11,4],[.3,y+11,34],[.3,y,34]],'#aa8056','#c7ab77',.65);
  p.line([.5,79,17],[.5,79,21],gold,1);p.line([.5,82,17],[.5,82,21],gold,1);
 }
 function trolley(p,x,y,angle=0){
  for(const dx of [-6,6])for(const dy of [-7,7]){p.ellipse(x+dx,y+dy,2,2,2,'#2e514b','#c3ad69',.5);p.ellipse(x+dx,y+dy,2,.6,.6,gold);p.line([x+dx-1.5*Math.cos(angle),y+dy,2-1.5*Math.sin(angle)],[x+dx+1.5*Math.cos(angle),y+dy,2+1.5*Math.sin(angle)],gold,.45);}
  p.box(x-7,y-8,4,14,16,1,'gold');p.box(x-7,y-8,5,14,1,13,'green');p.box(x-7,y+7,5,14,1,13,'green');p.box(x+6,y-7,5,1,14,13,'green');
  for(const dx of [-7,7])for(const dy of [-8,8])p.line([x+dx,y+dy,4],[x+dx,y+dy,22],gold,.8);
  for(const dy of [-8,8])p.line([x-7,y+dy,22],[x+7,y+dy,22],gold,.9);
  p.box(x-5,y-5,5,9,10,9,'stone');p.box(x-4,y-4,14,8,8,6,'wood');p.line([x,y-4,20.1],[x,y+4,20.1],cream,.6);p.line([x-7,y+7,16],[x+7,y+7,16],gold,1);
  p.planeImage('crest',x-5,y+8.2,8,10,7,'rear');
 }
 function palm(p,x,y){
  p.box(x-5,y-5,0,10,10,2,'gold');p.box(x-5,y-5,2,10,10,11,'green');p.box(x-5.5,y-5.5,12,11,11,1,'gold');p.ellipse(x,y,13,6,3,'#887551');p.line([x,y,13],[x+1,y,38],'#b29b60',1.8);
  for(let i=0;i<10;i++){const a=i*Math.PI/5,dx=Math.cos(a)*17,dy=Math.sin(a)*17;const pts=[[x+1,y,39],[x+dx*.5-dy*.14,y+dy*.5+dx*.14,43],[x+dx,y+dy,23+i%3*3],[x+dx*.5+dy*.14,y+dy*.5-dx*.14,39]];p.face(pts,i%2?'#779268':'#99ab79','#b6bd87',.18);p.line([x+1,y,39],[x+dx,y+dy,23+i%3*3],'#d0ce94',.25);}
 }
 function roof(p,L){CityHallVaultAndWalls.roof(p,L);}
 function draw(p,L){
  p.box(-4,-4,-10,232,200,8);p.box(-2,-2,-2,228,196,2,'gold');p.box(0,0,0,224,192,.5,'wood');
  // Quiet timber apron beneath the ivory board.
  for(let y=0;y<192;y+=8)for(let x=0;x<224;x+=32){p.face([[x,y,.55],[Math.min(224,x+32),y,.55],[Math.min(224,x+32),y+8,.55],[x,y+8,.55]],(x+y)%24?'#cba779':'#d5b78b','#b99970',.16);p.planeImage('material-wood',x,y,.56,Math.min(32,224-x),8,'floor',.15);}
  CityHallCivicSquare.plinth(p);CityHallDaylight.floor(p,L);
  windows(p,'rear',224,[[13,51],[68,105],[176,211]]);windows(p,'left',192,[[14,48],[69,107],[128,171]]);
  p.box(-3,-3,133,230,6,5);p.box(-3,0,133,6,195,5);p.box(0,0,47,224,2,3);p.box(0,0,47,2,192,3);
  for(const b of L.columns)column(p,b);
  CityHallClockBay.wall(p);CityHallSortingFloor.cabinets(p);furniture(p,L);gallery(p,L);CityHallClockBay.gallery(p);CityHallVaultAndWalls.gallery(p);CityHallSortingFloor.counter(p);CityHallCivicSquare.desk(p);CityHallCivicSquare.indoorPlant(p);trolley(p,49,146);CityHallCivicSquare.indoorBench(p);CityHallSortingFloor.stairs(p,L);tubes(p);CityHallSortingFloor.details(p);CityHallClockBay.clock(p);CityHallClockBay.lamps(p);roof(p,L);
  CityHallVaultAndWalls.lamps(p);
  p.fibre(L.bounds,.11);
 }
 function foreground(p){rail(p,'rear',1,29);CityHallSortingFloor.landing(p);CityHallClockBay.rail(p);CityHallVaultAndWalls.rail(p);CityHallSortingFloor.plant(p); }
 root.CityHallArchitecture={draw,foreground,trolley};
})(globalThis);
