/* Existing authored doors and cats, registered to source 16-unit cells.
   Door state and cat poses are sampled by the unchanged canonical host. */
(function(root){
 'use strict';
 const P=CityHallProjection,DX=[1,0,-1,0],DY=[0,1,0,-1],K=16/(380/6);
 class Flaps{
  constructor(r){this.r=r;this.c=r.ctx;this.p={x:0,y:0};this.cats=[];this.doors=[];this.bands=[];
   for(const name of Object.keys(r.assets.registration)){const a=r.assets.registration[name].registration;if(!a)continue;const item={image:r.images[name],meta:a,rect:a.rect};
    if(a.flapIndex!==undefined)this.cats[a.flapIndex]=item;
    else if(a.family?.startsWith('edge_')){const fields=a.family.split('_'),side=CityHallRules.GR_DIR[fields.at(-1)],coat=fields.at(-2)==='blue'?1:0,index=coat*4+side;
     if(fields[1]==='approach')this.bands[index]=item;
     else {if(!this.doors[index])this.doors[index]=[];this.doors[index][EDGE_PORTAL_DATA.doorTags.indexOf(a.frame)]=item;}
    }
   }
  }
  piece(a,x,y){const p=P.project(x,y,0,this.p),r=a.rect;this.c.drawImage(a.image,p.x+r.dx,p.y+r.dy,r.w,r.h);}
  band(f){const c=this.c;c.save();c.scale(1/K,1/K);this.piece(this.bands[(f.coat-1)*4+f.side],f.x*16+8,f.y*16+8);c.restore();}
  door(f,state){const c=this.c;c.save();c.scale(1/K,1/K);this.piece(this.doors[(f.coat-1)*4+f.side][state],f.x*16+8,f.y*16+8);c.restore();}
  cat(o,tr){
   const c=this.c,d=o.dir,a=this.cats[((tr.coat-1)*2+(d>=2?1:0))*8+o.flapPose],r=a.rect,mirror=d===0||d===3;
   let x=o.x-DX[d]*o.flapBack,y=o.y-DY[d]*o.flapBack,sx,sy;
   if(d>=2){const j=tr.n-1,hx=tr.x1[j]*16+8,hy=tr.y1[j]*16+8,p=8+EDGE_PORTAL_DATA.backOutset,m=a.meta;
    x=d===2?hx-p+o.flapBack:hx+m.entryMouth[0];y=d===3?hy-p+o.flapBack:hy-m.entryMouth[0];
    const ex=mirror?16-m.entryNative[0]/4+.75:m.entryNative[0]/4-16,ey=m.entryNative[1]/4-34;
    sx=Math.round(x-y-ex);sy=Math.round((x+y)*.5-m.entryMouth[1]-ey);
   }else {sx=Math.round(x-y);sy=Math.round((x+y)*.5);}
   c.save();c.scale(1/K,1/K);
   // The source sprite stands vertically: its world delivery-plane clip is a
   // screen-x half-plane. Away art already contains the measured aperture.
   if(d<2){const edge=sx+(d===0?2*(o.flapClipAt-x):2*(y-o.flapClipAt));c.beginPath();c.rect(d===0?edge-2000:edge,-2000,2000,4000);c.clip();}
   c.translate(sx,sy);if(mirror)c.scale(-1,1);c.drawImage(a.image,r.x-16,r.y-34,r.w,r.h);c.restore();
   if(o.flapRim)this.r.carriers.carrier(o.boxX,o.boxY,d,0,0,true);
  }
  dispose(){this.r=this.c=null;this.cats.length=this.doors.length=this.bands.length=0;}
 }
 root.CityHallFlaps=Flaps;
})(globalThis);
