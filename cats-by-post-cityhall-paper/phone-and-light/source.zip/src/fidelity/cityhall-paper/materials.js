/* Prepared card stock and measured faces. All construction is baked, never
   rebuilt on a moving frame. Textures are the retained project masters. */
(function(root){
 'use strict';
 const P=CityHallProjection;
 const stock={stone:['#faedd6','#dfc8a7','#bd9f7c'],green:['#567c65','#315b49','#24483e'],gold:['#ebcb76','#caa14c','#a57d39'],wood:['#d6ac78','#b38355','#916747'],wall:['#e4e7d9','#d4dacb','#bbccbf'],red:['#bc7460','#a9604d','#85503f']};
 class Painter{
  constructor(c,images){this.c=c;this.images=images;this.patterns={};}
  path(points,fill,stroke,width=.4){const c=this.c;c.beginPath();for(let i=0;i<points.length;i++){const p=points[i];if(i)c.lineTo(p[0],p[1]);else c.moveTo(p[0],p[1]);}c.closePath();if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=width;c.stroke();}}
  face(points,fill,stroke='#bfa782',width=.2){
   const projected=points.map(v=>{const q=P.project(v[0],v[1],v[2]);return[q.x,q.y];});this.path(projected,fill,stroke,width);
   if(fill&&fill.length===7&&this.images['material-marble']){
    const c=this.c;if(!this.grain){const tile=document.createElement('canvas');tile.width=tile.height=96;const tc=tile.getContext('2d');tc.drawImage(this.images['material-marble'],0,0);const data=tc.getImageData(0,0,96,96);for(let i=0;i<data.data.length;i+=4){const v=data.data[i];data.data[i]=data.data[i+1]=data.data[i+2]=Math.max(0,Math.min(255,128+(v-230)*3));}tc.putImageData(data,0,0);this.grain=c.createPattern(tile,'repeat');}
    c.save();c.clip();c.globalCompositeOperation='soft-light';c.globalAlpha=.26;c.fillStyle=this.grain;c.fill();c.restore();
   }
  }
  line(a,b,color,width=.5){const p=P.project(...a),q=P.project(...b),c=this.c;c.beginPath();c.moveTo(p.x,p.y);c.lineTo(q.x,q.y);c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.stroke();}
  box(x,y,z,w,d,h,kind='stone'){
   const s=Array.isArray(kind)?kind:stock[kind];
   this.face([[x,y+d,z],[x+w,y+d,z],[x+w,y+d,z+h],[x,y+d,z+h]],s[1]);
   this.face([[x+w,y,z],[x+w,y+d,z],[x+w,y+d,z+h],[x+w,y,z+h]],s[2]);
   this.face([[x,y,z+h],[x+w,y,z+h],[x+w,y+d,z+h],[x,y+d,z+h]],s[0]);
  }
  image(name,x,y,z,w,h){const p=P.project(x,y,z);this.c.drawImage(this.images[name],p.x-w/2,p.y-h,w,h);}
  ellipse(x,y,z,rx,ry,fill,stroke,width=.4){const p=P.project(x,y,z),c=this.c;c.beginPath();c.ellipse(p.x,p.y,rx,ry,0,0,Math.PI*2);c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=width;c.stroke();}}
  shadow(x,y,z,rx,ry,alpha=.15){const p=P.project(x,y,z),c=this.c;c.save();c.translate(p.x,p.y);c.scale(rx,ry);const g=c.createRadialGradient(0,0,.1,0,0,1);g.addColorStop(0,'#42372e');g.addColorStop(1,'#42372e00');c.globalAlpha=alpha;c.fillStyle=g;c.fillRect(-1,-1,2,2);c.restore();}
  planeImage(name,x,y,z,w,h,axis='floor',alpha=1){const c=this.c,p=P.project(x,y,z);c.save();c.translate(p.x,p.y);if(axis==='floor')c.transform(1,.5,-1,.5,0,0);else if(axis==='rear')c.transform(1,.5,0,-1,0,0);else c.transform(-1,.5,0,-1,0,0);c.globalAlpha*=alpha;c.drawImage(this.images[name],0,0,w,h);c.restore();}
  fibre(bounds,alpha=.1){const c=this.c;c.save();c.globalAlpha=alpha;for(let i=0;i<24000;i++){const k=Math.imul(i+9,1597334677)>>>0,x=bounds.left+(k%65536)/65536*(bounds.right-bounds.left),y=bounds.top+(k>>>16)/65536*(bounds.bottom-bounds.top);c.fillStyle=i%2?'#fff9e6':'#584e40';c.fillRect(x,y,.1+(i%3)*.08,.1);}c.restore();}
 }
 root.CityHallMaterials={Painter,stock};
})(globalThis);
