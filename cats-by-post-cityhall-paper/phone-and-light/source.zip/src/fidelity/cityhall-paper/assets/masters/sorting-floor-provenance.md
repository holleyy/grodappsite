# Sorting floor assets

Three independent Astra-directed OpenAI Image Gen asset tasks,15November2026. Original transparent PNGs retained byte for byte. Runtime WebP retains each complete image at native aspect and resolution, with no crops or painting. Manifest records hashes, dimensions and measured base anchors.

Generation briefs (summaries, not verbatim prompt transcripts):
- Palm: complete Kentia-style palm and stems, no pot or ground, visibly folded sage/olive/gold paper fronds, warm upper-left light, transparent. Actual planter and soil are measured world geometry.
- Lamp: small emerald banker's lamp with brass paper stem and oval foot, elevated orthographic2:1 game view, warm underside, transparent, no desk or ground. Transparent pixels contain RGB halo colour; alpha makes that colour invisible in the game.
- Flowers: compact ivory/champagne paper daisy bouquet with olive leaves in a faceted cream vase, elevated orthographic game view, transparent, no ground or cast shadow.

The entire raw asset is used and anchored at its measured base contact centre. Foot shadows are supplied on the counter/planter receiving plane.
