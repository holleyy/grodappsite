# Generated scenery provenance

## Current distant skyline

`civic-skyline.png` is the unedited OpenAI Image Gen master from
`exec-76311f9a-18d2-40f0-a701-6459964aa549`. Generated 15 November 2026 without
reference-image inputs. The full master is converted to WebP quality 92; native
2:1 aspect and complete image are retained. The runtime manifest records both
SHA-256 values and native dimensions. The scene places this image behind a
separately measured square; it does not stretch its buildings onto the floor.

Prompt: Standalone distant skyline background asset for a handmade papercraft
Victorian civic postal-hall game. Wide 2:1. Only distant scenery: 80–85% quiet
textured sky, 15–20% low skyline along the bottom. No foreground, hall, board,
pavement, characters, UI or lettering. Pale warm-blue morning sky grading to
apricot and dusty rose at the horizon, with a few complete layered cream-card
clouds in the lower half. Low ivory and sandstone Victorian–Edwardian façades,
slate-blue and lavender roofs, chimneys, modest clock tower, tiny copper dome,
paper trees, hazy lavender hills. Matte fibres, card relief, warm upper-left
lighting; no photorealism or plastic. No large landmark competing with the
independently modelled foreground hall. Opaque background.

## Retained provisional square

`civic-square.png` is the earlier unedited Image Gen master,
`exec-476a5cf1-cc21-4eeb-aeba-2ecb3de4b102`, 1536×1024. Source SHA-256:
`1085ff3d9cb3b83aea2333d7731748cee22c4362dcc5d10eefc72518111fc0da`.
The retained full-image `../civic-square.webp` uses quality 92, SHA-256:
`8ae5671d1646f35d817ddd3609c74f0a3f66eefd7f8b92af06c8ff148139c11e`.
It depicted a warm matte papercraft civic square with ivory municipal buildings,
blue dome, slate roofs, fountain, trees and sky, without a hall or gameplay
objects. It is historical source material, no longer embedded or drawn.
