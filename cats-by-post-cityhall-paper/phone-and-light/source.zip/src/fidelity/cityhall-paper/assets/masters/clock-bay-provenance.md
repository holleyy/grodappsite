# Clock bay asset provenance

Generated with OpenAI Image Gen on 15 November 2026, in three independent Astra asset tasks. The original PNG masters are retained byte for byte. Runtime WebP files preserve each complete image, including transparency. No destructive crops, image retouching or existing project art replacements.

Generation briefs:
- Clock: front-on orthographic circular civic clock in layered ivory, emerald and antique gold paper; botanical ornament, winged envelope crest, 10:10 hands; transparent complete silhouette. Mapped once onto the measured rear wall.
- Stock: four equal borderless material swatches in a square atlas: ivory fibrous stone, emerald card, ochre gold paper and warm walnut kraft. Runtime uses registered quadrant UVs from the complete atlas.
- Tree: complete upright broadleaf tree in layered sage, olive and golden cut-paper leaves, warm upper-left light, visible brown branches and trunk base; transparent, no ground, planter or cast shadow. World footing and contact shadow supplied by the renderer.

These are retained generation briefs, not a verbatim transcript of every image prompt. Manifest records raw/output hashes, dimensions and registration. The tree canopy approaches the horizontal image edges; use at native aspect ratio without clipping.
