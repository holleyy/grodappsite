# Vault roof paper stock

`vault-slate.png` is the complete 1254 × 1254 opaque RGB output generated with
OpenAI Image Gen for this checkpoint. Astra directed the material: uniform,
matte, muted grey-green slate paper, fine fibres, low contrast, no drawn roof
seams, objects, framing, lighting hotspot or transparency. The unmodified
master is retained; `../vault-slate.webp` is its full-size quality-94 derivative.
Both hashes and dimensions are recorded in `../manifest.json`.

The complete material is mapped onto measured roof facets in
`vault-and-walls.js`. Geometry supplies seams, pitch, cap edges and receiving
faces. No concept image is used as scenery. Existing ivory, green, brass and
wood stock, crests, palm, civic foliage and shared backdrop remain retained.
