/* Presentation boundary only. The host owns rules, storage, input and clocks. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallPaper=api;})(globalThis,function(){
 'use strict';
 function createCityHallPaper(host){
  const frame={level:null,turns:null,traces:null,gateTrace:null,time:0,sceneTime:0,mode:'edit',presentation:'board',originX:64,originY:64,selected:null,partner:null,gray:false,motion:true,chapter:null};
  const empty=Object.freeze({bytes:0,buffers:0,scope:'disposed City Hall presentation'});
  let mounted=false,closed=false,pending=null,restore=null,unsubscribe=null;
  function capture(){if(!mounted||closed)return null;host.read(frame);return frame;}
  function draw(){const f=capture();if(!f)return;host.renderer.prepare(f,host.viewport);host.renderer.draw(f);}
  function refresh(){if(!mounted||closed)return;host.check();if(host.invalidate)host.invalidate();}
  function dispose(){if(closed)return;closed=true;mounted=false;if(unsubscribe)unsubscribe();if(restore)restore();unsubscribe=restore=null;host.renderer.dispose();frame.level=frame.turns=frame.traces=frame.gateTrace=frame.chapter=null;}
  function mount(){
   if(pending)return pending;
   pending=(async()=>{try{host.check();await host.renderer.load();if(closed)return;host.check();mounted=true;unsubscribe=host.subscribe(refresh);restore=host.install({draw,refresh,capture});refresh();}catch(error){dispose();throw error;}})();
   return pending;
  }
  return {mount,refresh,draw,capture,dispose,resources:()=>closed?empty:host.renderer.resources()};
 }
 return {createCityHallPaper};
});
