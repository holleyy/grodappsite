# Current checkpoint: clock bay, 15 November 2026

User authorised the next representative-section refinement. Implemented the
ornate paper clock, textured receiving wall/window reveals, gallery rail and
supports, wall service chase and raised lanterns. The adjacent archive/neighbours
are smaller and set back; the courtyard tree is visible through the real window.
The selected vault height and exact board projection remain unchanged.

Current runtime e64e10ccfdd0e7ef2b075d3dcc376a5ebdd6de95932ab9e947c4bfb7f94842a4.
25 focused tests,72 browser checks,26 qualification checks and15 real solutions
pass. All195 protected inputs and all three board raster hashes remain exact.
Fresh Astra review found a lantern/hat collision and an underestimated test
height; both corrected and independently checked. No remaining blocking finding
in this checkpoint. Physical-device qualification and whole-room/user visual
acceptance remain open. Do not automatically expand the finish across the room.

Review: docs/review-images/cityhall-paper/clock-bay/index.html, with matched
actual captures,20-second motion,visual QA and review reports. Reproduction:
studies/cityhall-paper/clock-bay/. Publication uses an add-only clock-bay/ child
of the already-authorised grodappsite City Hall prefix. The previous packet is
preserved. Canonical/shared source and other room work stay untouched.

---

# City Hall paper · Great Postal Vault handoff

15 November 2026. User selected the second height study and authorised execution.
The room-owned playable study now covers all fifteen deliveries. Final evidence
and review status are recorded below; the earlier checkpoint is retained as history.
No game-source push, merge or shared-code change. A separate grodappsite review
packet uses the new cats-by-post-cityhall-paper/ prefix under the later user grant.

Review: https://holleyy.github.io/grodappsite/cats-by-post-cityhall-paper/

Publication receipt: cityhall-paper-publication.md.

## Current user review

The user says the published candidate is not there yet. Visual acceptance is
open; the prior technical review is not acceptance of reference-level artwork.
The next pass is described in cityhall-paper-refinement-plan.md: setting scale,
architectural depth, material/light treatment and a complete clock-bay pilot
before applying the finish across the room. Keep the selected vault and board
projection.

## Implementation

Open `studies/cityhall-paper/index.html` through the local server on port 8798.
Its README covers use, reproduction, assets and qualification limits. Source is
in `src/fidelity/cityhall-paper/`; the production integration proposal is
`docs/rooms/progress/cityhall-paper-integration.md`.

The measured vault has a z138 spring and z180 crown, a z46 gallery, connected
15-tread stair, tall arched windows, brass-card routes and one civic-square
backdrop shared by every opening. Play and hall views use one exact 2:1 board
projection and inverse. All fifteen authored levels remain selectable.

Retained cats/carriers and edge-flap poses consume the actual canonical traces.
Tunnel symbols and partner selection work without colour; simultaneous users
keep independent entry/hidden/exit samples. Gates retain their actual state.
Original workers and Postmistress remain human/cat respectively. A parcel has
one owner through pickup, carrying and release; a loading trolley rolls along
a clear aisle; the ambient ginger cat leaves an empty bench during its outing.

Arrival, actual three-cat demo, both growth presentations, final settling and
satchel dispatch read the existing chapter controller. The study retains real
Train→Hall and Hall→Parcel navigation. Only its two private save-key substitutions
alter the copied host; all source game rules and production outputs stay exact.

## Verified candidate

The broad root suite passed1,687/1,687 before the last visual/compact-layout pass.
Final focused suite passes23/23; browser checks pass72/72, including15actual wins,
all tile centres and ordered queues across five viewport shapes. The26additional
qualification checks cover saved state, trusted input, resize/pinch cancellation,
chapter restoration, Train→Hall→Parcel, reduced motion, offline operation and
actual resource disposal. All195protected canonical/source/export inputs remain
exact. The self-contained build reproduces byte-for-byte; build.json and the
implemented gallery's verification.json bind its exact current hash.

The final backdrop includes the connected measured forecourt, six entrance
steps, neighbouring facades, trees, lamps and fountain. A full2:1 distant skyline
and quiet sky sit behind them and remain registered through every window. This
replaces the provisional full-square image after the user's Town Depot refs.

Owned Canvas backing storage is65,915,080bytes in51buffers including9static bakes.
No new Canvas or cache growth appears during120warm draws; actual disposal
releases them. Timings are synchronous cloud draw calls, not presented FPS.
Physical Safari, sustained thermal/battery behaviour and production manager
integration remain open. Layered occlusion approximates paper depth; the study
is not a full3D renderer. Private save keys do not replace production save policy.

The one fresh Astra whole-change review has no actionable Critical, Important
or Minor findings. No correction pass was required. See cityhall-paper-review.md.
All three board bake images remain byte-exact to the measured pilot. The nested
packet passes12checks, including actual playback of all three motion clips.

## Earlier composition checkpoint (historical)

## Checkout and ownership

Remote main verified by `git ls-remote` and fetch as
`923b40d7c3ef2b9e4fab49d290267f0094a1a9bb` (same as the supplied verified main).
Original `/workspace/cosysortie` remains on `work` at `032382eb`, clean.
New sparse worktree `/workspace/cosysortie-cityhall`, branch
`codex/cityhall-paper-fidelity`, began clean at the exact remote base. Branch
absent locally and on the remote before creation. Existing edits and files are
preserved. Shallow filtered fetch and sparse checkout took several minutes and
transferred a temporary pack of roughly 566 MiB. Proxy/TLS settings unchanged.
`gh pr list` returned GraphQL Forbidden; PR discovery was unavailable.

Current checkpoint owns only this handoff and
`docs/review-images/cityhall-paper/`. Proposed later ownership is
`src/fidelity/cityhall-paper/`, `studies/cityhall-paper/`,
`tests/cityhall-paper-*.test.js` and the existing review folder. These source,
study and test paths do not yet exist at the base. Integration owns shared
camera/renderer/manager, build/bridge/UI, generated outputs, PLAN and AGENTS.

## Current-source assessment

Read the ownership guide, common/City Hall briefs, chapter handover, retained
City Hall README/HANDOFF, integration HANDOFF, manifest, production presentation
README, build extraction/hooks, manager and Office adapter/projection. Older
briefs call rules and levels proposed; main already contains all 100 campaign
levels, including all 15 Hall records and their chapter. The actual boards grow
after 6-3 and 6-7, so 6-8 already uses 8×6 (older prose says by level 10).

The manifest retains City Hall `cityhall-fidelity-527093ea02`, frozen playable
SHA-256 `3bc6f63cf43905af4f706f2b148902297f38ba8bd0fcaf42297ffb055d684236`.
The current build tool extracts a presentation extension, removes study policy,
and installs hooks through the shared manager. Only Office currently has the
modular paper source. Do not edit generated City Hall JS or historical hashes.

Observed local City Hall has a coherent ivory board, green galleries, large
clock, tube stations and purposeful staff. Its whole-hall study capture is
small on desktop and the diagnostic HUD occupies much of portrait height.
These are observations of the retained study, not proof of production UI defects.
The new direction should strengthen tactile construction and room silhouette,
reserve board-first framing and dark symbol contrast, and retain personalities
(including the Postmistress, workers, roof pigeons and existing beagle).

Public City Hall preview failed proxy CONNECT with 403; inspected the exact
local frozen HTML instead. Also inspected local approved Office foundation
(`?v=cat-scale&view=hall`) in Chromium. Lantern Quay and supplied City Hall images
were directly visible in the chat and used as visual references. No live-site
publication or physical-device testing.

## Three compositions

Review gallery: `docs/review-images/cityhall-paper/index.html`.

1. Clocklight Nave: central great clock, clerestory and twin side stairs.
   Most ceremonial, but tall and costlier in architecture/route space.
2. Sorting Arcade: asymmetric long gallery/counter, left clock tower and rear
   stair. Strong visible postal workflow; widest portrait framing compromise.
3. Civic Conservatory (recommended): compact corner hall, corner clock, partial
   roof and single side stair. Preserves the current identity with a larger
   foreground board; loses some cathedral scale and needs measured aisle proof.

Each generated sheet shows first/max board intent, portrait framing, material
and grayscale studies. These are generated concepts, not measured construction.
They have approximate grids and schematic/incorrect piece positions. They do
not authorise relocating any gameplay piece or using their perspective as the
renderer contract. The two separate authored SVG plans come directly from main
level JSON, and override all illustration errors. They show the actual 7×5
first board and 8×6 finale with eight endpoints and three hatches.

All concepts reserve rear/side working aisles, gallery supports outside tile
cores and wall/high-beam decorative pipes. Exact floor symbols, local entry/
exit and partner highlighting remain functional; no cat travels across intervening
tiles. All three must use the same coherent isometric floor projection in code,
including arrows, boxes, shadows, architecture and inverse picking. Desktop may
show the full hall; portrait play must keep the complete board and hatch approach
visible, allowing upper roof to crop. Shared camera changes require a small
proposal to the integration owner, not local host takeover.

## Stages after selection

1. Record the selected composition and dimensional design; map first, middle
   and maximum boards, supports, doors, stair landing and clear working routes.
2. Build a room-owned standalone study using real canonical rules/traces and an
   isolated save namespace. Propose a narrow presentation adapter contract to
   integration. Keep authored data, inventory, timing and save formats exact.
3. Add layered card construction, light and contact shadows; complete smooth
   worker grips/releases, rolling wheels and consistently scaled cats. Outings
   must empty their resting spots. Supported reduced-motion poses are required.
4. Exercise all 15 solutions, tunnel directions/bounces/simultaneous users,
   shape pairing/input modes, board sizes/picks, chapter/demo/growth/exit and
   Train→Hall→Parcel connections. Inspect desktop, portrait and landscape,
   grayscale and motion in Chromium. Report cloud versus hardware limits.
5. Deliver source/provenance, standalone playable, captures/motion evidence and
   integration handoff. No merge, deploy or public-prefix overwrite without
   this chat's explicit authorisation.

## Evidence and provenance

Concept sheets generated with OpenAI Image Gen from the user's references and
current City Hall captures; no generated art has been installed in the game.
WebP copies retain the full sheets at review size, each under 1 MiB.
Baseline captures are actual Chromium screenshots at 1440×1000 and 390×844.
Authored board SVGs are original diagrams derived from unchanged main JSON.
Gallery checked in Chromium: all five referenced images decoded successfully.
The first board/finale/portrait baseline and local Office reference loaded.
No claim of checked physical geometry, implemented grayscale contrast, motion
fidelity or device performance at this concept checkpoint.

Baseline `npm test` result is recorded below after completion. No build is
needed for this documentation-only checkpoint; the user explicitly excludes
changes to `sorting_office.html` and generated outputs.

Checkpoint status: `npm test` is still running in the background at selection
handoff; no complete passing-suite claim is made. Log:
`work/baseline-tests.log` in this isolated checkout. Review artefacts remain
uncommitted pending that baseline result. Resume by reading the log/process
status before any implementation or checkpoint commit. Fresh `git diff --check`
passes, protected source/output paths have no diff, and the original checkout
remains clean. The designated `/codex/browser/projectless/.../output` folder
could not be created (OS permission denied); review artefacts are preserved in
the repository and the generated sheets are visible directly in chat.

## User correction and revised setting studies

The user rejected the concepts' frontal board angle and incidental backdrop,
requested combining strong elements, and explicitly requires refinement before
continuing even if the compact corner direction is used. No composition is
selected. The previous recommendation is not approval.

`docs/review-images/cityhall-paper/refinement/index.html` contains three new
full-scene concepts in displayed order: civic square, railway rooftops, garden
square. They combine compact corner architecture, long working arcade, great
clock and glazed roof with a deliberately composed city setting. The proper
camera target is the existing exact 2:1 orthographic projection (tile axes
slopes ±0.5); previous frontal trapezoids were a concept-generation error.
The new illustrations improve orientation, but generated line slopes, tile
counts and positions remain approximate. They do not replace the projection
contract or canonical boards. Exterior horizon and window views must agree.

Known generation errors remain explicit: 1/2 invented a human supervisor and
3 anthropomorphised the human workers. Preserve the actual human staff and
ordinary tuxedo Postmistress cat; do not import those changes. Material gloss
and background detail also need restraint in the implemented paper treatment.
No new source, shared code, publication or merge.

The baseline full test run completed: 1,568 tests, 1,543 pass, 25 fail,
891,250.72 ms. Failures include sparse-excluded `web/journey`,
`docs/paper-cutout/recovered`, `docs/review-images/depot/baseline` and
`docs/review-images/rooms/baseline` dependencies. This is not a green baseline.
Restore the required sparse paths and inspect remaining failures before
implementation; do not alter tests or expected hashes. Full log is preserved
in `work/baseline-tests.log`. This supersedes the earlier running-test note.

## Grandness refinement

User: “Ok lets refine your idea - I like the grandness, as it is city hall after
all.” This authorises developing the combined civic-square/quiet-distance idea,
not starting implementation. New single refined concept is
`refinement/grand-civic-square.webp`; raw Image Gen master
`/workspace/generated_images/exec-4f7ddb20-0651-49bd-a2ef-583ef176e81f.png`.
It increases arched window height, column/cornice articulation, clock presence
and raised glass roof, retaining the diagonal board, working gallery and quiet
civic square backdrop. Ordinary human staff and tuxedo Postmistress are restored
in this concept. Board/piece placement remains illustrative; no gameplay or
camera change is authorised. Still return for visual refinement/selection.

## Height and scale explorations

User requests versions with height and scale pushed further. Three independent
Image Gen studies now appear in displayed order: Tall Civic Hall (elongated
windows/columns), Great Postal Vault (high curved glass roof), Monumental Lantern
Hall (upper glazing tier and raised central lantern). Gallery:
`refinement/height-studies.html`; exact master names are in its provenance JSON.
These are comparable art-direction studies in the same civic-square setting,
not measured geometric percentage proofs. Higher architecture consumes more of
the viewport; the final board-first camera must be resolved with the integration
owner and exact authored board before implementation. User selection remains
pending; no product/source change, publication or merge.

## Selection and plan-first instruction

User selects height-study 2, Great Postal Vault, then explicitly says “Make a
plan first”. Design and task plan saved under docs/superpowers/specs and plans
as `2026-11-15-cityhall-paper-design.md` and
`2026-11-15-cityhall-paper-fidelity.md`. No implementation has begun. Sparse
paths for the earlier baseline failures were restored successfully; tests have
not yet been rerun. Do not claim the baseline is green. Next step is user review
of the plan, then Task 1 baseline/contract work.
