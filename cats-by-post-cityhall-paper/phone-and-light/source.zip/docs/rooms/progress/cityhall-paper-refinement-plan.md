# City Hall visual refinement after the first playable review

User review: “Ok what’s next. We aren’t there yet.” The published candidate is a
functional foundation. It has not met the user's visual acceptance bar. The
previous code/behaviour review does not establish reference-level visual quality.
Keep the selected Great Postal Vault direction, its grand scale and the exact
board projection. The selected height image, Lantern Quay and supplied Town
Depot scenes remain the quality targets. Do not reopen the composition choice.

Fresh local Chromium captures of the exact published runtime are in
work/cityhall-paper/visual-audit/: 01-hall, 02-board and 03-phone. No runtime or
public-preview edits were made during this assessment.

## Findings and order of work

1. Whole hall: the broad vaulted silhouette is established, but the near town
   crowds it with large repeated facades and roofs. The square is connected yet
   sparse, and its detail/material language differs from the distant painted
   skyline. Recompose the neighbours with more breathing room, varied massing
   and distance. Establish readable near street, middle town and quiet horizon.
   Treat each window view as part of that same composition.
2. Architecture: roof ribs, rails, capitals and clock have much less depth and
   ornament than the approved image. Strengthen the actual folded-card volumes,
   joinery, clock casing and brass manifold. Use selected postal motifs and
   substantial receiving surfaces. Preserve the board and clear routes.
3. Materials and light: broad beige surfaces read flat; stone, wood, brass,
   glazing and vegetation need distinct paper treatments. Add layered edges,
   subtle material variation, warm directional light and receiving shadows.
   Keep the board quieter and clearer than the working edges of the room.
4. Board and phone: current pieces/controls remain readable, but close views
   expose simplified counters, cubbies and plants. Refine those assets and
   contacts at their actual display scale. Introduce purposeful postal detail
   around working stations without filling the puzzle or movement routes.
   Inspect motion in short loops as part of the visual acceptance checkpoint.

## First concrete checkpoint

Finish one representative section in the real renderer: the great clock bay,
its brass tube/gauge assembly, the gallery beneath it, and the exterior seen
through its neighbouring window. Show the current and refined section at the
same camera and scale, plus a whole-hall capture to prove the section belongs
in the composition. This must visibly demonstrate the reference's material,
lighting and construction standard before repeating that treatment everywhere.

Then apply the approved finish across the hall and square, resolve contacts and
occlusion, and compare whole-hall, first-board, maximum-board and portrait views.
Retain the current public checkpoint for comparison. Any new public packet uses
an add-only child beneath the owned City Hall prefix.

Acceptance is visual and behavioural: coherent setting and scale; tangible paper
construction; strong clock/tube focal point; inhabited working edges; original
characters and grounded motion; clear board and symbols at actual phone size.
Screenshots alone cannot certify touch feel, motion quality or physical-device
performance. Existing rule preservation remains a required regression guard.
