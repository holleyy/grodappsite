# City Hall — full-height phone and daylight checkpoint

Approved continuation from the vault/walls checkpoint. Source baseline
aaa1bfec; previous runtime c76abd4c. Owned plan and ledger:
`studies/cityhall-paper/phone-and-light/`. Review:
`docs/review-images/cityhall-paper/phone-and-light/index.html`.

The owned review now measures actual overlay bounds and fits its existing
projection into a safe region within a full-screen canvas. The real production
web UI was measured read-only; canonical controls are reparented rather than
reimplemented. Original queue sources, control positions and input handlers
restore when leaving the study. Pinch anchoring uses the same inset centre.
The unused legacy HUD fitting loop is bypassed only while the owned renderer
is active, avoiding recursive fitting at small DPR2 dimensions. Chapter entry
returns focus to a visible action. Canonical/shared files remain unchanged.

Sky and ground are prepared continuous world materials. The original horizon
is retained; its upper sky feathers into full original generated paper stock.
The civic approach extends the existing stair landing. Fixed sun geometry
prepares restrained receiving shadows for the foundations, galleries and near
town. New canvases are counted, reused and released. Board rasters stay exact.

Swift/Metal mapping for this isolated study: overlay insets feed the same
orthographic fit and gesture anchor calculation; prepared sky/ground and
receiving-light layers map to retained textures/world geometry. This records
the intended mapping only. No native implementation is included.

Final evidence:38 focused tests,72 canonical browser checks,26 qualification
checks,44 phone checks,15 wins,195 protected files,237 build inputs and three
exact board rasters. A fresh Astra review had no Critical/Important findings;
two Minor restoration findings were corrected and checked once by the author.
See the adjacent review and receipts for scope. The 32-second renderer clip
and eleven matched views are cloud Chromium evidence, not physical phone FPS.

Publication target authorised by the user:
`https://holleyy.github.io/grodappsite/cats-by-post-cityhall-paper/phone-and-light/`.
Add only this child prefix. Preserve the parent and every previous checkpoint,
other room and user save namespace. Source push to cosysortie is not included.
The publication receipt is recorded after the isolated packet is merged and
Pages completes. Whole-scene artistic acceptance remains the user's review.
