"""Extract the published source packet, rebuild it and run its room regressions."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,tempfile,zipfile

packet=Path(sys.argv[1]).resolve()
expected=json.loads((packet/'build-manifest.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with tempfile.TemporaryDirectory(prefix='cityhall-scene-finish-',dir='/tmp') as directory:
 root=Path(directory)
 with zipfile.ZipFile(packet/'source.zip') as archive:archive.extractall(root)
 subprocess.run(['python3','studies/cityhall-paper/build.py'],cwd=root,check=True,capture_output=True,text=True)
 assert sha(root/'studies/cityhall-paper/index.html')==expected['sha256']
 for path,digest in expected['inputs'].items():assert sha(root/path)==digest,path
 tests=sorted(str(p.relative_to(root)) for p in (root/'tests').glob('cityhall-paper-*.test.js'))
 result=subprocess.run(['node','--test',*tests],cwd=root,capture_output=True,text=True)
 (packet/'archive-tests.log').write_text(result.stdout+result.stderr)
 assert result.returncode==0,result.stdout+result.stderr
 total=re.findall(r'ℹ tests (\d+)',result.stdout);passed=re.findall(r'ℹ pass (\d+)',result.stdout)
 assert total==passed and re.findall(r'ℹ fail (\d+)',result.stdout)==['0']
 report={'runtimeSha256':expected['sha256'],'finalArchiveSha256':sha(packet/'source.zip'),'exactRebuild':True,'buildInputCount':len(expected['inputs']),'focusedTests':int(total[0]),'method':'The final extracted source archive reproduces the runtime and passes every included City Hall paper regression.'}
 (packet/'archive-report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
