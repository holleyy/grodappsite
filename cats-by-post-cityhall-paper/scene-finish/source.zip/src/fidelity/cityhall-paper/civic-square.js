/* Civic furniture uses the same receiving planes and paper stock as the hall.
   Everything here is prepared into existing scenery layers, never per frame. */
(function(root,factory){const D=typeof module==='object'&&module.exports?require('./civic-district'):root.CityHallCivicDistrict,api=factory(D);if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallCivicSquare=api;})(globalThis,function(D){
 'use strict';
 const volume=(id,x0,y0,z0,x1,y1,z1)=>({id,x0,y0,z0,x1,y1,z1});
 function layout(){return {
  desk:volume('postmistress-desk',10,117,0,43,137,28),
  indoorSeat:volume('bench',26,172,0,54,186,16),
  palm:volume('palm-left',13,152,0,21,160,41),palmAnchor:{x:17,y:156,z:13,height:29},
  planters:[volume('arrival-flowers-left',48,224,-12,66,242,-3),volume('arrival-flowers-right',166,224,-12,184,242,-3),volume('east-flowers',239,143,-12,257,161,-3),volume('fountain-flowers',-70,216,-12,-52,234,-3)],
  benches:[volume('fountain-seat',-88,180,-12,-60,190,1),volume('square-seat',-11,228,-12,17,238,1),volume('garden-seat',230,303,-12,258,313,1)],
  gardens:D.layout().gardens,
  shrubs:[[-65,276,18],[-62,327,18],[-36,327,17,'civic-flowers'],[-12,327,18],[15,327,17],[45,327,16,'civic-flowers'],[9,273,16],[32,271,14,'civic-flowers'],[53,281,18],[49,303,16,'civic-flowers'],[24,301,18],[9,293,13],[211,271,15],[233,283,18],[251,271,13,'civic-flowers'],[273,271,17],[298,281,15,'civic-flowers'],[345,281,17],[272,287,14],[211,287,12,'civic-flowers']].map(([x,y,h,art='civic-shrub'],i)=>({...volume('garden-shrub-'+i,x-9,y-9,-11.2,x+9,y+9,h-11.2),art}))
 };}
 function box(p,x,y,z,w,d,h,kind='stone'){CityHallClockBay.paperBox(p,x,y,z,w,d,h,kind);}
 function face(p,pts,kind,shade=0){CityHallClockBay.paperFace(p,pts,kind,shade);}
 function art(p,name,x,y,z,h){const m=CityHallAssets.registration[name],a=m.registration.anchor,q=CityHallProjection.project(x,y,z),w=h*m.width/m.height;p.c.drawImage(p.images[name],q.x-w*a[0],q.y-h*a[1],w,h);}
 function panel(p,x,y,z,w,h){
  face(p,[[x,y,z+h],[x+w,y,z+h],[x+w,y,z],[x,y,z]],'wood',-.3);
  box(p,x+.7,y+.15,z+.7,w-1.4,.5,h-1.4,'wood');
  for(const u of [x,x+w-.55])box(p,u,y+.4,z,.55,.5,h,'wood');
  for(const v of [z,z+h-.55])box(p,x,y+.4,v,w,.5,.55,'wood');
 }
 function desk(p){
  const b=layout().desk;
  p.shadow(27,129,0,25,12,.17);box(p,10,117,0,33,20,2,'green');box(p,10,117,2,33,20,23,'wood');
  box(p,9.7,116.8,24.5,33.6,20.6,1.1,'gold');box(p,9.5,116.7,25.6,34,20.9,2.4);
  face(p,[[43.1,119,23],[43.1,135,23],[43.1,135,5],[43.1,119,5]],'wood',-.28);
  for(const x of [12,27])panel(p,x,137.1,5,13.1,18);
  box(p,20,138,9,13,.5,9,'green');CityHallClockBay.rearImage(p,'crest',26.5,138.6,13.5,11.8,7.6);
  box(p,27,129,28,11,5,.6,'green');p.planeImage('letters',27.7,129.3,28.65,9.5,4.3,'floor');
  p.shadow(17,125,28,3,1.5,.15);art(p,'sorting-lamp',17,123,28,12);
  p.shadow(16,132,28,2,1,.13);art(p,'sorting-flowers',16,132,28,12);
 }
 function indoorPlant(p){
  const a=layout().palmAnchor,x=a.x,y=a.y;
  p.shadow(x+1,y+2,0,8,4,.17);box(p,x-4,y-4,0,8,8,1.5,'gold');box(p,x-3.6,y-3.6,1.5,7.2,7.2,10.3,'green');
  for(const dx of [-3.6,3])box(p,x+dx,y+3.6,1.5,.6,.4,10.3,'gold');box(p,x-4,y-4,11.8,8,8,1.2,'gold');
  p.ellipse(x,y,13,4.3,2.15,'#65563d');CityHallClockBay.rearImage(p,'crest',x,y+4.1,6.6,5.6,3.6);art(p,'sorting-palm',x,y,13,a.height);
 }
 function indoorBench(p){
  const x=26,y=172;p.shadow(40,180,0,20,8,.15);
  for(const u of [28,50]){box(p,u,y+2,0,2,10,4,'green');box(p,u,y,4,2,2,12,'green');}
  for(let k=0;k<5;k++){box(p,x+k*5.6,y+2,4,5.25,12,2,'wood');box(p,x+k*5.6,y,6,5.25,2,10,'wood');}
  for(const u of [26,52]){box(p,u,y+1,6,2,12,1,'gold');box(p,u,y+11,4,2,2,3,'green');}
 }
 function plinth(p){
  for(let x=-4;x<228;x+=21){const w=Math.min(20.6,228-x);box(p,x,196.05,-10,w,.8,7.6);}
  for(let y=-4;y<196;y+=21){const d=Math.min(20.6,196-y);box(p,228.05,y,-10,.8,d,7.6);}
  box(p,-4,196,-3,232,1.3,.8);box(p,228,-4,-3,1.3,200,.8);
 }
 function footing(p,b){
  // The broad stone foot sits on the square; its contact precedes the solid.
  const foot={x0:b.x0-2,y0:b.y0-2,x1:b.x1+2,y1:b.y1+2};
  const ground=CityHallDaylight.groundHeight((b.x0+b.x1)/2,(b.y0+b.y1)/2),source=ground===-12?b:foot,top=ground===-12?b.z1:-12;
  p.c.save();p.c.filter='blur(.45px)';p.face(CityHallDaylight.shadowFootprint(source,top,ground),'#34463838',null);p.c.restore();
  box(p,foot.x0,foot.y0,-14,foot.x1-foot.x0,foot.y1-foot.y0,2);
 }
 function planter(p,b){
  const x=b.x0,y=b.y0,w=b.x1-x,d=b.y1-y,z=b.z0;footing(p,b);p.shadow(x+w/2+2,y+d/2+2,z,11,5,.12);
  box(p,x,y,z,w,d,1.3);box(p,x+.5,y+.5,z+1.3,w-1,d-1,6.6,'wood');
  panel(p,x+2,y+d-.3,z+2,w-4,5);box(p,x-.4,y-.4,z+7.6,w+.8,d+.8,1.4);
  face(p,[[x+1,y+1,b.z1+.03],[x+w-1,y+1,b.z1+.03],[x+w-1,y+d-1,b.z1+.03],[x+1,y+d-1,b.z1+.03]],'wood',-.4);
  art(p,'civic-flowers',x+w/2,y+d/2,b.z1+.05,33);
 }
 function bench(p,b){
  footing(p,b);const x=b.x0,y=b.y0,z=b.z0;
  p.shadow(x+16,y+7,z,22,8,.16);
  for(const dx of [3,24]){p.shadow(x+dx+.7,y+5,z+.03,3.2,1.5,.24);box(p,x+dx,y+1,z,1.4,8,6,'green');box(p,x+dx,y+1,z+6,1.4,1.5,7,'green');box(p,x+dx-.5,y+.5,z+12.8,2.4,2.5,.6,'gold');}
  for(let k=0;k<4;k++)box(p,x,y+1+k*2.2,z+5.5,28,1.8,.8,'green');
  for(let k=0;k<3;k++)box(p,x,y+.5,z+7+k*2.1,28,1,1.4,'green');
  for(const dx of [2.5,24]){p.line([x+dx,y+1,z+9],[x+dx,y+9,z+9],'#365c49',1.1);p.line([x+dx,y+9,z+6],[x+dx,y+9,z+9],'#365c49',1.1);}
 }
 function lamp(p,b){
  const x=(b.x0+b.x1)/2,y=(b.y0+b.y1)/2;
  p.shadow(x+3,y+3,b.z0,6,3,.16);art(p,'civic-lamp',x,y,b.z0,42);
 }
 function gardens(p){for(const b of layout().gardens){
  const w=b.x1-b.x0,d=b.y1-b.y0;p.face(CityHallDaylight.shadowFootprint(b,-11.5,-14),'#34463830',null);box(p,b.x0,b.y0,-14,w,d,2.5);p.face([[b.x0+1.5,b.y0+1.5,-11.2],[b.x1-1.5,b.y0+1.5,-11.2],[b.x1-1.5,b.y1-1.5,-11.2],[b.x0+1.5,b.y1-1.5,-11.2]],'#9fa978',null);
  for(const x of [b.x0,b.x1-1.3])box(p,x,b.y0,-11.5,1.3,d,.8);for(const y of [b.y0,b.y1-1.3])box(p,b.x0,y,-11.5,w,1.3,.8);
  for(let x=b.x0+12;x<b.x1;x+=12)for(const y of [b.y0,b.y1-1.3])p.line([x,y,-10.69],[x,y+1.3,-10.69],'#b9a887',.18);
 }}
 function shrub(p,b){const x=(b.x0+b.x1)/2,y=(b.y0+b.y1)/2;p.shadow(x+1,y+2,b.z0,17,6,.12);p.shadow(x,y,b.z0+.02,6,2.5,.18);art(p,b.art,x,y,b.z0,b.z1-b.z0);}
 function exterior(p,front,extra=[]){
  const e=layout(),items=[...e.planters.map(b=>({b,draw:planter})),...e.benches.map(b=>({b,draw:bench})),...e.shrubs.map(b=>({b,draw:shrub}))].filter(({b})=>(b.y0>=218||b.x0>228)===front).concat(extra).sort((a,b)=>(a.b.x0+a.b.x1+a.b.y0+a.b.y1)-(b.b.x0+b.b.x1+b.b.y0+b.b.y1));
  for(const item of items)item.draw(p,item.b);
 }
 return {layout,desk,indoorPlant,indoorBench,plinth,exterior,lamp,gardens};
});
