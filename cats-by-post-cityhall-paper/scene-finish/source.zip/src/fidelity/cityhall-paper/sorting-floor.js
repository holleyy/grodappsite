/* Measured working furniture. Recesses, paper artwork and receiving shadows are
   prepared once; moving people and puzzle pieces keep their original routes. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallSortingFloor=api;})(globalThis,function(){
 'use strict';
 function layout(){
  const shelves=[10,19,28].map(z=>({z0:z,z1:z+1})),contents=[];
  for(let i=0;i<10;i++)for(let row=0;row<3;row++){
   const kind=(i*5+row*3)%7;if(kind===6)continue;const x=82+i*12.7,y=kind%2?14.6:14.2,z=shelves[row].z1;
   contents.push({row,kind,x0:x+.6,y0:y,z0:z,x1:x+8.7+(i%2),y1:y+3,z1:z+(kind<2?2:kind===5?5.5:4)});
  }
  return {counter:{x0:77,y0:24,z0:0,x1:156,y1:42,z1:29},cabinet:{x0:80,y0:1,z0:0,x1:210,y1:18,z1:38,cavityDepth:4},shelves,contents,
   props:[{asset:'sorting-lamp',x:95,y:38,z:29,radius:2.8,height:19},{asset:'sorting-flowers',x:145,y:38,z:29,radius:2.3,height:16}],
   palm:{x0:216,y0:24,z0:0,x1:224,y1:32,z1:43},palmAnchor:{x:220,y:28,z:14,height:30}};
 }
 function box(p,x,y,z,w,d,h,kind='wood'){CityHallClockBay.paperBox(p,x,y,z,w,d,h,kind);}
 function face(p,points,kind='wood',shade=0){CityHallClockBay.paperFace(p,points,kind,shade);}
 function rear(p,name,x,y,z,w,h){CityHallClockBay.rearImage(p,name,x,y,z,w,h);}
 function artwork(p,asset,x,y,z,height){
  const a=CityHallProjection.project(x,y,z),meta=CityHallAssets.registration[asset],anchor=meta.registration.anchor,w=height*meta.width/meta.height;
  p.c.drawImage(p.images[asset],a.x-w*anchor[0],a.y-height*anchor[1],w,height);
 }
 function panel(p,x,y,z,w,h){
  face(p,[[x,y,z+h],[x+w,y,z+h],[x+w,y,z],[x,y,z]],'wood',-.27);
  box(p,x+.8,y+.1,z+.8,w-1.6,.6,h-1.6);
  for(const u of [x,x+w-.6])box(p,u,y+.1,z,.6,.9,h);
  for(const v of [z,z+h-.65])box(p,x,y+.1,v,w,.9,.65);
 }
 function cabinets(p){
  const s=layout(),b=s.cabinet;
  p.shadow(146,12,0,72,14,.17);box(p,b.x0,b.y0,0,130,17,2.3,'green');
  box(p,80,1,2.3,130,16,6.7);
  for(let x=82;x<208;x+=12.7){panel(p,x,17.2,3,10.8,5);p.line([x+4,18.2,6.5],[x+6,18.2,6.5],'#b99250',.5);}
  // Dark backing planes and real side depth make emptier pigeonholes readable.
  for(let i=0;i<10;i++)for(let row=0;row<3;row++){
   const x=82+i*12.7,z=s.shelves[row].z1;
   face(p,[[x,14,z+7.4],[x+11.6,14,z+7.4],[x+11.6,14,z],[x,14,z]],'wood',-.48+(i%3)*.035);
   face(p,[[x,18,z],[x+11.6,18,z],[x+11.6,14,z],[x,14,z]],'wood',-.12);
  }
  for(const shelf of s.shelves)box(p,80,14,shelf.z0,130,4,1);
  for(const v of s.contents){
   const x=v.x0,y=v.y0,z=v.z0,w=v.x1-x,d=v.y1-y,h=v.z1-z;
   if(v.kind<2){for(let k=0;k<h;k+=.5){p.box(x+(k%1)*.3,y,z+k,w-.3,d,.45,'stone');p.line([x,y+d,z+k],[x+w-.3,y+d,z+k],'#d3bf98',.12);}p.planeImage('letters',x+.3,y+.3,v.z1+.05,w-1,d-1,'floor',.8);}
   else {p.box(x,y,z,w,d,h,v.kind===3?'red':v.kind===4?'green':v.kind===5?'wood':'stone');p.line([x+w*.45,y,v.z1+.1],[x+w*.45,y+d,v.z1+.1],'#edddb4',.35);p.line([x+w*.45,y+d,z],[x+w*.45,y+d,v.z1],'#e4d3ad',.35);rear(p,'letters',x+w*.75,y+d+.1,z+h*.55,2.4,1.2);}
  }
  // Only the narrow front lips may cover contents; their rear planes were drawn first.
  for(const s0 of s.shelves)box(p,80,17.5,s0.z0,130,.5,1);
  box(p,80,14,37,130,4,1);
  for(let i=0;i<=10;i++)box(p,80.8+i*12.7,14,9,.9,4,28);
  for(const x of [80,208.6]){box(p,x,1,2,1.4,17,36);box(p,x-.2,17.5,2,1.8,.7,36,'wood');}
  box(p,79.7,.7,37.6,130.6,18,.9,'wood');p.line([80,18.1,38.3],[210,18.1,38.3],'#ecd1a1',.35);
  // Small ivory label holders are quiet against the dark bank.
  for(let i=0;i<10;i++)for(const z of [18.3,27.3,36.3]){box(p,85+i*12.7,18,z,3.8,.3,.75,'gold');p.line([85.4+i*12.7,18.4,z+.4],[88.4+i*12.7,18.4,z+.4],'#efe2c8',.35);}
 }
 function counter(p){
  const s=layout(),b=s.counter;
  // Painted after the cabinet and gallery supports, so the near counter wins
  // occlusion at their shared screen pixels.
  p.shadow(119,35,0,51,17,.22);box(p,78,25,0,77,16,2,'green');box(p,77,24,2,79,18,24);
  box(p,76.6,23.7,3,79.8,18.7,1.2,'wood');box(p,76.7,23.6,24.8,79.6,18.8,1.3,'wood');
  box(p,76,23,26.1,81,20,1.2,'gold');box(p,76,23,27.3,81,20,1.7,'stone');
  p.line([76,43.05,27.25],[157,43.05,27.25],'#786846',.4);
  p.line([76.3,42.8,29.05],[156.7,42.8,29.05],'#fff5dc',.48);
  // Both a proper end panel and a restrained postal crest survive the wider view.
  face(p,[[156.1,26,23],[156.1,39.5,23],[156.1,39.5,6],[156.1,26,6]],'wood',-.25);
  face(p,[[77,42.1,25],[156,42.1,25],[156,42.1,4.2],[77,42.1,4.2]],'wood',-.12);
  for(const x of [79,96,113,130,147]){const w=Math.min(14.7,154-x);if(w>3)panel(p,x,42.2,6,w,16);}
  box(p,109,43.2,11,16,.5,10,'green');rear(p,'crest',117,43.9,16,14,9);
 }
 function details(p){
  const s=layout();
  box(p,113.5,35,29,12,5.5,.7,'green');box(p,114,35.3,29.7,11,4.8,.6,'stone');p.planeImage('letters',114.4,35.5,30.35,10,4.3,'floor');
  for(const a of s.props){p.shadow(a.x+.5,a.y+.5,a.z,a.radius*1.4,a.radius*.65,.19);artwork(p,a.asset,a.x,a.y,a.z,a.height);}
  // Warm lamp light belongs to the worktop, without washing out the board.
  p.face([[90,35,29.08],[100,35,29.08],[101,42,29.08],[88,42,29.08]],'#ffe9a316',null);
 }
 function stairs(p,L){
  const steps=L.stairs.steps;
  for(const s of steps){face(p,[[s.x0,s.y1,s.z1],[s.x1,s.y1,s.z1],[s.x1,s.y0,s.z1],[s.x0,s.y0,s.z1]],'stone',.08);p.line([s.x0,s.y1,s.z1-.35],[s.x1,s.y1,s.z1-.35],'#9f9278',.55);p.line([s.x0,s.y1,s.z1+.05],[s.x1,s.y1,s.z1+.05],'#fff2d5',.32);}
  stairRails(p);
 }
 function stairRails(p){
  for(const x of [29.3,49]){
   face(p,[[x,96,0],[x,36,43],[x,36,46],[x,96,3]],'green',-.05);
   p.line([x,96,2.7],[x,36,45.7],'#718a70',.28);
   for(let i=0;i<=10;i++){const y=96-i*6,z=i*46/10;p.line([x,y,z+3],[x,y,z+13],'#486f58',.65);p.line([x+.3,y,z+3],[x+.3,y,z+13],'#849675',.15);}
   p.line([x,96,13],[x,36,59],'#936d34',1.5);p.line([x,96,13.6],[x,36,59.6],'#edcf82',1.1);
   for(const [y,z]of [[96,0],[36,46]]){box(p,x-1,y-1,z,2,2,14,'green');box(p,x-1.3,y-1.3,z+13.6,2.6,2.6,.9,'gold');CityHallClockBay.paperFinial(p,x,y,z+14.5);}
  }
 }
 function landing(p){
  for(let x=53;x<111;x+=5.3){box(p,x,23.4,47,.8,1,10.8,'green');box(p,x-.2,23.3,52,1.2,1.2,.9,'green');}
  box(p,50,23.4,47,61,1.3,1.3,'green');box(p,50,23.4,56.8,61,1.6,1.5,'green');box(p,49.5,22.9,58.3,62,2.6,1.1,'gold');box(p,49.5,22.75,59.4,62,2.9,.6,'gold');
  for(const x of [50,80,111]){box(p,x-1,22.8,46,2,2.6,14,'green');box(p,x-1.4,22.5,59.7,2.8,3.2,1,'gold');CityHallClockBay.paperFinial(p,x,24,60.7);}
  box(p,75,24.2,49,10,1,7.6,'green');rear(p,'crest',80,25.3,52.8,8.8,5.65);
 }
 function plant(p){
  const a=layout().palmAnchor,x=a.x,y=a.y;
  p.shadow(x+1,y+2,0,10,5,.18);box(p,x-4,y-4,0,8,8,2,'gold');box(p,x-3.6,y-3.6,2,7.2,7.2,11,'green');
  for(const dx of [-3.6,3])box(p,x+dx,y+3.6,2,.6,.4,11,'gold');
  box(p,x-4,y-4,12.8,8,8,1.2,'gold');p.ellipse(x,y,14,4.4,2.2,'#6b583d');
  rear(p,'crest',x,y+4.1,7.5,5.6,3.6);artwork(p,'sorting-palm',x,y,14,a.height);
 }
 return {layout,cabinets,counter,details,stairs,stairRails,landing,plant};
});
