/* One finished bay. Artwork receives measured faces; all work runs at bake time.
   The wall service chase is behind the gallery's occupied walking envelope. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallClockBay=api;})(globalThis,function(){
 'use strict';
 const quadrants={stone:[0,0],green:[627,0],gold:[0,627],wood:[627,627]};
 function layout(){return {
  lamps:[{x:166,y:15,z:90},{x:220,y:15,z:90}],
  clock:{x:140,y:9.5,z:93.8,width:41,height:41*4/3},pipeRadius:3.1,
  pipes:[[[108,5,116],[119,5,116],[119,5,64],[173,5,64],[173,5,130],[214,5,130],[214,5,32]]],
  mounts:[{x0:116,y0:0,z0:56,x1:131,y1:9,z1:68},{x0:211,y0:0,z0:52,x1:217,y1:9,z1:56}]
 };}
 function face(p,pts,kind,shade=0){
  const c=p.c,P=CityHallProjection,a=P.project(...pts[0]),b=P.project(...pts[1]),d=P.project(...pts[3]),uv=quadrants[kind];
  c.save();c.beginPath();for(let i=0;i<pts.length;i++){const q=P.project(...pts[i]);if(i)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);}c.closePath();c.clip();
  c.transform(b.x-a.x,b.y-a.y,d.x-a.x,d.y-a.y,a.x,a.y);c.drawImage(p.images['clock-bay-stock'],uv[0]+1,uv[1]+1,625,625,0,0,1,1);
  // Pigment colour and directional shade remain separate from the retained paper grain.
  const pigment=kind==='green'?['#164c3d',.22]:kind==='wood'?['#9d582d',.13]:kind==='gold'?['#be872b',.055]:['#ffe0a5',.055];
  c.fillStyle=pigment[0];c.globalAlpha=pigment[1];c.fillRect(0,0,1,1);
  if(shade){c.fillStyle=shade>0?'#fff2cf':kind==='wood'?'#413d2b':'#203f38';c.globalAlpha=Math.min(.75,Math.abs(shade)*(shade>0?1.2:1.32));c.fillRect(0,0,1,1);}c.restore();
 }
 function box(p,x,y,z,w,d,h,kind='stone'){
  face(p,[[x,y+d,z+h],[x+w,y+d,z+h],[x+w,y+d,z],[x,y+d,z]],kind,-.06);
  face(p,[[x+w,y+d,z+h],[x+w,y,z+h],[x+w,y,z],[x+w,y+d,z]],kind,kind==='green'?-.29:-.23);
  face(p,[[x,y,z+h],[x+w,y,z+h],[x+w,y+d,z+h],[x,y+d,z+h]],kind,.12);
  // The exposed cut follows its material: painted card has no ivory wire outline.
  const edge=kind==='green'?'#718a70':kind==='wood'?'#c5a272':kind==='gold'?'#e3c782':'#fff0ca';
  p.line([x,y+d,z+h],[x+w,y+d,z+h],edge,kind==='green'?.15:.22);
  if(h>5&&w>2&&d>2)p.line([x+w,y+d,z+.2],[x+w,y+d,z+h-.2],edge,kind==='stone'?.26:.14);
 }
 function rearImage(p,name,x,y,z,w,h,alpha=1){const a=CityHallProjection.project(x-w/2,y,z+h/2),c=p.c;c.save();c.transform(1,.5,0,1,a.x,a.y);c.globalAlpha=alpha;c.drawImage(p.images[name],0,0,w,h);c.restore();}
 function finialGeometry(x,y,z){
  // A seated neck and three folded shoulders, in the same world space as its post.
  const profile=[[0,.32],[.35,.32],[.62,.74],[1.2,.88],[1.85,.65],[2.25,.22]],rings=profile.map(([h,r])=>Array.from({length:8},(_,i)=>[x+Math.cos(i*Math.PI/4)*r,y+Math.sin(i*Math.PI/4)*r,z+h])),faces=[];
  for(let j=1;j<rings.length;j++)for(let i=0;i<8;i++)faces.push([rings[j-1][i],rings[j-1][(i+1)%8],rings[j][(i+1)%8],rings[j][i]]);
  faces.push(rings[0].slice().reverse(),rings.at(-1));return faces;
 }
 function finial(p,x,y,z){
  const c=p.c,light=unit([-.46,-.25,1]),faces=finialGeometry(x,y,z).map(points=>({points,normal:unit(cross(sub(points[1],points[0]),sub(points[2],points[0]))),depth:points.reduce((s,v)=>s+v[0]+v[1]+v[2],0)/points.length}));
  faces.sort((a,b)=>a.depth-b.depth);
  for(const f of faces){
   if(dot(f.normal,[1,1,1])<=0)continue;
   const q=f.points.map(v=>CityHallProjection.project(...v)),xs=q.map(v=>v.x),ys=q.map(v=>v.y),x0=Math.min(...xs),y0=Math.min(...ys),w=Math.max(...xs)-x0,h=Math.max(...ys)-y0;
   c.save();c.beginPath();q.forEach((v,i)=>i?c.lineTo(v.x,v.y):c.moveTo(v.x,v.y));c.closePath();c.clip();
   c.drawImage(p.images['clock-bay-stock'],1,628,625,625,x0,y0,w,h);
   const amount=dot(f.normal,light);c.fillStyle=amount>0?'#fff2cb':'#504832';c.globalAlpha=amount>0?.04+amount*.22:.08-amount*.3;c.fillRect(x0,y0,w,h);c.restore();
  }
 }
 function wall(p){
  // Each ivory course is a receiving wall face, not a second window backdrop.
  for(let z=52;z<133;z+=9)for(let x=116-((z-52)/9%2)*11.5;x<162;x+=23){const x0=Math.max(116,x),x1=Math.min(162,x+23);face(p,[[x0,0.4,z+8.8],[x1,0.4,z+8.8],[x1,0.4,z],[x0,0.4,z]],'stone',((z-52)/9%3)*.012);p.line([x0,.6,z],[x1,.6,z],'#b8aa91',.14);if(x>116)p.line([x,.6,z+.3],[x,.6,z+8.5],'#bdae92',.12);}
  const u0=176,u1=211,r=(u1-u0)/2,mid=(u0+u1)/2,spring=127-r;
  for(const x of [u0-3.7,u1]){box(p,x,0,55,3.7,4.7,spring-55);box(p,x-.5,-.3,54,4.7,5.7,2);}
  for(let i=0;i<14;i++){
   const a=i*Math.PI/14,b=(i+1)*Math.PI/14,at=(v,rr,y)=>[mid+Math.cos(v)*rr,y,spring+Math.sin(v)*rr];
   face(p,[at(a,r+3.7,4.7),at(b,r+3.7,4.7),at(b,r,4.7),at(a,r,4.7)],'stone',i<7?-.06:.03);
   face(p,[at(a,r,4.7),at(b,r,4.7),at(b,r,0),at(a,r,0)],'stone',-.32);
   p.line(at(a,r,4.8),at(a,r+3.7,4.8),'#b6a589',.16);
   p.line(at(a,r,4.8),at(b,r,4.8),'#f7e8c9',.23);
  }
  box(p,mid-2,1,125.5,4,5.5,6,'stone');box(p,u0-4,-1,51,u1-u0+8,8,3);box(p,u0-4.5,-1.3,53.5,u1-u0+9,8.8,.8,'gold');
  for(const x of [166,220]){
   box(p,x-2.8,7.9,61,5.6,.6,65,'green');
   for(const dx of [-1.65,0,1.65]){p.line([x+dx,8.7,64],[x+dx,8.7,122],'#1d493a',.38);p.line([x+dx-.27,8.7,64],[x+dx-.27,8.7,122],'#71876b',.14);}
   box(p,x-4,0,126,8,9,1.5,'gold');box(p,x-4.7,-.4,127.5,9.4,10,3,'green');box(p,x-5.5,-1,130.5,11,11,1.2,'gold');
   for(let k=-3;k<=3;k+=2)box(p,x+k-.5,9,128,.9,1.1,2.1,'green');
  }
  box(p,116,-1,132,108,6,2,'gold');box(p,116,-2,134,108,7.5,3.5);box(p,116,-2.6,137.5,108,8.6,.8);
  for(let x=118;x<224;x+=5)box(p,x,3.7,130.5,2.2,1.6,1.7);
 }
 function gallery(p){
  box(p,112,21,37.5,112,2.5,5,'green');box(p,112,20.8,42.5,112,3.4,1.2,'gold');box(p,112,21,43.7,112,4,2.3);
  p.line([112,24.25,43.5],[224,24.25,43.5],'#59604a',.4);
  for(let x=116;x<222;x+=5)box(p,x,23.6,39.6,1.8,.8,1.8,'green');
  for(const x of [112,164,218]){
   box(p,x-2.5,18.5,0,5,5,36.5,'green');box(p,x-3.5,18,0,7,6,3);box(p,x-3.5,18,34,7,6,2,'gold');
   for(const sign of [-1,1]){const points=[[x,24,36],[x+sign*10,24,40],[x+sign*7,24,36],[x,24,29]];face(p,points,'green',-.07);p.line(points[0],points[1],'#173d32',.65);p.line(points[2],points[3],'#758b70',.22);}
  }
 }
 function rail(p){
  const y=23.4;
  for(let x=114;x<224;x+=5.3){box(p,x,y,47,.8,1,10.8,'green');box(p,x-.2,y-.1,52,1.2,1.2,.9,'green');}
  box(p,112,y,47,112,1.3,1.3,'green');box(p,112,y,56.8,112,1.6,1.5,'green');box(p,111.5,y-.5,58.3,113,2.6,1.1,'gold');box(p,111.5,y-.65,59.4,113,2.9,.6,'gold');
  for(const x of [112,140,168,196,224]){box(p,x-1,y-.6,46,2,2.6,14,'green');box(p,x-1.4,y-.9,59.7,2.8,3.2,1,'gold');finial(p,x,y+.6,60.7);}
  // Full retained crest on two small plaques; open balusters retain the worker.
  for(const x of [140,196]){box(p,x-5,y+.8,49,10,1,7.6,'green');rearImage(p,'crest',x,y+1.9,52.8,8.8,5.65);}
 }
 const add=(a,b)=>a.map((v,i)=>v+b[i]),sub=(a,b)=>a.map((v,i)=>v-b[i]),mul=(a,k)=>a.map(v=>v*k);
 const dot=(a,b)=>a.reduce((v,x,i)=>v+x*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],unit=a=>mul(a,1/Math.hypot(...a));
 function pipeGeometry(points){
  // A closed octagonal paper tube, swept in world space. Frames are transported
  // through each elbow so the same folded edge continues around the bend.
  const path=[points[0].slice()],solids=[];
  function extend(to){const from=path.at(-1),n=Math.ceil(Math.hypot(...sub(to,from))/18);for(let i=1;i<=n;i++)path.push(add(from,mul(sub(to,from),i/n)));}
  for(let i=1;i<points.length-1;i++){
   const a=points[i-1],b=points[i],d=points[i+1],u=unit(sub(b,a)),v=unit(sub(d,b)),r=Math.min(4,Math.hypot(...sub(b,a))*.22,Math.hypot(...sub(d,b))*.22),start=sub(b,mul(u,r)),end=add(b,mul(v,r));
   extend(start);for(let j=1;j<=6;j++){const t=j/6;path.push(add(add(mul(start,(1-t)**2),mul(b,2*t*(1-t))),mul(end,t*t)));}
  }
  extend(points.at(-1));path[path.length-1]=points.at(-1).slice();
  const frame=t=>unit(cross(Math.abs(t[2])<.9?[0,0,1]:[0,1,0],t));
  const ring=(p,t,n,r)=>{const v=cross(t,n);return Array.from({length:8},(_,k)=>add(p,add(mul(n,r*Math.cos(k*Math.PI/4)),mul(v,r*Math.sin(k*Math.PI/4)))));};
  const face=points=>({points,normal:unit(cross(sub(points[1],points[0]),sub(points.at(-1),points[0])))});
  const join=(a,b)=>a.map((p,k)=>face([p,a[(k+1)%8],b[(k+1)%8],b[k]]));
  let tangent=unit(sub(path[1],path[0])),normal=frame(tangent);const rings=[];
  for(let i=0;i<path.length;i++){
   const next=unit(sub(path[Math.min(i+1,path.length-1)],path[Math.max(0,i-1)])),axis=cross(tangent,next),s=Math.hypot(...axis),c=dot(tangent,next);
   if(s>1e-8){const a=mul(axis,1/s);normal=add(add(mul(normal,c),mul(cross(a,normal),s)),mul(a,dot(a,normal)*(1-c)));}
   tangent=next;normal=unit(sub(normal,mul(tangent,dot(normal,tangent))));rings.push(ring(path[i],tangent,normal,2.65));
  }
  const body=[face(rings[0].slice().reverse())];for(let i=1;i<rings.length;i++)body.push(...join(rings[i-1],rings[i]));body.push(face(rings.at(-1)));solids.push({kind:'body',faces:body});
  // Collars are folded annular strips with bevels and a hidden inner surface,
  // rather than painted rings. Their outer radius retains the cleared envelope.
  for(let i=1;i<points.length;i++){
   const a=points[i-1],b=points[i],length=Math.hypot(...sub(b,a)),t=unit(sub(b,a)),n=frame(t);
   const count=Math.max(1,Math.floor(length/24));
   for(let j=0;j<count;j++){
    const distance=length*(j+.5)/count;if(distance<5||length-distance<5)continue;
    const centre=add(a,mul(t,distance)),profile=[[-.8,2.64],[-.5,3.1],[.5,3.1],[.8,2.64]],rr=profile.map(([offset,r])=>ring(add(centre,mul(t,offset)),t,n,r)),faces=[];
    for(let k=0;k<rr.length;k++)faces.push(...join(rr[k],rr[(k+1)%rr.length]));solids.push({kind:'collar',faces});
   }
  }
  return {path,solids};
 }
 function pipe(p,points){
  const c=p.c,mesh=pipeGeometry(points),light=unit([-.46,-.25,1]),faces=[];
  for(const solid of mesh.solids)for(const f of solid.faces){if(dot(f.normal,[1,1,1])<=0)continue;const q=f.points.map(v=>CityHallProjection.project(...v)),path=new Path2D();q.forEach((v,i)=>i?path.lineTo(v.x,v.y):path.moveTo(v.x,v.y));path.closePath();faces.push({...f,kind:solid.kind,q,path,depth:f.points.reduce((s,v)=>s+v[0]+v[1]+v[2],0)/f.points.length});}
  faces.sort((a,b)=>a.depth-b.depth);
  const silhouette=new Path2D();for(const f of faces)silhouette.addPath(f.path);c.save();c.translate(.8,1);c.fillStyle='#263d342c';c.fill(silhouette);c.restore();
  for(const f of faces){
   const xs=f.q.map(v=>v.x),ys=f.q.map(v=>v.y),x=Math.min(...xs),y=Math.min(...ys),w=Math.max(...xs)-x,h=Math.max(...ys)-y;
   if(w<1e-6||h<1e-6)continue;
   c.save();c.clip(f.path);c.fillStyle='#c3a660';c.fillRect(x,y,w,h);
   // Sample the retained brass paper at a consistent grain scale; no gloss band.
   c.drawImage(p.images['clock-bay-stock'],31,658,Math.min(560,Math.max(24,w*12)),Math.min(560,Math.max(24,h*12)),x,y,w,h);
   c.fillStyle='#c2b08a';c.globalAlpha=f.kind==='collar'?.25:.08;c.fillRect(x,y,w,h);
   const amount=dot(f.normal,light);c.fillStyle=amount>0?'#fff2c8':'#403e30';c.globalAlpha=amount>0?.05+amount*.27:.12-amount*.38;c.fillRect(x,y,w,h);
   c.globalAlpha=f.kind==='collar'?.55:.2;c.strokeStyle=amount>0?'#fff0c8':'#695d3d';c.lineWidth=f.kind==='collar'?.23:.12;c.stroke(f.path);c.restore();
  }
 }
 function pipes(p){
  const b=layout();for(const path of b.pipes)pipe(p,path);
  // Wall feet support the service body and the lower return. No gallery post.
  for(const m of b.mounts){box(p,m.x0,m.y0,m.z0,m.x1-m.x0,1,m.z1-m.z0,'green');box(p,m.x0+1,1,m.z0+1,m.x1-m.x0-2,m.y1-1,1.5,'gold');}
  box(p,116.5,2,57,13,6.5,10,'gold');for(const z of [57,66])box(p,116,1.7,z,14,7.1,1,'gold');
  for(const x of [120,126]){const a=CityHallProjection.project(x,9,62),c=p.c;c.save();c.transform(1,.5,0,1,a.x,a.y);c.beginPath();c.arc(0,0,2.8,0,Math.PI*2);c.fillStyle='#e8c775';c.fill();c.strokeStyle='#8e6d36';c.lineWidth=.5;c.stroke();c.beginPath();c.arc(0,0,2.1,0,Math.PI*2);c.fillStyle='#f9edcf';c.fill();for(let i=0;i<8;i++){const a=i*Math.PI/4;c.beginPath();c.moveTo(Math.sin(a)*1.55,Math.cos(a)*1.55);c.lineTo(Math.sin(a)*1.85,Math.cos(a)*1.85);c.strokeStyle='#335d4c';c.lineWidth=.15;c.stroke();}c.beginPath();c.moveTo(0,0);c.lineTo(-.6,-1.2);c.lineWidth=.3;c.stroke();c.restore();}
  for(const [x,z]of [[119,98],[173,91],[214,99]]){box(p,x-2,0,z-2,4,1,4,'green');box(p,x-1,1,z-1,2,5,1.5,'gold');}
 }
 function lamps(p){
  for(const {x,z}of layout().lamps){
   // The small warm pool is received by the column, behind the physical lamp.
   const a=CityHallProjection.project(x,8.8,z+2),c=p.c;c.save();c.translate(a.x,a.y);c.transform(1,.5,0,1,0,0);const g=c.createRadialGradient(0,0,1,0,0,10);g.addColorStop(0,'#ffdc7c55');g.addColorStop(1,'#ffdc7c00');c.fillStyle=g;c.fillRect(-10,-10,20,20);c.restore();
   box(p,x-1.7,8,z+7,3.4,1.2,4,'gold');box(p,x-.6,9,z+9,1.2,7,1.3,'gold');p.line([x,15,z+9],[x,15,z+6],'#d3aa52',.85);
   p.box(x-2,13,z-1,4,4,6,['#fff0b5','#ffe19b','#ebc576']);
   for(const dx of [-2,2])for(const dy of [13,17])p.line([x+dx,dy,z-1],[x+dx,dy,z+5],'#a87932',.45);
   box(p,x-2.4,12.6,z-1.5,4.8,4.8,.8,'gold');box(p,x-2.5,12.5,z+5,5,5,.7,'gold');
   p.face([[x-2.5,12.5,z+5.7],[x+2.5,12.5,z+5.7],[x,15,z+7.3]],'#efce78','#c09542',.2);p.face([[x+2.5,12.5,z+5.7],[x+2.5,17.5,z+5.7],[x,15,z+7.3]],'#b98d41','#c09542',.2);
  }
 }
 function clock(p){
  const a=layout().clock,c=p.c;
  // A real projecting mount and opaque card layers hold the original full art.
  box(p,a.x-8,0,80,16,8,20,'green');
  c.save();c.shadowColor='#253a3466';c.shadowBlur=1.2;c.shadowOffsetX=1.4;c.shadowOffsetY=1.8;rearImage(p,'clock-bay-clock',a.x,8.6,a.z-.6,a.width,a.height);c.restore();
  rearImage(p,'clock-bay-clock',a.x,a.y,a.z,a.width,a.height);
 }
 return {layout,wall,gallery,rail,pipes,clock,lamps,paperBox:box,paperFace:face,paperPipe:pipe,pipeGeometry,paperFinial:finial,finialGeometry,rearImage};
});
