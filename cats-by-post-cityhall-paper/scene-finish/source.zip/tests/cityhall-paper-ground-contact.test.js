const test=require('node:test'),assert=require('node:assert/strict'),D=require('../src/fidelity/cityhall-paper/daylight');
test('exterior contacts use raised footways and entrance walks rather than the lower street',()=>{
 assert.equal(typeof D.groundHeight,'function');
 for(const [x,y]of [[57,233],[175,233],[248,152],[3,233],[100,300],[200,250],[200,335],[-100,80]])assert.equal(D.groundHeight(x,y),-12,`raised paving ${x},${y}`);
 for(const [x,y]of [[-61,225],[-74,185],[244,308],[100,-110],[400,400]])assert.equal(D.groundHeight(x,y),-14,`lower square ${x},${y}`);
});
