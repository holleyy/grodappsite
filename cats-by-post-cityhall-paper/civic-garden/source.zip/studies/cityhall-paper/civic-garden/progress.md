# Ledger — plan: studies/cityhall-paper/civic-garden/plan.md

Ruling: this is a requested refinement within the approved scene direction,
not a new concept selection. Existing authorisation covers implementation and
an isolated new public checkpoint; no repeated approval gate is needed.
Ruling: use the existing owned worktree and study/evidence folders. Preserve
all earlier review material. Measured world geometry and retained full art
remain the approved renderer approach.
Pre-flight: the east tree is outside x228 but previously painted behind the
hall; foreground layer bounds must also contain the new gardens. Planting
shares the existing arrival path and retained front tree root contact.
Task1: preserved runtime4e9ae07e. Capturing before and canopy regression.
Task1 complete: actual-renderer crown test failed at42.046% visible, then
passed at100% (11259 samples). Near trees sort with foreground civic items.
Task2 complete: two grounded low beds, retained front tree, mixed original
flowers/new full shrub artwork, one bench and warm staggered stone setts.
Route/support regression failed before beds existed, then all7 affected cases
passed. Foreground bounds grow50 world units to include the entire planting.
Task3 complete:39 focused,72 browser,26 qualification and44 phone checks pass;
all15 deliveries win; all195 protected files,238 inputs and three board rasters
are exact. Fresh Astra review found no Critical/Important/actionable Minor
issues. Independent120 warm draws create no canvases; disposal releases all.
Task4: prepare isolated civic-garden public child with22 matched captures,
actual32-second motion, source and receipts. Preserve prior public files.
