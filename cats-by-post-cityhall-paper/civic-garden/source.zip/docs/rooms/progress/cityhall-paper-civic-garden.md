# City Hall — near tree and planted civic square

User feedback identifies a street tree hidden below the hall edge and a sparse,
concrete foreground. This continues the accepted Grand Postal Vault direction
from source4265b25b/runtime4e9ae07e. Plan/ledger are under
`studies/cityhall-paper/civic-garden/`; gallery/evidence under
`docs/review-images/cityhall-paper/civic-garden/`.

The east tree was physically outside the near x228 boundary, but was drawn in
the backdrop. Both near trees now join the foreground civic furniture, sorted
by their world root depth. Existing tree artwork and position remain exact.
An actual-renderer pixel check improves from4734/11259 to11259/11259 visible
opaque upper-crown samples. Two planted stone beds leave the complete connected
approach clear. The front tree roots in a bed, with low sage shrubs, retained
small flower clusters and one green municipal bench. Smaller warm staggered
stone setts replace the broad grey ground pattern without changing its world
phase or infinite coverage.

All new art retains its original full master and registration. Planting,
sorting and paving prepare once. The existing foreground canvas grows50 world
units in height, adding560000 backing bytes; buffer/bake counts stay53/11.
Swift/Metal mapping remains prepared textures and fixed world geometry; no
native changes or new live render system is introduced.

Verification:39 focused tests,72 canonical browser checks,26 qualification
checks,44 phone checks,15 City Hall wins,195 protected files,238 build inputs,
three exact board rasters and the full opaque crown check. One fresh Astra
review has no Critical, Important or actionable Minor findings. It independently
confirms120 warm draws create no canvases and disposal releases all owned
buffers. Physical-device and final whole-scene artistic acceptance remain open.

Publish only the authorised new child
`cats-by-post-cityhall-paper/civic-garden/` in holleyy/grodappsite. Preserve every
previous checkpoint and other room; no cosysortie source push is included.
The local deployment receipt records the merged packet and Pages result.
