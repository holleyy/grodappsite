/* The neighbouring town is measured scenery in the hall's own world plane.
   Only the distant skyline is an image. Construction happens once at load. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallEnvironment=api;})(globalThis,function(){
 'use strict';
 const ground=-12,stone=['#eadcc3','#d3c2a6','#b5a38c'],roof=['#9aaba6','#7c9690','#647f7d'];
 const box=(id,x0,y0,z0,x1,y1,z1)=>({id,x0,y0,z0,x1,y1,z1});
 function layout(){
  return {ground,foundation:box('foundation',-4,-4,ground,228,196,-10),pavement:box('pavement',-38,-38,-14,263,245,ground),
   steps:Array.from({length:6},(_,i)=>box('arrival-step-'+i,86,194+i*4,ground,142,198+i*4,0-2*i)),approach:box('arrival',86,218,ground,142,245,ground),
   buildings:[box('civic-library',-138,28,ground,-70,100,70),box('archive',-32,-190,ground,42,-144,50),box('town-houses',155,-157,ground,211,-113,43),box('east-offices',308,-59,ground,356,-12,42)],
   trees:[box('square-tree-west',-46,121,ground,-22,145,42),box('square-tree-east',249,100,ground,273,124,45),box('square-tree-front',171,266,ground,195,290,40),box('library-tree',-113,139,ground,-89,163,41),box('clock-courtyard-tree',116,-76,ground,140,-52,39)],
   lamps:[box('arrival-lamp-left',74,220,ground,78,224,29),box('arrival-lamp-right',150,220,ground,154,224,29),box('corner-lamp',239,177,ground,243,181,29)],
   fountain:box('civic-fountain',-58,165,ground,-10,213,17)};
 }
 function paving(p){CityHallDaylight.paving(p);CityHallDaylight.forecourt(p);}
 function pavement(p,b){
  p.box(b.x0,b.y0,b.z0,b.x1-b.x0,b.y1-b.y0,b.z1-b.z0,stone);
  for(let y=b.y0;y<b.y1;y+=16)for(let x=b.x0;x<b.x1;x+=24){const x1=Math.min(b.x1,x+24),y1=Math.min(b.y1,y+16);p.face([[x,y,b.z1+.05],[x1,y,b.z1+.05],[x1,y1,b.z1+.05],[x,y1,b.z1+.05]],((x-b.x0)/24+(y-b.y0)/16)%3?'#d8cfb9':'#ded4be','#c3baa6',.25);}
  for(let x=b.x0;x<b.x1;x+=12)p.box(x,b.y1-2,b.z1-.3,Math.min(12,b.x1-x),2,1,stone);
  for(let y=b.y0;y<b.y1;y+=12)p.box(b.x1-2,y,b.z1-.3,2,Math.min(12,b.y1-y),1,stone);
 }
 function building(p,b,index){CityHallVaultAndWalls.building(p,b,index);}
 function leaf(p,x,y,z,rx,ry,col,seed){
  const q=CityHallProjection.project(x,y,z),points=[];for(let i=0;i<24;i++){const a=i*Math.PI/12,r=1+(i%2?.08:-.04);points.push([q.x+Math.cos(a)*rx*r,q.y+Math.sin(a)*ry*r]);}
  p.path(points,col,'#7c825e',.18);p.c.save();p.c.translate(-.35,-.5);p.path(points,null,'#d2cd91',.35);p.c.restore();
  for(let j=0;j<3;j++){const a=(seed+j)*2.399,dx=Math.cos(a)*rx*.55,dy=Math.sin(a)*ry*.5;p.c.beginPath();p.c.moveTo(q.x+dx-1,q.y+dy+1);p.c.quadraticCurveTo(q.x+dx+2,q.y+dy-3,q.x+dx+4,q.y+dy);p.c.strokeStyle='#e0d99d66';p.c.lineWidth=.4;p.c.stroke();}
 }
 function tree(p,b,index){
  const x=(b.x0+b.x1)/2,y=(b.y0+b.y1)/2,z=b.z0,h=b.z1-z;
  p.shadow(x+4,y+3,z,31,13,.2);if(!CityHallCivicSquare.layout().gardens.some(g=>x>g.x0&&x<g.x1&&y>g.y0&&y<g.y1)){p.box(x-10,y-10,-14,20,20,2,stone);p.box(x-8,y-8,z,16,16,1,['#9b956c','#aaa584','#aaa584']);}
  const a=CityHallProjection.project(x,y,z+1),ih=h/.984,iw=ih*.75;p.c.drawImage(p.images['clock-bay-tree'],a.x-iw*.497,a.y-ih*.984,iw,ih);
 }
 function lamp(p,b){CityHallCivicSquare.lamp(p,b);}
 function ring(p,x,y,z,r,height,fill){
  const n=32;for(let i=0;i<n;i++){const a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n;CityHallClockBay.paperFace(p,[[x+Math.cos(a)*r,y+Math.sin(a)*r,z],[x+Math.cos(b)*r,y+Math.sin(b)*r,z],[x+Math.cos(b)*r,y+Math.sin(b)*r,z+height],[x+Math.cos(a)*r,y+Math.sin(a)*r,z+height]],'stone',-.08-.14*(1+Math.sin(a))*.5);}
 }
 function rim(p,x,y,z,r,inner){for(let i=0;i<32;i++){const a=i*Math.PI/16,b=(i+1)*Math.PI/16,at=(t,d)=>[x+Math.cos(t)*d,y+Math.sin(t)*d,z];CityHallClockBay.paperFace(p,[at(a,r),at(b,r),at(b,inner),at(a,inner)],'stone',.06);if(i%2===0)p.line(at(a,inner),at(a,r),'#bdae90',.16);}}
 function fountain(p,b){
  const x=(b.x0+b.x1)/2,y=(b.y0+b.y1)/2,z=b.z0;
  p.shadow(x+3,y+4,z,35,18,.15);ring(p,x,y,z,24,1.5,'#d8cbb2');p.ellipse(x,y,z+1.5,24*Math.SQRT2,12*Math.SQRT2,'#e5d9c0','#c2b395',.6);
  ring(p,x,y,z+1.5,20,4,'#c8baa1');rim(p,x,y,z+5.5,20,17);p.ellipse(x,y,z+5.6,17*Math.SQRT2,8.5*Math.SQRT2,'#91b7b1','#c6d3b7',.55);
  p.box(x-2,y-2,z+4,4,4,15,stone);rim(p,x,y,z+18,8.5,6.4);p.ellipse(x,y,z+18.3,9,4.5,'#9dbdb1');p.box(x-1,y-1,z+18,2,2,7,stone);p.ellipse(x,y,z+26,2.1,2.1,'#c5b991','#e9dfbc',.5);
  for(const a of [0,Math.PI*.67,Math.PI*1.34]){const q=CityHallProjection.project(x+Math.cos(a)*6,y+Math.sin(a)*6,z+18),r=CityHallProjection.project(x+Math.cos(a)*14,y+Math.sin(a)*14,z+6),c=p.c;c.beginPath();c.moveTo(q.x,q.y);c.quadraticCurveTo(r.x,r.y-9,r.x,r.y);c.strokeStyle='#e1ede0';c.lineWidth=.8;c.stroke();p.ellipse(x+Math.cos(a)*14,y+Math.sin(a)*14,z+6,2,1,'#d6e3cf');}
 }
 function draw(p){
  const e=layout();paving(p);pavement(p,e.pavement);CityHallCivicSquare.gardens(p);CityHallDaylight.plinth(p);
  for(const b of e.buildings)building(p,b,e.buildings.indexOf(b));
  // Footings and all six treads meet the same square. The hall's retained gold
  // floor edge covers the first tread's inner two units at y194.
  const f=e.foundation;p.box(f.x0,f.y0,f.z0,f.x1-f.x0,f.y1-f.y0,f.z1-f.z0,stone);
 }
 function foreground(p){
  const e=layout();
  for(const s of e.steps){p.box(s.x0,s.y0,s.z0,s.x1-s.x0,s.y1-s.y0,s.z1-s.z0,stone);p.line([s.x0,s.y1,s.z1],[s.x1,s.y1,s.z1],'#f5e8cd',.65);}
  // Side cheek walls avoid a rail through the arrival route.
  for(const x of [82,144])for(const s of e.steps)p.box(x,s.y0,ground,2,s.y1-s.y0,s.z1-ground+2,stone);
  CityHallCivicSquare.exterior(p,true,[...e.trees.filter(inFront).map(b=>({b,draw:tree})),...e.lamps.map(b=>({b,draw:lamp}))]);
 }
 function inFront(b){return b.x0>228||b.y0>218;}
 function behind(p){const e=layout();draw(p);fountain(p,e.fountain);CityHallCivicSquare.exterior(p,false);for(const b of e.trees)if(!inFront(b))tree(p,b);p.fibre({left:-700,right:700,top:-70,bottom:450},.07);}
 return {layout,draw:behind,foreground};
});
