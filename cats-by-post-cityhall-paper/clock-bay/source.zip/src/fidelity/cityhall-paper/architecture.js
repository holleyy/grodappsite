/* Cutaway vault, receiving beams and supported working gallery. */
(function(root){
 'use strict';
 const P=CityHallProjection,cream='#f7ebd3',green='#335d4c',gold='#d9b45e';
 function wallPoint(axis,u,z){return axis==='rear'?[u,0,z]:[0,u,z];}
 function arch(axis,u0,u1,z0,z1,inset=0){const mid=(u0+u1)/2,r=(u1-u0)/2-inset,spring=z1-r,pts=[wallPoint(axis,u0+inset,z0),wallPoint(axis,u1-inset,z0),wallPoint(axis,u1-inset,spring)];for(let i=0;i<=24;i++){const a=i*Math.PI/24;pts.push(wallPoint(axis,mid+r*Math.cos(a),spring+r*Math.sin(a)));}return pts;}
 function path3(c,points){for(let i=0;i<points.length;i++){const p=P.project(...points[i]);if(i)c.lineTo(p.x,p.y);else c.moveTo(p.x,p.y);}c.closePath();}
 function windows(p,axis,length,bays){
  const c=p.c;c.beginPath();path3(c,[wallPoint(axis,0,0),wallPoint(axis,length,0),wallPoint(axis,length,138),wallPoint(axis,0,138)]);
  for(const [u0,u1]of bays)path3(c,arch(axis,u0,u1,55,127));c.fillStyle=axis==='rear'?'#dee3d7':'#cbd7ce';c.fill('evenodd');
  for(let z=8;z<138;z+=8){c.save();c.beginPath();path3(c,[wallPoint(axis,0,0),wallPoint(axis,length,0),wallPoint(axis,length,138),wallPoint(axis,0,138)]);for(const [u0,u1]of bays)path3(c,arch(axis,u0,u1,55,127));c.clip('evenodd');p.line(wallPoint(axis,0,z),wallPoint(axis,length,z),'#bcc9bd',.25);for(let u=(z%16?8:0);u<length;u+=16)p.line(wallPoint(axis,u,z),wallPoint(axis,u,z+8),'#c0ccbe',.2);c.restore();}
  for(const [u0,u1]of bays){
   const pts=arch(axis,u0,u1,55,127);p.face(pts,'#bcdfdf2b',null);c.beginPath();path3(c,pts);c.strokeStyle='#b8ad92';c.lineWidth=5.2;c.stroke();c.strokeStyle=cream;c.lineWidth=3.5;c.stroke();
   const spring=127-(u1-u0)/2,mid=(u0+u1)/2;
   for(const u of [u0+(u1-u0)/3,mid,u0+(u1-u0)*2/3])p.line(wallPoint(axis,u,55),wallPoint(axis,u,spring+Math.sqrt(((u1-u0)/2)**2-(u-mid)**2)),cream,1);
   for(const z of [77,99,spring])p.line(wallPoint(axis,u0,z),wallPoint(axis,u1,z),cream,1.2);
   for(let i=1;i<6;i++){const a=i*Math.PI/6;p.line(wallPoint(axis,mid,spring),wallPoint(axis,mid+(u1-u0)/2*Math.cos(a),spring+(u1-u0)/2*Math.sin(a)),cream,.7);}
   if(axis==='rear')p.box(u0-2,-1,52,u1-u0+4,6,3);else p.box(-1,u0-2,52,6,u1-u0+4,3);
  }
 }
 function column(p,b){
  const x=b.x0,y=b.y0,w=b.x1-x,d=b.y1-y;
  p.box(x-1,y-1,0,w+2,d+2,5);p.box(x,y,5,w,d,127,'green');
  p.box(x-.4,y-.4,11,w+.8,d+.8,1,'gold');p.box(x-.5,y-.5,89,w+1,d+1,1.2,'gold');
  p.box(x-1.5,y-1.5,127,w+3,d+3,4,'green');p.box(x-2,y-2,131,w+4,d+4,2,'gold');p.box(x-3,y-3,133,w+6,d+6,5);
  p.line([x+1,y+d+.15,16],[x+1,y+d+.15,125],'#77917b',.7);p.line([x+w-.8,y+d+.15,16],[x+w-.8,y+d+.15,125],'#203f35',.65);
  const px=P.project(x+w*.5,y+d+.2,122),c=p.c;c.save();c.translate(px.x,px.y);c.fillStyle=gold;for(let i=0;i<3;i++){c.beginPath();c.ellipse((i-1)*1.7,-i%2*2,1,3,(i-1)*.5,0,Math.PI*2);c.fill();}c.restore();
 }
 function rail(p,axis,start,end,z=46){
  const at=(u,h)=>axis==='rear'?[u,23,h]:[23,u,h];
  for(let u=start;u<=end;u+=6){p.line(at(u,z+1),at(u,z+12),green,1);p.line(at(u+.65,z+1),at(u+.65,z+12),'#7c9678',.25);}
  p.line(at(start,z+2),at(end,z+2),green,1.4);p.line(at(start,z+10.5),at(end,z+10.5),green,1);
  p.line(at(start,z+13),at(end,z+13),'#a47d38',1.7);p.line(at(start,z+13.8),at(end,z+13.8),'#e9ce83',1);
  for(let u=start;u<=end;u+=30){p.line(at(u,z),at(u,z+14),green,2);const a=at(u,z+15);p.ellipse(a[0],a[1],a[2],1.4,1.4,gold);}
 }
 function gallery(p,L){
  p.box(0,0,42,224,23,4,'stone');p.box(0,23,42,23,169,4,'stone');p.box(0,21,40,224,2,2,'green');p.box(21,23,40,2,169,2,'green');
  for(const x of [60,112,164,218]){p.box(x-2,19,0,4,4,42,'green');p.face([[x-10,22,41],[x,22,41],[x,22,31]],green,'#9ab093',.5);p.face([[x,22,41],[x+10,22,41],[x,22,31]],green,'#9ab093',.5);}
  for(const y of [114,178]){p.box(19,y-2,0,4,4,42,'green');p.face([[22,y-10,41],[22,y,41],[22,y,31]],green,'#9ab093',.5);p.face([[22,y,41],[22,y+10,41],[22,y,31]],green,'#9ab093',.5);}
  // Stair flight descends towards the free floor aisle; the rear rail has an
  // actual 19-unit opening and a receiving landing, rather than crossing it.
  const s=L.stairs;p.box(s.landing.x0,s.landing.y0,42,31,14,4,'stone');
  for(const b of s.steps){p.box(b.x0,b.y0,0,b.x1-b.x0,b.y1-b.y0,b.z1);p.box(b.x0-.25,b.y0,b.z1-.7,b.x1-b.x0+.5,b.y1-b.y0+.5,.7);}
  for(const x of [30,49]){p.face([[x,96,0],[x,36,43],[x,36,46],[x,96,3]],green,'#d9caab',.45);p.line([x,96,13],[x,36,59],gold,1.2);p.line([x,36,59],[x,23,59],gold,1.2);for(let i=0;i<=5;i++)p.line([x,96-i*12,i*46/5],[x,96-i*12,i*46/5+13],gold,.7);}
 }
 function tubes(p){
  const paths=[[[27,2,101],[27,12,101],[65,12,101],[65,12,116],[108,12,116],[108,5,116]],[[12,177,99],[12,126,99],[12,126,113],[12,70,113],[12,70,92],[12,18,92]],[[77,31,27],[77,31,34],[153,31,34],[153,9,34]]];
  const c=p.c;for(let k=0;k<paths.length;k++){
   const path=paths[k],q=path.map(a=>P.project(...a)),tube=new Path2D();tube.moveTo(q[0].x,q[0].y);
   for(let i=1;i<q.length-1;i++){const a=q[i-1],b=q[i],d=q[i+1],l=Math.hypot(a.x-b.x,a.y-b.y),m=Math.hypot(d.x-b.x,d.y-b.y),r=Math.min(5,l*.35,m*.35);tube.lineTo(b.x+(a.x-b.x)/l*r,b.y+(a.y-b.y)/l*r);tube.quadraticCurveTo(b.x,b.y,b.x+(d.x-b.x)/m*r,b.y+(d.y-b.y)/m*r);}tube.lineTo(q.at(-1).x,q.at(-1).y);
   c.lineCap='round';c.strokeStyle='#9f7c3f';c.lineWidth=k<2?5:6.5;c.stroke(tube);c.strokeStyle='#d9b763';c.lineWidth=k<2?3.8:5;c.stroke(tube);c.save();c.translate(-.55,-.55);c.strokeStyle='#f2d78f';c.lineWidth=.7;c.stroke(tube);c.restore();
   for(let i=1;i<q.length;i++){const a=q[i-1],b=q[i],len=Math.hypot(b.x-a.x,b.y-a.y),n=Math.max(1,Math.floor(len/20)),dx=(b.x-a.x)/len,dy=(b.y-a.y)/len;for(let j=0;j<n;j++){const t=(j+.5)/n,x=a.x+(b.x-a.x)*t,y=a.y+(b.y-a.y)*t,r=k<2?2.8:3.5;c.beginPath();c.moveTo(x-dy*r,y+dx*r);c.lineTo(x+dy*r,y-dx*r);c.strokeStyle='#a58644';c.lineWidth=1.2;c.stroke();c.strokeStyle='#efce7b';c.lineWidth=.55;c.stroke();}}
  }
  CityHallClockBay.pipes(p);
 }
 function furniture(p,L){
  for(const [x,y,w,d,h] of [[77,24,79,18,27],[10,110,31,23,26]]){
   p.shadow(x+w*.5,y+d*.5,0,w*.75,d*.45,.14);for(const a of [x+1,x+w-4])for(const b of [y+1,y+d-4])p.box(a,b,0,3,3,h-2,'wood');p.box(x,y,h-3,w,d,3,'wood');p.box(x-1,y-1,h,w+2,d+2,2);p.box(x+4,y+d-2,9,w-8,2,h-11,'wood');
   for(let a=x+6;a<x+w-4;a+=11){p.box(a,y+d+.1,12,9,.5,9,['#d7b17a','#bd8c58','#997344']);p.line([a+3,y+d+.6,19],[a+6,y+d+.6,19],gold,.7);}
   for(const a of [x+9,x+w-12]){p.planeImage('letters',a,y+6,h+2,9,5);}
  }
  p.planeImage('crest',18,133.7,13,15,10,'rear');
  // Pigeonholes under the working gallery; the left stair approach stays open.
  p.box(80,1,0,130,16,38,'wood');for(let x=82;x<208;x+=13)for(let z=3;z<35;z+=10){p.box(x,14,z,11,1,8,['#be9768','#715b43','#6c583e']);p.box(x+1,14.5,z+1,8,3,4,x%3?'stone':'red');p.planeImage('letters',x+2,18,z+2,4,2,'rear');}
  p.box(8,172,4,44,14,2,'red');p.box(8,172,6,44,2,12,'red');for(const x of [12,46]){p.box(x,174,0,2,10,4,'gold');p.box(x,172,6,2,13,2,'wood');}for(let x=10;x<51;x+=5)p.line([x,175,6.2],[x,184,6.2],'#e4aa81',.4);
  palm(p,20,156);palm(p,215,16);
  trolley(p,49,146);
  p.planeImage('map',0.2,136,14,27,21,'left');
  p.face([[.2,66,0],[.2,94,0],[.2,94,38],[.2,66,38]],'#856548','#efdfbd',1.2);
  for(const y of [68,81])p.face([[.3,y,4],[.3,y+11,4],[.3,y+11,34],[.3,y,34]],'#aa8056','#c7ab77',.65);
  p.line([.5,79,17],[.5,79,21],gold,1);p.line([.5,82,17],[.5,82,21],gold,1);
 }
 function trolley(p,x,y,angle=0){
  for(const dx of [-6,6])for(const dy of [-7,7]){p.ellipse(x+dx,y+dy,2,2,2,'#2e514b','#c3ad69',.5);p.ellipse(x+dx,y+dy,2,.6,.6,gold);p.line([x+dx-1.5*Math.cos(angle),y+dy,2-1.5*Math.sin(angle)],[x+dx+1.5*Math.cos(angle),y+dy,2+1.5*Math.sin(angle)],gold,.45);}
  p.box(x-7,y-8,4,14,16,1,'gold');p.box(x-7,y-8,5,14,1,13,'green');p.box(x-7,y+7,5,14,1,13,'green');p.box(x+6,y-7,5,1,14,13,'green');
  for(const dx of [-7,7])for(const dy of [-8,8])p.line([x+dx,y+dy,4],[x+dx,y+dy,22],gold,.8);
  for(const dy of [-8,8])p.line([x-7,y+dy,22],[x+7,y+dy,22],gold,.9);
  p.box(x-5,y-5,5,9,10,9,'stone');p.box(x-4,y-4,14,8,8,6,'wood');p.line([x,y-4,20.1],[x,y+4,20.1],cream,.6);p.line([x-7,y+7,16],[x+7,y+7,16],gold,1);
  p.planeImage('crest',x-5,y+8.2,8,10,7,'rear');
 }
 function palm(p,x,y){
  p.box(x-5,y-5,0,10,10,2,'gold');p.box(x-5,y-5,2,10,10,11,'green');p.box(x-5.5,y-5.5,12,11,11,1,'gold');p.ellipse(x,y,13,6,3,'#887551');p.line([x,y,13],[x+1,y,38],'#b29b60',1.8);
  for(let i=0;i<10;i++){const a=i*Math.PI/5,dx=Math.cos(a)*17,dy=Math.sin(a)*17;const pts=[[x+1,y,39],[x+dx*.5-dy*.14,y+dy*.5+dx*.14,43],[x+dx,y+dy,23+i%3*3],[x+dx*.5+dy*.14,y+dy*.5-dx*.14,39]];p.face(pts,i%2?'#779268':'#99ab79','#b6bd87',.18);p.line([x+1,y,39],[x+dx,y+dy,23+i%3*3],'#d0ce94',.25);}
 }
 function roof(p,L){
  // A built transept occupies the rear 55 units. The forward roof is explicitly
  // cut away, leaving no low beam or transparent roof across the puzzle.
  const ribs=L.vault.ribs;
  for(let k=0;k<ribs.length-1;k++)for(let i=0;i<40;i++)p.face([ribs[k][i],ribs[k][i+1],ribs[k+1][i+1],ribs[k+1][i]],i%5===0?'#eff6dc55':'#c7e3dd33',null);
  for(const rib of ribs){
   const front=rib.map(a=>[a[0],a[1]+1.2,a[2]]),back=rib.map(a=>[a[0],a[1]-1.2,a[2]+2]).reverse();p.face(front.concat(back),'#f0dfbd','#b6a580',.35);
   const c=p.c;for(const [offset,color,width]of [[0,green,1.4],[1.4,cream,.65]]){c.beginPath();for(let i=0;i<rib.length;i++){const a=rib[i],q=P.project(a[0],a[1]+1.2,a[2]+offset);if(i)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);}c.strokeStyle=color;c.lineWidth=width;c.lineJoin='round';c.stroke();}
  }
  for(let i=0;i<=40;i+=4)p.line(ribs[0][i],ribs.at(-1)[i],cream,.65);
  // The side clerestory follows the same left wall, without an invented plane.
  for(let y=56;y<192;y+=12){p.face([[0,y,138],[20,y,144],[20,y+12,144],[0,y+12,138]],'#c1ddd466','#e9e6ce',.7);}
  p.line([20,55,144],[20,192,144],cream,2.2);p.line([0,55,138],[0,192,138],cream,2);
 }
 function draw(p,L){
  p.shadow(112,96,-9,235,110,.16);p.box(-4,-4,-10,232,200,8);p.box(-2,-2,-2,228,196,2,'gold');p.box(0,0,0,224,192,.5,'wood');
  // Quiet timber apron beneath the ivory board.
  for(let y=0;y<192;y+=8)for(let x=0;x<224;x+=32){p.face([[x,y,.55],[Math.min(224,x+32),y,.55],[Math.min(224,x+32),y+8,.55],[x,y+8,.55]],(x+y)%24?'#cba779':'#d5b78b','#b99970',.16);p.planeImage('material-wood',x,y,.56,Math.min(32,224-x),8,'floor',.15);}
  windows(p,'rear',224,[[13,51],[68,105],[176,211]]);windows(p,'left',192,[[14,48],[69,107],[128,171]]);
  p.box(-3,-3,133,230,6,5);p.box(-3,0,133,6,195,5);p.box(0,0,47,224,2,3);p.box(0,0,47,2,192,3);
  for(const b of L.columns)column(p,b);
  CityHallClockBay.wall(p);furniture(p,L);gallery(p,L);CityHallClockBay.gallery(p);tubes(p);CityHallClockBay.clock(p);CityHallClockBay.lamps(p);roof(p,L);
  for(const [x,y,z]of [[58,10,78],[4,114,78]]){p.line([x,y,z+10],[x,y+5,z+10],gold,.8);p.line([x,y+5,z+10],[x,y+5,z+5],gold,.8);p.box(x-2,y+3,z,4,4,5,['#fff0b7','#ebd290','#c5ad6a']);p.box(x-2.5,y+2.5,z+5,5,5,.7,'gold');}
  p.fibre(L.bounds,.11);
 }
 function foreground(p){rail(p,'rear',1,29);rail(p,'rear',50,111);CityHallClockBay.rail(p);rail(p,'left',38,192);}
 root.CityHallArchitecture={draw,foreground,trolley};
})(globalThis);
