/* One world plane for construction, artwork contacts, arrows and input. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallProjection=api;})(globalThis,function(){
 'use strict';
 function project(x,y,z=0,out={x:0,y:0}){out.x=x-y;out.y=(x+y)*.5-z;return out;}
 function unproject(px,py,z=0,out={x:0,y:0}){out.x=py+z+px*.5;out.y=py+z-px*.5;return out;}
 function pick(px,py,board,cam,out={x:0,y:0}){
  px=(px-cam.tx)/cam.scale;py=(py-cam.ty)/cam.scale;
  const x=(py+px*.5-board.x)/16,y=(py-px*.5-board.y)/16;
  if(x<0||y<0||x>=board.w||y>=board.h)return null;out.x=Math.floor(x);out.y=Math.floor(y);return out;
 }
 function camera(viewport,layout,board,out={scale:1,tx:0,ty:0}){
  const b=layout.bounds;let left=b.left,right=b.right,top=b.top,bottom=b.bottom;
  if(viewport.view!=='hall'){left=board.x-board.y-board.h*16-20;right=board.x-board.y+board.w*16+20;top=(board.x+board.y)*.5-36;bottom=(board.x+board.y)*.5+(board.w+board.h)*8+18;}
  const w=Math.max(1,viewport.width),h=Math.max(1,viewport.height);
  out.scale=Math.min(w/(right-left),h/(bottom-top))*(viewport.zoom||1);
  out.tx=w*.5-(left+right)*.5*out.scale+(viewport.panX||0);out.ty=h*.5-(top+bottom)*.5*out.scale+(viewport.panY||0);return out;
 }
 return {project,unproject,pick,camera};
});
