/* The neighbouring town is measured scenery in the hall's own world plane.
   Only the distant skyline is an image. Construction happens once at load. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallEnvironment=api;})(globalThis,function(){
 'use strict';
 const ground=-12,stone=['#eadcc3','#d3c2a6','#b5a38c'],roof=['#9aaba6','#7c9690','#647f7d'];
 const box=(id,x0,y0,z0,x1,y1,z1)=>({id,x0,y0,z0,x1,y1,z1});
 function layout(){
  return {ground,foundation:box('foundation',-4,-4,ground,228,196,-10),pavement:box('pavement',-38,-38,-14,263,245,ground),
   steps:Array.from({length:6},(_,i)=>box('arrival-step-'+i,86,194+i*4,ground,142,198+i*4,0-2*i)),approach:box('arrival',86,218,ground,142,245,ground),
   buildings:[box('civic-library',-138,28,ground,-70,100,70),box('archive',-32,-190,ground,42,-144,50),box('town-houses',155,-157,ground,211,-113,43),box('east-offices',308,-59,ground,356,-12,42)],
   trees:[box('square-tree-west',-46,121,ground,-22,145,42),box('square-tree-east',249,100,ground,273,124,45),box('square-tree-front',171,266,ground,195,290,40),box('library-tree',-113,139,ground,-89,163,41),box('clock-courtyard-tree',116,-76,ground,140,-52,39)],
   lamps:[box('arrival-lamp-left',74,220,ground,78,224,22),box('arrival-lamp-right',150,220,ground,154,224,22),box('corner-lamp',239,177,ground,243,181,22)],
   fountain:box('civic-fountain',-50,165,ground,-2,213,17)};
 }
 function paving(p){
  const c=p.c;c.save();c.beginPath();c.rect(-700,-70,1400,520);c.clip();c.fillStyle='#b8b7a7';c.fillRect(-700,-70,1400,520);
  // Continuous 2:1 courses. Low contrast keeps this below the playable floor.
  for(let y=-480;y<750;y+=12)for(let x=-480;x<750;x+=24){const n=((x/24)*7+(y/12)*11)%5;p.face([[x,y,-14],[x+24,y,-14],[x+24,y+12,-14],[x,y+12,-14]],['#beb9a9','#c2bdad','#bcb8aa','#c6bfae','#b9b6a8'][(n+5)%5],'#d2c9b5',.38);}
  c.restore();
 }
 function pavement(p,b){
  p.box(b.x0,b.y0,b.z0,b.x1-b.x0,b.y1-b.y0,b.z1-b.z0,stone);
  for(let y=b.y0;y<b.y1;y+=16)for(let x=b.x0;x<b.x1;x+=24){const x1=Math.min(b.x1,x+24),y1=Math.min(b.y1,y+16);p.face([[x,y,b.z1+.05],[x1,y,b.z1+.05],[x1,y1,b.z1+.05],[x,y1,b.z1+.05]],((x-b.x0)/24+(y-b.y0)/16)%3?'#d8cfb9':'#ded4be','#c3baa6',.25);}
  for(let x=b.x0;x<b.x1;x+=12)p.box(x,b.y1-2,b.z1-.3,Math.min(12,b.x1-x),2,1,stone);
  for(let y=b.y0;y<b.y1;y+=12)p.box(b.x1-2,y,b.z1-.3,2,Math.min(12,b.y1-y),1,stone);
 }
 function facadeWindow(p,axis,u,v,z,w,h){
  const at=(a,b)=>axis==='rear'?[a,v,b]:[v,a,b],mid=u+w/2,r=w/2,s=z+h-r,outline=[at(u,z),at(u+w,z),at(u+w,s)];
  for(let i=0;i<=12;i++){const a=i*Math.PI/12;outline.push(at(mid+r*Math.cos(a),s+r*Math.sin(a)));}
  p.face(outline,'#829e9b','#eee0c4',1.6);
  p.line(at(mid,z),at(mid,z+h-.8),'#e9dfc8',.7);p.line(at(u,z+h*.52),at(u+w,z+h*.52),'#e9dfc8',.7);
  p.line(at(u+1,z+1),at(u+1,z+h-r),'#547674',.5);
  if(axis==='rear')p.box(u-1,v-.7,z-1,w+2,2,1.5,stone);else p.box(v-.7,u-1,z-1,2,w+2,1.5,stone);
 }
 function building(p,b,index){
  const x=b.x0,y=b.y0,w=b.x1-x,d=b.y1-y,z=b.z0,h=b.z1-z;
  p.shadow(x+w*.5+6,y+d*.5+5,z,w*.9,d*.55,.2);p.box(x-5,y-5,-14,w+10,d+10,2,stone);
  p.box(x,y,z,w,d,h,index%2?['#e0d4bc','#d7c6ab','#b9ad98']:stone);
  for(let k=z+7;k<b.z1;k+=7){p.line([x,y+d+.1,k],[x+w,y+d+.1,k],'#bda98e',.2);p.line([x+w+.1,y,k],[x+w+.1,y+d,k],'#ac9c87',.2);}
  for(let k=z+4;k<b.z1-12;k+=23){
   for(let u=x+8;u<x+w-8;u+=18)facadeWindow(p,'rear',u,y+d+.3,k,10,17);
   for(let u=y+8;u<y+d-8;u+=18)facadeWindow(p,'side',u,x+w+.3,k,10,17);
  }
  for(const a of [x,x+w-3])p.box(a,y+d-.4,z,3,1.8,h,stone);
  for(const a of [y,y+d-3])p.box(x+w-.4,a,z,1.8,3,h,stone);
  for(const k of [z+24,z+47,b.z1-2]){p.box(x-1,y+d-1,k,w+2,2,1.5,stone);p.box(x+w-1,y-1,k,2,d+2,1.5,stone);}
  p.box(x-2,y-2,b.z1,w+4,d+4,2.5,stone);p.box(x-3,y-3,b.z1+2,w+6,d+6,1.3,stone);
  const ridge=b.z1+19,m=y+d*.5;
  p.face([[x-3,y-3,b.z1+3],[x+w+3,y-3,b.z1+3],[x+w-5,m,ridge],[x+5,m,ridge]],roof[0],'#d0d0ba',.6);
  p.face([[x-3,y+d+3,b.z1+3],[x+w+3,y+d+3,b.z1+3],[x+w-5,m,ridge],[x+5,m,ridge]],roof[1],'#c9c9b3',.6);
  p.face([[x+w+3,y-3,b.z1+3],[x+w+3,y+d+3,b.z1+3],[x+w-5,m,ridge]],roof[2],'#bbbdab',.6);
  for(let u=x+5;u<x+w-5;u+=9)p.line([u,m,ridge+.1],[u,y+d+3,b.z1+3.1],'#b6c0ae',.35);
  for(let t=.25;t<1;t+=.25)p.line([x-3+8*t,y+d+3-(d*.5+3)*t,b.z1+3+16*t],[x+w+3-8*t,y+d+3-(d*.5+3)*t,b.z1+3+16*t],'#647f79',.32);
  p.line([x+5,m,ridge],[x+w-5,m,ridge],'#c6cab3',1.1);
  for(const u of [x+13,x+w-18]){p.box(u,m-3,ridge-5,5,5,12,['#dbc2a0','#bb9c79','#a18b70']);p.box(u-1,m-4,ridge+6,7,7,1.2,stone);}
  // A small porch makes the neighbouring building read as a usable address.
  const doorX=x+w*.5-5;p.face([[doorX,y+d+.4,z],[doorX+10,y+d+.4,z],[doorX+10,y+d+.4,z+19],[doorX,y+d+.4,z+19]],'#486f60','#e5d7bb',1.4);
  p.line([doorX+5,y+d+.5,z],[doorX+5,y+d+.5,z+18],'#cfbb88',.6);p.box(doorX-3,y+d,z-1,16,6,1,stone);
  p.face([[doorX-4,y+d+1,z+21],[doorX+14,y+d+1,z+21],[doorX+5,y+d+1,z+28]],'#e9ddc6','#b5a383',.6);
 }
 function leaf(p,x,y,z,rx,ry,col,seed){
  const q=CityHallProjection.project(x,y,z),points=[];for(let i=0;i<24;i++){const a=i*Math.PI/12,r=1+(i%2?.08:-.04);points.push([q.x+Math.cos(a)*rx*r,q.y+Math.sin(a)*ry*r]);}
  p.path(points,col,'#7c825e',.18);p.c.save();p.c.translate(-.35,-.5);p.path(points,null,'#d2cd91',.35);p.c.restore();
  for(let j=0;j<3;j++){const a=(seed+j)*2.399,dx=Math.cos(a)*rx*.55,dy=Math.sin(a)*ry*.5;p.c.beginPath();p.c.moveTo(q.x+dx-1,q.y+dy+1);p.c.quadraticCurveTo(q.x+dx+2,q.y+dy-3,q.x+dx+4,q.y+dy);p.c.strokeStyle='#e0d99d66';p.c.lineWidth=.4;p.c.stroke();}
 }
 function tree(p,b,index){
  const x=(b.x0+b.x1)/2,y=(b.y0+b.y1)/2,z=b.z0,h=b.z1-z;
  p.shadow(x+4,y+3,z,31,13,.2);p.box(x-10,y-10,-14,20,20,2,stone);p.box(x-8,y-8,z,16,16,1,['#9b956c','#aaa584','#aaa584']);
  if(b.id==='clock-courtyard-tree'||b.id==='square-tree-east'){const a=CityHallProjection.project(x,y,z+1),ih=h/.984,iw=ih*.75;p.c.drawImage(p.images['clock-bay-tree'],a.x-iw*.497,a.y-ih*.984,iw,ih);return;}
  p.line([x,y,z+1],[x,y,z+h-9],'#8f7954',2.3);p.line([x-.5,y,z+1],[x-.5,y,z+h-9],'#c3a36e',.65);
  for(let j=0;j<5;j++){const a=j*2.399;p.line([x,y,z+h*.4],[x+Math.cos(a)*10,y+Math.sin(a)*8,z+h-9],'#94815c',1);}
  const colours=['#829163','#9da16a','#afaf74','#bcc07d','#909d69'];
  for(let row=0;row<3;row++)for(let j=0;j<7-row;j++){const a=j*2.399+row,spread=17-row*4;leaf(p,x+Math.cos(a)*spread*.75,y+Math.sin(a)*spread*.6,z+h-18+row*7,11-row,8-row*.6,colours[(j+row+index)%5],j+row*8);}
 }
 function lamp(p,b){
  const x=(b.x0+b.x1)/2,y=(b.y0+b.y1)/2,z=b.z0,h=b.z1-z;
  p.shadow(x+3,y+2,z,7,3,.13);p.box(x-2,y-2,z,4,4,2,stone);p.box(x-1,y-1,z+2,2,2,4,'green');p.line([x,y,z+5],[x,y,z+h-6],'#365c4c',1.1);
  p.box(x-2,y-2,z+h-6,4,4,5,['#ffe7af','#f4d99a','#e7cc92']);
  for(const a of [-2,2])for(const d of [-2,2])p.line([x+a,y+d,z+h-6],[x+a,y+d,z+h-1],'#52624b',.5);
  p.box(x-2.5,y-2.5,z+h-1,5,5,.8,'green');p.face([[x-3,y-3,z+h],[x+3,y-3,z+h],[x,y,z+h+3]],'#789078');p.face([[x+3,y-3,z+h],[x+3,y+3,z+h],[x,y,z+h+3]],'#375b4d');p.face([[x-3,y+3,z+h],[x+3,y+3,z+h],[x,y,z+h+3]],'#56745d');
 }
 function ring(p,x,y,z,r,height,fill){
  const n=32;for(let i=0;i<n;i++){const a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n;p.face([[x+Math.cos(a)*r,y+Math.sin(a)*r,z],[x+Math.cos(b)*r,y+Math.sin(b)*r,z],[x+Math.cos(b)*r,y+Math.sin(b)*r,z+height],[x+Math.cos(a)*r,y+Math.sin(a)*r,z+height]],fill,'#b5a88b',.15);}
 }
 function fountain(p,b){
  const x=(b.x0+b.x1)/2,y=(b.y0+b.y1)/2,z=b.z0;
  p.shadow(x+3,y+4,z,35,18,.15);ring(p,x,y,z,24,1.5,'#d8cbb2');p.ellipse(x,y,z+1.5,24*Math.SQRT2,12*Math.SQRT2,'#e5d9c0','#c2b395',.6);
  ring(p,x,y,z+1.5,20,4,'#c8baa1');p.ellipse(x,y,z+5.5,20*Math.SQRT2,10*Math.SQRT2,'#eadfc8','#b9ac90',.6);p.ellipse(x,y,z+5.6,17*Math.SQRT2,8.5*Math.SQRT2,'#91b7b1','#c6d3b7',.55);
  p.box(x-2,y-2,z+4,4,4,15,stone);p.ellipse(x,y,z+18,12,6,'#e3d7ba','#b7aa8c',.6);p.ellipse(x,y,z+18.3,9,4.5,'#9dbdb1');p.box(x-1,y-1,z+18,2,2,7,stone);p.ellipse(x,y,z+26,2.1,2.1,'#c5b991','#e9dfbc',.5);
  for(const a of [0,Math.PI*.67,Math.PI*1.34]){const q=CityHallProjection.project(x+Math.cos(a)*6,y+Math.sin(a)*6,z+18),r=CityHallProjection.project(x+Math.cos(a)*14,y+Math.sin(a)*14,z+6),c=p.c;c.beginPath();c.moveTo(q.x,q.y);c.quadraticCurveTo(r.x,r.y-9,r.x,r.y);c.strokeStyle='#e1ede0';c.lineWidth=.8;c.stroke();p.ellipse(x+Math.cos(a)*14,y+Math.sin(a)*14,z+6,2,1,'#d6e3cf');}
 }
 function draw(p){
  const e=layout();paving(p);pavement(p,e.pavement);
  for(const b of e.buildings)building(p,b,e.buildings.indexOf(b));
  // Footings and all six treads meet the same square. The hall's retained gold
  // floor edge covers the first tread's inner two units at y194.
  const f=e.foundation;p.box(f.x0,f.y0,f.z0,f.x1-f.x0,f.y1-f.y0,f.z1-f.z0,stone);
 }
 function foreground(p){
  const e=layout();
  for(const s of e.steps){p.box(s.x0,s.y0,s.z0,s.x1-s.x0,s.y1-s.y0,s.z1-s.z0,stone);p.line([s.x0,s.y1,s.z1],[s.x1,s.y1,s.z1],'#f5e8cd',.65);}
  // Side cheek walls avoid a rail through the arrival route.
  for(const x of [82,144])for(const s of e.steps)p.box(x,s.y0,ground,2,s.y1-s.y0,s.z1-ground+2,stone);
  for(let i=0;i<e.trees.length;i++)if(i===2)tree(p,e.trees[i],i);for(const b of e.lamps)lamp(p,b);
 }
 function behind(p){const e=layout();draw(p);fountain(p,e.fountain);for(let i=0;i<e.trees.length;i++)if(i!==2)tree(p,e.trees[i],i);p.fibre({left:-700,right:700,top:-70,bottom:450},.07);}
 return {layout,draw:behind,foreground};
});
