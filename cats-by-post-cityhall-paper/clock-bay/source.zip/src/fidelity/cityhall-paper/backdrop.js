/* One horizon and one constructed square. Windows reveal this exact scene;
   no per-window panorama offsets or second perspective are introduced. */
(function(root){
 'use strict';
 function draw(p){
  const c=p.c,im=p.images['civic-skyline'],W=1000,H=W*im.height/im.width,x=-500,y=-70-H;
  c.drawImage(im,0,0,im.width,1,-700,-500,1400,Math.max(0,y+500));
  c.drawImage(im,0,0,1,im.height,-700,y,200,H);c.drawImage(im,x,y,W,H);c.drawImage(im,im.width-1,0,1,im.height,500,y,200,H);
  CityHallEnvironment.draw(p);
 }
 root.CityHallBackdrop={draw};
})(globalThis);
