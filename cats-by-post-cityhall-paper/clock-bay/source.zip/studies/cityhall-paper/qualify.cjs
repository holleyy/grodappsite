/* End-to-end boundaries and emulated devices; no physical-device FPS claim. */
const {chromium}=require('/opt/codex/cua_node/lib/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const out='work/cityhall-paper',url=(process.env.CITYHALL_STUDY_URL||'http://127.0.0.1:8798/studies/cityhall-paper/');let browser;
(async()=>{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),errors=[],report={checks:[],errors};
 const check=(name,v)=>{assert.ok(v,name);report.checks.push(name);console.log('PASS',name);};
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 await page.addInitScript(()=>{localStorage.setItem('catsByPost.progress','NORMAL-GAME-SENTINEL');localStorage.setItem('catsByPost.nightShiftBest','NORMAL-SCORE-SENTINEL');});
 const start=Date.now();await page.goto(url,{timeout:120000});await page.waitForFunction(()=>window.CityHallStudy?.ready,{timeout:120000});report.hostLoadAndPrepareMs=Date.now()-start;
 check('normal saves unchanged',await page.evaluate(()=>localStorage.getItem('catsByPost.progress')==='NORMAL-GAME-SENTINEL'&&localStorage.getItem('catsByPost.nightShiftBest')==='NORMAL-SCORE-SENTINEL'));
 // A real held mouse is cancelled across the viewport change.
 let p=await page.evaluate(()=>{CityHallStudy.app.draw();return CityHallStudy.screenCell(6,2);});await page.mouse.move(p.x,p.y);await page.mouse.down();await page.setViewportSize({width:1024,height:600});await page.waitForTimeout(120);p=await page.evaluate(()=>{CityHallStudy.app.draw();return CityHallStudy.screenCell(6,2);});await page.mouse.move(p.x,p.y);await page.mouse.up();
 check('resize cancels held pointer',await page.evaluate(()=>gm.chutes.length===0));
 await page.setViewportSize({width:1440,height:1000});await page.waitForTimeout(100);
 await page.locator('#vaultCanvas').focus();await page.evaluate(()=>{gm.cx=1;gm.cy=2;gm.cursor=true;});await page.keyboard.press('ArrowRight');
 check('real keyboard highlights both tunnel ends',await page.evaluate(()=>{CityHallStudy.app.draw();return gm.cx===2&&gm.cy===2&&CityHallStudy.renderer.selectedPair===0;}));
 await page.evaluate(()=>{gm.cx=6;gm.cy=2;});await page.keyboard.press('Enter');check('real keyboard places arrow',await page.evaluate(()=>gm.chutes.some(t=>t.x===6&&t.y===2)));
 await page.evaluate(()=>{CityHallStudy.select('6-15');CityHallStudy.fixtureAnswer();gSend();});
 const before=await page.evaluate(()=>({t:gm.t,tick:gm.sim.tick,turns:JSON.stringify(gm.chutes)}));await page.setViewportSize({width:390,height:844});await page.waitForTimeout(100);
 check('mid-run resize preserves trace and placements',await page.evaluate(b=>gm.t>=b.t&&gm.sim.tick>=b.tick&&JSON.stringify(gm.chutes)===b.turns,before));
 await page.evaluate(()=>{while(gm.mode==='running')gUpdate();for(let i=0;i<180;i++)gUpdate();});
 const earned=await page.evaluate(()=>JSON.stringify({turns:gm.chutes,tray:gm.tray,attempts:gm.attempts,hinted:gm.hinted,progress:PROGRESS.serialize(progress),tick:gm.sim.tick,result:grResult(gm.sim),mode:gm.mode}));
 await page.evaluate(()=>gNext());check('actual finale enters departure',await page.evaluate(()=>CP.hall&&CP.mode==='exit'));
 await page.evaluate(()=>{CP.frame=300;cpWorld();CityHallStudy.app.draw();});await page.screenshot({path:out+'/departure-portrait.png'});
 await page.click('#chapterSecondary');check('departure can replay shared demo',await page.evaluate(()=>CP.mode==='demo'&&CP.hall));
 await page.click('#chapterPrimary');await page.evaluate(()=>cpFinishEntry());
 check('replay returns the same earned finale',earned===await page.evaluate(()=>JSON.stringify({turns:gm.chutes,tray:gm.tray,attempts:gm.attempts,hinted:gm.hinted,progress:PROGRESS.serialize(progress),tick:gm.sim.tick,result:grResult(gm.sim),mode:gm.mode})));
 check('chapter entry restores usable button focus',await page.evaluate(()=>document.activeElement.tagName==='BUTTON'&&!document.activeElement.disabled));
 await page.evaluate(()=>gNext());await page.click('#chapterPrimary');await page.waitForTimeout(100);
 check('Hall → Parcel uses native invitation',await page.evaluate(()=>gm.L.id==='7-1'&&CP.parcel&&CP.mode==='intro'&&ACTIVE_ROOM.id==='parcel'&&document.getElementById('vaultScene').hidden));
 // A source answer is an explicit test fixture; navigation uses real gNext and buttons.
 await page.evaluate(()=>{cpCancel();gLoad(54);cpCancel();CityHallStudy.fixtureAnswer();gSend();while(gm.mode==='running')gUpdate();gNext();});
 check('actual solved Train finale opens its departure',await page.evaluate(()=>gm.L.id==='5-15'&&gm.mode==='won'&&CP.train&&CP.mode==='exit'));
 await page.click('#chapterPrimary');await page.waitForTimeout(100);
 check('Train → Hall uses native invitation and returns new scene',await page.evaluate(()=>gm.L.id==='6-1'&&CP.hall&&CP.mode==='intro'&&!document.getElementById('vaultScene').hidden));
 await page.click('#chapterPrimary');await page.evaluate(()=>cpFinishEntry());
 for(const size of [[390,844],[844,390]])for(const id of ['6-3','6-7']){
  await page.setViewportSize({width:size[0],height:size[1]});await page.evaluate(id=>{CityHallStudy.select(id);CityHallStudy.fixtureAnswer();gSend();while(gm.mode==='running')gUpdate();gNext();},id);await page.waitForTimeout(80);
  check('growth card and scene fit '+id+' '+size,await page.evaluate(()=>{const a=document.getElementById('chapterCard').getBoundingClientRect(),b=document.getElementById('vaultScene').getBoundingClientRect();return a.left>=0&&a.right<=innerWidth&&a.top>=0&&a.bottom<=innerHeight&&(a.top>=b.bottom||a.left>=b.right);}));
  await page.click('#chapterPrimary');await page.evaluate(()=>cpFinishEntry());
 }
 await page.setViewportSize({width:1440,height:1000});await page.evaluate(()=>{CityHallStudy.select('6-15');CityHallStudy.view('hall');});await page.waitForTimeout(80);
 await page.click('#vaultGray');await page.screenshot({path:out+'/finale-grayscale.png'});
 check('four symbol identities survive grayscale',await page.evaluate(()=>{CityHallStudy.app.draw();return grayscale&&new Set(CityHallStudy.renderer.portals.map(p=>p.symbol)).size===4;}));await page.click('#vaultGray');
 await page.emulateMedia({reducedMotion:'reduce'});await page.evaluate(()=>{CityHallStudy.fixtureAnswer();gSend();});
 const t=await page.evaluate(()=>gm.t);await page.waitForTimeout(160);check('reduced motion keeps rules clock active and actor feet supported',await page.evaluate(t=>{CityHallStudy.app.draw();const o=CityHallStudy.renderer.actors.out;return gm.t>t&&o.workers.every((a,i)=>a.walk===-1&&a.z===(i?46:0))&&o.cat.z===6;},t));
 await page.evaluate(()=>{while(gm.mode==='running')gUpdate();});check('reduced-motion finale still wins',await page.evaluate(()=>gm.mode==='won'));
 await page.emulateMedia({reducedMotion:'no-preference'});await page.evaluate(()=>{CityHallStudy.select('6-15');CityHallStudy.app.draw();});
 report.warm=await page.evaluate(()=>{const r=CityHallStudy.renderer,initial={...r.resources()},create=document.createElement;let canvases=0;document.createElement=function(name,...args){if(name==='canvas')canvases++;return create.call(this,name,...args);};const samples=[];try{for(let i=0;i<120;i++){CityHallStudy.seekAmbient(i*.37);const t=performance.now();CityHallStudy.app.draw();samples.push(performance.now()-t);}}finally{document.createElement=create;}samples.sort((a,b)=>a-b);return{initial,final:{...r.resources()},newCanvases:canvases,drawCallMs:{median:samples[60],p95:samples[114],max:samples[119]},scope:'120 synchronous Canvas draw calls in cloud Chromium; not presented FPS or physical-device performance'};});
 check('warm draws do not prepare canvases or grow caches',report.warm.newCanvases===0&&JSON.stringify(report.warm.initial)===JSON.stringify(report.warm.final));
 await page.evaluate(()=>{CityHallStudy.fixtureAnswer();gSend();while(gm.mode==='running')gUpdate();});const saved=await page.evaluate(()=>PROGRESS.serialize(progress));await page.reload();await page.waitForFunction(()=>window.CityHallStudy?.ready,{timeout:120000});
 check('private progress reloads at completed finale',await page.evaluate(saved=>gm.L.id==='6-15'&&PROGRESS.serialize(progress)===saved,saved));
 await page.evaluate(()=>CityHallStudy.dispose());check('real renderer disposal releases owned buffers',await page.evaluate(()=>CityHallStudy.app.resources().bytes===0&&CityHallStudy.renderer.canvas.width===0&&CityHallStudy.renderer.actors===null));
 const phone=await browser.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:true}),touch=await phone.newPage();touch.on('pageerror',e=>errors.push(e.message));touch.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 await touch.goto(url,{timeout:120000});await touch.waitForFunction(()=>window.CityHallStudy?.ready,{timeout:120000});await touch.evaluate(()=>{CityHallStudy.select('6-15');CityHallStudy.app.draw();});
 p=await touch.evaluate(()=>CityHallStudy.screenCell(gm.L.tunnels[3].a.x,gm.L.tunnels[3].a.y));await touch.touchscreen.tap(p.x,p.y);
 check('DPR2 touch selects the fourth partner',await touch.evaluate(()=>{CityHallStudy.app.draw();return CityHallStudy.renderer.selectedPair===3&&CityHallStudy.renderer.dpr===2;}));
 await touch.screenshot({path:out+'/finale-dpr2-touch.png'});
 const cdp=await phone.newCDPSession(touch);await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:120,y:300,id:1},{x:220,y:300,id:2}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:90,y:300,id:1},{x:250,y:300,id:2}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
 check('two-finger zoom changes camera without placing',await touch.evaluate(()=>CityHallStudy.viewport.zoom>1.3&&gm.chutes.length===0));await phone.close();
 const offline=await browser.newContext({offline:true}),file=await offline.newPage();file.on('pageerror',e=>errors.push(e.message));let requests=0;file.on('request',r=>{if(/^https?:/.test(r.url())&&r.resourceType()!=='document')requests++;});await offline.route('http://cityhall.invalid/',route=>route.fulfill({contentType:'text/html',body:fs.readFileSync('studies/cityhall-paper/index.html')}));await file.goto('http://cityhall.invalid/',{timeout:120000});await file.waitForFunction(()=>window.CityHallStudy?.ready,{timeout:120000});
 report.offlineMethod='Network-disabled Chromium with only the document supplied in memory. Managed Chromium blocks file URLs; direct file opening remains unqualified.';check('standalone runs offline with no subresource network requests',requests===0&&await file.evaluate(()=>CityHallStudy.renderer.ready));await offline.close();
 check('no console or page errors',errors.length===0);fs.writeFileSync(out+'/qualification-report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));await browser.close();
})().catch(async e=>{console.error(e);if(browser)await browser.close();process.exitCode=1;});
