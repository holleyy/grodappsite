/* Review binding to the unchanged host. Explicit diagnostic actions stay here,
   outside the production presentation adapter. */
(async function(){
 'use strict';
 const loading=document.createElement('div');loading.id='vaultLoading';loading.textContent='Opening the Great Postal Vault…';document.body.append(loading);
 const header=document.createElement('header');header.id='vaultHeader';header.innerHTML='<div class="identity"><small>Cats by Post · City sorting hall</small><h1>The Great Postal Vault</h1></div><select id="vaultLevel" aria-label="City Hall delivery"></select><button id="vaultView" aria-pressed="false">Explore hall</button>';
 const scene=document.createElement('main');scene.id='vaultScene';scene.innerHTML='<canvas id="vaultCanvas" tabindex="0" aria-label="City Hall puzzle board. Use arrow keys to choose a tile, Enter to place or turn an arrow, Space to send."></canvas><div id="vaultCaption"><b>City Hall · First post</b>Matching symbols connect across the hall.</div><div id="vaultTools"><button id="vaultMotion" aria-pressed="false">Motion</button><button id="vaultGray" aria-pressed="false" aria-label="Grayscale">G</button><button id="vaultMinus" aria-label="Zoom out">−</button><button id="vaultPlus" aria-label="Zoom in">+</button></div>';
 document.body.append(header,scene);const heading=document.createElement('div');heading.id='vaultHeading';heading.innerHTML='<div id="vaultKicker">Delivery 6-1 · 7 × 5</div><h2 id="vaultLevelTitle"></h2><p id="vaultBrief">Place the arrows. Send every cat to its basket.</p>';hud.root.prepend(heading);
 const selector=document.getElementById('vaultLevel'),canvas=document.getElementById('vaultCanvas'),layout=CityHallLayout.create();
 for(const L of LEVELS)if(/^6-/.test(L.id)){const option=document.createElement('option');option.value=L.id;option.textContent=L.id+' · '+L.title;selector.append(option);}
 const empty=[],traces=[],selection={x:0,y:0},chapter={mode:'',frame:0,stage:0,demo:null,growth:null,dispatch:null,life:null};
 const viewport={width:1,height:1,dpr:1,view:'play',zoom:1,panX:0,panY:0};
 const renderer=new CityHallRenderer(canvas,CityHallAssets,layout);let app=null,installed=false,motion=true,sceneTime=0,lastLevel=null,lastMode=null,gestures=null;
 const media=matchMedia('(prefers-reduced-motion: reduce)');
 function eligible(){return installed&&ACTIVE_ROOM.id==='cityhall';}
 function resize(){if(gestures)gestures.cancel();const r=scene.getBoundingClientRect();viewport.width=Math.max(1,r.width);viewport.height=Math.max(1,r.height);viewport.dpr=devicePixelRatio||1;dirty=true;}
 function read(out){
  const demo=CP.hall&&CP.mode==='demo'?HC.demo:null;
  const growth=CP.hall&&CP.mode==='growth';out.presentation=growth?'growth':'board';
  out.level=demo?demo.level:gm.L;out.turns=growth?empty:demo?demo.turns:gm.chutes;out.mode=demo?'running':gm.mode;out.time=demo?(CP.frame%(demo.loop*60))/60:gm.t;out.sceneTime=sceneTime;
  const n=growth?0:demo?demo.traces.length:gm.mode!=='edit'&&gm.sim?gm.sim.n:0;traces.length=n;for(let i=0;i<n;i++)traces[i]=demo?demo.traces[i]:G_TRACES[i];out.traces=traces;out.gateTrace=demo?demo.gates:gm.gateTrace;
  out.originX=demo?64:gTX(0);out.originY=demo?64:gTY(0);selection.x=gm.cx;selection.y=gm.cy;out.selected=!cpActive()&&gm.cursor?selection:null;out.partner=null;out.gray=grayscale;out.motion=motion&&!media.matches;
  chapter.mode=CP.hall?CP.mode:'';chapter.frame=CP.frame;chapter.stage=HC.stage;chapter.demo=demo;chapter.growth=CP.hall&&CP.mode==='growth'?CITYCHAPTER.growth(HC.stage,CP.frame,HC.motion):null;chapter.dispatch=CP.hall&&CP.mode==='exit'?CITYCHAPTER.dispatch(CP.frame,HC.dispatch):null;chapter.life=CITYLIFE;out.chapter=chapter;
  if(lastLevel!==gm.L||lastMode!==CP.mode){if(gestures)gestures.cancel();lastLevel=gm.L;lastMode=CP.mode;selector.value=/^6-/.test(gm.L.id)?gm.L.id:'';document.getElementById('vaultLevelTitle').textContent=gm.L.title;document.getElementById('vaultKicker').textContent='Delivery '+gm.L.id+' · '+gm.L.board.w+' × '+gm.L.board.h;document.getElementById('vaultCaption').firstElementChild.textContent='City Hall · '+gm.L.id;}
  return out;
 }
 const native={renderFrame,present,update,gPick};
 const host={renderer,viewport,read,check(){if(!canvas.isConnected)throw Error('Study detached');},invalidate(){dirty=true;},subscribe(fn){media.addEventListener('change',fn);return()=>media.removeEventListener('change',fn);},install(binding){
  installed=true;
  renderFrame=function(){if(eligible()){binding.draw();return;}return native.renderFrame();};
  present=function(){const on=eligible();document.body.classList.toggle('cityhall-paper',on);header.hidden=scene.hidden=!on;if(on)return;return native.present();};
  update=function(){if(eligible()&&!document.hidden)sceneTime+=DT;return native.update();};
  gPick=function(x,y){if(!eligible())return native.gPick(x,y);const r=canvas.getBoundingClientRect(),cell=PICK(x-r.left,y-r.top);return cell?cell.y*gm.L.board.w+cell.x:-1;};
  return()=>{installed=false;renderFrame=native.renderFrame;present=native.present;update=native.update;gPick=native.gPick;};
 }};
 const pickOut={x:0,y:0};function PICK(x,y){return CityHallProjection.pick(x,y,renderer.board,renderer.cam,pickOut);}
 function select(id){if(gestures)gestures.cancel();const index=LEVELS.findIndex(l=>l.id===id);if(index<0||!/^6-/.test(id))return false;cpCancel();gLoad(index);cpCancel();viewport.zoom=1;viewport.panX=viewport.panY=0;dirty=true;return true;}
 selector.addEventListener('change',()=>select(selector.value));
 const view=document.getElementById('vaultView');function setView(value){if(gestures)gestures.cancel();viewport.view=value;viewport.zoom=1;viewport.panX=viewport.panY=0;view.textContent=value==='hall'?'Return to board':'Explore hall';view.setAttribute('aria-pressed',String(value==='hall'));dirty=true;}view.onclick=()=>setView(viewport.view==='hall'?'play':'hall');
 document.getElementById('vaultMotion').onclick=e=>{motion=!motion;e.target.setAttribute('aria-pressed',String(!motion));dirty=true;};
 document.getElementById('vaultGray').onclick=e=>{grayscale=!grayscale;e.target.setAttribute('aria-pressed',String(grayscale));dirty=true;};
 document.getElementById('vaultMinus').onclick=()=>{gestures.cancel();viewport.zoom=Math.max(.7,viewport.zoom-.15);dirty=true;};document.getElementById('vaultPlus').onclick=()=>{gestures.cancel();viewport.zoom=Math.min(2.5,viewport.zoom+.15);dirty=true;};
 gestures=CityHallInput.create(viewport,(x,y)=>{if(!cpActive()){const r=canvas.getBoundingClientRect();gTapAt(x+r.left,y+r.top);}},(x,y)=>{if(!cpActive()){const r=canvas.getBoundingClientRect();gHover(x+r.left,y+r.top);canvas.style.cursor=PICK(x,y)?'pointer':'grab';}},()=>{dirty=true;});
 canvas.addEventListener('pointerdown',e=>{if(cpActive())return;const r=canvas.getBoundingClientRect();gestures.down(e.pointerId,e.clientX-r.left,e.clientY-r.top);canvas.setPointerCapture(e.pointerId);canvas.focus({preventScroll:true});});
 canvas.addEventListener('pointermove',e=>{if(cpActive())return;const r=canvas.getBoundingClientRect();gestures.move(e.pointerId,e.clientX-r.left,e.clientY-r.top);});
 canvas.addEventListener('pointerup',e=>{const r=canvas.getBoundingClientRect();gestures.up(e.pointerId,e.clientX-r.left,e.clientY-r.top);});
 canvas.addEventListener('pointercancel',()=>gestures.cancel());
 const observer=new ResizeObserver(resize);observer.observe(scene);window.addEventListener('resize',resize);
 try{
  document.body.classList.add('cityhall-paper');const saved=progress.current;select(/^6-/.test(saved)?saved:'6-1');resize();
  app=CityHallPaper.createCityHallPaper(host);await app.mount();loading.remove();resize();
  window.CityHallStudy={ready:true,renderer,app,viewport,select,view:setView,
   snapshot(){return {level:gm.L.id,mode:gm.mode,time:gm.t,chapter:CP.mode,chutes:gm.chutes,tray:gm.tray,attempts:gm.attempts,progress:PROGRESS.serialize(progress),camera:{...renderer.cam},resources:{...app.resources()}};},
   fixtureAnswer(){if(gm.mode==='running')gSend();gm.chutes=gm.L.solution.map(t=>({...t}));gm.tray={...gm.L.tray};for(const t of gm.chutes)gm.tray[t.type]--;gSyncSrc();gHud();dirty=true;},
   intro(){hcIntro();},demo(){hcIntro();hcDemo();},send:gSend,next:gNext,
   screenCell(x,y){const p=CityHallProjection.project(renderer.board.x+x*16+8,renderer.board.y+y*16+8),r=canvas.getBoundingClientRect();return{x:r.left+p.x*renderer.cam.scale+renderer.cam.tx,y:r.top+p.y*renderer.cam.scale+renderer.cam.ty};},
   pick:gPick,seekAmbient(t){sceneTime=t;dirty=true;},dispose(){gestures.cancel();app.dispose();observer.disconnect();window.removeEventListener('resize',resize);header.remove();scene.remove();heading.remove();document.body.classList.remove('cityhall-paper');dirty=true;}
  };
 }catch(error){loading.textContent='Could not open the hall: '+error.message;console.error(error);}
})();
