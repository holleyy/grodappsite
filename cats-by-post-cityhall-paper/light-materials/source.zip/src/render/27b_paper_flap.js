// Separate flap presentation: rooted support, low passage and a delayed empty-box fold.
// Rule events/ticks remain authoritative. Angles and times are immutable scene data.
function paperBoardFlapPose(o,tr,now){
  o.flapPose=-1;o.flapRim=0;o.flapBack=0;o.flapClipSide=-1;o.flapClipAt=0;
  if(tr.homeKind!=='flap'||tr.n===0)return;
  const A=EDGE_PORTAL_DATA.arrival,j=tr.n-1,d=tr.homeSide,T=now-(tr.rel+tr.n*tr.tick);
  const hx=tr.ox+tr.x1[j]*TILE+8,hy=tr.oy+tr.y1[j]*TILE+8;
  const plane=8+(d<2?EDGE_PORTAL_DATA.outset+EDGE_PORTAL_DATA.housingDepth:EDGE_PORTAL_DATA.backOutset);
  const wrong=tr.end===BOARDANIM.END_WRONG,stop=wrong?0:plane-(d>=2?A.awayStopGap:A.stopGap)-(tr.big?2:0);
  const bx=hx+TAKEOFF_DX[d]*stop,by=hy+TAKEOFF_DY[d]*stop;
  if(T<0){
    if(T<-tr.tick||o.anim===BA.HIDDEN||o.anim===BA.POP)return;
    const f=clamp((T+tr.tick)/tr.tick,0,1),bounced=tr.bn[j];
    const p=bounced?(f<.35?-2*takeoffEase(f/.35):lerp(-2,stop,takeoffEase((f-.35)/.65))):stop*takeoffEase(f/.8);
    o.x=takeoffQ(hx+TAKEOFF_DX[d]*p);o.y=takeoffQ(hy+TAKEOFF_DY[d]*p);
    o.dir=o.head=bounced&&f<.35?tr.d0[j]:d;o.z=0;o.bob=0;return;
  }
  o.dir=o.head=d;o.z=0;o.bob=0;o.flapOpen=0;o.takeoff=-1;o.flapWrong=wrong;
  if(wrong){
    o.anim=BA.IDLE;o.x=hx;o.y=hy;o.boxFold=-1;
    const face=Math.floor(T*2)%3;o.eyes=face===1?1:0;o.ears=face===2?BOARDANIM.EARS_TWITCH:0;return;
  }
  o.boxX=bx;o.boxY=by;o.boxFade=0;
  o.boxFold=T<A.fold?0:T<A.flat?1+Math.floor((T-A.fold)*10+1e-6):T<A.gone?4:-1;
  if(T>=A.flat){
    const fade=clamp((T-A.flat)/(A.gone-A.flat),0,1),slide=takeoffEase(fade);
    o.boxX=takeoffQ(bx-Math.SQRT1_2*12*slide);o.boxY=takeoffQ(by+Math.SQRT1_2*12*slide);o.boxFade=fade;
  }
  if(T>=A.clear){o.anim=BA.HIDDEN;o.x=bx;o.y=by;return;}
  const posesAt=d>=2?A.awayPosesAt:A.posesAt;
  let pose=0;for(let k=1;k<posesAt.length;k++)if(T>=posesAt[k])pose=k;
  o.flapPose=pose;o.flapRim=T<.65?1:0;
  o.flapBack=d>=2?2*(1-takeoffEase(T/A.contact)):2*(1-takeoffEase((T-.36)/.12));o.anim=BA.TRAVEL;
  const p=takeoffEase((T-A.contact)/(A.clear-A.contact))*(d>=2?A.awayTravel:10);
  o.x=takeoffQ(bx+TAKEOFF_DX[d]*p);o.y=takeoffQ(by+TAKEOFF_DY[d]*p);
  o.flapClipSide=d;o.flapClipAt=(d&1?hy:hx)*(d<2?1:-1)+plane;
}
function paperFlapDoorState(src,f){
  const A=EDGE_PORTAL_DATA.arrival;let active=0,latest=Infinity;
  for(let i=0;i<src.n;i++){
    const tr=src.traces[i],now=src.times[i];
    if(!tr||now<0||tr.homeKind!=='flap'||tr.end!==BOARDANIM.END_HOME||tr.homeSide!==f.side||tr.coat!==f.coat||!tr.n)continue;
    const j=tr.n-1;if(tr.x1[j]!==f.x||tr.y1[j]!==f.y)continue;
    const T=now-(tr.rel+tr.n*tr.tick);if(T<A.contact)continue;
    latest=Math.min(latest,T);
    if(T<A.clear)active=Math.max(active,T<.56?1:T<.68?2:3);
  }
  if(active)return active;
  let state=0;for(let k=0;k<A.doorTimes.length;k++)if(latest>=A.doorTimes[k])state=A.doorStates[k];
  return latest===Infinity?0:state;
}
function buildPaperFlapCat(coat,dir,frame){
  const k=((coat-1)*2+(dir>=2?1:0))*8+frame,source=paperFlapSources[k];
  if(coat<1||coat>2||frame<0||frame>=8||!source)return false;
  SPR.set(source);SPO.fill(0);return true;
}
function drawPaperFlapCat(o,tr){
  if(!buildPaperFlapCat(tr.coat,o.dir,o.flapPose))return false;
  if(o.dir>=2)return drawPaperFlapEntry(o,tr);
  drawPaperFlapBox(o,tr);buildPaperFlapCat(tr.coat,o.dir,o.flapPose);
  shSunMax=1;shFlag=0;shBias=0;
  blitSurface=o.dir>=2?paperLookup.get(paperSpriteHash()):null;
  blitClipSide=o.flapClipSide;blitClipAt=o.flapClipAt;
  const x=o.x-TAKEOFF_DX[o.dir]*o.flapBack,y=o.y-TAKEOFF_DY[o.dir]*o.flapBack;
  const sx=Math.round(x-y),sy=Math.round((x+y)*.5);
  blitSprite(sy+sx*.5,sy-sx*.5,0,o.dir===0||o.dir===3,true);
  blitClipSide=-1;blitClipAt=0;blitSurface=null;
  return true;
}

// Authored away poses are progressively occluded at one real doorway anchor.
// Keeping the mouth fixed prevents a world-plane clip from erasing a cat beside it.
function drawPaperFlapEntry(o,tr){
  drawPaperFlapBox(o,tr);buildPaperFlapCat(tr.coat,o.dir,o.flapPose);
  const r=paperLookup.get(paperSpriteHash()),j=tr.n-1,d=o.dir,mirror=d===3;
  const hx=tr.ox+tr.x1[j]*TILE+8,hy=tr.oy+tr.y1[j]*TILE+8,p=8+EDGE_PORTAL_DATA.backOutset;
  const x=d===2?hx-p+o.flapBack:hx+r.entryMouth[0],y=d===3?hy-p+o.flapBack:hy-r.entryMouth[0];
  const ex=mirror?AX-r.entryNative[0]/4+.75:r.entryNative[0]/4-AX,ey=r.entryNative[1]/4-AY;
  const sx=Math.round(x-y-ex),sy=Math.round((x+y)*.5-r.entryMouth[1]-ey);
  shSunMax=1;shFlag=0;shBias=0;blitSurface=r;blitClipSide=-1;blitClipAt=0;
  blitSprite(sy+sx*.5,sy-sx*.5,0,mirror,true);
  blitSurface=null;return true;
}

function drawPaperFlapBox(o,tr){
  if(o.boxFold<0)return;
  drawPaperPhysicalPiece(7,(tr.coat===COAT_BLUE?5:0)+o.boxFold,o.boxX,o.boxY,o.boxFade);
}
