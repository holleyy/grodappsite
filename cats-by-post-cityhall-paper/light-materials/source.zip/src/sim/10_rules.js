// ============================================================================
// 10 RULES: the Cats by Post puzzle as a pure, deterministic simulation. No DOM,
// canvas, clock or randomness, and whole numbers only: the caller advances it
// one tick at a time, once every 300 ms. This is the part to port 1:1 to Swift,
// which runs the same golden cases (tests/golden.json).
//
// Board: x = column (+x right), y = row (+y down); (0,0) is the back corner tile,
// and the board's edges are walls. Level and result data use names that map to
// Swift enums: Dir U R D L; Coat ginger blue; TurntableType plain ginger blue;
// Outcome running won wrongBasket timeUp; CatState waiting travelling delivered
// puzzled. Inside, directions are 0 R, 1 D, 2 L, 3 U (clockwise, like the scene's
// E S W N) and coats 1 ginger, 2 blue (a coloured turntable has its coat's number).
//
// The rules (exact: the levels depend on them):
//  1. One tick every 300 ms (the caller's clock).
//  2. Each tick: first move travelling cats in release-tick order, breaking ties
//     by hatch list order. Then release new cats, also in hatch list order.
//  3. Each hatch releases its cats in order, one every 2 ticks from tick 0. A new
//     cat appears on the hatch tile facing the hatch's direction and starts
//     moving on the next tick.
//  4. A cat steps 1 tile. Into a wall or a dog it reverses and steps that way in
//     the same tick; if that's blocked too, it stays where it is.
//  5. Entering a tile: its own coat's basket delivers it; the other basket leaves
//     it puzzled there (the attempt has failed); a turntable turns it to face the
//     turntable's way (plain turns every cat, ginger only ginger, blue only blue).
//  6. Hatch tiles are plain floor once a cat has left them.
//  7. Cats pass through each other. A puzzled cat doesn't block its basket.
//  8. Won: every cat delivered. After a wrong basket the run plays on until every
//     cat is delivered or puzzled, or time runs out, and ends wrongBasket. Time up:
//     the level's time limit (36 ticks unless it sets timeLimit) with cats still out.
//  9. A gate (railway points) has two distinct exits and starts on the first. A cat
//     entering its tile turns to face the gate's current exit, then the gate switches
//     to its other exit. It turns every cat. Cats move in the order they were released,
//     so when two cats enter a gate in the same tick, the one released first takes the
//     current exit. A cat that stays where it is doesn't switch it. Each run starts
//     with every gate on its first exit.
//     Entry includes the reversed step of a bounce (rule 4), exactly once.
// 10. A coloured flap occupies one outer side of an edge tile. Before either
//     attempted step leaves the board, its matching flap delivers the cat;
//     the other coat leaves it puzzled on the edge tile. No flap means a wall.
//     Along-edge movement and merely standing on that tile do not use a flap.
//
// 11. Actual entry into a tunnel relocates to its partner, preserving direction.
//     The exit has no effects this tick and standing there never triggers a return.
//
// Level data (format 1) can grow: each kind of piece is its own optional list
// (missing = none), and a hatch's cat is a coat name or an object with a coat.
// ============================================================================
const GR_DIR = { R: 0, D: 1, L: 2, U: 3 }, GR_DIRS = ['R', 'D', 'L', 'U'];
const GR_DX = [1, 0, -1, 0], GR_DY = [0, 1, 0, -1];
const GR_TICK_MS = 300, GR_TIME_LIMIT = 36, GR_RELEASE_EVERY = 2;
const GR_GINGER = 1, GR_BLUE = 2, GR_COAT = { ginger: 1, blue: 2 }, GR_COATS = [null, 'ginger', 'blue'];
const GR_PLAIN = 0, GR_TYPE = { plain: 0, ginger: 1, blue: 2 }, GR_TYPES = ['plain', 'ginger', 'blue'];
const GC_FLOOR = 0, GC_DOG = 1, GC_BASKET_GINGER = 2, GC_BASKET_BLUE = 3, GC_HATCH = 4, GC_GATE = 5, GC_TUNNEL = 6;
const GO_RUNNING = 'running', GO_WON = 'won', GO_WRONG = 'wrongBasket', GO_TIME_UP = 'timeUp';
const GL_WAIT = 0, GL_BOARD = 1, GL_DONE = 2, GL_WRONG = 3, GL_STATES = ['waiting', 'travelling', 'delivered', 'puzzled'];
const GE_NONE = 0, GE_RELEASED = 1, GE_MOVED = 2, GE_DELIVERED = 3, GE_WRONG = 4, GE_STUCK = 5, GE_TUNNEL = 6, GE_WAIT = 7;
const GR_TUNNEL_SYMBOLS = ['circle', 'square', 'triangle', 'diamond'];

const grList = (a) => a || [];                          // a piece list a level leaves out is empty
function grCatCoat(c) {
  const coat = c !== null && typeof c === 'object' ? c.coat : c;
  return Object.hasOwn(GR_COAT, coat) ? GR_COAT[coat] : 0;
}

function grCatBig(c) { return !!(c && typeof c === 'object' && c.big === true); }
// Only actual movement attempts count; a bounce, stuck attempt or tunnel keeps the schedule.
function grCanMove(s, i, t) { const age = t - s.releaseTick[i]; return !s.big[i] || age > 0 && age % 2 === 0; }

// A fresh simulation of a level with the player's turntables ([{x, y, type, dir}]).
function grCreate(level, placements) {
  const W = level.board.w, H = level.board.h;
  const cell = new Int8Array(W * H), chDir = new Int8Array(W * H).fill(-1), chType = new Int8Array(W * H);
  const gates = grList(level.gates), gateAt = new Int16Array(W * H).fill(-1), gateExit = new Int8Array(gates.length * 2);
  const flaps = grList(level.flaps), flapAt = new Int16Array(W * H * 4).fill(-1);
  const tunnels = grList(level.tunnels), tunnelAt = new Int8Array(W * H).fill(-1), tunnelTo = new Int16Array(W * H).fill(-1);
  for (let t = 0; t < tunnels.length; t++) {
    const p = tunnels[t], a = p.a.y * W + p.a.x, b = p.b.y * W + p.b.x;
    cell[a] = cell[b] = GC_TUNNEL; tunnelAt[a] = tunnelAt[b] = t; tunnelTo[a] = b; tunnelTo[b] = a;
  }
  for (let f = 0; f < flaps.length; f++) {
    const p = flaps[f]; flapAt[(p.y * W + p.x) * 4 + GR_DIR[p.side]] = f;
  }
  for (let g = 0; g < gates.length; g++) {
    const p = gates[g], k = p.y * W + p.x;
    cell[k] = GC_GATE; gateAt[k] = g;
    gateExit[g * 2] = GR_DIR[p.exits[0]]; gateExit[g * 2 + 1] = GR_DIR[p.exits[1]];
  }
  for (const d of grList(level.dogs)) cell[d.y * W + d.x] = GC_DOG;
  for (const b of grList(level.baskets)) cell[b.y * W + b.x] = GR_COAT[b.coat] === GR_GINGER ? GC_BASKET_GINGER : GC_BASKET_BLUE;
  let n = 0;
  const hatches = grList(level.hatches).map((h) => {
    cell[h.y * W + h.x] = GC_HATCH;
    const hatch = { x: h.x, y: h.y, dir: GR_DIR[h.dir], first: n, count: h.cats.length };
    n += h.cats.length;
    return hatch;
  });
  for (const p of grList(placements)) { chDir[p.y * W + p.x] = GR_DIR[p.dir]; chType[p.y * W + p.x] = GR_TYPE[p.type]; }
  const s = {
    W, H, cell, chDir, chType, hatches, n, tick: 0, endTick: -1, timeLimit: level.timeLimit || GR_TIME_LIMIT,
    outcome: GO_RUNNING, delivered: 0, puzzled: 0, wrong: -1, wrongTick: -1,
    gates, gateAt, gateExit, gateState: new Uint8Array(gates.length), moveOrder: new Int16Array(n),
    tunnels, tunnelAt, tunnelTo, tunnelUses: new Int32Array(tunnels.length),
    tunnelPair: new Int8Array(n).fill(-1), entryX: new Int8Array(n).fill(-1), entryY: new Int8Array(n).fill(-1),
    flaps, flapAt, homeFlap: new Int16Array(n).fill(-1),
    // At most one gate entry per cat per tick. Ordered events feed the animation trace.
    flipCount: 0, flipGate: new Int16Array(n), flipCat: new Int16Array(n), flipFrom: new Uint8Array(n),
    // solver hook: per-tile bits of the coats whose turntable is still undecided (null in the game)
    undec: null, paused: false, pendI: -1, pendK: -1, turns: new Int16Array(W * H), dogHits: 0,
    // per cat: coat, state, tile and heading (a waiting cat sits on its hatch), and this tick's move (for animation)
    hasBig: false, big: new Uint8Array(n), releaseTick: new Int32Array(n),
    coat: new Int8Array(n), st: new Int8Array(n), x: new Int8Array(n), y: new Int8Array(n), dir: new Int8Array(n),
    px: new Int8Array(n), py: new Int8Array(n), pdir: new Int8Array(n), ev: new Int8Array(n), bounced: new Int8Array(n),
  };
  grList(level.hatches).forEach((h, k) => {
    for (let j = 0; j < h.cats.length; j++) {
      const i = hatches[k].first + j;
      s.big[i] = grCatBig(h.cats[j]) ? 1 : 0; s.hasBig = s.hasBig || !!s.big[i]; s.releaseTick[i] = j * GR_RELEASE_EVERY;
      s.coat[i] = grCatCoat(h.cats[j]); s.x[i] = h.x; s.y[i] = h.y; s.dir[i] = hatches[k].dir;
    }
  });
  // Cat IDs and result arrays stay hatch-major. Only this separate index is release-major.
  for (let j = 0, q = 0; q < n; j++) for (let k = 0; k < hatches.length; k++) {
    if (j < hatches[k].count) s.moveOrder[q++] = hatches[k].first + j;
  }
  return s;
}
function grBlocked(s, x, y) {
  return x < 0 || y < 0 || x >= s.W || y >= s.H || s.cell[y * s.W + x] === GC_DOG;
}
// One settlement path preserves wrong-destination diagnostics for baskets/flaps.
function grSettle(s, i, coat) {
  if (coat === s.coat[i]) { s.st[i] = GL_DONE; s.delivered++; s.ev[i] = GE_DELIVERED; }
  else {
    s.st[i] = GL_WRONG; s.puzzled++; s.ev[i] = GE_WRONG;
    if (s.wrong < 0 || (s.wrongTick === s.tick && i < s.wrong)) { s.wrong = i; s.wrongTick = s.tick; }
  }
}
function grFlapAt(s, i, d) { return s.flapAt[(s.y[i] * s.W + s.x[i]) * 4 + d]; }
function grExitFlap(s, i, d) {
  const f = grFlapAt(s, i, d);
  if (f < 0) return false;
  s.homeFlap[i] = f; s.dir[i] = d;
  grSettle(s, i, GR_COAT[s.flaps[f].coat]);
  return true;
}
// Rule 5: what entering a tile does.
function grEnter(s, i) {
  const k = s.y[i] * s.W + s.x[i], c = s.cell[k];
  // An entry consumes this move. Never settle the destination or recurse.
  if (c === GC_TUNNEL) {
    const pair = s.tunnelAt[k], to = s.tunnelTo[k];
    s.entryX[i] = s.x[i]; s.entryY[i] = s.y[i]; s.tunnelPair[i] = pair;
    s.x[i] = to % s.W; s.y[i] = Math.floor(to / s.W); s.ev[i] = GE_TUNNEL; s.tunnelUses[pair]++;
    return;
  }
  if (c === GC_BASKET_GINGER || c === GC_BASKET_BLUE) {
    grSettle(s, i, c === GC_BASKET_GINGER ? GR_GINGER : GR_BLUE);
    return;
  }
  if (c === GC_GATE) {
    const g = s.gateAt[k], from = s.gateState[g], e = s.flipCount++;
    s.dir[i] = s.gateExit[g * 2 + from]; s.gateState[g] = 1 - from;
    s.flipGate[e] = g; s.flipCat[e] = i; s.flipFrom[e] = from;
    return;
  }
  if (s.undec !== null && (s.undec[k] & s.coat[i])) { s.pendI = i; s.pendK = k; s.paused = true; return; }
  const d = s.chDir[k];
  if (d >= 0 && (s.chType[k] === GR_PLAIN || s.chType[k] === s.coat[i])) {
    if (d !== s.dir[i]) s.turns[k]++;
    s.dir[i] = d;
  }
}
// Rule 4: step; into a wall or a dog, reverse and try the other way in the same tick.
function grMove(s, i) {
  let d = s.dir[i], nx = s.x[i] + GR_DX[d], ny = s.y[i] + GR_DY[d];
  if ((nx < 0 || ny < 0 || nx >= s.W || ny >= s.H) && grExitFlap(s, i, d)) return;
  if (grBlocked(s, nx, ny)) {
    if (nx >= 0 && ny >= 0 && nx < s.W && ny < s.H) s.dogHits++;
    d = (d + 2) & 3; s.dir[i] = d; s.bounced[i] = 1;
    nx = s.x[i] + GR_DX[d]; ny = s.y[i] + GR_DY[d];
    if ((nx < 0 || ny < 0 || nx >= s.W || ny >= s.H) && grExitFlap(s, i, d)) return;
    if (grBlocked(s, nx, ny)) { s.ev[i] = GE_STUCK; return; }
  }
  s.x[i] = nx; s.y[i] = ny; s.ev[i] = GE_MOVED;
  grEnter(s, i);
}
// One tick (rules 2, 3 and 8). Does nothing once the outcome is decided.
function grTick(s) {
  if (s.outcome !== GO_RUNNING || s.paused) return s;
  const t = s.tick; s.flipCount = 0;
  for (let i = 0; i < s.n; i++) { s.px[i] = s.x[i]; s.py[i] = s.y[i]; s.pdir[i] = s.dir[i]; s.ev[i] = GE_NONE; s.bounced[i] = 0; s.tunnelPair[i] = s.entryX[i] = s.entryY[i] = -1; }
  for (let q = 0; q < s.n; q++) {                                                 // 1. move
    const i = s.moveOrder[q];
    if (s.st[i] !== GL_BOARD) continue;
    if (!grCanMove(s, i, t)) { s.ev[i] = GE_WAIT; continue; }
    grMove(s, i);
    if (s.paused) return s;                                                        // the solver takes over
  }
  if (t % GR_RELEASE_EVERY === 0) {                                               // 2. release
    const j = t / GR_RELEASE_EVERY;
    for (let k = 0; k < s.hatches.length; k++) {
      const h = s.hatches[k];
      if (j < h.count) { s.st[h.first + j] = GL_BOARD; s.ev[h.first + j] = GE_RELEASED; }
    }
  }
  s.tick = t + 1;
  if (s.delivered + s.puzzled === s.n) s.outcome = s.puzzled ? GO_WRONG : GO_WON;    // every cat has settled
  else if (s.tick >= s.timeLimit) s.outcome = s.puzzled ? GO_WRONG : GO_TIME_UP;
  if (s.outcome !== GO_RUNNING) s.endTick = t;
  return s;
}
function grRun(level, placements) {
  const s = grCreate(level, placements);
  while (s.outcome === GO_RUNNING) grTick(s);
  return s;
}
// The result as plain data (what tests/golden.json stores): cats hatch by hatch, in release order.
function grResult(s) {
  const cats = [];
  for (let i = 0; i < s.n; i++) {
    const cat = { coat: GR_COATS[s.coat[i]], x: s.x[i], y: s.y[i], dir: GR_DIRS[s.dir[i]], state: GL_STATES[s.st[i]] };
    if (s.big[i]) cat.big = true;
    if (s.homeFlap[i] >= 0) {
      const f = s.flaps[s.homeFlap[i]];
      cat.destination = { kind: 'flap', side: f.side, coat: f.coat };
    }
    cats.push(cat);
  }
  const result = { outcome: s.outcome, endTick: s.endTick, cats };
  if (s.gates.length) result.gates = s.gates.map((g, i) => ({ x: g.x, y: g.y, exit: GR_DIRS[s.gateExit[i * 2 + s.gateState[i]]] }));
  return result;
}
// Static checks on a level (bounds, overlaps, names) and on a set of turntables (the tray).
function grValidate(level, placements) {
  if (!level || !level.board) return ['level needs a board'];
  const errs = [], W = level.board.w, H = level.board.h, used = {};
  if (!Number.isSafeInteger(W) || !Number.isSafeInteger(H) || W < 1 || H < 1) return ['board dimensions must be positive whole tiles'];
  if (level.timeLimit !== undefined && (!Number.isSafeInteger(level.timeLimit) || level.timeLimit < 1)) errs.push('timeLimit must be a positive whole tick count');
  for (const kind of ['hatches', 'baskets', 'dogs', 'gates']) {
    const list = level[kind];
    if (list !== undefined && list !== null && (!Array.isArray(list) || list.some(p => !p || typeof p !== 'object' || Array.isArray(p))))
      return errs.concat(kind + ' must be a list of piece records');
  }
  if (placements !== undefined && placements !== null && (!Array.isArray(placements) || placements.some(p => !p || typeof p !== 'object' || Array.isArray(p))))
    return errs.concat('turntables must be a list of piece records');
  if (level.tray !== undefined) {
    if (!level.tray || typeof level.tray !== 'object' || Array.isArray(level.tray)) errs.push('tray must be an object');
    else for (const type of GR_TYPES) if (level.tray[type] !== undefined && (!Number.isSafeInteger(level.tray[type]) || level.tray[type] < 0))
      errs.push('tray.' + type + ' must be a non-negative whole count');
  }
  const put = (what, x, y) => {
    if (!Number.isInteger(x) || !Number.isInteger(y)) errs.push(what + ' coordinates must be whole tiles');
    if (x < 0 || y < 0 || x >= W || y >= H) errs.push(what + ' outside the board at ' + x + ',' + y);
    const k = x + ',' + y;
    if (used[k]) errs.push(what + ' overlaps ' + used[k] + ' at ' + k);
    used[k] = what;
  };
  for (const h of grList(level.hatches)) {
    put('hatch', h.x, h.y);
    if (GR_DIRS.indexOf(h.dir) < 0) errs.push('bad hatch dir ' + h.dir);
    if (!Array.isArray(h.cats) || !h.cats.length) errs.push('a hatch at ' + h.x + ',' + h.y + ' needs a non-empty cats list');
    else for (const c of h.cats) {
      if (!grCatCoat(c)) errs.push('bad cat coat ' + JSON.stringify(c));
      if (c && typeof c === 'object' && Object.hasOwn(c, 'big') && typeof c.big !== 'boolean') errs.push('cat big flag must be boolean');
    }
  }
  for (const b of grList(level.baskets)) { put('basket', b.x, b.y); if (b.coat !== 'ginger' && b.coat !== 'blue') errs.push('bad basket coat ' + b.coat); }
  for (const d of grList(level.dogs)) put('dog', d.x, d.y);
  for (const g of grList(level.gates)) {
    put('gate', g.x, g.y);
    if (!Number.isInteger(g.x) || !Number.isInteger(g.y)) errs.push('gate coordinates must be whole tiles');
    if (!Array.isArray(g.exits) || g.exits.length !== 2 || !GR_DIRS.includes(g.exits[0]) || !GR_DIRS.includes(g.exits[1]) ||
        g.exits[0] === g.exits[1]) errs.push('gate exits must be two different directions');
  }
  if (level.tunnels !== undefined) {
    if (!Array.isArray(level.tunnels)) errs.push('tunnels must be a list of complete pairs');
    else {
      const symbols = new Set();
      if (level.tunnels.length > 4) errs.push('at most four tunnel pairs');
      for (const t of level.tunnels) {
        if (!t || typeof t !== 'object' || Array.isArray(t) || !t.a || !t.b ||
            typeof t.a !== 'object' || typeof t.b !== 'object' || Array.isArray(t.a) || Array.isArray(t.b)) {
          errs.push('tunnel needs two endpoint records'); continue;
        }
        if (!GR_TUNNEL_SYMBOLS.includes(t.symbol) || symbols.has(t.symbol)) errs.push('tunnel symbols must be distinct circle/square/triangle/diamond');
        symbols.add(t.symbol);
        for (const e of [t.a, t.b]) {
          put('tunnel', e.x, e.y);
          if (Array.isArray(level.flaps) && level.flaps.some(f => f && f.x === e.x && f.y === e.y)) errs.push('tunnel overlaps flap');
          if (grList(level.hatches).some(h => h.x + GR_DX[GR_DIR[h.dir]] === e.x && h.y + GR_DY[GR_DIR[h.dir]] === e.y)) errs.push('tunnel cannot be a hatch exit tile');
        }
      }
    }
  }
  if (level.flaps !== undefined && !Array.isArray(level.flaps)) errs.push('flaps must be a list');
  else {
    const edges = new Set();
    for (const f of grList(level.flaps)) {
      if (!f || typeof f !== 'object') { errs.push('invalid flap record'); continue; }
      const tile = Number.isInteger(f.x) && Number.isInteger(f.y) && f.x >= 0 && f.y >= 0 && f.x < W && f.y < H;
      if (!tile) errs.push('flap coordinates must be whole tiles inside the board');
      if (!GR_DIRS.includes(f.side)) errs.push('bad flap side ' + f.side);
      else if (tile && !((f.side === 'R' && f.x === W - 1) || (f.side === 'L' && f.x === 0) ||
          (f.side === 'D' && f.y === H - 1) || (f.side === 'U' && f.y === 0))) errs.push('flap side must face an outer edge');
      if (f.coat !== 'ginger' && f.coat !== 'blue') errs.push('bad flap coat ' + f.coat);
      const key = f.x + ',' + f.y + ',' + f.side;
      if (edges.has(key)) errs.push('duplicate flap side at ' + key);
      edges.add(key);
      if (grList(level.hatches).some(h => h.x === f.x && h.y === f.y && h.dir === f.side)) errs.push('flap conflicts with hatch direction at ' + key);
    }
  }
  if (placements) {
    const tray = level.tray || {}, left = { plain: tray.plain | 0, ginger: tray.ginger | 0, blue: tray.blue | 0 };
    for (const p of placements) {
      put('turntable', p.x, p.y);
      if (GR_DIRS.indexOf(p.dir) < 0) errs.push('bad turntable dir ' + p.dir);
      if (GR_TYPES.indexOf(p.type) < 0) errs.push('bad turntable type ' + p.type);
      else if (--left[p.type] < 0) errs.push('the tray has no spare ' + p.type + ' turntable');
    }
  }
  return errs;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { grCreate, grTick, grRun, grResult, grValidate, grEnter, grCatCoat, grCatBig, grCanMove, grFlapAt, GR_DIR, GR_DIRS, GR_DX, GR_DY, GR_TICK_MS,
    GR_TIME_LIMIT, GR_GINGER, GR_BLUE, GR_COAT, GR_COATS, GR_PLAIN, GR_TYPE, GR_TYPES, GC_FLOOR, GC_DOG,
    GC_BASKET_GINGER, GC_BASKET_BLUE, GC_HATCH, GC_GATE, GC_TUNNEL, GR_TUNNEL_SYMBOLS, GO_RUNNING, GO_WON, GO_WRONG,
    GO_TIME_UP, GL_WAIT, GL_BOARD, GL_DONE, GL_WRONG, GL_STATES, GE_NONE, GE_RELEASED, GE_MOVED, GE_DELIVERED, GE_WRONG, GE_STUCK, GE_TUNNEL, GE_WAIT };
}
