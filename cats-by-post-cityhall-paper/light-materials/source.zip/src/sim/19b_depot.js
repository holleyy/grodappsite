// ============================================================================
// 19b DEPOT (pure; Node-exported). Geometry, sunlight and analytic room motion.
// Whole world units and integer frames in data; 1 tile = 16 wu. The view ray,
// swept-hexagon coverage test and 1 wu rounding guard match 18_boxroom.js.
// Sun rays enter the east wall: the office's windowAmt model with arched heads.
// build/checks allocate once. sunAmt is an allocation-free point query for the
// future bake and actors. No clock, DOM, randomness or drawing lives here.
// Swift: DepotData: Codable; the same interval/ray checks in Double at loading.
// ============================================================================
const DEPOT = (function () {
  const CFG = typeof module !== 'undefined' && module.exports ? require('../data/depot.json') : DEPOT_DATA;
  const T = 16, CORE = 7;
  const ratio = q => q[0] / q[1];
  const clamp = (v,a,b) => v < a ? a : v > b ? b : v;

  function hidesTile(B, bx) {
    const hx0=bx[0]-bx[5], hx1=bx[3]-bx[2], hy0=bx[1]-bx[5], hy1=bx[4]-bx[2];
    const hs0=bx[0]+bx[1]-2*bx[5], hs1=bx[3]+bx[4]-2*bx[2], hd0=bx[0]-bx[4], hd1=bx[3]-bx[1];
    for(let j=0;j<B.h;j++) for(let i=0;i<B.w;i++) {
      const x=B.x+8+i*T, y=B.y+8+j*T;
      if(hx0<x+CORE && x-CORE<hx1 && hy0<y+CORE && y-CORE<hy1 &&
        hs0<x+y+CORE && x+y-CORE<hs1 && hd0<x-y+CORE && x-y-CORE<hd1) return [i,j];
    }
    return null;
  }
  function routeBoxes(route) {
    const out=[], r=route.radius, p=route.points;
    for(let i=1;i<p.length;i++) {
      const a=p[i-1], b=p[i];
      out.push([Math.min(a[0],b[0])-r,Math.min(a[1],b[1])-r,Math.min(a[2],b[2]),
        Math.max(a[0],b[0])+r,Math.max(a[1],b[1])+r,Math.max(a[2],b[2])+route.height,route.id]);
    }
    return out;
  }
  function solids(room) {
    const out=[];
    for(const f of room.furniture) for(const b of f.parts) out.push(b.concat(f.id));
    for(const w of room.walls) out.push(w.bounds.concat(w.id));
    for(const b of room.roof.bands) out.push(b.concat('roof'));
    for(const o of room.openings) for(const b of o.doors || []) out.push(b.concat(o.id+' door'));
    for(const l of room.lamps) {
      out.push([l.x-l.r-1,l.y-l.r-1,l.z,l.x+l.r+1,l.y+l.r+1,l.z+l.height,l.id+' lamp']);
      out.push([l.x-1,l.y-1,l.z+l.height,l.x+1,l.y+1,l.hangZ,l.id+' flex']);
    }
    for(const r of room.routes) out.push(...routeBoxes(r));
    for(const e of room.motionEnvelopes) out.push(e.bounds.concat(e.id));
    return out;
  }
  function hidden(room) {
    const out=[];
    for(const s of solids(room)) { const tile=hidesTile(room.board,s); if(tile) out.push({what:s[6],tile}); }
    return out;
  }
  function footprintIssues(room) {
    const out=[], B=room.board;
    for(const f of room.furniture) for(const p of f.parts) {
      const z=f.zone==='interior' ? [0,0,room.room.w,room.room.d] : room.exterior;
      if(p.length!==6 || p[0]>=p[3] || p[1]>=p[4] || p[2]>=p[5]) out.push({what:f.id,reason:'invalid volume'});
      if(p[0]<z[0] || p[1]<z[1] || p[3]>z[2] || p[4]>z[3]) out.push({what:f.id,reason:'outside '+f.zone});
      if(p[0]<B.x+B.w*T && p[3]>B.x && p[1]<B.y+B.h*T && p[4]>B.y) out.push({what:f.id,reason:'sorting floor'});
      if((p[0]>=B.x+B.w*T || p[1]>=B.y+B.h*T) && p[5]>12 && p[3]>B.x && p[4]>B.y)
        out.push({what:f.id,reason:'front item taller than one box'});
    }
    return out;
  }
  function routeIssues(room) {
    const out=[], B=room.board;
    for(const r of room.routes) for(const s of routeBoxes(r)) {
      if(s[3]>B.x && s[4]>B.y) out.push({what:r.id,reason:'route leaves back/left margins'});
      if(s[0]<0 || s[1]<0 || s[3]>room.room.w || s[4]>room.room.d) out.push({what:r.id,reason:'route outside room'});
    }
    return out;
  }

  // Ray from P to x=0, along (-1,m,k). Slabs, no temporary vectors per query.
  function blocked(room,x,y,z,m,k) {
    for(let f=0;f<room.furniture.length;f++) {
      const item=room.furniture[f]; if(item.castsShadow===false || item.zone==='exterior') continue;
      const solids=item.occluders || item.parts;
      for(let n=0;n<solids.length;n++) {
        const b=solids[n]; let lo=0.001, hi=x;
        for(let a=0;a<3 && lo<hi;a++) {
          const p=a===0?x:a===1?y:z, d=a===0?-1:a===1?m:k;
          if(d===0) { if(p<b[a] || p>b[a+3]) hi=-1; continue; }
          const u=(b[a]-p)/d, v=(b[a+3]-p)/d;
          lo=Math.max(lo,Math.min(u,v)); hi=Math.min(hi,Math.max(u,v));
        }
        if(lo<hi) return true;
      }
    }
    return false;
  }
  // Orthographic sun rays share wall-space y/z. Reject disjoint solid silhouettes before
  // the exact slab test. This loading-time index changes neither pixels nor shadow edges.
  function compileSun(room){
    const m=-room.sun.direction[1]/room.sun.direction[0],k=-room.sun.direction[2]/room.sun.direction[0],a=[];
    for(const item of room.furniture){
      if(item.castsShadow===false||item.zone==='exterior')continue;
      for(const b of item.occluders||item.parts)a.push(...b,
        b[1]+Math.min(m*b[0],m*b[3]),b[4]+Math.max(m*b[0],m*b[3]),
        b[2]+Math.min(k*b[0],k*b[3]),b[5]+Math.max(k*b[0],k*b[3]));
    }
    return Float64Array.from(a);
  }
  function indexedBlocked(a,x,y,z,m,k){
    const yw=y+m*x,zw=z+k*x;
    for(let i=0;i<a.length;i+=10){
      if(x<=a[i]||yw<a[i+6]-1e-9||yw>a[i+7]+1e-9||zw<a[i+8]-1e-9||zw>a[i+9]+1e-9)continue;
      let lo=.001,hi=x;
      for(let axis=0;axis<3&&lo<hi;axis++){
        const p=axis===0?x:axis===1?y:z,d=axis===0?-1:axis===1?m:k;
        if(d===0){if(p<a[i+axis]||p>a[i+axis+3])hi=-1;continue;}
        const u=(a[i+axis]-p)/d,v=(a[i+axis+3]-p)/d;
        lo=Math.max(lo,Math.min(u,v));hi=Math.min(hi,Math.max(u,v));
      }
      if(lo<hi)return true;
    }
    return false;
  }
  function sunAmt(room,x,y,z,index) {
    const S=room.sun, m=-S.direction[1]/S.direction[0], k=-S.direction[2]/S.direction[0];
    const yw=y+m*x, zw=z+k*x, frame=ratio(S.frame), bar=ratio(S.bar), rail=ratio(S.rail);
    let amount=0;
    for(let i=0;i<room.windows.length;i++) {
      const w=room.windows[i], yg=yw+w.depth*m, zg=zw+w.depth*k, mid=(w.u0+w.u1)/2;
      if(yw<=w.u0 || yw>=w.u1 || zw<=w.z0 || zw>=w.z1) continue;
      if(zw>w.springZ && Math.hypot(yw-mid,zw-w.springZ)>=w.radius) continue;
      let edge=Math.min(yw-w.u0,w.u1-yw,zw-w.z0,w.z1-zw,
        yg-w.u0-frame,w.u1-frame-yg,zg-w.z0-frame,w.z1-frame-zg);
      if(zw>w.springZ) edge=Math.min(edge,w.radius-Math.hypot(yw-mid,zw-w.springZ));
      if(zg>w.springZ) edge=Math.min(edge,w.radius-frame-Math.hypot(yg-mid,zg-w.springZ));
      for(let j=0;j<w.mullions.length;j++) edge=Math.min(edge,Math.abs(yg-w.mullions[j])-bar);
      for(let j=0;j<w.rails.length;j++) edge=Math.min(edge,Math.abs(zg-w.rails[j])-rail);
      amount=Math.max(amount,clamp(edge/ratio(S.soft)+ratio(S.bias),0,1));
    }
    return amount && !(index?indexedBlocked(index,x,y,z,m,k):blocked(room,x,y,z,m,k)) ? amount : 0;
  }

  // Convex shadows as in the Box Room. This is loading/review maths only.
  function hull(P) {
    P.sort((a,b)=>a[0]-b[0] || a[1]-b[1]); const lo=[], up=[];
    const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
    for(const p of P) { while(lo.length>1 && cross(lo.at(-2),lo.at(-1),p)<=0) lo.pop(); lo.push(p); }
    for(let i=P.length-1;i>=0;i--) { const p=P[i]; while(up.length>1 && cross(up.at(-2),up.at(-1),p)<=0) up.pop(); up.push(p); }
    return lo.slice(0,-1).concat(up.slice(0,-1));
  }
  function shadows(room,m,k) {
    const out=[];
    for(const f of room.furniture) if(f.castsShadow!==false && f.zone!=='exterior') for(const b of f.occluders || f.parts) {
      const p=[];
      for(const x of [b[0],b[3]]) for(const y of [b[1],b[4]]) for(const z of [b[2],b[5]]) p.push([x+z/k,y-m*z/k]);
      out.push(hull(p));
    }
    return out;
  }
  // Full-strength fraction (a stricter threshold than merely nonzero light).
  // Exact along each x scanline: partition at every frame/bar/arch/shadow edge,
  // then classify an interior point. Midpoint quadrature only between y rows.
  function sunlit(room,dy) {
    dy=dy===undefined?0.5:dy;
    if(!(dy>0 && Number.isFinite(dy))) throw new RangeError('scanline step must be positive');
    const B=room.board,S=room.sun,m=-S.direction[1]/S.direction[0],k=-S.direction[2]/S.direction[0];
    const sh=shadows(room,m,k), e=(1-ratio(S.bias))*ratio(S.soft), frame=ratio(S.frame), bar=ratio(S.bar),rail=ratio(S.rail);
    let area=0;
    for(let row=B.y;row<B.y+B.h*T;row+=dy) {
      const h=Math.min(dy,B.y+B.h*T-row),y=row+h/2,x0=B.x,x1=B.x+B.w*T, cuts=[x0,x1];
      const add=x=>{if(x>x0 && x<x1) cuts.push(x);};
      const linear=(a,b,target)=>{if(a) add((target-b)/a);};
      for(const w of room.windows) {
        for(const depth of [0,w.depth]) {
          const inset=depth?frame:0;
          for(const u of [w.u0+inset+e,w.u1-inset-e]) linear(m,y+m*depth,u);
          for(const z of [w.z0+inset+e,w.z1-inset-e,w.springZ]) linear(k,k*depth,z);
          const u=y+m*depth-(w.u0+w.u1)/2, v=k*depth-w.springZ, r=w.radius-inset-e;
          const a=m*m+k*k,b=2*(m*u+k*v),c=u*u+v*v-r*r, d=b*b-4*a*c;
          if(d>=0) { add((-b-Math.sqrt(d))/(2*a)); add((-b+Math.sqrt(d))/(2*a)); }
        }
        for(const u of w.mullions) for(const sign of [-1,1]) linear(m,y+m*w.depth,u+sign*(bar+e));
        for(const z of w.rails) for(const sign of [-1,1]) linear(k,k*w.depth,z+sign*(rail+e));
      }
      for(const p of sh) for(let i=0;i<p.length;i++) {
        const a=p[i],b=p[(i+1)%p.length];
        if((a[1]<=y && y<b[1]) || (b[1]<=y && y<a[1])) add(a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1]));
      }
      cuts.sort((a,b)=>a-b);
      for(let i=1;i<cuts.length;i++) if(sunAmt(room,(cuts[i-1]+cuts[i])/2,y,0)>=1) area+=(cuts[i]-cuts[i-1])*h;
    }
    return area/(B.w*B.h*T*T);
  }
  // Only horizontal window members cast grid-parallel edges. Vertical members
  // follow the oblique sun direction. Keep hard edges >=3 wu from a tile line.
  function onGridLines(room) {
    const out=[],B=room.board,S=room.sun,m=-S.direction[1]/S.direction[0],k=-S.direction[2]/S.direction[0];
    for(const w of room.windows) {
      const lines=[[w.z0,0],[w.z1,0],[w.z0+ratio(S.frame),w.depth],[w.z1-ratio(S.frame),w.depth]];
      for(const z of w.rails) lines.push([z-ratio(S.rail),w.depth],[z+ratio(S.rail),w.depth]);
      for(const [z,depth] of lines) {
        const x=z/k-depth, y0=w.u0-m*(x+depth), y1=w.u1-m*(x+depth);
        if(y1<=B.y || y0>=B.y+B.h*T) continue;
        for(let i=0;i<=B.w;i++) if(Math.abs(x-B.x-i*T)<3) out.push({window:w.id,at:x,tileLine:B.x+i*T});
      }
    }
    return out;
  }
  function bounds(room) {
    let sx0=Infinity,sx1=-Infinity,sy0=Infinity,sy1=-Infinity;
    for(const b of solids(room).concat(room.bases.map(q=>q.bounds)))
      for(const x of [b[0],b[3]]) for(const y of [b[1],b[4]]) for(const z of [b[2],b[5]]) {
        sx0=Math.min(sx0,x-y);sx1=Math.max(sx1,x-y);sy0=Math.min(sy0,(x+y)/2-z);sy1=Math.max(sy1,(x+y)/2-z);
      }
    return {sx0:Math.floor(sx0),sx1:Math.ceil(sx1),sy0:Math.floor(sy0),sy1:Math.ceil(sy1)};
  }
  function build(data) {
    const room=JSON.parse(JSON.stringify(data || CFG));
    const integers=(v,at)=>{
      if(typeof v==='number' && !Number.isInteger(v)) throw new RangeError(at+' must be an integer');
      if(v && typeof v==='object') for(const key of Object.keys(v)) integers(v[key],at+'.'+key);
    };
    integers(room,'depot');
    const B=room.board,R=room.room;
    if(room.version!==1 || room.tile!==T || room.loopFrames!==2880) throw new RangeError('unsupported depot data');
    if(B.w!==7 || B.h!==5 || B.x<3*T || B.y<3*T || R.w-B.x-B.w*T<2*T || R.d-B.y-B.h*T<2*T) throw new RangeError('sorting floor margins');
    const S=room.sun;if(S.direction[0]<=0 || S.direction[2]>=0) throw new RangeError('sun must enter the left wall and descend');
    for(const w of room.windows) if(w.wall!=='L' || w.u0<0 || w.u1>R.d || w.z0<0 || w.z1>R.wallH || w.radius<=0 || w.u1-w.u0!==2*w.radius || w.z1-w.springZ!==w.radius) throw new RangeError('invalid window '+w.id);
    const foot=footprintIssues(room);if(foot.length) throw new RangeError(foot[0].what+': '+foot[0].reason);
    if(!room.bases.some(b=>b.id===room.baseTreatment))throw new RangeError('invalid base treatment');
    for(const f of room.furniture)for(const b of f.occluders || []) {
      if(b.length!==6 || b.slice(0,3).some((v,i)=>v>=b[i+3]) || !f.parts.some(a=>b.slice(0,3).every((v,i)=>v>=a[i] && b[i+3]<=a[i+3])))throw new RangeError(f.id+': occluder outside envelope');
    }
    const routes=routeIssues(room);if(routes.length) throw new RangeError(routes[0].what+': '+routes[0].reason);
    const grid=onGridLines(room);if(grid.length) throw new RangeError(grid[0].window+': sun edge on a tile line');
    const hid=hidden(room);if(hid.length) throw new RangeError(hid[0].what+' hides tile '+hid[0].tile);
    if(sunlit(room)<0.5) throw new RangeError('less than half the board in full sunlight');
    room.bounds=bounds(room);
    if(room.bounds.sx1-room.bounds.sx0+24>720 || room.bounds.sy1-room.bounds.sy0+24>400) throw new RangeError('depot exceeds world layer');
    const C=room.camera;
    for(const key of C.keys) {
      const p=key.focus;
      key.offset=p ? [Math.round(clamp((p[0]-p[1]-C.centre[0])*ratio(C.strength),-C.maxShift,C.maxShift)),
        Math.round(clamp(((p[0]+p[1])/2-p[2]-C.centre[1])*ratio(C.strength),-C.maxShift,C.maxShift))] : [0,0];
    }
    return room;
  }
  // A mote's six seeded parameters live in the existing renderer pool. Its position and visibility
  // are a pure function of the integer loop frame; write into reusable output storage, no allocation.
  function dustAt(pool,offset,frame,out) {
    const t=((frame%2880)+2880)%2880/60, tau=Math.PI*2;
    out[0]=pool[offset]+Math.sin(t/24*tau+pool[offset+3])*4;
    out[1]=pool[offset+1]+Math.cos(t/16*tau+pool[offset+4])*3;
    out[2]=pool[offset+2]+Math.sin(t/48*tau+pool[offset+5]*tau)*5;
    const phase=t/3+pool[offset+5];out[3]=phase-Math.floor(phase)>=.18?1:0;
    return out;
  }
  return {build,hidden,hidesTile,solids,footprintIssues,routeIssues,sunAmt,compileSun,sunlit,onGridLines,bounds,dustAt};
})();
if(typeof module !== 'undefined' && module.exports) module.exports=DEPOT;
