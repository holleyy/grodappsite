// City Hall's immutable layout and projected clearance.16wu tiles; pure Node/Swift data.
const CITYHALL=(function(){
 const node=typeof module!=='undefined'&&module.exports,CFG=node?require('../data/cityhall.json'):CITYHALL_DATA,D=node?require('./19b_depot'):DEPOT;
 const finite=v=>Array.isArray(v)&&v.every(Number.isFinite);
 // Snapshot source-local geometry once. Anchored drawings consume XY; fixed drawings
 // retain their native coordinates. Neither may silently keep stale declarations.
 const anchored=new Set(['palm','sorting-table','supervisor-desk','bench','trolley']),models=new Map();
 for(const f of CFG.furniture)models.set(f.id,{kind:f.kind,anchor:f.anchor.slice(),parts:f.parts.map(b=>b.slice()),solidParts:f.solidParts?.map(b=>b.slice())});
 function furnitureGeometry(f){
  const m=models.get(f.id)||Array.from(models.values()).find(m=>m.kind===f.kind);
  if(!m)return f.solidParts||f.parts;
  if(f.kind!==m.kind||!finite(f.anchor)||f.anchor.length!==3)throw new RangeError('Invalid furniture anchor '+f.id);
  const moving=anchored.has(f.kind),dx=f.anchor[0]-m.anchor[0],dy=f.anchor[1]-m.anchor[1];
  if(f.anchor[2]!==m.anchor[2]||!moving&&(dx||dy))throw new RangeError('Fixed native furniture anchor '+f.id);
  const translate=list=>list?.map(b=>b.map((v,k)=>v+(k%3===0?dx:k%3===1?dy:0)));
  const parts=translate(m.parts),solids=translate(m.solidParts);
  const matches=(a,b)=>!a&&!b||Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((q,i)=>finite(q)&&q.length===6&&q.every((v,k)=>Math.abs(v-b[i][k])<1e-8));
  if(!matches(f.parts,parts)||!matches(f.solidParts,solids))throw new RangeError('Furniture footprint differs from its anchor '+f.id);
  return solids||parts;
 }

 function volumes(r){
  const a=r.volumes.map(b=>b.concat('architecture')).concat(r.columns.map(b=>b.concat('column')));
  for(const f of r.furniture)for(const b of f.parts)a.push(b.concat(f.id));
  for(const route of r.routes)for(let i=1;i<route.points.length;i++){
   const p=route.points[i-1],q=route.points[i],v=route.radius;
   a.push([Math.min(p[0],q[0])-v,Math.min(p[1],q[1])-v,Math.min(p[2],q[2]),Math.max(p[0],q[0])+v,Math.max(p[1],q[1])+v,Math.max(p[2],q[2])+route.height,route.id]);
  }
  for(const p of r.pipes)for(let i=1;i<p.points.length;i++){
   const a0=p.points[i-1],b=p.points[i],v=p.radius;
   a.push([Math.min(a0[0],b[0])-v,Math.min(a0[1],b[1])-v,Math.min(a0[2],b[2])-v,Math.max(a0[0],b[0])+v,Math.max(a0[1],b[1])+v,Math.max(a0[2],b[2])+v,p.id]);
  }
  if(r.motionEnvelopes)for(const e of r.motionEnvelopes)a.push(e.bounds.concat(e.id));
  return a;
 }
 function hidden(r,extra){const out=[];for(const b of volumes(r).concat(extra||[])){if(b[5]<=0)continue;const tile=D.hidesTile(r.board,b);if(tile)out.push({what:b[6],tile});}return out;}
 // Visibility bounds include empty space; traffic uses the native solids instead.
 function staffObstacles(r){
  const out=[];
  for(const f of r.furniture){
   const parts=furnitureGeometry(f);
   for(const b of parts)out.push({id:f.id,bounds:b});
  }
  for(let i=0;i<r.columns.length;i++)out.push({id:'column-'+i,bounds:r.columns[i]});
  const z=r.gallery.z,w=r.gallery.width;
  out.push({id:'back gallery deck',bounds:[0,0,z-2,r.room.w,w,z]},{id:'left gallery deck',bounds:[0,0,z-2,w,r.room.d,z]},
   {id:'back gallery rail',bounds:[0,w-1,z-1,r.room.w,w+1,z+15]},{id:'left gallery rail',bounds:[w-1,0,z-1,w+1,r.room.d,z+15]});
  for(let i=0;i<r.windows.length;i++){
   const a=r.windows[i],back=a.wall==='Y';
   out.push({id:'window-'+i,bounds:back?[a.u0,8.9,a.z0,a.u1,9.1,a.z1]:[8.9,a.u0,a.z0,9.1,a.u1,a.z1]},
    {id:'window sill-'+i,bounds:back?[a.u0-1,1,a.z0-2,a.u1+1,10,a.z0]:[1,a.u0-1,a.z0-2,10,a.u1+1,a.z0]});
  }
  for(const p of r.pipes)for(let k=1;k<p.points.length;k++){
   const a=p.points[k-1],b=p.points[k],v=p.radius+.6;
   out.push({id:p.id,bounds:[Math.min(a[0],b[0])-v,Math.min(a[1],b[1])-v,Math.min(a[2],b[2])-v,Math.max(a[0],b[0])+v,Math.max(a[1],b[1])+v,Math.max(a[2],b[2])+v]});
  }
  for(const x of[110,140])out.push({id:'station hood-'+x,bounds:[x-4.2,27.8,27.8,x+4.2,42.2,39.2]});
  out.push({id:'left station hood',bounds:[21.8,27.8,29.8,30.2,42.2,40.2]});
  for(const t of[45,91,202])out.push({id:'back wall lamp-'+t,bounds:[t-2.5,10.5,68.5,t+2.5,17.5,78.5]});
  for(const t of[48,151])out.push({id:'left wall lamp-'+t,bounds:[10.5,t-2.5,68.5,17.5,t+2.5,78.5]});
  for(const b of r.volumes)if(b[2]>=90)out.push({id:'roof',bounds:b});
  out.push({id:'back wall',bounds:[-4,-4,0,r.room.w,0,112]},{id:'left wall',bounds:[-4,0,0,0,r.room.d,112]});
  return out;
 }
 // Accepted towards artwork looks left; rear artwork looks right.
 const staffMirror=face=>face===1||face===2;
 // Native blit mirrors about half a screen pixel; margin includes anchor rounding.
 function staffSpan(body,action,face){
  const a=body.spans[action][face===2||face===3?'away':'towards'],mirror=staffMirror(face);
  return [ (mirror?.5-a[1]:a[0])-body.margin,(mirror?.5-a[0]:a[1])+body.margin ];
 }
 // Load-time and verification queries only; the frame loop never allocates these bounds.
 function staffBounds(r,a){const u=staffSpan(r.staff,a.action,a.face);return [a.x+u[0],a.y-u[1],a.z-r.staff.sole,a.x+u[1],a.y-u[0],a.z+r.staff.height];}
 function staffSegmentHits(p,q,action,face,body,b){
  if(Math.max(p[2],q[2])+body.height<=b[2]||Math.min(p[2],q[2])-body.sole>=b[5])return false;
  const u=staffSpan(body,action,face);let lo=0,hi=1;
  for(let k=0;k<2;k++){
   const d=q[k]-p[k],min=b[k]-(k?-u[0]:u[1]),max=b[k+3]-(k?-u[1]:u[0]);
   if(!d){if(p[k]<=min||p[k]>=max)return false;}
   else{const a=(min-p[k])/d,c=(max-p[k])/d;lo=Math.max(lo,Math.min(a,c));hi=Math.min(hi,Math.max(a,c));if(lo>=hi)return false;}
  }
  return lo<hi;
 }
 function staffRouteIssues(r){
  const body=r.staff,obstacles=staffObstacles(r),out=[];
  if(!body||!Number.isFinite(body.height)||body.height<=0||!Number.isFinite(body.sole)||body.sole<0||!Number.isFinite(body.margin)||body.margin<0||['walk','read','check','sort','wave'].some(k=>['towards','away'].some(v=>!finite(body.spans?.[k]?.[v])||body.spans[k][v].length!==2||body.spans[k][v][0]>=body.spans[k][v][1])))throw new RangeError('Invalid staff clearance profile');
  for(const o of obstacles){const b=o.bounds;if(!finite(b)||b.length!==6||b[0]>=b[3]||b[1]>=b[4]||b[2]>=b[5])throw new RangeError('Invalid staff solid '+o.id);}
  if(!Array.isArray(r.routes)||r.routes.length<3)throw new RangeError('Missing staff routes');
  for(let i=0;i<3;i++){
   const route=r.routes[i],points=route.points,faces=i===0?[3,1,1,2,0]:i===1?[1,2]:[3,0];
   if(route.id!==['sorter','worker-back','worker-left'][i]||points.length!==faces.length+1||points.some(p=>p[2]!==points[0][2])||points[0].some((n,k)=>n!==points[points.length-1][k]))throw new RangeError('Invalid closed staff route');
   for(const o of obstacles)for(let k=1;k<points.length;k++)if(staffSegmentHits(points[k-1],points[k],'walk',faces[k-1],body,o.bounds))out.push({kind:'route',who:route.id,obstacle:o.id,segment:k-1});
  }
  const life=create(r),seen=new Set();
  for(let f=0;f<2880;f++){
   step(life,f);
   for(let i=0;i<3;i++){
    const a=life.workers[i];if(a.action==='walk')continue;
    const key=i+':'+a.x+':'+a.y+':'+a.action+':'+a.face;if(seen.has(key))continue;seen.add(key);
    const b=staffBounds(r,a);
    for(const o of obstacles)if(b[0]<o.bounds[3]&&b[3]>o.bounds[0]&&b[1]<o.bounds[4]&&b[4]>o.bounds[1]&&b[2]<o.bounds[5]&&b[5]>o.bounds[2])out.push({kind:'stationary',who:r.routes[i].id,obstacle:o.id,frame:f});
   }
  }
  for(const f of r.furniture)if(f.kind==='trolley'){
   const a=f.anchor,b=[a[0]-9,a[1]-11,0,a[0]+9,a[1]+11,27];
   if(f.parts.length!==1||b.some((v,k)=>v!==f.parts[0][k]))throw new RangeError('Trolley footprint differs from its anchor');
   for(const o of obstacles)if(o.id!==f.id&&b[0]<o.bounds[3]&&b[3]>o.bounds[0]&&b[1]<o.bounds[4]&&b[4]>o.bounds[1]&&b[2]<o.bounds[5]&&b[5]>o.bounds[2])out.push({kind:'parking',who:f.id,obstacle:o.id});
  }
  return out;
 }
 function build(data){
  const r=JSON.parse(JSON.stringify(data||CFG));
  if(r.board?.w!==8||r.board?.h!==6||r.board.x!==64||r.board.y!==64||!Number.isInteger(r.room?.w)||!Number.isInteger(r.room?.d)||r.room.w<216||r.room.d<184)throw new RangeError('City Hall requires its full8x6 sorting floor and margins');
  for(const route of r.routes){if(!Number.isFinite(route.radius)||route.radius<=0||!Number.isFinite(route.height)||route.height<=0||route.points.length<2||route.points.some(p=>!finite(p)||p.length!==3))throw new RangeError('Invalid City Hall route');}
  const b={sx0:Infinity,sy0:Infinity,sx1:-Infinity,sy1:-Infinity};
  for(const q of volumes(r)){
   if(!finite(q.slice(0,6))||q[0]>=q[3]||q[1]>=q[4]||q[2]>=q[5])throw new RangeError('Invalid City Hall volume '+q[6]);
   for(const x of[q[0],q[3]])for(const y of[q[1],q[4]])for(const z of[q[2],q[5]]){b.sx0=Math.min(b.sx0,x-y);b.sx1=Math.max(b.sx1,x-y);b.sy0=Math.min(b.sy0,(x+y)/2-z);b.sy1=Math.max(b.sy1,(x+y)/2-z);}
  }
  for(const k of['sx0','sy0'])b[k]=Math.floor(b[k]);for(const k of['sx1','sy1'])b[k]=Math.ceil(b[k]);
  if(b.sx1-b.sx0+24>720||b.sy1-b.sy0+24>400||r.room.w+8>720)throw new RangeError('City Hall exceeds720x400');
  if(hidden(r).length)throw new RangeError('City Hall scenery hides a board tile');
  const traffic=staffRouteIssues(r);if(traffic.length)throw new RangeError('Staff '+traffic[0].kind+': '+traffic[0].who+' intersects '+traffic[0].obstacle);
  r.bounds=b;return r;
 }
 const mod=f=>((Math.floor(f)%2880)+2880)%2880;
 function actor(x,y,z){return {x,y,z,face:0,action:'read',frame:0};}
 function create(r){return step({room:r,frame:0,clock:0,lightX:0,lightY:0,workers:r.routes.slice(0,3).map(p=>actor(...p.points[0])),
  pm:{x:26,y:120,z:26,state:3,frame:0,face:0,head:0,flick:0,bat:-1},pigeon:{x:8,y:40,z:111,state:'perch',frame:0,bob:0,face:1},
  capsules:[{x:66,y:24,z:35,visible:false},{x:24,y:32,z:36,vertical:true,visible:false}],
  puffs:[{x:26,y:38,z:31,visible:false,pose:0},{x:110,y:38,z:28,visible:false,pose:0},{x:140,y:38,z:28,visible:false,pose:0}],pressure:new Uint8Array(3)},0);}
 // Cosine ramps keep cruise pace even and bring both feet to a stop before turns.
 function move(a,f,from,to,p,q,face){
  const t=f-from,duration=to-from,r=24,left=duration-t;
  const travel=t<r?(t-r/Math.PI*Math.sin(Math.PI*t/r))*.5:left<r?duration-r-(left-r/Math.PI*Math.sin(Math.PI*left/r))*.5:t-r*.5;
  const u=travel/(duration-r),dx=q[0]-p[0],dy=q[1]-p[1],cycles=Math.max(1,Math.round(Math.hypot(dx,dy)/16));
  a.x=p[0]+dx*u;a.y=p[1]+dy*u;a.z=p[2]+(q[2]-p[2])*u;a.face=face;a.action='walk';a.frame=Math.floor(u*cycles*4+.5)%4;
 }
 function stand(a,p,face,action){a.x=p[0];a.y=p[1];a.z=p[2];a.face=face;a.action=action;a.frame=0;}
 function step(s,frame){
  const f=mod(frame),a=s.workers[0],path=s.room.routes[0].points,p0=path[0],p1=path[1],p2=path[2],p3=path[3];
  s.frame=f;s.clock=Math.floor(f/240)%12;s.lightX=Math.sin(f/2880*Math.PI*2)*3;s.lightY=Math.cos(f/2880*Math.PI*2)*2;
  stand(a,p0,f<156||f>=2796?0:3,'check');
  if(f>=180&&f<516)move(a,f,180,516,p0,p1,3);
  else if(f>=516&&f<552)stand(a,p1,f<534?3:1,'check');
  else if(f>=552&&f<876)move(a,f,552,876,p1,p2,1);
  else if(f>=876&&f<1296)stand(a,p2,f<894||f>=1278?1:3,'sort');
  else if(f>=1296&&f<1452)move(a,f,1296,1452,p2,p3,1);
  else if(f>=1452&&f<1728)stand(a,p3,f<1470?1:3,'check');
  else if(f>=1728&&f<1908)stand(a,p3,0,'wave');
  else if(f>=1908&&f<1944)stand(a,p3,f<1926?0:2,'check');
  else if(f>=1944&&f<2400)move(a,f,1944,2400,p3,path[4],2);
  else if(f>=2400&&f<2436)stand(a,path[4],f<2418?2:0,'check');
  else if(f>=2436&&f<2796)move(a,f,2436,2796,path[4],path[5],0);
  for(let i=1;i<3;i++){
   const p=s.workers[i],t=(f+(i-1)*480)%1440,back=i===1,route=s.room.routes[i].points,outEnd=back?600:720,inStart=back?1080:960;
   const turning=t<18||t>=222;stand(p,route[0],t<18?(back?2:0):t>=222?(back?1:3):(back?0:1),turning?'check':'read');
   if(t>=240&&t<outEnd)move(p,t,240,outEnd,route[0],route[1],back?1:3);
   else if(t>=outEnd&&t<inStart){const turn=t<outEnd+18||t>=inStart-18;stand(p,route[1],t<outEnd+18?(back?1:3):t>=inStart-18?(back?2:0):(back?0:1),turn?'check':'read');}
   else if(t>=inStart)move(p,t,inStart,1440,route[1],route[2],back?2:0);
  }
  for(let i=0;i<3;i++){s.pressure[i]=Math.round(1+Math.sin(f/480*Math.PI*2+i));const p=s.puffs[i],age=(f+i*60)%360;p.visible=age>=6&&age<36;p.pose=Math.min(3,Math.floor(age/9));}
  const p=s.pm;p.frame=Math.floor(f/240)%6;p.head=Math.floor(p.frame/2);p.flick=p.frame&1;
  const age=(f+48)%480;p.bat=age<24?0:age<64?1:age<81?2:age<108?3:-1;
  const b=s.pigeon,t=(f%960)/960,v=t<.5?t*2:2-t*2;b.y=40+92*v;b.face=t<.5?0:1;b.state=f%480<60?'peck':'perch';b.frame=Math.floor(f/30)&1;b.bob=b.frame;
  const c=s.capsules[0],d=s.capsules[1],u=(f%480)/480,w=((f+240)%480)/480;c.x=66+144*u;c.visible=c.x>=132&&c.x<=164;d.y=32+134*w;d.visible=d.y>=82&&d.y<=108;
  return s;
 }
 return {CFG,build,hidden,volumes,staffMirror,staffObstacles,staffBounds,staffRouteIssues,create,step};

})();
if(typeof module!=='undefined'&&module.exports)module.exports=CITYHALL;
