// ============================================================================
// 12 BOARD ANIMATION (pure; Node-exported). Turns a cat's run under the rules into
// an animation pose at any moment. A "trace" is one cat's run: when its box sits on
// the hatch (rel), the tick length, and one record per tick after release (start tile
// and heading, end tile and heading, the rules' event, whether it bounced).
// pose(trace, now, out) is a pure function of time with no allocation, so the demo
// (loop time) and the game (seconds since Send) share it. Swift: a struct Trace and
// func pose(_ trace: Trace, at t: Double) -> CatPose.
//
// Timing, 10 fps stepped (F = frames per tick: 5 in the demo, 3 in the game):
//  travel   glide to the next tile (2 wu steps), 1 px bob; on a turntable the head
//           turns one frame before the box
//  bounce   nudge the obstacle, tiny hop with the ears back for 2 frames, turn round
//           (head first), glide back
//  home     box stops at the basket's edge; stretch, hop in, turn once, curl up, nap;
//           the empty box folds flat in 3 frames and slides off towards the conveyor
//  wrong    hop out onto the basket's rim and sit there, puzzled, for good
//  leave    (demo) after the nap: wake, yawn, stretch, hop through the cat flap
// ============================================================================
const BOARDANIM = (function () {
  const A = { HIDDEN: 0, POP: 1, TRAVEL: 2, BOUNCE: 3, STOP: 4, STRETCH: 5, HOP: 6, TURN: 7, CURL: 8, NAP: 9,
    WAKE: 10, LEAVE: 11, PUZZLED: 12, STUCK: 13, IDLE: 14 };
  const EARS_UP = 0, EARS_TWITCH = 1, EARS_BACK = 2;
  const END_RUNNING = 0, END_HOME = 1, END_WRONG = 2, END_STOPPED = 3;
  const EV_RELEASED = 1, EV_MOVED = 2, EV_DELIVERED = 3, EV_WRONG = 4, EV_STUCK = 5, EV_TUNNEL = 6, EV_WAIT = 7;    // the rules' GE_* codes
  const DX = [1, 0, -1, 0], DY = [0, 1, 0, -1];
  const FPS = 10;
  // Seconds after the home tick ends.
  const T_HOP = 0.3, T_TURN = 0.6, T_CURL = 0.9, T_NAP = 1.2, T_FOLD = 0.6, T_FLAT = 0.9, T_GONE = 1.8;
  const WAKE_LEN = 0.9, LEAVE_LEN = 0.6, ENTRY = 4, SLIDE = 12, RIM_OFF = 3;
  const SLIDE_X = -Math.SQRT1_2, SLIDE_Y = Math.SQRT1_2;          // towards the conveyor (front-left of the room)

  function makeTrace(maxTicks) {
    return {
      big: false, rel: 0, tick: 0.5, pop: 0.5, ox: 0, oy: 0, bw: 6, bh: 5, n: 0, end: END_RUNNING,
      napUntil: Infinity, leaveDir: 3, homeDX: 0, homeDY: 0, coat: 1, look: 0, blinkPhase: 0, hatchDir: 0,
      homeKind: 'basket', homeSide: -1, homeFlap: -1,
      hx: 0, hy: 0, max: maxTicks,
      x0: new Int8Array(maxTicks), y0: new Int8Array(maxTicks), d0: new Int8Array(maxTicks),
      x1: new Int8Array(maxTicks), y1: new Int8Array(maxTicks), d1: new Int8Array(maxTicks),
      ev: new Int8Array(maxTicks), bn: new Int8Array(maxTicks),
      tunnel: new Int8Array(maxTicks).fill(-1), entryX: new Int8Array(maxTicks), entryY: new Int8Array(maxTicks), recorded: false,
    };
  }
  function reset(tr) {
    tr.big = false; tr.recorded = false; tr.n = 0; tr.end = END_RUNNING; tr.napUntil = Infinity; tr.homeDX = 0; tr.homeDY = 0;
    tr.homeKind = 'basket'; tr.homeSide = -1; tr.homeFlap = -1;
  }
  function recordDestination(tr, s, i) {
    if (!tr.recorded) return;
    tr.big = !!s.big[i];
    if (s.ev[i] === EV_TUNNEL) {
      const k = tr.n - 1; tr.tunnel[k] = s.tunnelPair[i]; tr.entryX[k] = s.entryX[i]; tr.entryY[k] = s.entryY[i];
    }
    if (s.homeFlap[i] < 0) return;
    tr.homeKind = 'flap'; tr.homeFlap = s.homeFlap[i];
    const side = s.flaps[tr.homeFlap].side;
    tr.homeSide = side === 'R' ? 0 : side === 'D' ? 1 : side === 'L' ? 2 : 3;
  }
  function record(tr, x0, y0, d0, x1, y1, d1, ev, bounced) {
    tr.recorded = false;
    if (tr.n >= tr.max) return;
    const k = tr.n++; tr.recorded = true; tr.tunnel[k] = -1;
    tr.x0[k] = x0; tr.y0[k] = y0; tr.d0[k] = d0; tr.x1[k] = x1; tr.y1[k] = y1; tr.d1[k] = d1; tr.ev[k] = ev; tr.bn[k] = bounced;
    if (ev === EV_DELIVERED) tr.end = END_HOME; else if (ev === EV_WRONG) tr.end = END_WRONG;
  }
  // Run one cat through the real rules (R = 10_rules) and fill its trace.
  // One cat of coat ('ginger' | 'blue') from the level's first hatch. The caller places the board
  // in the room afterwards (tr.ox, tr.oy: world units of the board's back corner).
  function runRules(R, level, chutes, coat, tick, rel, tr) {
    const h0 = level.hatches[0];
    const one = { board: level.board, dogs: level.dogs, baskets: level.baskets, gates: level.gates, flaps: level.flaps, tunnels: level.tunnels,
      timeLimit: level.timeLimit, hatches: [{ x: h0.x, y: h0.y, dir: h0.dir, cats: [coat] }] };
    const s = R.grCreate(one, chutes);
    reset(tr);
    tr.tick = tick; tr.pop = tick; tr.rel = rel; tr.coat = R.GR_COAT[coat && typeof coat === 'object' ? coat.coat : coat]; tr.big = !!(coat && typeof coat === 'object' && coat.big === true);
    tr.ox = 0; tr.oy = 0; tr.bw = level.board.w; tr.bh = level.board.h;
    tr.hx = h0.x; tr.hy = h0.y; tr.hatchDir = R.GR_DIR[h0.dir];
    R.grTick(s);                                                   // tick 0: the box pops up on the hatch
    while (s.outcome === R.GO_RUNNING && tr.n < tr.max) {
      R.grTick(s);
      record(tr, s.px[0], s.py[0], s.pdir[0], s.x[0], s.y[0], s.dir[0], s.ev[0], s.bounced[0]);
      recordDestination(tr, s, 0);
    }
    if (tr.end === END_RUNNING) tr.end = END_STOPPED;
    return tr;
  }
  // A shared gate trace, recorded in rules move order. Allocate once before Send.
  // The swing begins when the entering cat reaches the tile; same-tick arrivals
  // all retain their rule events, with the last one determining the displayed flap.
  function makeGateTrace(max) {
    return { n: 0, time: new Float64Array(max), gate: new Int16Array(max), cat: new Int16Array(max), from: new Uint8Array(max) };
  }
  function recordGates(tr, s, time) {
    for (let e = 0; e < s.flipCount; e++) {
      const k = tr.n++;
      tr.time[k] = time; tr.gate[k] = s.flipGate[e]; tr.cat[k] = s.flipCat[e]; tr.from[k] = s.flipFrom[e];
    }
  }
  function makeGateOut() { return { state: 0, from: 0, frame: 2 }; }
  function gatePose(tr, gate, now, out) {
    out.state = 0; out.from = 0; out.frame = 2;
    if (tr) for (let k = tr.n - 1; k >= 0; k--) {
      if (tr.gate[k] !== gate || tr.time[k] > now + 1e-9) continue;
      out.from = tr.from[k]; out.state = 1 - out.from;
      out.frame = Math.min(2, Math.floor((now - tr.time[k]) * FPS + 1e-6));
      break;
    }
    return out;
  }
  function makeOut() {
    return { big: false, anim: A.HIDDEN, frame: 0, x: 0, y: 0, z: 0, dir: 0, head: 0, ears: EARS_UP, eyes: 0, bob: 0,
      boxX: 0, boxY: 0, boxFold: -1, boxFade: 0, hatchOpen: 0, spinX: -1, spinY: -1, spin: 0,
      bumpX: -1, bumpY: -1, bumpAge: -1, flapOpen: 0, flapWrong: false, home: 0, tunnelPair: -1, tunnelPhase: -1 };
  }
  const q2 = (v) => Math.round(v * 0.5) * 2;                      // whole 2 wu steps: clean 2:1 pixel moves
  const ss = (t) => { t = t < 0 ? 0 : t > 1 ? 1 : t; return t * t * (3 - 2 * t); };
  const cx = (tr, x) => tr.ox + x * 16 + 8, cy = (tr, y) => tr.oy + y * 16 + 8;
  function flapBounce(dt) {                                       // open, then two decaying swings
    if (dt < 0 || dt > 0.9) return 0;
    return dt < 0.12 ? 1 : dt < 0.22 ? 0.5 : dt < 0.34 ? 0 : dt < 0.44 ? 0.5 : 0;
  }
  // Blink every 4 s and twitch an ear every 6 s (whole frames, so the 48 s demo loop is seamless).
  function face(tr, now, o) {
    const g = Math.floor(now * FPS + 1e-6);
    if(tr.big){const p=((g+tr.blinkPhase)%60+60)%60;o.eyes=p<6?1:p>=30&&p<37?2:0;o.ears=EARS_UP;return;}
    o.eyes = ((g + tr.blinkPhase) % 40 + 40) % 40 === 0 ? 1 : 0;
    o.ears = ((g + tr.blinkPhase * 7 + 20) % 60 + 60) % 60 === 0 ? EARS_TWITCH : EARS_UP;
  }
  function lastBump(tr, k, now, o) {                              // latest bounce into an on-board obstacle
    o.bumpX = -1; o.bumpY = -1; o.bumpAge = -1;
    for (let j = Math.min(k, tr.n - 1); j >= 0; j--) {
      if (!tr.bn[j]) continue;
      const bx = tr.x0[j] + DX[tr.d0[j]], by = tr.y0[j] + DY[tr.d0[j]];
      if (bx < 0 || by < 0 || bx >= tr.bw || by >= tr.bh) return;  // the board's edge: no dog to wake
      const age = now - (tr.rel + j * tr.tick + 0.2 * tr.tick);
      if (age >= 0) { o.bumpX = bx; o.bumpY = by; o.bumpAge = age; }
      return;
    }
  }
  function pose(tr, now, o) {
    o.big = !!tr.big; o.tunnelPair = -1; o.tunnelPhase = -1;
    o.frame = 0; o.z = 0; o.bob = 0; o.boxFold = -1; o.boxFade = 0; o.hatchOpen = 0;
    o.spinX = -1; o.spinY = -1; o.spin = 0; o.flapOpen = 0; o.flapWrong = false; o.home = 0; o.ears = EARS_UP; o.eyes = 0;
    o.bumpX = -1; o.bumpY = -1; o.bumpAge = -1;
    const F = Math.max(1, Math.round(tr.tick * FPS));
    if (now < tr.rel - tr.pop) { o.anim = A.HIDDEN; return o; }
    if (now < tr.rel) {                                           // pops up through the hatch
      const f = (now - (tr.rel - tr.pop)) / tr.pop;
      o.anim = A.POP; o.frame = Math.min(F - 1, Math.floor(f * F));
      o.x = q2(cx(tr, tr.hx)); o.y = q2(cy(tr, tr.hy)); o.dir = o.head = tr.hatchDir;
      const rise=tr.big?32:8;o.z = -rise + Math.round(ss((f - 0.15) / 0.6) * rise);
      o.hatchOpen = f < 0.12 ? 1 : f < 0.8 ? 2 : f < 0.9 ? 1 : 0;
      face(tr, now, o);
      return o;
    }
    const k = Math.floor((now - tr.rel) / tr.tick);
    if (k < tr.n) { move(tr, k, (now - tr.rel - k * tr.tick) / tr.tick, F, now, o); lastBump(tr, k, now, o); return o; }
    if (tr.n === 0) { o.anim = A.IDLE; o.x = q2(cx(tr, tr.hx)); o.y = q2(cy(tr, tr.hy)); o.dir = o.head = tr.hatchDir; face(tr, now, o); return o; }
    lastBump(tr, tr.n - 1, now, o);
    const j = tr.n - 1, T = now - (tr.rel + tr.n * tr.tick);
    const hx = cx(tr, tr.x1[j]), hy = cy(tr, tr.y1[j]), dIn = tr.d0[j];
    if (tr.homeKind === 'flap') return flapHome(tr, T, now, hx, hy, o);
    const ex = hx - DX[dIn] * ENTRY, ey = hy - DY[dIn] * ENTRY;   // where the box stopped
    if (tr.end === END_HOME) return home(tr, T, now, hx + tr.homeDX, hy + tr.homeDY, ex, ey, dIn, o);
    if (tr.end === END_WRONG) return wrong(tr, T, now, hx, hy, ex, ey, dIn, o);
    o.anim = A.IDLE; o.x = q2(hx); o.y = q2(hy); o.dir = o.head = tr.d1[j]; face(tr, now, o);
    return o;
  }
  function move(tr, k, f, F, now, o) {
    const fr = Math.min(F - 1, Math.floor(f * F));
    const x0 = cx(tr, tr.x0[k]), y0 = cy(tr, tr.y0[k]), d0 = tr.d0[k], d1 = tr.d1[k], ev = tr.ev[k];
    let x1 = cx(tr, tr.x1[k]), y1 = cy(tr, tr.y1[k]);
    o.frame = fr; o.dir = o.head = d0;
    face(tr, now, o);
    if (ev === EV_WAIT) {
      o.anim = A.IDLE; o.x = q2(x0); o.y = q2(y0); return;
    }
    if (ev === EV_TUNNEL) {
      const ex = cx(tr, tr.entryX[k]), ey = cy(tr, tr.entryY[k]);
      o.tunnelPair = tr.tunnel[k]; o.tunnelPhase = f < .45 ? 0 : f < .65 ? 1 : 2;
      o.anim = o.tunnelPhase === 1 ? A.HIDDEN : A.TRAVEL;
      o.dir = o.head = tr.bn[k] && f < .15 ? d0 : d1;
      const drop=tr.big?32:24;
      if (o.tunnelPhase === 2) {
        o.x = x1; o.y = y1; o.z = -drop + Math.round(ss((f - .65) / .27) * drop);
      } else {
        let ax = x0, ay = y0, t = f / .25;
        if (tr.bn[k]) {
          const nudge = ss(f / .15) * 3;
          ax += DX[d0] * nudge; ay += DY[d0] * nudge; t = (f - .15) / .1;
        }
        o.x = q2(ax + (ex - ax) * ss(t)); o.y = q2(ay + (ey - ay) * ss(t));
        o.z = 0 - Math.round(ss((f - .25) / .2) * drop);
      }
      return;
    }
    if (tr.homeKind === 'flap' && k === tr.n - 1) {
      const d = tr.homeSide, p = ss(f);
      o.x = q2(x0 + DX[d] * 3 * p); o.y = q2(y0 + DY[d] * 3 * p);
      o.dir = o.head = tr.bn[k] && f < .5 ? d0 : d;
      o.anim = A.TRAVEL;
      return;
    }
    if (ev === EV_STUCK) {                                        // boxed in: jiggle, look both ways
      o.anim = A.STUCK; o.x = q2(x0) + ((Math.floor(now * FPS) & 1) ? 2 : 0); o.y = q2(y0);
      o.head = (Math.floor(now * FPS / 2) & 1) ? d0 : (d0 + 2) & 3;
      return;
    }
    if (tr.bn[k]) {                                               // bounce: bump, hop, turn round, glide back
      const back = (d0 + 2) & 3, b0 = F >= 4 ? 1 : 0;              // first ears-back frame
      const fTurn = Math.min(0.99, (b0 + 3) / F);                   // body turns round on this fraction
      o.anim = A.BOUNCE;
      if (fr === b0 || fr === b0 + 1) { o.ears = EARS_BACK; o.z = fr === b0 ? 2 : 1; }
      if (fr >= b0 + 2) o.head = back;
      if (fr >= b0 + 3 || (F < 4 && fr >= b0 + 2)) o.dir = back;
      if (fr === F - 1 && d1 !== back) o.head = d1;                 // a turntable on the way back: head first again
      const nx = x0 + DX[d0] * 3 * ss(f / 0.2), ny = y0 + DY[d0] * 3 * ss(f / 0.2);
      const g = F < 4 ? (f - 2 / F) * F : (f - fTurn) / (1 - fTurn);
      o.x = q2(g > 0 ? nx + (x1 - nx) * ss(g) : nx); o.y = q2(g > 0 ? ny + (y1 - ny) * ss(g) : ny);
      return;
    }
    const turned = d1 !== d0 && ev === EV_MOVED, arrive = ev === EV_MOVED ? (turned ? 0.6 : 0.8) : 0.6;
    if (ev !== EV_MOVED) { x1 -= DX[d0] * ENTRY; y1 -= DY[d0] * ENTRY; }   // home or wrong: stop at the basket's edge
    const m = ss(f / arrive);
    o.x = q2(x0 + (x1 - x0) * m); o.y = q2(y0 + (y1 - y0) * m);
    o.anim = ev !== EV_MOVED && f >= arrive ? A.STOP : A.TRAVEL;
    if (f < arrive) o.bob = Math.floor(now * FPS / 2) & 1;
    if (turned) {
      const hf = Math.floor(0.6 * F);
      if (fr >= hf) { o.head = d1; o.spinX = tr.x1[k]; o.spinY = tr.y1[k]; o.spin = fr - hf + 1; }
      if (fr >= hf + 1) o.dir = d1;
    }
  }
  // Rule-phase preview only: remain boxed, then hide at the exit. The piece
  // phase supplies the checked push/rim/fold artwork; never borrow basket hops.
  function flapHome(tr, T, now, hx, hy, o) {
    const d = tr.homeSide;
    o.x = q2(hx + DX[d] * 3); o.y = q2(hy + DY[d] * 3); o.dir = o.head = d;
    o.anim = tr.end === END_WRONG || T < .3 ? A.IDLE : A.HIDDEN;
    o.flapWrong = tr.end === END_WRONG;
    o.flapOpen = o.flapWrong ? 0 : flapBounce(T);
    face(tr, now, o); return o;
  }
  function home(tr, T, now, hx, hy, ex, ey, dIn, o) {
    o.home = 1; o.dir = o.head = dIn;
    if (now >= tr.napUntil) {
      const w = now - tr.napUntil;
      o.x = q2(hx); o.y = q2(hy);
      if (w < WAKE_LEN) { o.anim = A.WAKE; o.frame = Math.min(2, Math.floor(w / WAKE_LEN * 3)); o.dir = o.head = tr.leaveDir; return o; }
      const p = (w - WAKE_LEN) / LEAVE_LEN, ld = tr.leaveDir;
      const tFlap = tr.napUntil + WAKE_LEN + LEAVE_LEN * 0.35;           // reaches the flap about a third of the way
      o.flapOpen = now < tFlap ? 0 : flapBounce(now - tFlap);
      if (p >= 1) { o.anim = A.HIDDEN; return o; }
      o.anim = A.LEAVE; o.frame = Math.min(1, Math.floor(p * 2)); o.dir = o.head = ld;
      o.x = q2(hx + DX[ld] * 12 * p); o.y = q2(hy + DY[ld] * 12 * p); o.z = Math.round(Math.sin(Math.min(1, p * 1.5) * Math.PI) * 2);
      return o;
    }
    if (T < T_HOP) { o.anim = A.STRETCH; o.frame = Math.min(2, Math.floor(T / T_HOP * 3)); o.x = q2(ex); o.y = q2(ey); return o; }
    // the box is empty from here: it waits, folds flat in 3 frames, then slides away and fades
    o.boxFold = T < T_FOLD ? 0 : T < T_FLAT ? 1 + Math.floor((T - T_FOLD) * FPS + 1e-6) : T < T_GONE ? 4 : -1;
    const sl = ss((T - T_FLAT) / (T_GONE - T_FLAT));
    o.boxX = q2(ex + SLIDE_X * SLIDE * sl); o.boxY = q2(ey + SLIDE_Y * SLIDE * sl); o.boxFade = T < T_FLAT ? 0 : (T - T_FLAT) / (T_GONE - T_FLAT);
    if (T < T_TURN) {
      const p = (T - T_HOP) / (T_TURN - T_HOP);
      o.anim = A.HOP; o.frame = Math.min(2, Math.floor(p * 3));
      o.x = q2(ex + (hx - ex) * p); o.y = q2(ey + (hy - ey) * p); o.z = Math.round(Math.sin(p * Math.PI) * 3);
      return o;
    }
    o.x = q2(hx); o.y = q2(hy);
    if (T < T_CURL) { o.anim = A.TURN; o.frame = Math.min(2, Math.floor((T - T_TURN) / (T_CURL - T_TURN) * 3)); o.dir = o.head = (dIn + 1 + o.frame) & 3; return o; }
    if (T < T_NAP) { o.anim = A.CURL; o.frame = Math.min(2, Math.floor((T - T_CURL) / (T_NAP - T_CURL) * 3)); return o; }
    o.anim = A.NAP; o.frame = Math.floor(now / 1.5) & 1;            // slow breathing
    o.ears = ((Math.floor(now * FPS) + tr.blinkPhase * 11) % 80 + 80) % 80 === 0 ? EARS_TWITCH : EARS_UP;
    return o;
  }
  function wrong(tr, T, now, hx, hy, ex, ey, dIn, o) {
    o.dir = o.head = dIn; o.boxX = q2(ex); o.boxY = q2(ey); o.boxFold = T < 0 ? -1 : 0;
    const rx = hx + RIM_OFF, ry = hy + RIM_OFF;                   // the basket's near rim
    if (T < T_HOP) { o.anim = A.STRETCH; o.boxFold = -1; o.x = q2(ex); o.y = q2(ey); o.frame = Math.min(2, Math.floor(T / T_HOP * 3)); return o; }
    if (T < T_TURN) {
      const p = (T - T_HOP) / (T_TURN - T_HOP);
      o.anim = A.HOP; o.frame = Math.min(2, Math.floor(p * 3));
      o.x = q2(ex + (rx - ex) * p); o.y = q2(ey + (ry - ey) * p); o.z = Math.round(Math.sin(p * Math.PI) * 3 + p * 5);
      return o;
    }
    o.anim = A.PUZZLED; o.x = q2(rx); o.y = q2(ry); o.z = 5; o.dir = o.head = 1;   // sits up facing the room
    const c = Math.floor(now * 2.5) % 6;                           // slow tail flick: 3 frames then a rest
    o.frame = c < 3 ? c : 0;
    return o;
  }
  return { A, EARS_UP, EARS_TWITCH, EARS_BACK, END_RUNNING, END_HOME, END_WRONG, END_STOPPED,
    EV_RELEASED, EV_MOVED, EV_DELIVERED, EV_WRONG, EV_STUCK, EV_TUNNEL, FPS, T_NAP, WAKE_LEN, LEAVE_LEN,
    makeTrace, reset, record, recordDestination, runRules, makeOut, pose, makeGateTrace, recordGates, makeGateOut, gatePose };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = BOARDANIM;
