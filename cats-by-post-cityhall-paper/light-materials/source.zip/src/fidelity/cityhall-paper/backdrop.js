/* One horizon and one constructed square. Windows reveal this exact scene;
   no per-window panorama offsets or second perspective are introduced. */
(function(root){
 'use strict';
 function draw(p){
  // The panorama's quiet ground fades into the same paving beneath it.
  CityHallDaylight.paving(p);
  const c=p.c,im=p.images['daylight-skyline'],W=1000,H=W*im.height/im.width,x=-500,y=-70-H;
  c.drawImage(im,0,0,1,im.height,-700,y,200,H);c.drawImage(im,x,y,W,H);c.drawImage(im,im.width-1,0,1,im.height,500,y,200,H);
  CityHallEnvironment.draw(p);
 }
 root.CityHallBackdrop={draw};
})(globalThis);
