function level(extra={}){return {id:'tunnel-study',title:'A linked pair',room:'train',board:{w:9,h:4,roomX:0,roomY:0},timeLimit:24,hatches:[{x:0,y:1,dir:'R',cats:['ginger']}],baskets:[{x:7,y:2,coat:'ginger'}],dogs:[],gates:[],flaps:[],tunnels:[{a:{x:2,y:1},b:{x:6,y:2},symbol:'circle'}],tray:{plain:1,ginger:0,blue:0},solution:[],...extra};}
module.exports={level};
