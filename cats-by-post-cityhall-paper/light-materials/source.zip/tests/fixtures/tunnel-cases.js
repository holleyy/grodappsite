// Shared rules-study/golden inputs, independent of the later City Hall chapter.
const {level}=require('./tunnels');
const straight=(id,title,dir,coat,a,b,h,basket,symbol)=>({title,hint:'Both ends share a symbol. The cat keeps its heading.',expected:'won',level:level({id,title,hatches:[{...h,dir,cats:[coat]}],baskets:[{...basket,coat}],tunnels:[{a,b,symbol}],tray:{plain:0,ginger:0,blue:0},solution:[]})});
module.exports=[
 {title:'A linked route',hint:'Place one plain turntable after the exit and turn it down. Hint can show the spot.',expected:'won',level:level({id:'tunnel-puzzle',baskets:[{x:7,y:3,coat:'ginger'}],solution:[{x:7,y:2,type:'plain',dir:'D'}],minTurntables:1})},
 straight('tunnel-right','Ginger · right','R','ginger',{x:2,y:1},{x:6,y:2},{x:0,y:1},{x:7,y:2},'circle'),
 straight('tunnel-down','Blue · down','D','blue',{x:2,y:2},{x:6,y:2},{x:2,y:0},{x:6,y:3},'square'),
 straight('tunnel-left','Blue · left','L','blue',{x:2,y:2},{x:6,y:1},{x:8,y:1},{x:1,y:2},'triangle'),
 straight('tunnel-up','Ginger · up','U','ginger',{x:2,y:1},{x:6,y:1},{x:2,y:3},{x:6,y:0},'diamond'),
 {title:'Opposite users together',hint:'A stress study with no destinations: both cats exchange ends on the same tick, then keep moving.',expected:'timeUp',level:level({id:'tunnel-opposite',hatches:[{x:0,y:2,dir:'R',cats:['ginger']},{x:8,y:2,dir:'L',cats:['blue']}],baskets:[],tunnels:[{a:{x:2,y:2},b:{x:6,y:2},symbol:'square'}],timeLimit:12})},
 {title:'A blocked exit',hint:'A stress study with no destination: the exit wall and dog stop the cat. Standing there never sends it back.',expected:'timeUp',level:level({id:'tunnel-stuck',tunnels:[{a:{x:2,y:1},b:{x:8,y:2},symbol:'triangle'}],dogs:[{x:7,y:2}],baskets:[],timeLimit:12})},
 {title:'Two links in sequence',hint:'Each genuine entry uses one pair. No extra movement happens on the exit tick.',expected:'won',level:level({id:'tunnel-sequential',board:{w:10,h:4,roomX:0,roomY:0},tunnels:[{a:{x:2,y:1},b:{x:5,y:1},symbol:'circle'},{a:{x:6,y:1},b:{x:7,y:3},symbol:'diamond'}],baskets:[{x:8,y:3,coat:'ginger'}]})},
 {title:'Bounce into a link',hint:'The dog reverses the cat into the entrance. It emerges facing left, once.',expected:'won',level:level({id:'tunnel-bounce',hatches:[{x:3,y:0,dir:'D',cats:['ginger']}],dogs:[{x:4,y:2}],tunnels:[{a:{x:2,y:2},b:{x:6,y:2},symbol:'triangle'}],baskets:[{x:5,y:2,coat:'ginger'}],solution:[{x:3,y:2,type:'plain',dir:'R'}]})}
];
