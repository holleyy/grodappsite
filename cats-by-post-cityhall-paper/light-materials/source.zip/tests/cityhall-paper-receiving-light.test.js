const test=require('node:test'),assert=require('node:assert/strict');
const D=require('../src/fidelity/cityhall-paper/daylight'),L=require('../src/fidelity/cityhall-paper/layout').create();
function contains(poly,p){let sign=0;for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],v=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);if(Math.abs(v)<1e-8)continue;const s=Math.sign(v);if(sign&&s!==sign)return false;sign=s;}return true;}
test('cast shadows contain the contact footprint and projected top on the receiving plane',()=>{
 assert.equal(typeof D.shadowFootprint,'function');
 for(const [b,top,z]of [[{x0:0,y0:23,x1:23,y1:192},46,.7],[{x0:26,y0:172,x1:54,y1:186},16,.7],[{x0:-20,y0:0,x1:10,y1:14},14,-12]]){
  const poly=D.shadowFootprint(b,top,z);assert.ok(poly.length>=4&&poly.length<=6);
  for(const p of poly)assert.equal(p[2],z);
  for(const x of [b.x0,b.x1])for(const y of [b.y0,b.y1]){assert.ok(contains(poly,[x,y,z]));assert.ok(contains(poly,D.shadowPoint([x,y,top],z)));}
  const low=D.shadowFootprint(b,z,z);assert.equal(low.length,4);assert.ok(low.every(p=>p[0]>=b.x0&&p[0]<=b.x1&&p[1]>=b.y0&&p[1]<=b.y1));
 }
});
test('stair shadows use the actual tread heights and remain deterministic without moving the treads',()=>{
 assert.equal(typeof D.floorCasters,'function');const before=JSON.stringify(L),a=D.floorCasters(L),b=D.floorCasters(L);assert.deepEqual(a,b);
 for(const step of L.stairs.steps){assert.ok(a.some(c=>c.top===step.z1&&c.b.x0===step.x0&&c.b.x1===step.x1&&c.b.y0===step.y0&&c.b.y1===step.y1));}
 assert.equal(JSON.stringify(L),before);
});
