const test=require('node:test'),assert=require('node:assert/strict');
const V=require('../src/fidelity/cityhall-paper/vault-and-walls'),L=require('../src/fidelity/cityhall-paper/layout').create();
const P=require('../src/fidelity/cityhall-paper/projection'),C=require('../src/fidelity/cityhall-paper/clock-bay');
const overlap=(a,b)=>['x','y','z'].every(k=>a[k+'0']<b[k+'1']&&a[k+'1']>b[k+'0']);
const bounds=pts=>Object.fromEntries(['x','y','z'].flatMap((k,i)=>[[k+'0',Math.min(...pts.map(p=>p[i]))],[k+'1',Math.max(...pts.map(p=>p[i]))]]));
function capture(draw){
 const boxes=[],faces=[],lines=[],old=[global.CityHallClockBay,global.CityHallProjection,global.CityHallDaylight];
 const c=new Proxy({},{get:()=>()=>{}}),p={c,images:{crest:{}},line:(a,b)=>lines.push([a,b]),face:pts=>faces.push({pts,...bounds(pts)}),ellipse:()=>{}};
 global.CityHallProjection=P;global.CityHallDaylight={wall:()=>{},glass:()=>{}};
 global.CityHallClockBay={paperBox:(p,x,y,z,w,d,h,kind)=>boxes.push({x0:x,y0:y,z0:z,x1:x+w,y1:y+d,z1:z+h,kind}),paperFace:(p,pts,kind)=>faces.push({pts,kind,...bounds(pts)}),rearImage:()=>{}};
 try{draw(p);}finally{[global.CityHallClockBay,global.CityHallProjection,global.CityHallDaylight]=old;}
 return {boxes,faces,lines};
}
const contains=(b,p)=>['x','y','z'].every((k,i)=>p[i]>=b[k+'0']&&p[i]<=b[k+'1']);
const segment=(a,b,r)=>{const v=bounds([a,b]);for(const k of ['x','y','z']){v[k+'0']-=r;v[k+'1']+=r;}return v;};

test('iron piers have a continuous stone-to-shaft load path at every original anchor',()=>{
 for(const col of L.columns){
  const {boxes}=capture(p=>V.column(p,col)),centre=[(col.x0+col.x1)/2,(col.y0+col.y1)/2];
  for(let z=0;z<=138;z+=.25)assert.ok(boxes.some(b=>contains(b,[...centre,z])),col.id+' unsupported at '+z);
  const stone=boxes.filter(b=>b.kind==='stone'&&b.z1<=15),shaft=boxes.find(b=>b.kind==='green'&&b.z0===17&&b.z1===124);
  assert.ok(stone.some(b=>b.z1-b.z0>=10),'masonry pedestal has substantial height');
  assert.deepEqual([shaft.x0,shaft.y0,shaft.x1,shaft.y1],[col.x0,col.y0,col.x1,col.y1]);
  assert.ok(stone.some(b=>b.x0<shaft.x0&&b.x1>shaft.x1&&b.y0<shaft.y0&&b.y1>shaft.y1),'plinth receives the whole shaft');
 }
});

test('both walls have stepped arch faces and solid deep returns behind the brass chase',()=>{
 for(const axis of ['left','rear']){
  const {faces,boxes}=capture(p=>V.windows(p,axis,64,[[14,48]])),depth=axis==='left'?'x':'y';
  for(const d of [4.5,7.5])assert.ok(faces.filter(f=>f.kind==='stone'&&f[depth+'0']===d&&f[depth+'1']===d).length>=14,'each archivolt has its own front plane');
  assert.ok(faces.some(f=>f.kind==='stone'&&f[depth+'0']===0&&f[depth+'1']===7.5),'arch has a full soffit return');
  assert.ok(boxes.some(b=>b[depth+'1']===7.5&&b.z1-b.z0>40),'jamb has the same deep return');
  for(const solid of [...boxes,...faces.filter(f=>f.kind)])assert.ok(solid[depth+'1']<8.4,'stone stays behind the service pipe');
 }
 const authored=capture(p=>V.windows(p,'rear',224,[[176,211]]));
 assert.equal(authored.boxes.length,0,'authored clock-bay reveal is not duplicated');
});

test('solid roof ribs meet bearing shoes and a continuous beam spanning the receiving piers',()=>{
 const {boxes,faces}=capture(p=>V.roof(p,L));
 assert.equal(L.vault.spring,138);assert.equal(L.vault.crown,180);
 for(const rib of L.vault.ribs){
  assert.equal(Math.max(...rib.map(p=>p[2])),180);
  for(const a of [rib[0],rib.at(-1)]){
   assert.equal(a[2],138);
   const shoe=boxes.find(b=>b.kind==='green'&&b.z0===135.7&&contains(b,a));assert.ok(shoe,'rib must enter a physical shoe');
   const plate=boxes.find(b=>b.kind==='gold'&&b.z0===134.5&&b.x0<=shoe.x0&&b.x1>=shoe.x1&&b.y0<=shoe.y0&&b.y1>=shoe.y1);assert.ok(plate,'shoe sits on a bearing plate');
   const beam=boxes.find(b=>b.z1===plate.z0&&b.x0<=plate.x0&&b.x1>=plate.x1&&b.y0<=plate.y0&&b.y1>=plate.y1);assert.ok(beam,'bearing plate sits on the continuous beam');
   assert.ok(L.columns.filter(c=>overlap(beam,c)).length>=2,'beam transfers load to two original piers');
  }
  for(let i=0;i<rib.length-1;i++)assert.ok(faces.some(f=>f.kind==='stone'&&f.y0===rib[i][1]+2.1&&f.y1===f.y0&&f.x0===rib[i][0]&&f.x1===rib[i+1][0]&&f.z1-f.z0>=6-1e-9),'every rib segment has a solid deep web');
 }
 const ties=boxes.filter(b=>b.kind==='green'&&b.y0===2&&b.y1===57);
 assert.equal(ties.length,6);
 for(const tie of ties){
  assert.ok(tie.x1-tie.x0>=1.5&&tie.z1-tie.z0>=1.5,'ties have a rectangular section');
  for(const rib of L.vault.ribs)assert.ok(boxes.some(b=>b.kind==='gold'&&overlap(b,tie)&&b.y0<rib[0][1]&&b.y1>rib[0][1]),'tie connects at every rib');
 }
});

test('new mass clears the occupied gallery, stair landing and all retained brass pipe segments',()=>{
 const mass=capture(p=>{for(const col of L.columns)V.column(p,col);V.windows(p,'left',192,[[14,48],[69,107],[128,171]]);V.windows(p,'rear',224,[[13,51],[68,105]]);V.roof(p,L);});
 const routes=[{x0:12.75,y0:38,z0:46,x1:18.75,y1:192,z1:82},{x0:12.75,y0:12.75,z0:46,x1:224,y1:18.75,z1:82},{x0:30,y0:22,z0:46,x1:49,y1:36,z1:82}];
 for(const solid of [...mass.boxes,...mass.faces])for(const route of routes)assert.ok(!overlap(solid,route),'structural face enters human corridor: '+JSON.stringify({solid,route}));
 const roof=capture(p=>V.roof(p,L)),networks=[V.layout().pipe,...C.layout().pipes];
 for(const net of networks)for(let i=1;i<net.length;i++)for(const solid of [...roof.boxes,...roof.faces])assert.ok(!overlap(solid,segment(net[i-1],net[i],3.1)),'roof construction intersects brass pipe');
});

test('left and rear cornices meet the finished clock-bay profile without crossing its boundary',()=>{
 const {boxes}=capture(p=>V.gallery(p));
 for(const [z,height,depth]of [[132,2,6],[134,3.5,7.5],[137.5,.8,8.6]]){
  const rear=boxes.find(b=>b.x0===0&&b.x1===116&&b.z0===z),left=boxes.find(b=>b.y0===0&&b.y1===192&&b.z0===z);
  assert.ok(rear&&left);assert.equal(rear.z1,z+height);assert.equal(left.z1,z+height);assert.equal(rear.y1-rear.y0,depth);assert.equal(left.x1-left.x0,depth);
 }
});

test('each complete roof soffit is behind its cream web instead of painting segment teeth over it',()=>{
 const {faces}=capture(p=>V.roof(p,L));
 for(const rib of L.vault.ribs){
  const y=rib[0][1],soffits=[],webs=[],tops=[];
  faces.forEach((f,i)=>{
   if(f.x0===f.x1)return;
   if(f.kind==='green'&&f.y0===y-2.1&&f.y1===y+2.1)soffits.push(i);
   if(f.kind==='stone'&&f.y0===y+2.1&&f.y1===y+2.1)webs.push(i);
   if(f.kind==='stone'&&f.y0===y-2.1&&f.y1===y+2.1)tops.push(i);
  });
  assert.equal(soffits.length,40);assert.equal(webs.length,40);assert.equal(tops.length,40);
  assert.ok(Math.max(...soffits)<Math.min(...webs),'a later soffit must never overpaint the preceding web');
  assert.ok(Math.max(...webs)<Math.min(...tops),'the continuous top edge must cover every web segment');
 }
});
