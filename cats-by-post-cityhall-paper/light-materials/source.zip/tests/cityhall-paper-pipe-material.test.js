const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/fidelity/cityhall-paper/clock-bay'),V=require('../src/fidelity/cityhall-paper/vault-and-walls');
const routes=[V.layout().pipe,...C.layout().pipes,[[77,31,27],[77,31,34],[153,31,34],[153,9,34]]];
function segmentDistance(p,a,b){const v=b.map((x,i)=>x-a[i]),w=p.map((x,i)=>x-a[i]),t=Math.max(0,Math.min(1,w.reduce((n,x,i)=>n+x*v[i],0)/v.reduce((n,x)=>n+x*x,0)));return Math.hypot(...p.map((x,i)=>x-a[i]-v[i]*t));}
test('rolled-paper pipe geometry preserves endpoints and the existing clearance envelope',()=>{
 assert.equal(typeof C.pipeGeometry,'function');
 for(const route of routes){const mesh=C.pipeGeometry(route);assert.deepEqual(mesh.path[0],route[0]);assert.deepEqual(mesh.path.at(-1),route.at(-1));
  for(const solid of mesh.solids)for(const face of solid.faces)for(const p of face.points){assert.ok(p.every(Number.isFinite));const d=Math.min(...route.slice(1).map((b,i)=>segmentDistance(p,route[i],b)));assert.ok(d<=3.100001,'new tube/collar leaves the already-cleared envelope: '+d);}
 }
});
test('tube elbows and raised collars are closed paper solids without missing faces',()=>{
 assert.equal(typeof C.pipeGeometry,'function');
 const key=p=>p.map(v=>Math.round(v*1e8)).join(',');
 for(const route of routes){const mesh=C.pipeGeometry(route);assert.ok(mesh.solids.some(s=>s.kind==='body'));assert.ok(mesh.solids.some(s=>s.kind==='collar'));
  for(const solid of mesh.solids){const edges=new Map();for(const f of solid.faces){assert.ok(f.points.length>=3);for(let i=0;i<f.points.length;i++){const a=key(f.points[i]),b=key(f.points[(i+1)%f.points.length]);assert.notEqual(a,b,'collapsed edge');const e=[a,b].sort().join('|');edges.set(e,(edges.get(e)||0)+1);}}assert.ok([...edges.values()].every(n=>n===2),solid.kind+' has an open or duplicated edge');}
  assert.deepEqual(C.pipeGeometry(route),mesh,'geometry is deterministic');
 }
});
