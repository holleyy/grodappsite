const test=require('node:test'),assert=require('node:assert/strict');
const D=require('../src/fidelity/cityhall-paper/civic-district');
const overlap=(a,b)=>a.x0<b.x1&&a.x1>b.x0&&a.y0<b.y1&&a.y1>b.y0;
test('connected civic frontages share actual party walls and remain subordinate to the vault',()=>{
 const d=D.layout(),L=require('../src/fidelity/cityhall-paper/layout').create();
 for(const row of d.frontages){const b=row.ids.map(id=>d.buildings.find(x=>x.id===id));assert.ok(b.length>=3);for(let i=1;i<b.length;i++){
  if(row.axis==='y'){assert.equal(b[i-1].y1,b[i].y0);assert.equal(b[i-1].x0,b[i].x0);assert.equal(b[i-1].x1,b[i].x1);}
  else{assert.equal(b[i-1].x1,b[i].x0);assert.equal(b[i-1].y0,b[i].y0);assert.equal(b[i-1].y1,b[i].y1);}
 }}
 for(const b of d.buildings){assert.equal(b.z0,-12);assert.ok(b.z1+28<L.vault.spring);assert.ok(!overlap(b,{x0:-4,y0:-4,x1:228,y1:218}));}
});
test('district buildings and front doors have a continuous receiving pavement',()=>{
 const d=D.layout(),S=require('../src/fidelity/cityhall-paper/street-life').layout(),inside=(a,b)=>a.x0<=b.x0&&a.y0<=b.y0&&a.x1>=b.x1&&a.y1>=b.y1;
 for(const b of d.buildings){assert.ok(S.footways.some(a=>inside(a,b)),b.id);const door=D.door(b);assert.ok(S.footways.some(a=>inside(a,door)),b.id+' door approach');}
});
test('larger planted edges frame rather than obstruct the entrance and courier',()=>{
 const d=D.layout(),E=require('../src/fidelity/cityhall-paper/environment').layout(),C=require('../src/fidelity/cityhall-paper/civic-square').layout(),S=require('../src/fidelity/cityhall-paper/street-life').layout();
 assert.equal(C.gardens.length,2);assert.ok(C.gardens.reduce((n,b)=>n+(b.x1-b.x0)*(b.y1-b.y0),0)>18000);
 for(const b of [...C.gardens,...d.trees])for(const r of [E.approach,...E.steps,S.postalBay])assert.ok(!overlap(b,r),b.id+' blocks '+r.id);
 for(const t of d.trees)assert.ok(C.gardens.some(g=>inside(g,t)));
 function inside(a,b){return a.x0<=b.x0&&a.y0<=b.y0&&a.x1>=b.x1&&a.y1>=b.y1;}
 assert.deepEqual(D.layout(),d);
});
