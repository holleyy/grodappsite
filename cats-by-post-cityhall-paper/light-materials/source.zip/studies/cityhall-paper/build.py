"""Self-contained review host. Canonical source is read-only; substitutions are audited."""
from pathlib import Path
import base64, hashlib, json, re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT / 'src/fidelity/cityhall-paper'
inputs = {}
def read(path):
    data = path.read_bytes()
    inputs[str(path.relative_to(ROOT))] = hashlib.sha256(data).hexdigest()
    return data

host = read(ROOT / 'sorting_office.html').decode()
namespace = 'catsByPost.cityhallPaper.study.v1.'
keys = sorted(set(re.findall(r'catsByPost\.[A-Za-z0-9.]+', host)))
substitutions = []
for old in keys:
    new = namespace + old[len('catsByPost.'):]
    count = host.count(old)
    host = host.replace(old, new)
    substitutions.append({'from': old, 'to': new, 'count': count})
assert keys == ['catsByPost.nightShiftBest', 'catsByPost.progress'], keys
manifest = json.loads(read(SOURCE / 'assets/manifest.json'))
assets = {'images': {}, 'acting': manifest['assets']['acting']['registration'], 'registration': manifest['assets']}
for name, meta in manifest['assets'].items():
    data = read(SOURCE / 'assets' / meta['file'])
    assert hashlib.sha256(data).hexdigest() == meta['sha256'], name
    mime = 'image/webp' if meta['file'].endswith('.webp') else 'image/png'
    assets['images'][name] = 'data:' + mime + ';base64,' + base64.b64encode(data).decode()
files = ['projection.js','input.js','layout.js','materials.js','civic-district.js','street-life.js','environment.js','backdrop.js','clock-bay.js','sorting-floor.js','civic-square.js','vault-and-walls.js','daylight.js','architecture.js','acting.js','carriers.js','flaps.js','renderer.js','adapter.js']
for optional in ['motion.js', 'actors.js']:
    if (SOURCE / optional).exists():
        files.insert(files.index('renderer.js'), optional)
code = 'const CityHallRules={GR_DIR};\nconst CityHallAssets=' + json.dumps(assets,separators=(',',':')) + ';\n'
code += '\n'.join(read(SOURCE / name).decode() for name in files)
ui = {name:'data:image/svg+xml;base64,'+base64.b64encode(read(ROOT / 'web/journey/icons' / file)).decode() for name,file in [('menu','list.svg'),('tools','crosshair-simple.svg'),('reset','arrow-counter-clockwise.svg')]}
code += '\nconst CityHallUIAssets=' + json.dumps(ui) + ';\n' + read(HERE / 'phone.js').decode()
code += '\n' + read(HERE / 'study.js').decode()
style = read(HERE / 'study.css').decode() + '\n' + read(HERE / 'phone.css').decode()
for token,file in [('__BALTHAZAR__','balthazar.ttf'),('__SIGNIKA__','signika.ttf')]:
    style=style.replace(token,'data:font/ttf;base64,'+base64.b64encode(read(ROOT / 'web/assets' / file)).decode())
style=style.replace('__VIEW_ICON__','data:image/svg+xml;base64,'+base64.b64encode(read(ROOT / 'web/journey/icons/map-trifold.svg')).decode())
page = host.replace('</head>', '<link rel="icon" href="data:,"><style>\n'+style+'\n</style></head>').replace('</body>', '<script>\n'+code+'\n</script></body>')
(HERE / 'index.html').write_text(page)
report = {'base':'923b40d7c3ef2b9e4fab49d290267f0094a1a9bb','namespace':namespace,'substitutions':substitutions,'inputs':inputs,'bytes':len(page.encode()),'sha256':hashlib.sha256(page.encode()).hexdigest()}
(HERE / 'build.json').write_text(json.dumps(report,indent=2)+'\n')
print('Great Postal Vault:',report['bytes'],'bytes',report['sha256'])
