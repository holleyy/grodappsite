"""Prepare an additive grodappsite review packet; does not push or publish."""
from pathlib import Path
import json,hashlib,shutil,subprocess,zipfile,sys
src=Path(__file__).resolve().parents[3];repo=Path(sys.argv[1]);out=repo/'cats-by-post-cityhall-paper/light-materials';out.mkdir(exist_ok=True)
e=src/'docs/review-images/cityhall-paper/light-materials';city=json.loads((src/'studies/cityhall-paper/build.json').read_text())
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()
for p in e.iterdir():
 if p.is_file():shutil.copyfile(p,out/p.name)
shutil.copyfile(src/'studies/cityhall-paper/index.html',out/'playable.html')
html=(out/'index.html').read_text().replace('../../../../studies/cityhall-paper/','playable.html').replace('../civic-district/index.html','../civic-district/').replace('<footer>','<footer><a href="source.zip">Source and retained artwork</a> · <a href="ownership.json">Build provenance</a>')
(out/'index.html').write_text(html)
ownership={'prefix':'cats-by-post-cityhall-paper/light-materials/','addOnly':True,'purpose':'Lighting, material contrast and folded-paper pipes for City Hall','sourceCommit':commit,'runtimeSha256':city['sha256'],'scope':'Room-owned static scenery. Black worker artwork, board projection, rules, Town Depot, Sorting Office, shared originals and previous previews remain unchanged.'}
(out/'ownership.json').write_text(json.dumps(ownership,indent=2)+'\n')
with zipfile.ZipFile(out/'source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in ['src/fidelity/cityhall-paper','studies/cityhall-paper/light-materials']:
  for p in sorted((src/folder).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(src))
 for p in sorted((src/'studies/cityhall-paper').glob('*')):
  if p.is_file() and p.suffix in ['.py','.js','.css','.json','.md','.cjs']:z.write(p,p.relative_to(src))
 for file in ['src/render/27b_paper_flap.js','src/data/edge_portals.json','src/data/cityhall.json','src/data/depot.json','src/sim/19i_cityhall.js','src/sim/19b_depot.js','src/data/levels.json','src/sim/10_rules.js','src/sim/12_boardanim.js','tests/fixtures/tunnels.js','tests/fixtures/tunnel-cases.js','sorting_office.html','web/assets/balthazar.ttf','web/assets/signika.ttf','web/journey/icons/list.svg','web/journey/icons/crosshair-simple.svg','web/journey/icons/arrow-counter-clockwise.svg','web/journey/icons/map-trifold.svg','docs/rooms/progress/cityhall-paper-light-materials.md','docs/rooms/progress/cityhall-paper-light-materials-plan.md']:
  z.write(src/file,file)
 for p in sorted((src/'tests').glob('cityhall-paper-*.test.js')):z.write(p,p.relative_to(src))
 z.writestr('LIGHT-MATERIALS-README.md','Build: python3 studies/cityhall-paper/build.py\nServe through HTTP and open studies/cityhall-paper/. No asset/network dependencies at runtime. Native generated masters are retained unchanged. Browser scripts require Chromium and Playwright; adapt installation paths on other machines. See checkpoint and plan documents for scope, independent review and remaining artistic work.\n')
manifest={'sourceCommit':commit,'runtimeSha256':city['sha256'],'files':{}}
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name!='manifest.json':manifest['files'][str(p.relative_to(out))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(manifest['files']),'files;',sum(x['bytes'] for x in manifest['files'].values()),'bytes; source',commit)
