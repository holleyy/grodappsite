"""Preserve native-size captures, actual browser receipts and source hashes."""
from pathlib import Path
from PIL import Image
import json,hashlib,shutil,re
root=Path(__file__).resolve().parents[3];work=root/'work/cityhall-paper/light-materials';out=root/'docs/review-images/cityhall-paper/light-materials';out.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
build=read(root/'studies/cityhall-paper/build.json')
for f,h in build['inputs'].items():assert sha(root/f)==h,f
protected=read(root/'work/cityhall-paper/protected.json')
for f,h in protected.items():assert sha(root/f)==h,f
reports={}
for src,name,count in [(root/'work/cityhall-paper/browser-report.json','browser-report.json',72),(root/'work/cityhall-paper/qualification-report.json','qualification-report.json',26),(root/'work/cityhall-paper/street-life/phone-report.json','phone-report.json',44),(work/'coverage-report.json','coverage-report.json',5)]:
 assert src.stat().st_mtime>(root/'studies/cityhall-paper/index.html').stat().st_mtime,src
 data=read(src);assert len(data['checks'])==count and not data.get('errors') and not data.get('failures'),src
 reports[name]=data;shutil.copyfile(src,out/name)
before=read(work/'before-rasters.json');after=read(work/'after-rasters.json');assert before==after
counts={}
for file,key in [('baseline-tests.log','baselineTests'),('final-tests.log','finalTests'),('focused.log','focusedTests')]:
 log=(work/file).read_text();total=re.findall(r'ℹ tests (\d+)',log);passed=re.findall(r'ℹ pass (\d+)',log);failed=re.findall(r'ℹ fail (\d+)',log)
 assert total and passed==total and failed==['0'],file
 counts[key]=int(total[0]);shutil.copyfile(work/file,out/file)
captures={}
for side in ['before','after']:
 for view in ['phone-first','phone','phone-tall','phone-short','phone-hall','hall','square','light','detail','board','gray','architecture','pipes-left','pipes-right']:
  source=work/(side+'-'+view+'.png');target=out/(source.stem+'.webp')
  with Image.open(source) as im:
   if not target.exists() or target.stat().st_mtime<source.stat().st_mtime:im.save(target,'WEBP',quality=94,method=6)
   captures[target.name]={'width':im.width,'height':im.height,'sourceSha256':sha(source),'sha256':sha(target)}
shutil.copyfile(work/'material-report.json',out/'material-report.json')
for source,name in [(root/'studies/cityhall-paper/build.json','build-manifest.json'),(work/'before-build.json','before-build.json'),(work/'before-rasters.json','before-rasters.json'),(work/'after-rasters.json','after-rasters.json'),(root/'docs/rooms/progress/cityhall-paper-light-materials.md','checkpoint.md'),(root/'docs/rooms/progress/cityhall-paper-light-materials-plan.md','plan.md')]:shutil.copyfile(source,out/name)
write('capture-hashes.json',{'runtimeSha256':build['sha256'],'ambientSeconds':8,'images':captures})
write('preservation.json',{'protectedFiles':protected,'allExact':True,'boardRasters':after,'previousRuntime':read(work/'before-build.json')['sha256'],'assetChanges':[]})
write('verification.json',{'runtimeSha256':build['sha256'],'bytes':build['bytes'],**counts,'browserChecks':72,'qualificationChecks':26,'phoneChecks':44,'coverageChecks':5,'canonicalWins':len(reports['browser-report.json']['wins']),'protectedFiles':len(protected),'boardRastersExact':3,'errors':[],'warm':reports['qualification-report.json']['warm'],'captureResources':json.loads((work/'capture-after.log').read_text())['resources'],'scope':'Cloud Chromium and phone/DPR2 emulation; not physical-device, Safari or artistic-parity certification'})
print('Evidence complete',build['sha256'],counts,len(captures),'captures')
