Build: python3 studies/cityhall-paper/build.py
Serve through HTTP and open studies/cityhall-paper/. No asset/network dependencies at runtime. Native generated masters are retained unchanged. Browser scripts require Chromium and Playwright; adapt installation paths on other machines. See checkpoint and plan documents for scope, independent review and remaining artistic work.
