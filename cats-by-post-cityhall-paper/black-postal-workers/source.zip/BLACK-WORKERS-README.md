City Hall runtime: python3 studies/cityhall-paper/build.py
Depot runtime: python3 studies/cityhall-paper/black-workers/build-depot.py
To re-register art, see prepare.py and register-depot.cjs. Native masters are retained. Browser scripts expect the documented Chromium/Playwright installation; adapt its path on other machines. Serve through HTTP, not file://.
