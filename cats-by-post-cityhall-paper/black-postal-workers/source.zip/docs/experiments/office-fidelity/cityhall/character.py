"""Prepare articulated Hall paper poses from immutable accepted components.

Coordinates are native sprite units about the original shoe/ground anchor.
Nothing in this module runs in the frame loop or changes source pose hashes.
"""
from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
import math,base64,numpy as np
COMPONENTS={'coat-front':'coat-front.png','coat-back':'coat-back.png','sleeve':'sleeve.png','hand':'hand.png','shoe':'shoe.png'}
def component_paths(depot):
 depot=Path(depot);out={k:depot/v for k,v in COMPONENTS.items()};office=depot.parents[2]/'assets'
 out.update({'head-front':office/'worker-head-front.png','head-back':office/'worker-head-back.png'});return out
def load_components(depot):
 out={}
 for k,path in component_paths(depot).items():
  im=Image.open(path).convert('RGBA');box=im.getchannel('A').point(lambda n:255 if n>20 else 0).getbbox();im=im.crop(box)
  a=np.array(im);rgb=a[:,:,:3].astype(float)
  if k.startswith('head'):
   cool=(rgb[:,:,2]>rgb[:,:,0]+3)&(rgb[:,:,2]>=rgb[:,:,1]);rgb[cool]*=np.array([.84,.88,1.00])
  elif k=='hand':rgb*=np.array([1.39,1.47,1.54])
  elif k.startswith('coat')or k=='sleeve':rgb*=np.array([.94,1.02,1.09])
  a[:,:,:3]=np.clip(np.rint(rgb),0,255).astype('uint8');out[k]=Image.fromarray(a)
 return out
def actor_rig(pose):
 walk=pose['walk'];stride=-2 if walk==0 else 2 if walk==2 else 0;bob=pose['bob']
 hand_y=-5 if pose.get('pour') else 4 if pose.get('reach') else 17 if pose.get('pencil') else 16 if pose.get('hold') else 21
 hand_x=0 if pose.get('hold') and not pose.get('reach') else 2
 return {'feet':[[-4+stride,0],[1-stride,0]],'shoulder':[-4,-16+bob],'wrist':[-7+hand_x+(stride if walk>=0 else 0),-28+bob+hand_y],'head':[0,-31+bob],'back':pose['face']>=2}
def compose_actor(pose,components,carry=False,mirror=False):
 rig=actor_rig(pose);im=Image.new('RGBA',(128,144));S=4
 def xy(x,y):return(round((x+16)*S),round((y+34)*S))
 def put(name,x,y,w,h,mirror=False):
  a=components[name];fit=min(w*S/a.width,h*S/a.height);a=a.resize((max(1,round(a.width*fit)),max(1,round(a.height*fit))),Image.Resampling.LANCZOS)
  if mirror:a=ImageOps.mirror(a)
  X,Y=xy(x,y);im.alpha_composite(a,(X+round((w*S-a.width)/2),Y+round(h*S-a.height)))
 def sleeve(a,b,width):
  dx=b[0]-a[0];dy=b[1]-a[1];length=math.hypot(dx,dy)
  if length<.05:return
  tile=components['sleeve'].resize((round(width*S),max(1,round((length+.65)*S))),Image.Resampling.LANCZOS)
  tile=tile.rotate(math.degrees(math.atan2(dx,dy)),resample=Image.Resampling.BICUBIC,expand=True)
  X,Y=xy((a[0]+b[0])/2,(a[1]+b[1])/2);im.alpha_composite(tile,(X-tile.width//2,Y-tile.height//2))
 def hand(wrist,up=False,mirror=False):
  a=components['hand'];a=a.resize((12,13),Image.Resampling.LANCZOS)
  if mirror:a=ImageOps.mirror(a)
  if up:a=a.rotate(180)
  X,Y=xy(wrist[0],wrist[1]);im.alpha_composite(a,(X,Y-10 if up else Y))
 bob=pose['bob'];back=rig['back'];far_shoulder=[4,-16+bob];far_wrist=[4.3,-7+bob]
 # The far cuff, hand and boots sit behind the split coat, keeping their support.
 if not carry:sleeve(far_shoulder,far_wrist,2.8);hand(far_wrist,mirror=True)
 for i,(x,y)in enumerate(rig['feet']):put('shoe',x-1.0,y-4.1,5.4,5.0,mirror=i==1)
 put('coat-back'if back else'coat-front',-6.3,-19+bob,12.6,17.6)
 put('head-back'if back else'head-front',-6.6,-31+bob,13.2,13.7)
 a=rig['shoulder'];b=rig['wrist'];elbow=[a[0]+(b[0]-a[0])*.48-.25,a[1]+(b[1]-a[1])*.48+.65]
 sleeve(a,elbow,2.85);sleeve(elbow,b,2.5);hand(b,up=b[1]<a[1])
 if pose.get('pencil'):
  d=ImageDraw.Draw(im);x,y=xy(b[0]-.5,b[1]+.1);d.line((x-7,y+8,x+1,y-2),fill='#d3ae59',width=2)
 meta={'sourceHash':pose['sourceHash'],'view':'back'if back else'front','feet':rig['feet'],'wrist':rig['wrist'],'shoulder':rig['shoulder'],'head':rig['head'],'composition':'accepted layered head/coat/boots; native articulated cuffs/hands'}
 if carry:
  # The right strap is an actual opaque texel in the accepted registered bag.
  # World bag offset(4,9,11) projects to(-5,-4.5). Its(88,54)texel is(6,-20.5).
  gx,gy=1,-25;source_x=-gx if mirror else gx;wrist=[source_x-1.3,gy];elbow=[6.4,-20];start=[4,-16+bob]
  body=im;im=Image.new('RGBA',(128,144));sleeve(start,elbow,2.8);sleeve(elbow,wrist,2.5);hand(wrist,up=True,mirror=mirror);layer=im;im=body;im.alpha_composite(layer)
  mask=np.array(layer.getchannel('A'));delta=np.zeros((144,128),dtype='uint8');segments=[(start,elbow,0,32),(elbow,wrist,32,79)]
  for yy,xx in zip(*np.where(mask>12)):
   A=(xx+.5)/4-16;B=(yy+.5)/4-34;best=(1e9,0)
   for u,v,lo,hi in segments:
    dx=v[0]-u[0];dy=v[1]-u[1];t=max(0,min(1,((A-u[0])*dx+(B-u[1])*dy)/(dx*dx+dy*dy)));dist=(A-u[0]-dx*t)**2+(B-u[1]-dy*t)**2
    if dist<best[0]:best=(dist,round(lo+(hi-lo)*t))
   delta[yy,xx]=best[1]
  meta.update(carry=True,mirror=mirror,grip={'bagPixel':[88,54],'native':[gx,gy],'wristImage':wrist,'depthDelta':79,'derivation':'4*(bag.dx+bag.dy+bag.z + projectedBagY) + one quarter-unit paper layer = 79'},gripDepthDelta=base64.b64encode(delta.tobytes()).decode())
 return im,meta
