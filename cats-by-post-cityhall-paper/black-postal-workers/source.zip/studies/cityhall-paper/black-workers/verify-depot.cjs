const {chromium}=require('/opt/codex/cua_node/lib/node_modules/playwright');
const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const out='work/cityhall-paper/black-workers';
(async()=>{
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const report={errors:[],wins:[],picks:0,rasters:{}};
 try{
 for(const variant of ['before','after']){
  const p=await b.newPage({viewport:{width:1440,height:1000}});p.on('pageerror',e=>report.errors.push(e.message));
  const file=variant==='before'?'work/cityhall-paper/black-workers/depot-before.html':'studies/cityhall-paper/black-workers/depot.html';
  await p.goto('http://127.0.0.1:8817/'+file,{timeout:120000});await p.waitForFunction(()=>window.__depot?.ready,null,{timeout:120000});
  await p.evaluate(()=>{const D=__depot;D.pause(true);D.load(24);D.view('structure');D.renderer.ambient=8;D.renderer.draw(D.session);});await p.screenshot({path:out+'/depot-'+variant+'.png'});
  const rasters=await p.evaluate(()=>[...__depot.renderer.boardCaches].map(([id,l])=>({id,png:(l.canvas||l).toDataURL()})));
  report.rasters[variant]=rasters.map(x=>({id:x.id,hash:crypto.createHash('sha256').update(x.png).digest('hex')}));
  await p.setViewportSize({width:390,height:844});await p.waitForTimeout(100);await p.evaluate(()=>{__depot.view('structure');__depot.renderer.draw(__depot.session);});await p.screenshot({path:out+'/depot-'+variant+'-phone.png'});
  if(variant==='after'){
   await p.setViewportSize({width:1440,height:1000});
   const checks=await p.evaluate(()=>{const D=__depot,results=[];let picks=0;for(let i=0;i<25;i++){D.load(i);D.view('play');D.renderer.draw(D.session);const s=D.session;for(let y=0;y<s.level.board.h;y++)for(let x=0;x<s.level.board.w;x++){const a=D.cell(x,y),q=D.renderer.cellAt(a.x,a.y);if(!q||q.x!==x||q.y!==y)throw Error('pick '+i+':'+x+','+y);picks++;}s.chutes=s.level.solution.map(x=>({...x}));s.send();let steps=0;while(s.mode==='running'&&steps++<20000)s.step(1/60);results.push({id:s.level.id,mode:s.mode});}return{results,picks};});
   assert(checks.results.every(x=>x.mode==='won'));report.wins=checks.results;report.picks=checks.picks;
   await p.evaluate(()=>{__depot.load(24);__depot.view('structure');__depot.motion(false);__depot.renderer.ambient=8;__depot.renderer.draw(__depot.session);});
   report.reducedMotion=await p.evaluate(()=>!__depot.renderer.motion);
   const png=await p.evaluate(()=>{
    const r=__depot.renderer,c=document.createElement('canvas');c.width=1200;c.height=690;const ctx=c.getContext('2d'),old=r.ctx;r.ctx=ctx;
    ctx.fillStyle='#f5eddd';ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle='#254e45';ctx.font='24px Georgia';ctx.fillText('Town Depot · same working rig, new character artwork',26,38);
    const frames=[0,180,360,480,660,840,1100,1400];
    for(let i=0;i<frames.length;i++){r.postal.work.sample(frames[i]);const s=r.postal.work,p=s.pose,x=150+(i%4)*300,y=335+Math.floor(i/4)*310;ctx.save();ctx.translate(x,y);ctx.scale(2,2);ctx.translate(-(760+(p.x-p.y)*DepotProjection.HW),-(465+(p.x+p.y)*DepotProjection.HH));r.postal.puppet.draw(s,r.postal.drawHeld);ctx.restore();ctx.fillStyle='#254e45';ctx.font='15px sans-serif';ctx.fillText('Frame '+frames[i],x-45,y+26);}
    r.ctx=old;return c.toDataURL();
   });fs.writeFileSync(out+'/depot-poses.png',Buffer.from(png.split(',')[1],'base64'));
  }
  await p.close();
 }
 assert.deepEqual(report.rasters.before,report.rasters.after);assert.equal(report.errors.length,0);
 fs.writeFileSync(out+'/depot-report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
 }finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
