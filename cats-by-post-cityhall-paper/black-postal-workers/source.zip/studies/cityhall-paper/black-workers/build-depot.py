"""Additive worker-art variant of the exact published Depot final review.

Only two atlas data URLs change. No changes to rules, animation, layout, saves,
or another chat's source tree. Input is recoverable from the public git object.
"""
from pathlib import Path
import base64,hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
INPUT=ROOT/'work/cityhall-paper/black-workers/depot-before.html'
EXPECTED='5f0d1e9c2f0094d33b5a6830ae13dbcfa21c8b7814b7ab7cb1a981a918b44240'
PUBLIC=Path('/workspace/work/grodappsite-cityhall')
if not INPUT.exists():
    INPUT.parent.mkdir(parents=True,exist_ok=True)
    INPUT.write_bytes(subprocess.check_output(['git','show','origin/main:cats-by-post-depot-paper/final-review/playable.html'],cwd=PUBLIC))
raw=INPUT.read_bytes()
assert hashlib.sha256(raw).hexdigest()==EXPECTED, 'Depot source checkpoint changed'
source=raw.decode()
start=source.index('const DepotAssets=')+len('const DepotAssets=')
assets,end=json.JSONDecoder().raw_decode(source[start:])
updated=source
edits=[]
for key in ('puppets','workers'):
    path=HERE/'depot-assets'/(key+'.png')
    old=assets[key]['src']
    new='data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()
    assert updated.count(old)==1, key
    updated=updated.replace(old,new)
    edits.append({'asset':key,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'oldURL':old,'newURL':new})
restored=updated
for e in edits:restored=restored.replace(e['newURL'],e['oldURL'])
assert restored==source,'Non-art runtime bytes changed'
(HERE/'depot.html').write_text(updated)
report={'input':{'publicPath':'cats-by-post-depot-paper/final-review/playable.html','sha256':EXPECTED},'output':{'sha256':hashlib.sha256(updated.encode()).hexdigest(),'bytes':len(updated.encode())},'edits':[{k:v for k,v in e.items() if not k.endswith('URL')} for e in edits],'otherRuntimeBytesIdentical':True}
(HERE/'depot-build.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
