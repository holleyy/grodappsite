// Sprite atlas registration only. ImageGen authors the skin/hair changes;
// each native master stays intact. Fit each figure to its original alpha bounds.
const {chromium}=require('/opt/codex/cua_node/lib/node_modules/playwright');
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'../../..'),out=path.join(__dirname,'depot-assets');
(async()=>{
 fs.mkdirSync(out,{recursive:true});
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const p=await b.newPage();const report={};
 for(const key of ['puppets','workers']){
  const data=f=>'data:image/png;base64,'+fs.readFileSync(f).toString('base64');
  const result=await p.evaluate(async({original,master,key})=>{
   const load=src=>new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=reject;im.src=src;});
   const [old,fresh]=await Promise.all([load(original),load(master)]);
   if(old.width!==fresh.width||old.height!==fresh.height)throw Error('native dimensions changed');
   const w=old.width,h=old.height,cols=key==='puppets'?2:3,rows=key==='puppets'?1:2;
   const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d');
   const bounds=(im,cell)=>{ctx.clearRect(0,0,w,h);ctx.drawImage(im,0,0);const a=ctx.getImageData(0,0,w,h).data;let x0=w,y0=h,x1=0,y1=0;for(let y=cell[1];y<cell[3];y++)for(let x=cell[0];x<cell[2];x++)if(a[(y*w+x)*4+3]>128){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x+1);y1=Math.max(y1,y+1);}return[x0,y0,x1,y1];};
   const fits=[];for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){
    const cell=[col*w/cols,row*h/rows,(col+1)*w/cols,(row+1)*h/rows];fits.push({cell,from:bounds(fresh,cell),to:bounds(old,cell)});
   }
   ctx.clearRect(0,0,w,h);
   for(const f of fits){const [a,b,c,d]=f.from,[x,y,r,s]=f.to,[cx,cy,cr,cs]=f.cell,sx=(r-x)/(c-a),sy=(s-y)/(d-b);
    ctx.save();ctx.beginPath();ctx.rect(cx,cy,cr-cx,cs-cy);ctx.clip();ctx.translate(x-a*sx,y-b*sy);ctx.scale(sx,sy);ctx.drawImage(fresh,cx,cy,cr-cx,cs-cy,cx,cy,cr-cx,cs-cy);ctx.restore();
   }
   return{fits,png:c.toDataURL('image/png')};
  },{original:data(path.join(root,'work/cityhall-paper/black-workers/depot-assets',key+'.png')),master:data(path.join(__dirname,'masters','depot-'+key+'.png')),key});
  fs.writeFileSync(path.join(out,key+'.png'),Buffer.from(result.png.split(',')[1],'base64'));report[key]=result.fits;
 }
 fs.writeFileSync(path.join(__dirname,'depot-registration.json'),JSON.stringify(report,null,2)+'\n');await b.close();console.log('Registered both Depot atlases to original figure bounds');
})().catch(e=>{console.error(e);process.exitCode=1;});
