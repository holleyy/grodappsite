"""Register new Black worker artwork in the established City Hall pose rig.

ImageGen masters remain unchanged. Only alpha bounds and normal sprite scaling
are used here; faces, hair and skin are authored in those masters, not recolored.
Shared Office/Depot source artwork and all animation anchors remain untouched.
"""
from pathlib import Path
import importlib.util, json, hashlib, subprocess
from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = ROOT / 'docs/experiments/office-fidelity/cityhall'
DEST = ROOT / 'src/fidelity/cityhall-paper/assets'
spec = importlib.util.spec_from_file_location('hall_character', SOURCE/'character.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
depot = SOURCE.parent/'depot/bespoke/assets'
scratch = ROOT/'work/cityhall-paper/components'
for path in m.component_paths(depot).values():
    target = scratch/path.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = path.read_bytes() if path.exists() else subprocess.check_output(
        ['git', 'show', '923b40d7c3ef2b9e4fab49d290267f0094a1a9bb:'+str(path.relative_to(ROOT))], cwd=ROOT)
    target.write_bytes(raw)
components = m.load_components(scratch/depot.relative_to(ROOT))
masters = {}
for key in ('head-front', 'head-back', 'hand'):
    path = HERE/'masters'/(key+'.png')
    im = Image.open(path).convert('RGBA')
    box = im.getchannel('A').point(lambda a: 255 if a > 20 else 0).getbbox()
    components[key] = im.crop(box)
    masters[key] = {'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'nativeSize': list(im.size), 'alphaBounds': list(box)}
manifest = json.loads((DEST/'manifest.json').read_text())
poses = json.loads((SOURCE/'actor-poses.json').read_text())['sprites']
changed = []
def save(name, image, rig=None):
    meta = manifest['assets'][name]
    assert image.size == (meta['width'], meta['height']), name
    if rig is not None:
        for anchor in ('feet','wrist','shoulder','head','view'):
            assert rig[anchor] == meta['rig'][anchor], (name, anchor)
        # The carry depth mask follows the actual newly authored hand silhouette.
        meta['rig'] = rig
    path = DEST/meta['file']
    image.save(path)
    meta.update(sha256=hashlib.sha256(path.read_bytes()).hexdigest(), source='Black postal worker; ImageGen heads and hands registered in the existing paper rig', artworkMasters=masters)
    meta['componentSources'] = {k:v for k,v in meta.get('componentSources',{}).items() if not k.endswith(('worker-head-front.png','worker-head-back.png','/hand.png'))}
    meta['componentSources'].update({v['path']:v['sha256'] for v in masters.values()})
    if 'opaquePixels' in meta:
        meta['opaquePixels'] = sum(a > 0 for a in image.getchannel('A').getdata())
    changed.append(name)
for pose in poses:
    key = str(pose['sourceHash'])
    image, rig = m.compose_actor(pose, components)
    save('worker-'+key, image, rig)
    for mirrored in (False, True):
        name = 'worker-carry-'+key+('-mirrored' if mirrored else '-plain')
        if name in manifest['assets']:
            image, rig = m.compose_actor(pose, components, carry=True, mirror=mirrored)
            save(name, image, rig)
save('joint-hand', components['hand'].resize((32,36), Image.Resampling.LANCZOS))
armless = {k: v.copy() for k,v in components.items()}
for name in ('hand','sleeve'):
    armless[name].putalpha(0)
for pose in poses:
    image, rig = m.compose_actor(pose, armless)
    save('worker-base-'+str(pose['sourceHash']), image, rig)
(DEST/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
(HERE/'artwork.json').write_text(json.dumps({'masters':masters,'assets':changed,'unchanged':'pose hashes, feet, head and wrist anchors, uniforms, shoes, shared source art'},indent=2)+'\n')
print('Prepared',len(changed),'City Hall worker assets')
