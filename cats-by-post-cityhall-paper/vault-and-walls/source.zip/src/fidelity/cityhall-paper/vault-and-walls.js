/* One warm paper construction language for the vault, walls and civic roofs.
   All faces, paths and material work run only in the existing scenery bakes. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CityHallVaultAndWalls=api;})(globalThis,function(){
 'use strict';
 const point=(axis,u,d,z)=>axis==='rear'?[u,d,z]:[d,u,z];
 function layout(){return {
  pipeRadius:3.1,pipe:[[11.5,180,70],[11.5,180,116],[11.5,11.5,116],[108,11.5,116],[108,5,116]],
  service:{x0:8,y0:173,z0:64,x1:15,y1:187,z1:78},
  mounts:[{axis:'left',u:56,z:116},{axis:'left',u:116,z:116},{axis:'left',u:180,z:102},{axis:'rear',u:58,z:116}],
  lamps:[{axis:'left',u:56,z:90},{axis:'left',u:116,z:90},{axis:'rear',u:58,z:90}],
  supportFeet:[114,178].map(y=>({x0:18,y0:y-3,z0:0,x1:24,y1:y+3,z1:3})),
  leftFascia:{x0:21.5,y0:38,z0:37.5,x1:23.5,y1:192,z1:42.5},
  leftLip:{x0:21,y0:38,z0:43.7,x1:25,y1:192,z1:46}
 };}
 function box(p,x,y,z,w,d,h,kind='stone'){CityHallClockBay.paperBox(p,x,y,z,w,d,h,kind);}
 function face(p,pts,kind='stone',shade=0){CityHallClockBay.paperFace(p,pts,kind,shade);}
 function wallBox(p,axis,u,d,z,w,depth,h,kind='stone'){if(axis==='rear')box(p,u,d,z,w,depth,h,kind);else box(p,d,u,z,depth,w,h,kind);}
 function wallImage(p,name,axis,u,d,z,w,h){
  if(axis==='rear'){CityHallClockBay.rearImage(p,name,u,d,z,w,h);return;}
  const a=CityHallProjection.project(d,u+w/2,z+h/2),c=p.c;c.save();c.transform(-1,.5,0,1,a.x,a.y);c.drawImage(p.images[name],0,0,w,h);c.restore();
 }
 function arch(axis,u0,u1,z0,z1,d=0){const r=(u1-u0)/2,mid=(u0+u1)/2,s=z1-r,pts=[point(axis,u0,d,z0),point(axis,u1,d,z0),point(axis,u1,d,s)];for(let i=0;i<=24;i++){const a=i*Math.PI/24;pts.push(point(axis,mid+r*Math.cos(a),d,s+r*Math.sin(a)));}return pts;}
 function path(c,pts){for(let i=0;i<pts.length;i++){const q=CityHallProjection.project(...pts[i]);if(i)c.lineTo(q.x,q.y);else c.moveTo(q.x,q.y);}c.closePath();}
 function reveal(p,axis,u0,u1,z0,z1){
  const r=(u1-u0)/2,mid=(u0+u1)/2,s=z1-r;
  for(const u of [u0-3.7,u1]){wallBox(p,axis,u,0,z0,3.7,4.7,s-z0);wallBox(p,axis,u-.5,-.3,z0-1,4.7,5.7,2);}
  for(let i=0;i<14;i++){
   const a=i*Math.PI/14,b=(i+1)*Math.PI/14,at=(v,rr,d)=>point(axis,mid+Math.cos(v)*rr,d,s+Math.sin(v)*rr);
   face(p,[at(a,r+3.7,4.7),at(b,r+3.7,4.7),at(b,r,4.7),at(a,r,4.7)],'stone',i<7?-.06:.03);
   face(p,[at(a,r,4.7),at(b,r,4.7),at(b,r,0),at(a,r,0)],'stone',-.25);p.line(at(a,r,4.8),at(a,r+3.7,4.8),'#c1af8c',.22);
  }
  wallBox(p,axis,mid-2,1,z1-1.5,4,5.5,6);wallBox(p,axis,u0-4,-1,z0-4,u1-u0+8,8,3);wallBox(p,axis,u0-4.5,-1.3,z0-1.5,u1-u0+9,8.8,.8,'gold');
 }
 function windows(p,axis,length,bays){
  const c=p.c,at=(u,z)=>point(axis,u,0,z);
  c.save();c.beginPath();path(c,[at(0,0),at(length,0),at(length,138),at(0,138)]);for(const b of bays)path(c,arch(axis,b[0],b[1],55,127));c.clip('evenodd');
  for(let z=0;z<138;z+=9)for(let u=0;u<length;u+=23){const u1=Math.min(length,u+23),z1=Math.min(138,z+9);face(p,[at(u,z1),at(u1,z1),at(u1,z),at(u,z)],'stone',axis==='left'?-.025:.02);p.line(at(u,z),at(u1,z),'#bbaa8b',.16);}
  c.restore();
  for(const [u0,u1]of bays){
   p.face(arch(axis,u0,u1,55,127,.15),'#e5e7c516',null);
   // The finished clock bay already owns this exact reveal.
   if(axis!=='rear'||u0!==176)reveal(p,axis,u0,u1,55,127);
   const r=(u1-u0)/2,s=127-r,mid=(u0+u1)/2,wp=(u,z)=>point(axis,u,.55,z);
   for(const u of [u0+(u1-u0)/3,mid,u0+(u1-u0)*2/3])p.line(wp(u,55),wp(u,s+Math.sqrt(r*r-(u-mid)**2)),'#f4e8cc',1);
   for(const z of [77,99,s])p.line(wp(u0,z),wp(u1,z),'#f4e8cc',1.2);
   for(let i=1;i<6;i++){const a=i*Math.PI/6;p.line(wp(mid,s),wp(mid+r*Math.cos(a),s+r*Math.sin(a)),'#f4e8cc',.7);}
  }
 }
 function column(p,b){
  const x=b.x0,y=b.y0,w=b.x1-x,d=b.y1-y;
  box(p,x-1,y-1,0,w+2,d+2,5);box(p,x,y,5,w,d,127,'green');box(p,x-.4,y-.4,11,w+.8,d+.8,1,'gold');
  for(const u of [1,w/2,w-1]){p.line([x+u,y+d+.1,16],[x+u,y+d+.1,125],'#173c31',.55);p.line([x+u-.3,y+d+.1,16],[x+u-.3,y+d+.1,125],'#a7af7f',.2);}
  for(const u of [1,d/2,d-1]){p.line([x+w+.1,y+u,16],[x+w+.1,y+u,125],'#173c31',.55);p.line([x+w+.1,y+u-.3,16],[x+w+.1,y+u-.3,125],'#a7af7f',.2);}
  box(p,x-1,y-1,126,w+2,d+2,1.5,'gold');box(p,x-1.5,y-1.5,127.5,w+3,d+3,3,'green');box(p,x-2,y-2,130.5,w+4,d+4,1.2,'gold');box(p,x-3,y-3,132,w+6,d+6,6);
  for(let u=0;u<w+3;u+=2)box(p,x-1+u,y+d+1.4,128,.9,.8,1.6,'gold');
  const left=b.id==='left-column';wallImage(p,'crest',left?'left':'rear',left?y+d/2:x+w/2,left?x+w+.2:y+d+.2,122,5.5,3.6);
 }
 function gallery(p){
  const f=layout().leftFascia;box(p,f.x0,f.y0,f.z0,f.x1-f.x0,f.y1-f.y0,f.z1-f.z0,'green');wallBox(p,'left',38,20.8,42.5,154,3.4,1.2,'gold');wallBox(p,'left',38,21,43.7,154,4,2.3);
  for(let u=40;u<192;u+=5)wallBox(p,'left',u,23.6,39.6,1.8,.8,1.8,'gold');
  for(const foot of layout().supportFeet){
   const y=(foot.y0+foot.y1)/2;
   box(p,18.5,y-2.5,0,5,5,36.5,'green');box(p,foot.x0,foot.y0,foot.z0,foot.x1-foot.x0,foot.y1-foot.y0,foot.z1-foot.z0);box(p,18,y-3.5,34,6,7,2,'gold');
   for(const sign of [-1,1]){const pts=[[24,y,36],[24,y+sign*10,40],[24,y+sign*7,36],[24,y,29]];face(p,pts,'green');p.line(pts[1],pts[2],'#e5c57a',.5);p.line(pts[2],pts[3],'#e5c57a',.5);}
  }
  wallBox(p,'left',0,-1,132,192,6,2,'gold');wallBox(p,'left',0,-2,134,192,7.5,3.5);wallBox(p,'left',0,-2.6,137.5,192,8.6,.8);
  for(let u=2;u<192;u+=5)wallBox(p,'left',u,3.7,130.5,2.2,1.6,1.7);
 }
 function rail(p){
  for(let y=40;y<192;y+=5.3){box(p,23.4,y,47,1,.8,10.8,'green');box(p,23.3,y-.2,52,1.2,1.2,.9,'gold');}
  for(const [x,z,d,h,kind]of [[23.4,47,1.3,1.3,'green'],[23.4,56.8,1.6,1.5,'green'],[22.9,58.3,2.6,1.1,'gold'],[22.75,59.4,2.9,.6,'gold']])box(p,x,38,z,d,154,h,kind);
  for(const y of [38,68,98,128,158,190]){box(p,22.8,y-1,46,2.6,2,14,'green');box(p,22.5,y-1.4,59.7,3.2,2.8,1,'gold');p.ellipse(24,y,62,1.25,1.25,'#e5c775','#94723d',.25);}
  for(const y of [83,143]){box(p,24.2,y-5,49,1,10,7.6,'green');wallImage(p,'crest','left',y,25.3,52.8,8.8,5.65);}
 }
 function pipes(p){
  const a=layout();
  for(const m of a.mounts){wallBox(p,m.axis,m.u-2,7.8,m.z-2,4,.8,4,'green');wallBox(p,m.axis,m.u-1,8.6,m.z-1,2,3,1.5,'gold');}
  const b=a.service;box(p,b.x0,b.y0,b.z0,1,b.y1-b.y0,b.z1-b.z0,'green');box(p,9,174,65,6,12,12,'gold');
  for(const z of [65,76.4])box(p,8.8,173.6,z,6.5,12.8,.7,'gold');
  CityHallClockBay.paperPipe(p,a.pipe);
  const q=CityHallProjection.project(15.4,180,71),c=p.c;c.save();c.transform(-1,.5,0,1,q.x,q.y);c.beginPath();c.arc(0,0,3.4,0,Math.PI*2);c.fillStyle='#d4af58';c.fill();c.strokeStyle='#8c6d39';c.lineWidth=.45;c.stroke();c.beginPath();c.arc(0,0,2.6,0,Math.PI*2);c.fillStyle='#f6eacc';c.fill();for(let i=0;i<8;i++){const a=i*Math.PI/4;c.beginPath();c.moveTo(Math.sin(a)*1.9,Math.cos(a)*1.9);c.lineTo(Math.sin(a)*2.3,Math.cos(a)*2.3);c.strokeStyle='#335d4c';c.lineWidth=.2;c.stroke();}c.beginPath();c.moveTo(0,0);c.lineTo(-.6,-1.7);c.lineWidth=.35;c.stroke();c.restore();
 }
 function lamps(p){
  for(const {axis,u,z}of layout().lamps){
   const at=(a,d,h)=>point(axis,a,d,h);
   wallBox(p,axis,u-1.7,8,z+7,3.4,1.2,4,'gold');wallBox(p,axis,u-.6,9,z+9,1.2,7,1.3,'gold');p.line(at(u,15,z+9),at(u,15,z+6),'#d3aa52',.85);
   const a=at(u-2,13,z-1);p.box(...a,4,4,6,['#fff0b5','#ffe19b','#ebc576']);
   for(const du of [-2,2])for(const d of [13,17])p.line(at(u+du,d,z-1),at(u+du,d,z+5),'#a87932',.45);
   wallBox(p,axis,u-2.4,12.6,z-1.5,4.8,4.8,.8,'gold');wallBox(p,axis,u-2.5,12.5,z+5,5,5,.7,'gold');
   p.face([at(u-2.5,12.5,z+5.7),at(u+2.5,12.5,z+5.7),at(u,15,z+7.3)],'#efce78','#c09542',.2);p.face([at(u+2.5,12.5,z+5.7),at(u+2.5,17.5,z+5.7),at(u,15,z+7.3)],'#b98d41','#c09542',.2);
  }
 }
 function roof(p,L){
  const ribs=L.vault.ribs;
  for(let k=0;k<ribs.length-1;k++)for(let i=0;i<40;i++)p.face([ribs[k][i],ribs[k][i+1],ribs[k+1][i+1],ribs[k+1][i]],i%5===0?'#fff2d82b':'#ebedcf1f',null);
  for(const rib of ribs){
   for(let i=0;i<rib.length-1;i++){
    const a=rib[i],b=rib[i+1],a0=[a[0],a[1]+1.2,a[2]-1],b0=[b[0],b[1]+1.2,b[2]-1],a1=[a[0],a[1]+1.2,a[2]+2],b1=[b[0],b[1]+1.2,b[2]+2];
    face(p,[a0,b0,b1,a1],'stone',-.04);face(p,[a1,b1,[b[0],b[1]-1.2,b[2]+2],[a[0],a[1]-1.2,a[2]+2]],'stone',.13);p.line(a0,b0,'#315b49',.9);p.line(a1,b1,'#fff4db',.45);
    if(i%10===0)p.line(a0,a1,'#c3ab79',.45);
   }
   for(const a of [rib[0],rib.at(-1)]){box(p,a[0]-2,a[1]-2,135,4,4,2.5,'green');box(p,a[0]-2.4,a[1]-2.4,137.5,4.8,4.8,.7,'gold');}
  }
  for(let i=0;i<=40;i+=4){p.line(ribs[0][i],ribs.at(-1)[i],'#b8a98c',1);const a=ribs[0][i],b=ribs.at(-1)[i];p.line([a[0],a[1],a[2]+.55],[b[0],b[1],b[2]+.55],'#f3e7ce',.7);}
  for(let y=56;y<192;y+=12){p.face([[0,y,138],[20,y,144],[20,y+12,144],[0,y+12,138]],'#e5e9cf27','#e8dec6',.7);box(p,-.5,y,136.6,2,1.3,2.2);}
  p.line([20,55,144],[20,192,144],'#ac9877',2.5);p.line([20,55,145],[20,192,145],'#f5e9d0',1.5);p.line([0,55,138],[0,192,138],'#f5e9d0',2);
 }
 function texture(p,pts,shade=0){
  const c=p.c,a=CityHallProjection.project(...pts[0]),b=CityHallProjection.project(...pts[1]),d=CityHallProjection.project(...(pts[3]||pts[2]));c.save();c.beginPath();path(c,pts);c.clip();c.transform(b.x-a.x,b.y-a.y,d.x-a.x,d.y-a.y,a.x,a.y);c.drawImage(p.images['vault-slate'],0,0,1,1);if(shade){c.globalAlpha=Math.abs(shade);c.fillStyle=shade>0?'#fff3d5':'#203b36';c.fillRect(0,0,1,1);}c.restore();
 }
 function facadeWindow(p,axis,u,d,z,w,h){
  const at=(a,b,dep=d+.4)=>point(axis,a,dep,b),r=w/2,mid=u+r,s=z+h-r;
  p.face(arch(axis,u,u+w,z,z+h,d+.1),'#3e625b','#b6a488',1.2);p.face(arch(axis,u+.8,u+w-.8,z+.7,z+h-.8,d+.3),'#a1aea0',null);
  for(const a of [u-.8,u+w])wallBox(p,axis,a,d,z-.5,.8,1.4,h-r+1);
  for(let i=0;i<10;i++){const a=i*Math.PI/10,b=(i+1)*Math.PI/10,pp=(q,rad)=>at(mid+Math.cos(q)*rad,s+Math.sin(q)*rad,d+1.4);face(p,[pp(a,r+.8),pp(b,r+.8),pp(b,r),pp(a,r)],'stone',-.04);}
  p.line(at(mid,z+.8),at(mid,z+h-.6),'#f3e7cd',.6);p.line(at(u+.6,z+h*.52),at(u+w-.6,z+h*.52),'#f3e7cd',.6);wallBox(p,axis,u-1,d-.4,z-1,w+2,2.4,1.5);wallBox(p,axis,mid-.7,d,z+h-.6,1.4,1.8,2);
 }
 function building(p,b,index){
  const x=b.x0,y=b.y0,w=b.x1-x,d=b.y1-y,z=b.z0,h=b.z1-z;
  p.shadow(x+w*.5+6,y+d*.5+5,z,w*.9,d*.55,.2);box(p,x-5,y-5,-14,w+10,d+10,2);box(p,x,y,z,w,d,h);
  for(const [axis,start,len,depth]of [['rear',x,w,y+d+.03],['left',y,d,x+w+.03]])for(let k=z;k<b.z1;k+=8)for(let u=start;u<start+len;u+=16){const end=Math.min(start+len,u+16),top=Math.min(b.z1,k+8),at=(v,q)=>point(axis,v,depth,q);face(p,[at(u,top),at(end,top),at(end,k),at(u,k)],'stone',axis==='left'?-.12:.025);p.line(at(u,k),at(end,k),'#b3a183',.18);if(k<z+24)p.line(at(u,k),at(u,top),'#b3a183',.18);}
  for(let k=z+4;k<b.z1-12;k+=23){for(let u=x+8;u<x+w-8;u+=18)facadeWindow(p,'rear',u,y+d,k,10,17);for(let u=y+8;u<y+d-8;u+=18)facadeWindow(p,'left',u,x+w,k,10,17);}
  for(const a of [x,x+w-3])box(p,a,y+d-.4,z,3,1.8,h);for(const a of [y,y+d-3])box(p,x+w-.4,a,z,1.8,3,h);
  for(const k of [z+24,z+47,b.z1-2]){box(p,x-1,y+d-1,k,w+2,2,1.5);box(p,x+w-1,y-1,k,2,d+2,1.5);}
  box(p,x-2,y-2,b.z1,w+4,d+4,2.5);box(p,x-3,y-3,b.z1+2,w+6,d+6,1.3);
  for(let u=x+2;u<x+w;u+=6)box(p,u,y+d+1,b.z1-1.5,2,1.8,1.7);
  const m=y+d*.5,ridge=b.z1+19;
  texture(p,[[x-3,y-3,b.z1+3],[x+w+3,y-3,b.z1+3],[x+w-5,m,ridge],[x+5,m,ridge]],.13);
  const pos=(u,t)=>[x-3+8*t+(w+6-16*t)*u,y+d+3-(d*.5+3)*t,b.z1+3+16*t];
  for(let k=0;k<6;k++)for(let j=0;j<10;j++){const u=j/10,v=(j+1)/10,t=k/6,tt=(k+1)/6;texture(p,[pos(u,t),pos(v,t),pos(v,tt),pos(u,tt)],((j*3+k*2+index)%5-2)*.025);p.line(pos(u,t),pos(v,t),'#4d6c65',.25);if(k%2===j%2)p.line(pos(u,t),pos(u,tt),'#a2b2a1',.22);}
  texture(p,[[x+w+3,y-3,b.z1+3],[x+w+3,y+d+3,b.z1+3],[x+w-5,m,ridge]],-.13);
  p.line([x+5,m,ridge],[x+w-5,m,ridge],'#c4c9af',1.1);
  for(const u of [x+13,x+w-18]){box(p,u,m-3,ridge-5,5,5,12,'wood');for(let k=0;k<4;k++)p.line([u,m+2.1,ridge-3+k*2.7],[u+5,m+2.1,ridge-3+k*2.7],'#beaa88',.22);box(p,u-1,m-4,ridge+6,7,7,1.2);}
  const door=x+w*.5-5;face(p,[[door,y+d+.5,z+19],[door+10,y+d+.5,z+19],[door+10,y+d+.5,z],[door,y+d+.5,z]],'green',-.12);p.line([door+5,y+d+.6,z],[door+5,y+d+.6,z+18],'#cfbb88',.6);box(p,door-3,y+d,z-1,16,6,1);face(p,[[door-4,y+d+.7,z+21],[door+14,y+d+.7,z+21],[door+5,y+d+.7,z+28],[door+5,y+d+.7,z+28]],'stone',.06);
 }
 return {layout,windows,column,gallery,rail,pipes,lamps,roof,building};
});
