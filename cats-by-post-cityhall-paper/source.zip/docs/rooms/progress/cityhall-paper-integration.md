# Great Postal Vault integration contract

Base: 923b40d7c3ef2b9e4fab49d290267f0094a1a9bb. Room: cityhall, 6-1–6-15.
This is an implementation proposal for the integration owner. No shared manager,
camera, interface, rules, production build or other room has been edited.

`CityHallPaper.createCityHallPaper(host)` receives:

- `renderer`: CityHallRenderer with load/prepare/draw/dispose/resources.
- `read(out)`: fill the reused frame with immutable level, turns, traces,
  gateTrace, originX/Y, time, sceneTime, mode, selected/partner, gray/motion,
  and a reused chapter payload (mode/frame/stage/demo/growth/dispatch).
- `viewport`: reused CSS dimensions, DPR, view and camera options.
- `check()`: throw if this installation was superseded.
- `install(presentation)`: install host output hooks and return restoration.
- `subscribe(refresh)`: subscribe to preferences and return unsubscription.
- optional `invalidate()`: request a host frame.

The adapter returns mount/refresh/draw/capture/dispose/resources. It never picks
a level, places an answer, advances progress or changes canonical trace origins.
The manager must provide real CP/HC chapter payloads and keep its existing input
and save ownership. Geometry/picking must use the same returned camera. Room
return must restore the previous output and camera. Do not install the standalone
study toolbar or its diagnostic fixture actions in production.

Measured dimensions, resource counts and verification evidence follow. No
production installation is claimed.

## Measured implementation

Hall 224×192; tile16; galleryz46; vault spring138/crown180. All floor and
picking use (x−y, (x+y)/2−z). The world-origin board is64,64 for the full Hall;
read the supplied chapter/demo origin rather than assuming it in the manager.
Exterior pavementz−12 meets the plinth; six2-unit risers reach floorz0.
Near town geometry and distant skyline share the window registration.

Load module order from studies/cityhall-paper/build.py. Assets/manifest.json
binds source art and registration; resolve/decode those images before mount.
One additional foreground exterior bake prevents the hall's base from hiding
the connected steps and lamps. Board layers remain independent of the town.
At1440×1000, DPR1, the implementation owns51canvas backing stores /65,915,080bytes,
including9static bakes and carrier caches. The real disposal check reaches zero.
This excludes decoded images, canonical host, browser/GPU copies and process
peak. The host must qualify its total memory and frame budget before integration.

The standalone host validates15real wins and all three sizes; desktop/phone/
landscape, trusted pointer/keyboard/touch, resize cancellation, private saves,
reduced motion, all chapter boundaries and both adjacent-room transitions.
Production bridge installation and physical Safari remain unqualified.

Swift/Metal proposal: immutable measured volumes and per-room vertex geometry;
one shared projection/picking transform; retained texture/registration tables;
preallocated trace samples; local tunnel aperture masking; canonical scene clock
and explicit mount/cancel/dispose lifecycle. Do not port the diagnostic host UI
or replace the real game rules with study fixtures.
