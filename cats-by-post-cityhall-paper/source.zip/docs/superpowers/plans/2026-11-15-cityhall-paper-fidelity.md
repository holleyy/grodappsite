# City Hall Great Postal Vault Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans
> to implement this plan task-by-task after the user approves it. Steps use
> checkbox (`- [ ]`) syntax for tracking. Execution was subsequently authorised.

**Goal:** Deliver a playable, room-owned City Hall paper presentation matching
selected Great Postal Vault, with every existing Hall delivery and chapter state.

**Architecture:** Plain JavaScript Canvas presentation reading the canonical
engine's state/traces, following the existing Office separation. Room-owned
measured geometry, art, scene caches, live pieces and actor rigs share one
projection. A local build wraps the canonical host for standalone review;
production manager/camera/build integration is a documented proposal, not a
shared-code edit.

**Tech Stack:** Existing JavaScript, Canvas 2D, Node's test runner, Python 3 with
existing Pillow tooling, Chromium/Playwright for browser verification. No new
runtime dependency, remote font, image request or framework.

**Spec:** `docs/superpowers/specs/2026-11-15-cityhall-paper-design.md`.

## Global Constraints

- Base `923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`, existing isolated branch
  `codex/cityhall-paper-fidelity`; preserve original checkout and other rooms.
- Own `6-1`–`6-15`, board sizes 7×5, 7×6 and 8×6; preserve canonical data,
  inventory, solutions, 300 ms ticks, timing, progress and save formats.
- Keep exact 2:1 orthographic projection: one 16×16 world tile projects to 32×16.
- Never edit canonical source/art/hash baselines, `sorting_office.html`, native,
  other room assets or generated `web/rooms/*.js`; no shared build/UI/camera edits.
- No production adapter policy that selects levels, fills answers, changes saves
  or advances chapters. Private study namespace only:
  `catsByPost.cityhallPaper.study.v1`.
- No per-frame allocations in owned animation/render paths; prepare/reuse objects
  and caches at level/layout/load boundaries.
- Preserve all existing previews. The later user grant authorises work in grodappsite; prepare an isolated City Hall review packet. Source integration/merge remains separate.
- Execution authorised by the user: “Ok lets do it”.

## Review Focus

1. A resize, result footer or chapter overlay must not shift the board under a
   held pointer or during cat travel: measured camera and pick tests in Tasks 2/5.
2. Several cats can use the same/opposite tunnel in one tick: independent local
   entry/exit draws and no between-endpoint interpolation in Task 3.
3. Demo/growth/replay/departure must leave suspended live state and earned result
   intact: real controller/state snapshots in Task 5.
4. A cancelled decode or room return must not install stale artwork/hooks or
   leak motion listeners/caches: lifecycle tests in Tasks 1/6.
5. An ambient cat or parcel must not exist twice during an outing/handoff:
   ownership, scale/contact and wrap/reduced-motion tests in Task 4.

## File map and contract

New source under `src/fidelity/cityhall-paper/`:

| File | Responsibility |
|---|---|
| `README.md` | rendering contract, provenance and reproduction |
| `projection.js` | project/inverse, tile picking and uniform camera transform |
| `layout.js` | measured room solids, supports, routes, bounds and attachments |
| `architecture.js` | static surfaces, vault ribs, glazing and furniture layers |
| `backdrop.js` | civic square, skyline layers and consistent window apertures |
| `materials.js` | paper stock, edge and light preparation, no rule data |
| `pieces.js` | registered board pieces, carriers and local tunnel effects |
| `actors.js` | original staff/cat identities, rigs and attached props |
| `motion.js` | deterministic scene sampling into caller-owned outputs |
| `renderer.js` | prepared layers and depth-ordered live draw, no game session |
| `adapter.js` | read-only host frame mapping and reversible lifecycle |
| `assets/manifest.json` | source, rights, dimensions, anchors, states and hashes |

New study under `studies/cityhall-paper/`: `build.py`, `study.js`, `study.css`,
`index.html` (standalone generated REVIEW output), `verify.cjs` and `README.md`.
`study.js` is an adapter/diagnostic harness, not another simulator/session.

Tests under `tests/cityhall-paper-{contract,geometry,pieces,motion,lifecycle}.test.js`.
Review files under `docs/review-images/cityhall-paper/implemented/`.
Integration proposal under `docs/rooms/progress/cityhall-paper-integration.md`;
ongoing ledger/handoff stays `cityhall-paper-handoff.md`.

Proposed renderer interface, defined once for all tasks:

- `CityHallProjection.project(x,y,z=0) -> {x,y}`; units canonical world units.
- `CityHallProjection.unproject(px,py,z=0) -> {x,y}`.
- `CityHallProjection.pick(px,py,board,camera) -> {x,y}|null`; board includes
  origin and authored width/height; points are relative to the scene viewport.
- `CityHallLayout.create() -> Layout`; cached solids, attachments, surfaces,
  scene bounds and presentation routes, separate from canonical CITYR.
- `CityHallRenderer(canvas, assets, layout)`; `load()`,
  `prepare(frame, viewport)`, `draw(frame)`, `dispose()`, `resources()`.
- Reused `PresentationFrame`: `level`, `turns`, `traces`, `gateTrace`, `time`,
  `sceneTime`, `selected`, `partner`, `gray`, `motion`, `chapter`.
  `chapter` has `mode`, `frame`, `stage`, `demo`, `growth`, `dispatch`; payloads
  come from existing CP/HC/CITYCHAPTER, not an owned progression controller.
- `createCityHallPaper(host) -> {mount, refresh, draw, dispose, resources}`.
  `host` supplies authoritative state/viewport/camera mapping and lifecycle
  cancellation checks. Adapter reads existing state, never creates a simulator.
  Final production binding to the existing manager is integration-owned.
- `CityHallMotion.makeOut()` and `sample(sceneTime, chapter, out)` reuse all
  objects/arrays. Scene time cannot affect rule time or vice versa.

### Task 1: Establish preservation baseline and a usable presentation boundary

**Files:** create `README.md`, `adapter.js`, asset manifest and integration
proposal; add contract/lifecycle tests. Source paths refer to the directory above.

**Interfaces:** consumes unchanged canonical modules/levels, current manager
contract and selected image; produces `PresentationFrame` mapping and
`createCityHallPaper(host)` lifecycle seam.

- [x] Inspect current branch/status/worktree and record any newly fetched main
  separately; never silently replace the recorded base or someone else's edits.
- [x] Rerun the previously failing test FILES after the restored sparse paths.
  First run log is retained. If anything still fails, classify its actual cause
  before any edits; do not patch shared tests, reference hashes or game code.
- [x] Run `npm test > work/cityhall-paper-baseline.log 2>&1` on the restored
  baseline. Expected complete run with zero failures. If an unrelated genuine
  main failure remains, report its exact evidence and keep it separate.
- [x] Record SHA-256 of canonical source/level/save/controller files, frozen
  playable, selected image and all reused art. Enumerate current Hall assets
  without modifying historical preparers or re-generating old masters.
- [x] Write failing contract tests: adapter cannot change frozen level/traces;
  repeated capture reuses outputs; dispose restores references/removes listeners;
  cancelled mount cannot publish stale state. Run and observe the missing-module
  or actual behavioural failure.
- [x] Implement the narrow read-only mapping/lifecycle seam and asset manifest.
  Use one authoritative controller; no `CivicSession` copy. Run those tests green.
- [x] Write the integration proposal: owner supplies state/viewport mapping,
  renderer returns its canvas/resource metadata, manager handles restoration.
  Include supported deliveries, scene bounds and chapter requirements. No shared
  edits are needed to start the independent study.
- [x] Commit only owned planning/reference/contract files after checks. Record
  base and exact baseline results in handoff.

### Task 2: Prove the vault, board and backdrop composition in measured geometry

**Files:** create `projection.js`, `layout.js`, `architecture.js`, `backdrop.js`,
`materials.js`, geometry tests and the minimal room-owned study build/bootstrap.

**Interfaces:** consumes Task 1 lifecycle/frame seam; produces `Layout`,
projection/picking and prepared architecture/backdrop layers for the renderer.

- [x] Write geometry tests for project/inverse round trips, both tile-axis slopes,
  all centres/corners/outside-boundary picks for all 15 boards and all target
  viewport transforms. Include portrait/landscape resize and DPR 1/2.
- [x] Test real volumes: supports touch receiving surfaces; stair treads join
  landing/open rail and free approach; every vault rib lands on its beam;
  furniture/doors and projected scenery avoid board cores; pipe/palm and route
  envelopes do not intersect. Run tests red before layout implementation.
- [x] Implement the single world-unit projection. Start with room 224×192,
  board origin (64,64), gallery z=46; preserve actual per-record board origins.
  Pilot springline z=132–144 and crown z=174–184; freeze final dimensions only
  after first/middle/finale framing evidence. No canonical buffer enlargement.
- [x] Build static construction as actual layered card surfaces. Fit tall windows,
  broad curved vault, L gallery and great clock around the max board. Establish
  an explicit front roof cutaway and real rib/column joints. Keep all lower
  working routes clear. Use existing accepted material sources first.
- [x] Implement civic square/quiet skyline with real glazing apertures and one
  coherent exterior horizon. Protect board value contrast and reduce remote
  detail. Prepare caches outside the frame loop.
- [x] Study build reads/hashes the canonical exported host, adds owned scripts,
  and applies an exact allowlisted namespace substitution before host boot.
  Log every substitution. Never overwrite `sorting_office.html`; output only
  `studies/cityhall-paper/index.html`. Default play is unfilled puzzle; fixtures
  are explicit diagnostic actions.
- [x] Inspect first 7×5, middle 7×6 and 8×6 finale on 1440×1000, 390×844,
  402×874, 844×390 and 1024×600. Capture hall/play views and grayscale. Require
  all board corners, hatches and controls in play frame. Report actual tile hit
  dimensions, not invented touch-target compliance.
- [x] Compare with selected image: vault silhouette, grand scale, clock, colour,
  civic-square setting and board priority. Correct material/composition drift
  before detailed art. Inspect the measured pilot against the selected reference before completing acting.
  A necessary major silhouette/layout departure requires user review.
- [x] Run geometry/contract checks green and commit the owned architecture stage.

### Task 3: Render all existing pieces and prove tunnel clarity

**Files:** `pieces.js`, renderer's board/piece layers, asset manifest entries;
pieces tests and browser fixtures.

**Interfaces:** consumes canonical traces/gateTrace, projection and material
layers; produces registered piece draws with explicit depth/contact anchors.

- [x] Write tests using actual `grCreate/grTick` and `BOARDANIM` traces: both
  tunnel directions, heading retained, next-tick wall/dog bounce, re-entry,
  sequential pairs and same-tick opposite users. Check no drawn pose lies along
  the segment connecting distant endpoints during hidden transit.
- [x] Assert sampled endpoint effects are per-cat/per-endpoint, so one user cannot
  overwrite another. Test all four symbol identities in grayscale and partner
  selection through hover, keyboard and touch modes. Run red first.
- [x] Adapt accepted cat/carrier and mechanism techniques within City Hall.
  Preserve one plane for boxes, arrows, floor contacts and shadows; keep physical
  tunnel hood footprint and inverse picking exact. Use BOARDANIM entry/hidden/
  exit timing; do not interpolate teleport endpoints with generic smooth travel.
- [x] Implement gates/points, dogs, edge flaps, baskets, hatches, placed turns,
  waiting queues and shape-only partner highlight. No scenery pipe joins
  arbitrary board endpoints through playable tiles.
- [x] Add all-15 actual stored-solution checks with `R.grValidate` and `R.grRun`;
  every result must equal `GO_WON`. These are replay/preservation checks, not a
  claim to have re-proven old solver uniqueness/minima.
- [x] Inspect early `6-1`, simultaneous traffic and busiest `6-15` in colour and
  grayscale; capture local entry/exit and front-rim depth. Test every tile centre
  through real browser pointer mapping, not projection unit tests alone.
- [x] Run pieces/geometry/contract tests green; commit the board/tunnel stage.

### Task 4: Complete purposeful staff, cats and atmospheric life

**Files:** `actors.js`, `motion.js`, actor assets/provenance, motion tests and
renderer live scene layers.

**Interfaces:** consumes layout attachments/routes and existing character clocks;
produces caller-owned scene poses and separately owned parcel/prop attachments.

- [x] Write tests for full loop and wrap: swept actor/parcel envelopes clear
  solids; feet touch floors/landings; hands meet grips; parcels keep dimensions;
  transfer/release has one owner; wheels rotate consistently with distance.
- [x] Test cat scale with the same rig dimensions/anchors across sleep/walk/jump;
  active outing empties the rest site; returning restores one cat. Verify
  reduced-motion poses are supported and do not stop the game clock. Run red.
- [x] Fit source personality/timing to the measured room. Retain human postal
  workers, tuxedo Postmistress, roof pigeons and existing cats. Complete parcel
  collection, gauge checks, sorting, carrying and mutual reactions.
- [x] Generate only missing asset families with pilot-first review; record raw
  masters, references, cuts, anchors, frame timing, derived states and checks.
  Avoid scene-wide painted animation or differently scaled pose illustrations.
- [x] Sample smoothly using existing game time for gameplay and a separate
  deterministic ambient clock. Preallocate outputs/draw lists. Prepare texture
  and scene caches at boundaries only.
- [x] Capture short clips of walking, grip/release, wheel contact, Postmistress,
  cat outing/return and reduced motion. Play recordings back to confirm content.
- [x] Run motion/pieces/geometry/contract tests green and commit the acting stage.

### Task 5: Preserve arrival, teaching, growth and departure in the new scene

**Files:** extend `adapter.js`/renderer chapter layers and `studies/cityhall-paper/study.js`;
lifecycle tests and browser chapter scenarios. No canonical controller edits.

**Interfaces:** consumes existing CP/HC/CITYCHAPTER state in the frame; produces
presentation for `intro`, `demo`, `enter`, `growth`, `exit` and ordinary play.

- [x] Snapshot live placements, inventory, attempts, hint/stars/progress and trace
  time before/after replay/cancel of intro/demo/growth/exit. Write failing tests
  that require exact restoration and no unintended rules ticks.
- [x] Render the actual shared three-cat demo, retaining tunnel heading, dog
  bounce, points state and edge-flap destination. No independently simulated cats.
- [x] Render both existing growth stages after actual `6-3`/`6-7` advances,
  sampling the canonical runner clock and revealing 7×6/8×6 inactive floor.
  Live board and hit targets never move under an active run.
- [x] Render final settling/satchel dispatch using canonical dispatch state;
  preserve return to the same completed `6-15` and the Hall→Parcel invitation.
  Keep Train→Hall handoff through real host navigation. A controlled direct
  state fixture may supplement, not replace, end-to-end handoff evidence.
- [x] Test entry/mid-run/result/chapter resize, queued pointer input and focus
  restoration. Use supported static states for reduced motion, retaining clocks.
- [x] Browser-check chapter/demo/both growth/exit and cross-room return on desktop,
  portrait and landscape; no stale art after leaving/returning. Where host
  viewport support is needed, record the small integration proposal rather
  than patching shared camera/interface code.
- [x] Run lifecycle plus affected suites green; commit the chapter presentation.

### Task 6: Qualify the standalone study and resource lifecycle

**Files:** `studies/cityhall-paper/verify.cjs`, study README, evidence reports and
room-owned lifecycle/render checks.

**Interfaces:** consumes complete renderer/adapter/study; produces reproducible
machine-readable verification and matched actual-browser captures.

- [x] Add cancellation/rapid level-change/room-return/zoom/resize/resource tests:
  no stale decode install, no duplicated listeners, stable prepared cache counts
  during warm frames, released references on dispose and accurate census scope.
- [x] Run all 15 actual solutions, all authored board sizes and all centre picks;
  confirm canonical record/hash preservation and private-save isolation from
  normal game storage. Reload an actual private save and verify resume/replay.
- [x] Test desktop/phone portrait/landscape/DPR, grayscale, reduced motion, keyboard
  and touch emulation; console/page errors fail verification. Browser/device
  emulation is never labelled real iPhone/Safari qualification.
- [x] Confirm output HTML loads with network disabled and all art is embedded;
  no web fonts, runtime dependencies or live API calls. Rebuild twice and
  compare bytes/source manifest. Any nondeterministic metadata is excluded
  explicitly, not hidden behind changing baseline hashes.
- [x] Report active canvas/buffer dimensions and bytes, decode/preparation/warm
  timing samples and ownership limits. Do not equate partial census with total
  or peak memory, presented FPS, thermal or hardware performance.
- [x] Run the complete root `npm test` after core implementation, plus focused
  City Hall suites and actual Chromium verifier after the final visual changes. Preserve logs and do not fix
  unrelated shared code to obtain green results.
- [x] Commit verified study/evidence. No production build, deployment or merge.

### Task 7: Review and integration handoff

**Files:** final handoff, integration proposal, `studies/cityhall-paper/README.md`,
asset/source manifests, review gallery and verification summary.

**Interfaces:** consumes verified source/art/runtime and reports; produces the
standalone HTML and explicit integration contract for the integration owner.

- [x] Conduct one fresh whole-change code AND visual review against the selected
  vault image and spec: geometry, board clarity, tunnels, all chapter states,
  motion/contact, lifecycle and ownership. Use a fresh reviewer if available
  under the user-authorised review/delegation scope.
- [x] Classify findings. Correct Critical/Important findings in one bounded pass,
  each with a reproduced failure and passing regression. Re-run affected checks
  and full suite as warranted; record reviewed versus corrected revision.
- [x] Record deferred minor issues, physical-device/performance limits and any
  unimplemented shared integration work without claiming that it already works.
- [x] Package standalone HTML, source/assets/provenance, exact build/source hashes,
  screenshots/clips and concise verification results. Keep captures few, under
  roughly 1 MiB each where practical; preserve clip/asset source provenance.
- [x] Confirm `git diff` touches only owned files and canonical protected hashes
  match. Commit final owned handoff. The later user grant permits an isolated grodappsite
  review packet; no game-source push, merge or existing-preview overwrite.

## Plan review and execution status

Self-review: tasks cover selected vault/backdrop, geometry/picking, actual rules,
all fifteen deliveries, tunnels/points/flaps, original characters/props, smooth
motion, reduced motion, arrival/demo/two growth/departure, private saves, viewport
and resource lifecycle, provenance and integration ownership. No new runtime,
framework or shared source mutation is needed to start the independent study.

The measured pilot settled the vault at spring138/crown180 with a cut-away
front roof, verified across the required viewports. Production camera/manager binding remains
an integration proposal. Execution status: room-owned implementation exists. See the study README and
`docs/rooms/progress/cityhall-paper-handoff.md` for verified results and limits.

## Additional scene requirement, 15 November

The user supplied Town Depot backdrop references during execution. Replace the
provisional square plate with continuous measured ground, connected entrance
steps, neighbouring façades, planting, lamps and fountain. Keep the selected
vault, camera and board projection. Use only distant skyline artwork; all
windows reveal that same world. This is implemented in environment.js and
backdrop.js and verified at wide, board and phone framing.

Tasks 1–6 are implemented and checked. Task 7 is complete: the single fresh Astra review has no actionable findings,
no correction pass was needed, and the final evidence/handoff packet is ready.

Verification ruling: the broad1687-test run completed before the final room-owned
backdrop/compact-layout polish. Canonical sources remain exact; the final23focused,
72browser and26qualification checks cover those later changes. This is reported
explicitly rather than claiming the broad run used the final visual hash.
All three board bake images also match the earlier measured pilot byte-for-byte.
