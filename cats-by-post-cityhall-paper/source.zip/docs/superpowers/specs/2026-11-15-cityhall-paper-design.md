# City Hall paper design · Great Postal Vault

Status: selected design, execution authorised with “Ok lets do it”. The user
selected the SECOND image from the height studies and reviewed the plan before
implementation. The isolated playable study is implemented; final verification
and fresh review are recorded in the handoff.

## Intent and selected visual

Build City Hall as a grand, bright Victorian–Edwardian postal hall with a
sweeping curved glass-card vault, tall arched windows, deep green paper columns,
a supported gallery, an imposing clock and a memorable brass-card tube network.
The civic-square backdrop is part of the composition: fountain, trees and warm
municipal facades nearby; slate rooftops and a distant dome fade into quiet blue
and lavender distance. Exterior views through windows must agree with the
surrounding backdrop's horizon and height.

Selected image: `docs/review-images/cityhall-paper/refinement/great-postal-vault.webp`.
Raw Image Gen master: `exec-7d35a585-6c1a-45f6-8f6d-d368b15eb4d1.png`.
This selection refers to the second HEIGHT study, not the earlier Sorting Arcade
or railway-backdrop option. The image's approximate grid, piece coordinates,
character poses and structural connections are not gameplay or geometry data.

The goal is a reviewable, standalone playable study and a room-owned
presentation implementation covering every existing `6-1`–`6-15` delivery.
It is not a new engine, puzzle chapter, interface redesign or public release.

## Approaches considered

- Taller Civic Hall: elongated arches and columns with the earlier pitched
  roof. Lowest structural complexity, less distinctive sense of volume.
- Great Postal Vault: broad curved ribs and high glazing. Selected by the user;
  strongest grand postal-concourse identity. Costs more upper-screen space and
  needs careful roof cutaway, camera fit, caching and occlusion tests.
- Monumental Lantern Hall: separate high clerestory and raised lantern roof.
  Most imposing silhouette, but more architecture competing with the board.

The implementation proposal is a room-owned Canvas presentation using the
existing Office approach as a reference: measured projected construction,
registered artwork, cached static layers and live pieces/actors. It consumes
canonical state and traces. It never installs the whole generated concept as
one flattened scene behind independently angled pieces.

## Starting evidence and boundaries

Worktree `/workspace/cosysortie-cityhall`, branch
`codex/cityhall-paper-fidelity`, base main
`923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`.
Original checkout and other room work remain untouched.

Existing main already has the entire campaign, paired-tunnel rules, all 15 Hall
solutions, the shared three-cat teaching demonstration, Train→Hall arrival,
growth after `6-3` and `6-7`, and Hall→Parcel departure. Preserve their controllers,
clocks, timing, progress, inventory, hints, attempts, wins and save formats.

Current City Hall presentation is `cityhall-fidelity-527093ea02`, frozen playable
SHA-256 `3bc6f63cf43905af4f706f2b148902297f38ba8bd0fcaf42297ffb055d684236`.
Production extracts a presentation extension from that frozen file. Office now
uses modular source in `src/fidelity/office-paper/`; other rooms do not yet.

The initial full test run had 1,543 passes and 25 failures from an incomplete
sparse checkout, including missing `web/journey` modules and reference JSON.
Those sparse paths were restored before implementation. The clean baseline passed
1,674 tests; the later broad run passed 1,687. See the final handoff for the
subsequent focused/browser checks and their exact scope.

Own new `src/fidelity/cityhall-paper/`, `studies/cityhall-paper/`,
`tests/cityhall-paper-*.test.js`, `docs/review-images/cityhall-paper/` and the
City Hall handoff/design/plan records. Leave other rooms, native code, canonical
art/hash baselines, `sorting_office.html` and generated `web/rooms/*.js` alone.
Shared renderer/camera/room-manager/build/bridge/interface changes, root PLAN and
AGENTS belong to integration. Provide a small adapter proposal with evidence;
production installation is not part of this room branch.

## Measured floor and projection

Use canonical world units throughout: one tile is 16×16. The current Hall floor
is 224×192; maximum board origin is (64,64), extent 8×6 tiles, and gallery is at
z=46. These are verified existing layout values, not inferred from concept art.

One orthographic projection applies to floor, geometry, characters, arrows,
shadows and pointer picking:

    px = x - y
    py = (x + y)/2 - z

Camera adds uniform scale and translation only. Floor inverse at known z:

    x = py + z + px/2
    y = py + z - px/2

A tile projects to 32×16 logical pixels; both grid axes have slopes ±0.5.
Perspective convergence, a frontal trapezoid and a second sprite/box angle are
unacceptable. Board centring is a presentation mapping; canonical coordinates
and traces stay immutable. Preserve authored origins for each record rather
than assuming one origin for demos and puzzles.

Keep the existing board and practical aisle envelope as the layout starting
point. Proposed geometry pilot targets wall springline around z=132–144 and
vault crown around z=174–184, retaining ordinary staff scale and the gallery's
usable height. These are proposed ranges, NOT approved frozen dimensions.
Choose final values from first/max board and viewport evidence in Task 2.

Do not expand the canonical 720×400 world buffers or relax old scene validators.
The independent paper renderer may cache its own measured presentation bounds.
Any host view-metadata change is a narrow integration proposal.

## Architecture and board hierarchy

Use tall cream/duck-egg window bays, layered deep-green column shafts/capitals,
one supported rear L gallery, a large right-wall clock, one clear left stair
and substantial rear sorting furniture. Curved vault ribs are actual thickness
surfaces with endpoints seated on beams/columns; glass-card panels sit in their
ribs. Use an explicit open-front roof cutaway so the roof never hides routes.
The room must read as an interior, not a bare roof terrace.

Construct stepped treads and risers, free bottom approach, a real landing and a
railing opening, connected handrails, supported furniture, accessible doors,
trolley contact and pipe sockets. Decorative tubes run on walls/upper beams;
functional endpoints are independent board pieces at exact authored positions.
Test palms, picture frames, gallery traffic and roof pigeon against pipes.

Papercraft is material and construction: layered edges, folded flanges, matte
stock, restrained fibre, quiet marble veining and soft contact shadows. Avoid
concept-art gold gloss. Reuse accepted art/material masters where suitable;
new generated families must retain raw masters, cuts, anchors, frame metadata,
rights/source notes and checked provenance.

## Board sizes, tunnels and input

Support all three authored sizes: 7×5 (`6-1`–`6-3`), 7×6 (`6-4`–`6-7`),
8×6 (`6-8`–`6-15`). The exact finale contains eight endpoints (four pairs),
three hatches, six cats, two destinations and one points gate.

Circle, square, triangle and diamond must remain recognisable without colour.
Show partner identity for hover, touch selection and keyboard focus through
existing modes. Picking belongs to the actual one-tile footprint, not the drawn
hood or decorative pipes. Local entry, hidden transit and local exit follow
canonical BOARDANIM events; never interpolate a cat across the squares between
partners. Preserve heading, next eligible tick movement, bounce/re-entry rules,
multiple pairs, same-tick/opposite users, gates and edge flaps.

The renderer is presentation-only. Consume real grCreate/grTick traces; do not
run one simulator per cat, reproduce a solution by scripted motion, or change
canonical rule timing (300 ms/tick).

## Host and chapter boundary

`adapter.js` reads state into a reused presentation frame; `renderer.js` draws
it. The frame contains level, placed turns, canonical trace references,
canonical gate trace, selected/partner cells, simulation time, scene time,
grayscale/motion preferences, chapter mode and prepared chapter payload.

The adapter owns presentation mapping only, using reusable trace facades if an
origin adjustment is required. It never edits traces, level objects, saves,
controller clocks, attempts or outcomes. Renderer mount/refresh/dispose and
resource reporting mirror the existing manager lifecycle. Integration retains
camera, gestures, progression and input ownership.

For the standalone study, a room-local bootstrap runs against an unchanged
canonical host bundled from verified source/frozen input. Its isolated namespace
is `catsByPost.cityhallPaper.study.v1`. Any fixture selection/answer prefilling
is explicit review tooling, never normal initial play or production adapter
policy. All chapter demos/growth/departure sample existing CP/HC/CITYCHAPTER
state, not a new parallel story system.

Required presentations: arrival/entry and optional teaching; both runner-growth
reveals on inactive floors; final settling and accepted satchel departure; return
to the same finished board; retained Train and Parcel navigation. Preparing a
chapter must not mutate the suspended live puzzle. No test-only progression
fixture is described as a real cross-room handoff.

## Staff, cats and timing

Retain human uniformed staff, ordinary tuxedo Postmistress, existing cat coats,
roof pigeons and the room's other existing personalities. Begin with current
source routes and timing, fitting new construction around them. Presentation
retargeting, if needed for the new gallery/roof, must be explicit and clearance
tested; never feed retargeted positions into rules or chapter progression.

Finish smooth travel, planted feet, hands meeting grips, shape-preserving
parcels, visible releases and rolling wheels. Use one rig/anchor scale for each
cat across sleep, walk, crouch and jump. An outing renders the resting place empty.
Keep ambient routes out of gameplay and provide grounded reduced-motion poses.
Scenery motion and preferences cannot pause or accelerate canonical puzzle time.

## Framing, backdrop and resources

Study desktop target: 1440×1000; portrait: 390×844 and 402×874; landscape:
844×390; short desktop: 1024×600. Also check DPR 1/2 and resize mid-run.
Use full-hall view to establish grandeur; play view reserves the complete board,
hatch approaches, destinations and controls, allowing upper roof to crop.
Do not make the board tiny to keep the roof visible. No claim that every tile
has a 44-pixel touch target: report actual projected hit dimensions and test
picking directly. Production camera behaviour remains integration-owned.

Backdrop has sky/far/near layers, restrained scenic movement and consistent
window apertures, with quieter values and detail than the board in colour and
grayscale. Its horizon must remain coherent under pan/zoom. No scenic person,
plant, base facade or roof rib intrudes onto a playable tile core.

Bake static architecture/material/board variants at preparation/resize
boundaries; reuse animation outputs and draw lists. Do not decode every room or
rebake scenery per frame. Record cache bounds, densities, bytes, resource
ownership and mount/dispose results. Custom buffer/canvas accounting excludes
process peak and decoded/GPU memory unless actually measured. Cloud timings
are not iPhone Safari/Metal/FPS/thermal qualification.

## Completion and review

Deliver one standalone offline playable HTML, room-owned source and assets,
source/asset hashes, matched first/middle/finale and grayscale/mobile captures,
short verified motion clips, actual-rule results for all 15 solutions, chapter
and input results, known limits and a concise integration handoff. Run one fresh
whole-change code/visual review, then one bounded correction pass for blockers;
record remaining minor issues and exact reviewed/fixed revisions.

Do not merge, deploy, push to a public preview or select a publication prefix.
Return the plan for user review before implementation, as explicitly requested.
