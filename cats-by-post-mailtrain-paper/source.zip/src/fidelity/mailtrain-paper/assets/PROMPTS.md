# Mail Train asset provenance

Generated with the available image-generation tool during the authorised
Valley Mail implementation. Original returned PNG masters are retained here;
SHA256 values and active filenames are recorded in `manifest.json`. WebP files
are packed review assets. The descriptions below summarise generation intent;
they are not represented as verbatim transcripts of the prompts.

| Asset | Generation intent and use |
|---|---|
| paper-stock | Flat, evenly lit handmade paper albedos: warm wood, dark teal card, cream paper, warm bridge stone, brass and slate. Six crops mapped onto actual projected faces. No baked object perspective. |
| countryside | Rich layered paper sunset river valley, purple distant hills, warm village/church windows, large bank trees, textured rippling water and reflected light. This is the original landscape Alex asked to preserve. |
| worker | Eight isolated paper-cutout poses on a transparent4×2 atlas: sort hold/place, tea rest/sip, watch, two walks and seated Postmistress. Explicit crop/root anchors are in worker.json. Corrected transparent master is retained. |
| foreground-mask | Luminance mask aligned to the original countryside, selecting the near banks/large trees. Only its alpha is used; all foreground colours are copied from the original countryside image. |
| countryside-far | Alternate distant-only valley experiment, inactive after feedback. |
| foliage | Isolated paper foliage experiment for the discarded procedural-bank version; inactive. |

Active bundle: paper-stock, countryside, worker, foreground-mask and acting.
The alternate countryside-far/foliage assets and landscape.js are excluded from
build-study.py. They are retained as history, not selected visual assets.

`acting.webp` and `acting.json` are exact read-only copies from the approved
Sorting Office foundation. Both original and imported files have the manifest
hashes. Original Office source/assets remain unchanged. Room-owned acting.js
adapts its read-only pose sampling; takeoff preserves its explicit hind-sole
anchors and .4s supported hold/.2s flight. The original board animation supplies
action/release/deadline semantics.

Earlier generated composition art has separate provenance in
`studies/mailtrain-paper/concept-provenance.md`; it is not runtime geometry.

Geometry follow-up: registration.js derives room-local basket contact/near-wall
surfaces from the exact copied acting atlas. Column heights use the accepted
.78 presentation factor; straight blue contact edges are registered to±.5,
with original rounded contour retained. No source pixels/files were repainted.
Full-resolution512px material samples are retained for prepared solids, while
128px world-pattern tiles remain unchanged.

Walking-direction correction,15 November2026: `worker-front.webp` supplements
rather than replaces the original worker atlas. The first retained master
`exec-bbb1d436-8edb-4078-88be-e0a4c3a9b863.png` was generated using worker.webp
as reference, requesting the same uniform, materials, satchel and character in
front-facing southeast walking steps. Its two steps did not sufficiently differ;
only its first cutout is used. The second used master
`exec-35afd730-e7f2-491a-b234-35c066ab9503.png` requests one matching passing
step, with shoes close below the hips and the same satchel hand. Other generation
attempts remain outside the active asset bundle. Transparent masters retain
original pixels; pack-worker-front.py only crops/scales and records ground-root
anchors. The new pair plus mirroring covers travel towards the viewer; the
original rear pair covers travel away. No original atlas is repainted.
