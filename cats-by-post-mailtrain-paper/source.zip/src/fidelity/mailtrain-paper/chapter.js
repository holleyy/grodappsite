/* The existing chapter clock supplies the shunt; only its visual staging changes. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MailtrainChapter=factory();})(globalThis,function(){'use strict';
 function makeOut(){return {headOffset:0,tailOffset:0,joint:3,phase:3,entry:1,worldMoving:true,station:{approach:0,joint:3,bump:0,phase:3,lightFrame:0}};}
 function sample(f,canonical,o){o.headOffset=0;o.tailOffset=0;o.joint=3;o.phase=3;o.entry=1;o.worldMoving=f.chapterMode!=='station';if(f.chapterMode==='station'){canonical.station(f.stationStage,f.chapterFrame,o.station);o.headOffset=-o.station.approach/16;o.joint=o.station.joint;o.phase=o.station.phase;}if(f.chapterMode==='enter'){const u=Math.max(0,Math.min(1,f.chapterFrame/72));o.entry=u*u*(3-2*u);}return o;}
 return {makeOut,sample};
});
