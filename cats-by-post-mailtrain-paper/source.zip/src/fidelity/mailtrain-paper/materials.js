/* Texture albedos on complete projected faces; no painted camera baked into props. */
(function(root){'use strict';
class Painter{
 constructor(ctx,camera,assets){this.c=ctx;this.cam=camera;this.assets=assets;this.stroke='#65432b40';this.meshMode=false;this.patterns={};this.solids=new Map();if(assets.stockTiles)for(const name of Object.keys(assets.stockTiles))this.patterns[name]=ctx.createPattern(assets.stockTiles[name],'repeat');}
 solid(model,x=0,y=0,z=0,maxScale=Infinity){const density=Math.min(3,Math.max(1,this.c.getTransform().a),maxScale/this.cam.scale),scale=this.cam.scale*density;let entry=this.solids.get(model);
 if(!entry||entry.scale!==scale){const r=MailtrainEngine.raster(model,scale,this.assets),surface=entry?entry.surface:document.createElement('canvas');surface.width=r.width;surface.height=r.height;surface.getContext('2d').putImageData(new ImageData(r.pixels,r.width,r.height),0,0);entry={surface,scale,left:r.left,top:r.top};this.solids.set(model,entry);}
 this.c.drawImage(entry.surface,this.px(x,y)+entry.left/density,this.py(x,y,z)+entry.top/density,entry.surface.width/density,entry.surface.height/density);
 }
 preparedSolid(model,x=0,y=0,z=0){const e=this.solids.get(model),density=e.scale/this.cam.scale;this.c.drawImage(e.surface,this.px(x,y)+e.left/density,this.py(x,y,z)+e.top/density,e.surface.width/density,e.surface.height/density);}
 px(x,y){return this.cam.x+(x-y)*this.cam.scale;}py(x,y,z){return this.cam.y+((x+y)*.5-z)*this.cam.scale;}
 v(x,y,z,first){if(first)this.c.moveTo(this.px(x,y),this.py(x,y,z));else this.c.lineTo(this.px(x,y),this.py(x,y,z));}
 quad(x,y,z,a,b,d,e,f,g,h,i,j,mat,shade=0){
 const c=this.c;c.beginPath();this.v(x,y,z,true);this.v(a,b,d);this.v(e,f,g);this.v(h,i,j);c.closePath();
 if((this.meshMode||mat==='meadow'||mat==='river')&&this.patterns[mat]){c.fillStyle=this.patterns[mat];c.fill();}
 else if(mat&&this.assets['paper-stock'].rects[mat]){
 const r=this.assets['paper-stock'].rects[mat],sx=this.px(x,y),sy=this.py(x,y,z),ax=this.px(a,b)-sx,ay=this.py(a,b,d)-sy,bx=this.px(h===x&&i===y&&j===z?e:h,h===x&&i===y&&j===z?f:i)-sx,by=this.py(h===x&&i===y&&j===z?e:h,h===x&&i===y&&j===z?f:i,h===x&&i===y&&j===z?g:j)-sy;
 c.save();c.clip();c.transform(ax/r[2],ay/r[2],bx/r[3],by/r[3],sx,sy);c.drawImage(this.assets['paper-stock'].image,r[0],r[1],r[2],r[3],0,0,r[2],r[3]);c.restore();
 }else{c.fillStyle=mat||'#ead4ae';c.fill();}
 if(shade){c.save();c.fillStyle=shade>0?'#152b33':'#fff0cc';c.globalAlpha*=Math.abs(shade);c.fill();c.restore();}
 if(!this.meshMode){c.strokeStyle=this.stroke;c.lineWidth=Math.max(.4,this.cam.scale*.009);c.stroke();}
 }
 plane(x,y,z,w,d,m,shade=0){this.quad(x,y,z,x+w,y,z,x+w,y+d,z,x,y+d,z,m,shade);}
 box(x,y,z,w,d,h,m,front=m,side=front){this.quad(x+w,y,z,x+w,y+d,z,x+w,y+d,z+h,x+w,y,z+h,side,.23);this.quad(x,y+d,z,x+w,y+d,z,x+w,y+d,z+h,x,y+d,z+h,front,.1);this.plane(x,y,z+h,w,d,m,-.04);}
 line(x,y,z,a,b,d,col='#eed6a6',width=.025){const c=this.c;c.beginPath();this.v(x,y,z,true);this.v(a,b,d);c.strokeStyle=col;c.lineWidth=Math.max(.5,this.cam.scale*width);c.stroke();}
 disk(x,y,z,r,col,stroke){const c=this.c;c.beginPath();c.ellipse(this.px(x,y),this.py(x,y,z),r*this.cam.scale*1.414,r*this.cam.scale*.707,0,0,Math.PI*2);c.fillStyle=col;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=this.cam.scale*.04;c.stroke();}}
 cylinder(x,y,z,r,h,col,top='brass',segments=16){for(let n=0;n<segments;n++){const a=n*Math.PI*2/segments,b=(n+1)*Math.PI*2/segments;if(Math.cos((a+b)*.5)+Math.sin((a+b)*.5)<0)continue;const xx=x+Math.cos(a)*r,yy=y+Math.sin(a)*r,bx=x+Math.cos(b)*r,by=y+Math.sin(b)*r;this.quad(xx,yy,z,bx,by,z,bx,by,z+h,xx,yy,z+h,col,.08+Math.max(0,Math.cos(a))*.18);}this.disk(x,y,z+h,r,top==='brass'?'#e7bb62':top,'#ab8055');}
 sprite(sheet,name,x,y,z,height,mirror=false){const a=this.assets[sheet],s=a.sprites[name];if(!s)return;const c=this.c,r=s.rect,H=height*this.cam.scale,W=H*r[2]/r[3],u=s.anchor?s.anchor[0]:.5,v=s.anchor?s.anchor[1]:1;c.save();c.translate(this.px(x,y),this.py(x,y,z));if(mirror)c.scale(-1,1);c.drawImage(a.image,r[0],r[1],r[2],r[3],-u*W,-v*H,W,H);c.restore();}
 anchored(sheet,name,x,y,width,u,v,mirror=false){const a=this.assets[sheet],r=a.sprites[name].rect,h=width*r[3]/r[2],c=this.c;c.save();c.translate(x,y);if(mirror)c.scale(-1,1);c.drawImage(a.image,r[0],r[1],r[2],r[3],-u*width,-v*h,width,h);c.restore();}
 contact(x,y,z,w,d,alpha=.15){const c=this.c;c.save();c.globalAlpha*=alpha;this.plane(x,y,z,w,d,'#302923');c.restore();}
 shadow(x,y,z,rx,ry,alpha=.16){const c=this.c;c.save();c.globalAlpha*=alpha;c.beginPath();c.ellipse(this.px(x,y),this.py(x,y,z),rx*this.cam.scale,ry*this.cam.scale,0,0,Math.PI*2);c.fillStyle='#302923';c.fill();c.restore();}
 text(x,y,z,text,size=.18,col='#f8e9c5'){const c=this.c;c.fillStyle=col;c.font='600 '+Math.max(6,size*this.cam.scale)+'px Georgia';c.textAlign='center';c.fillText(text,this.px(x,y),this.py(x,y,z));}
}
// Prepared fixtures collect the same face primitives, then resolve per-pixel depth.
class Mesh{
 constructor(){this.faces=[];}
 quad(x,y,z,a,b,d,e,f,g,h,i,j,mat,shade=0){this.faces.push({priority:this.faces.length,v:[[x,y,z],[a,b,d],[e,f,g],[h,i,j]],mat,shade});}
 plane(...args){Painter.prototype.plane.apply(this,args);}
 box(...args){Painter.prototype.box.apply(this,args);}
 line(x,y,z,a,b,d,col,width=.025){const length=Math.hypot(a-x,b-y);if(length<1e-8)return;const u=-(b-y)*width/length/2,v=(a-x)*width/length/2;this.quad(x+u,y+v,z,a+u,b+v,d,a-u,b-v,d,x-u,y-v,z,col);}
 shadow(){}
}
root.MailtrainMaterials={Painter,Mesh};
})(globalThis);
