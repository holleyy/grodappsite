(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MailtrainArchitecture=factory();})(globalThis,function(){
'use strict';const cabinets=new Map();
function formation(extra){const vehicles=[{kind:'engine',a:-9.58,b:-.35,axles:[-7.8,-5.4,-3],wheelZ:1.7,radius:1},{kind:'sorting',a:0,b:16,axles:[1.2,2.5,12.8,14.1],wheelZ:1.4,radius:.7}];if(extra)vehicles.push({kind:'mail',a:16.35,b:21.7,axles:[17.3,20.7],wheelZ:1.4,radius:.7});vehicles.push({kind:'brake',a:extra?22.05:16.35,b:extra?27.4:21.7,axles:extra?[23,26.4]:[17.3,20.7],wheelZ:1.4,radius:.7});const joints=[];for(let i=1;i<vehicles.length;i++)joints.push({a:vehicles[i-1].b,b:vehicles[i].a});return {vehicles,joints};}
function envelope(p,x,y,z,w=.34){p.box(x,y,z,w,.23,.028,'cream');p.line(x,y,z+.03,x+w*.5,y+.15,z+.03,'#ba8c63',.012);p.line(x+w,y,z+.03,x+w*.5,y+.15,z+.03,'#ba8c63',.012);p.plane(x+w*.76,y+.03,z+.032,w*.14,.065,'#a7473a');}
function parcel(p,x,y,z,w=.7,d=.55,h=.55){
 p.box(x,y,z,w,d,h,'wood','cream','wood');const e=.003,t=Math.min(w,d)*.12,xx=x+w*.5-t*.5,yy=y+d*.5-t*.5;
 // Paper tape wraps the exterior; it has no exposed walls inside the carton.
 p.plane(xx,y,z+h+e,t,d,'cream');p.plane(x,yy,z+h+e,w,t,'cream');
 p.quad(xx,y+d+e,z,xx+t,y+d+e,z,xx+t,y+d+e,z+h,xx,y+d+e,z+h,'cream');
 p.quad(x+w+e,yy,z,x+w+e,yy+t,z,x+w+e,yy+t,z+h,x+w+e,yy,z+h,'cream',.15);
 p.plane(x+w*.15,y+d*.12,z+h+.008,w*.23,d*.27,'#f4e2b9');
}
function cabinetFaces(p,x,w,colour){const y=-1,z=3.1,d=.45,h=1.5,n=Math.round(w/1),cw=w/n;p.shadow(x+w*.5,y+.5,z,w*.65,.3);p.box(x,y,z,w,.10,h,'wood',colour);
 for(let row=0;row<3;row++){const zz=z+.12+row*.44;p.box(x,y,zz,w,d,.06,'wood',colour);for(let col=0;col<n;col++){const xx=x+col*cw+.1;for(let k=0;k<2+(row+col)%3;k++)envelope(p,xx+.1,y+.15,zz+.065+k*.033,.36);}}
 for(let col=0;col<=n;col++)p.box(x+col*cw-.03,y,z,.065,d,h,'wood',colour);
 p.box(x-.08,y-.04,z+h,w+.16,d+.12,.10,'wood',colour);p.box(x-.04,y,z,w+.08,d,.08,'wood',colour);
}
function cabinet(p,x,w,colour){const key=w+'|'+colour;let model=cabinets.get(key);if(!model){model=new MailtrainMaterials.Mesh();cabinetFaces(model,0,w,colour);cabinets.set(key,model);}p.contact(x-.035,-1.035,3.104,w+.07,.53);p.solid(model,x,0,0);}
function desk(p,x,y,w,d,z=3.1){for(let i=0;i<2;i++)for(let j=0;j<2;j++)p.box(x+i*(w-.14),y+j*(d-.14),z,.14,.14,1.2,'wood');p.box(x,y,z+.85,w,d,.25,'wood');p.box(x-.08,y-.06,z+1.13,w+.16,d+.12,.13,'wood');p.line(x,y+d+.02,z+1.04,x+w,y+d+.02,z+1.04,'#edc991',.025);}
function roof(p,x,w,full=false,base=6.8,y=-1.16,span=6.56){const r=span*.5;
 // Full enclosed ends; open sorting carriage retains its rear curved cornice.
 const from=full?0:Math.PI*.72,steps=full?20:6;
 for(let i=0;i<steps;i++){const a=from+(Math.PI-from)*i/steps,b=from+(Math.PI-from)*(i+1)/steps;
 const ya=y+r+r*Math.cos(a),yb=y+r+r*Math.cos(b),za=base+Math.sin(a)*.82,zb=base+Math.sin(b)*.82;
 p.quad(x,ya,za,x+w,ya,za,x+w,yb,zb,x,yb,zb,'cream',i%2?0:.035);}
 for(let k=0;k<=w;k+=2.6)p.line(x+k,y,base,x+k,y+.85,base+.65,'#f5dfb7',.095);
 p.box(x,y-.02,base-.1,w,.1,.16,'cream');}
function seal(p,x,y,z){p.quad(x-.3,y,z-.22,x+.3,y,z-.22,x+.3,y,z+.22,x-.3,y,z+.22,'#be4837');p.line(x-.23,y,z+.13,x,y,z-.035,'#ffdd9e',.028);p.line(x+.23,y,z+.13,x,y,z-.035,'#ffdd9e',.028);p.line(x-.23,y,z-.14,x+.23,y,z-.14,'#ffdd9e',.02);}
function lamp(p,x){const y=-.15,z=5.9;p.line(x,-1,6.6,x,y,z+.55,'#cfac61',.035);p.cylinder(x,y,z+.28,.065,.36,'brass');for(let i=0;i<16;i++){const a=i*Math.PI/8,b=(i+1)*Math.PI/8;p.quad(x+Math.cos(a)*.35,y+Math.sin(a)*.35,z,x+Math.cos(b)*.35,y+Math.sin(b)*.35,z,x+Math.cos(b)*.09,y+Math.sin(b)*.09,z+.32,x+Math.cos(a)*.09,y+Math.sin(a)*.09,z+.32,'brass',.08);}p.disk(x,y,z-.015,.29,'#fff2ae');}
function bag(p,x,y,z){p.line(x,y,z+.9,x-.15,y,z+.62,'#b79254',.03);p.line(x,y,z+.9,x+.15,y,z+.62,'#b79254',.03);for(let i=0;i<12;i++){const a=i*Math.PI/6,b=(i+1)*Math.PI/6;p.quad(x+Math.cos(a)*.2,y+Math.sin(a)*.2,z,x+Math.cos(b)*.2,y+Math.sin(b)*.2,z,x+Math.cos(b)*.29,y+Math.sin(b)*.29,z+.3,x+Math.cos(a)*.29,y+Math.sin(a)*.29,z+.3,'cream',i%3*.04);p.quad(x+Math.cos(a)*.29,y+Math.sin(a)*.29,z+.3,x+Math.cos(b)*.29,y+Math.sin(b)*.29,z+.3,x+Math.cos(b)*.16,y+Math.sin(b)*.16,z+.66,x+Math.cos(a)*.16,y+Math.sin(a)*.16,z+.66,'cream',i%3*.04);}p.disk(x,y,z+.67,.16,'#4b4136','#d1b98d');seal(p,x,y+.28,z+.31);}
function endRib(p,x){const y=-1.16,r=3.28,base=6.8;for(let i=0;i<18;i++){const a=i*Math.PI/18,b=(i+1)*Math.PI/18;p.quad(x,y+r+r*Math.cos(a),base+.82*Math.sin(a),x,y+r+r*Math.cos(b),base+.82*Math.sin(b),x,y+r+(r-.12)*Math.cos(b),base+.82*Math.sin(b)-.14,x,y+r+(r-.12)*Math.cos(a),base+.82*Math.sin(a)-.14,'cream');}p.box(x-.05,5.25,3.1,.11,.13,3.7,'cream');}
function bulkhead(p){
 // The sorting coach is wider than the cab. Close its end shoulders with a
 // real wall, leaving only the passage aligned to the cab's 1.08–3.32 doorway.
 p.box(0,-1.25,3.1,.06,2.33,3.7,'teal');
 p.box(0,3.32,3.1,.06,2.08,3.7,'teal');
 p.box(0,1.08,5.78,.06,2.24,1.02,'teal');
 const centre=2.12,r=3.28;
 for(let i=0;i<20;i++){const a=i*Math.PI/20,b=(i+1)*Math.PI/20,ya=centre+r*Math.cos(a),yb=centre+r*Math.cos(b);
  p.quad(.06,ya,6.8,.06,yb,6.8,.06,yb,6.8+.82*Math.sin(b),.06,ya,6.8+.82*Math.sin(a),'teal',.18);}
 // Frame, sill and scored joinery belong to the same end plane as the panel.
 for(const y of [1.01,3.32])p.box(.06,y,3.1,.07,.07,2.75,'wood');
 p.box(.06,1.01,5.78,.07,2.38,.10,'wood');
 p.box(0,1.08,3.07,.21,2.24,.05,'brass');
 for(const y of [-1.1,-.55,0,.55,3.65,4.2,4.75,5.25])p.line(.064,y,3.16,.064,y,6.72,'#76918a',.012);
}
function enclosed(p,x,w,brake){p.box(x,-1.15,2.35,w,6.55,.72,'wood','#734237');p.box(x,-1.15,3.07,w,6.55,3.64,'teal');
 for(let j=0;j<2;j++){const xx=x+.65+j*2.1;p.quad(xx,5.412,4.7,xx+1.25,5.412,4.7,xx+1.25,5.412,5.9,xx,5.412,5.9,'brass');p.quad(xx+.09,5.42,4.78,xx+1.16,5.42,4.78,xx+1.16,5.42,5.82,xx+.09,5.42,5.82,'#f5c36d');p.line(xx+.63,5.44,4.78,xx+.63,5.44,5.82,'#9b6f42',.05);p.line(xx+.1,5.44,5.33,xx+1.15,5.44,5.33,'#9b6f42',.045);}
 for(let j=0;j<4;j++){const yy=-.8+j*1.5;p.line(x+w+.01,yy,3.45,x+w+.01,yy,6.3,'#6c9085',.025);p.line(x+w+.01,yy,3.45,x+w+.01,yy+1.2,3.45,'#c4a66c',.025);}p.line(x+w+.015,-.8,6.3,x+w+.015,4.9,6.3,'#c4a66c',.025);
 p.line(x+.15,5.43,3.45,x+w-.15,5.43,3.45,'#dfb66c',.035);p.line(x+.15,5.43,6.45,x+w-.15,5.43,6.45,'#dfb66c',.04);seal(p,x+w*.5,5.44,4.05);roof(p,x,w,true);
 if(brake){for(let j=0;j<2;j++){p.box(x+w+.02,.15+j*3.8,3.4,.15,.28,.42,'brass','#bd3d32');p.disk(x+w+.2,.3+j*3.8,3.65,.14,'#ffbd68');}p.box(x+w,-.3,2.65,.4,4.8,.12,'slate');}
}
function dispatch(p){
 desk(p,12.2,.4,2.65,1.25);parcel(p,13.6,.55,4.36,.7,.68,.65);parcel(p,12.55,.53,4.36,.64,.55,.37);envelope(p,12.35,1.1,4.37,.46);
 p.cylinder(14.35,1.25,4.36,.2,.05,'brass');p.line(14.35,1.25,4.4,14.35,1.25,5.05,'#29474c',.07);p.line(14.35,1.25,5.05,14.03,1.25,5.3,'#29474c',.07);p.cylinder(14.04,1.25,5.15,.2,.13,'brass');
}
function trolley(p){
 p.box(12.5,2.25,3.36,1.45,.86,.12,'teal');for(let i=0;i<2;i++)for(let j=0;j<2;j++)p.cylinder(12.66+i*1.1,2.4+j*.56,3.1,.13,.25,'#3c4540','#c8a573');parcel(p,12.85,2.35,3.48,.8,.61,.59);p.line(12.5,2.25,3.45,12.5,2.25,4.25,'#355956',.06);p.line(12.5,3.1,3.45,12.5,3.1,4.25,'#355956',.06);p.line(12.5,2.25,4.25,12.5,3.1,4.25,'#355956',.06);
}
function draw(p,extra,attachments=true,section='all'){
 if(section==='tail'){if(attachments){for(let i=0;i<(extra?2:1);i++)enclosed(p,16.35+i*5.7,5.35,i===(extra?1:0));}return;}
 if(attachments)MailtrainEngine.draw(p);
 p.box(0,-1.15,2.72,16,6.55,.38,'wood','#a14836');
 // Long scored planks, staggered board joints and bright cut edges.
 for(let row=0;row<13;row++)for(let col=0;col<5;col++){const x=col*3.2; p.plane(x,-1.15+row*.5,3.102,3.19,.487,'wood',row%3*.035);}
 p.box(0,5.35,2.9,16,.1,.2,'cream','#c8a56b');p.line(0,5.46,2.84,16,5.46,2.84,'#e5ad66',.035);
 bulkhead(p);
 // Rear wall has actual open window apertures; countryside shows through.
 p.box(0,-1.25,3.1,16,.13,1.9,'teal');p.box(0,-1.25,6.2,16,.13,.5,'teal');
 for(let k=0;k<=16;k+=.5)p.box(k,-1.10,3.12,.035,.025,1.78,'teal');
 for(let x=0;x<16;x+=3.2){p.box(x,-1.25,5,1,.13,1.2,'teal');p.box(x+.94,-1.24,4.95,.08,.23,1.3,'wood');p.box(x+3.12,-1.24,4.95,.08,.23,1.3,'wood');p.box(x+.94,-1.24,4.96,2.25,.23,.09,'wood');p.box(x+.94,-1.24,6.15,2.25,.23,.09,'wood');}
 p.box(0,-1.1,4.91,16,.12,.07,'wood');roof(p,0,16);endRib(p,0);endRib(p,16);
 for(let j=0;j<5;j++){const lx=1.5+j*3.2,c=p.c,px=p.px(lx,-.9),py=p.py(lx,-.9,5.4),r=p.cam.scale*1.05,g=c.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,'#ffdc8055');g.addColorStop(1,'#ffdc8000');c.fillStyle=g;c.fillRect(px-r,py-r,r*2,r*2);}
 // Seat at the far left, entirely outside the maximum live floor.
 p.box(.08,-.9,3.1,.8,1.65,.5,'wood');p.box(.06,-.95,3.6,.84,1.7,.13,'#8b3c46');p.box(.08,-1.02,3.62,.8,.1,1,'wood','#8b3c46');p.shadow(.48,-.1,3.74,.25,.09);p.sprite('worker','postmistress',.48,-.12,3.74,1.45);
 desk(p,1.25,-.95,2,.88);p.cylinder(2.3,-.53,4.36,.24,.76,'brass');p.cylinder(2.3,-.53,5.12,.3,.07,'brass');p.line(2.54,-.53,4.7,2.75,-.53,4.7,'#8f6533',.08);p.cylinder(1.8,-.37,4.37,.12,.19,'cream','#4e3525');envelope(p,2.7,-.55,4.37,.36);
 cabinet(p,3.65,3.7,'#a64433');cabinet(p,7.7,3.05,'#2d6075');
 // Foreground furniture is prepared separately for actor depth in the live renderer.
 if(section!=='head'){dispatch(p);trolley(p);}
 for(let i=0;i<3;i++)bag(p,12.3+i*.75,-.7,5.12);for(let i=0;i<5;i++)lamp(p,1.5+i*3.2);
 // Small wall clock is printed in the wall plane, with full rim thickness.
 const c=p.c,x=.5,y=-1.02,z=5.67;c.save();c.translate(p.px(x,y),p.py(x,y,z));c.transform(1,.5,0,1,0,0);c.beginPath();c.arc(0,0,p.cam.scale*.36,0,Math.PI*2);c.fillStyle='#eed5a2';c.fill();c.strokeStyle='#b88742';c.lineWidth=p.cam.scale*.06;c.stroke();c.restore();
 if(attachments){if(section!=='head')for(let i=0;i<(extra?2:1);i++)enclosed(p,16.35+i*5.7,5.35,i===(extra?1:0));}
}
return {formation,draw,envelope,parcel,cabinet,bulkhead,dispatch,trolley};
});
