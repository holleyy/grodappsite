(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MailtrainLife=factory();})(globalThis,function(){
'use strict';const state={},lighting={};const mod=(v,m)=>((v%m)+m)%m;
function sample(frame,motion,o){const f=motion?frame:0,d=f/30,phase=mod(f,2880);o.distance=d;o.sleeper=mod(d,.8);o.arch=mod(d,6);o.wheelAngle=d/.7;o.workerZ=3.1;o.workerY=.35;o.workerX=6.5;o.mirror=false;
 if(phase<900)o.workerPose=phase%180<95?'sort-hold':'sort-place';
 else if(phase<1320){const u=(phase-900)/420;o.workerX=6.5-4.7*u;o.mirror=true;o.workerPose=Math.floor(phase/16)%2?'walk-0':'walk-1';}
 else if(phase<1740){o.workerX=1.8;o.workerPose=phase%240<150?'tea-rest':'tea-sip';}
 else if(phase<1980){o.workerX=1.8;o.workerPose='watch';}
 else if(phase<2400){const u=(phase-1980)/420;o.workerX=1.8+4.7*u;o.workerPose=Math.floor(phase/16)%2?'walk-0':'walk-1';}
 else o.workerPose='sort-hold';return o;}
function illumination(level,o){const stage=level.board.w<10?0:level.board.h===4?2:1;o.shade=stage===2?.14:stage===1?.065:0;o.warmth=stage===2?.24:stage===1?.16:.07;return o;}
// Prepared architecture only: live floor colours, coats and targets remain exact.
function light(p,level,lamps=true){illumination(level,lighting);const c=p.c,s=p.cam.scale;c.save();c.globalCompositeOperation='source-atop';c.fillStyle='#24344c';c.globalAlpha=lighting.shade;c.fillRect(0,0,c.canvas.width,c.canvas.height);c.globalAlpha=1;
 if(lamps)for(let i=0;i<5;i++){const x=p.px(1.5+i*3.2,-.3),y=p.py(1.5+i*3.2,-.3,4.7),g=c.createRadialGradient(x,y,0,x,y,s*1.35);g.addColorStop(0,'rgba(255,202,112,'+lighting.warmth+')');g.addColorStop(1,'rgba(255,202,112,0)');c.fillStyle=g;c.fillRect(x-s*1.35,y-s*1.35,s*2.7,s*2.7);}c.restore();}
function details(p,f){
 const c=p.c,s=p.cam.scale,t=f.worldFrame/60;
 // Clock hands share the actual printed wall plane; time is independent of puzzles.
 c.save();c.translate(p.px(.5,-1.02),p.py(.5,-1.02,5.67));c.transform(1,.5,0,1,0,0);c.strokeStyle='#354849';c.lineWidth=s*.025;c.lineCap='round';c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(t*Math.PI/21600)*s*.17,Math.sin(t*Math.PI/21600)*s*.17);const minute=-Math.PI/2+t*Math.PI/1800;c.moveTo(0,0);c.lineTo(Math.cos(minute)*s*.24,Math.sin(minute)*s*.24);c.stroke();const second=-Math.PI/2+t*Math.PI/30;c.strokeStyle='#a85e3f';c.lineWidth=s*.009;c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(second)*s*.27,Math.sin(second)*s*.27);c.stroke();c.restore();
 // A fine curl starts on the hot mug's coffee surface, wholly behind the board.
 c.save();c.strokeStyle='#fff2d7';c.lineWidth=Math.max(.5,s*.009);
 for(let i=0;i<3;i++){const age=mod(t*.45+i/3,1);c.globalAlpha=.15*Math.sin(age*Math.PI);c.beginPath();for(let j=0;j<9;j++){const u=j/8,zz=4.56+age*.48+u*.22,xx=1.8+Math.sin(age*5+u*3)*.045*u;p.v(xx,-.37,zz,j===0);}c.stroke();}c.restore();
}
function arch(p,x,y){const c=p.c;c.beginPath();p.v(x,y,.3,true);p.v(x+6,y,.3);p.v(x+6,y,-5.7);p.v(x,y,-5.7);c.closePath();p.v(x+.65,y,-5.7,true);p.v(x+.65,y,-2.8);for(let i=0;i<=20;i++){const a=Math.PI-i*Math.PI/20;p.v(x+3+2.35*Math.cos(a),y,-2.8+2.35*Math.sin(a));}p.v(x+5.35,y,-5.7);c.closePath();c.fillStyle=y>0?'#bd8b6c':'#956c5b';c.fill('evenodd');c.save();c.clip('evenodd');c.fillStyle=p.patterns.stone;c.fill();for(let row=0;row<10;row++){const zz=-.25-row*.56;p.line(x,y,zz,x+6,y,zz,'#a1765b60',.018);for(let k=0;k<6;k++){const xx=x+k+(row%2)*.5;p.line(xx,y,zz,xx,y,zz-.56,'#a1765b50',.015);}}c.restore();
 for(let j=0;j<10;j++){const a=j*Math.PI/10,b=(j+1)*Math.PI/10;p.quad(x+3+2.38*Math.cos(a),y,-2.8+2.38*Math.sin(a),x+3+2.38*Math.cos(b),y,-2.8+2.38*Math.sin(b),x+3+2.72*Math.cos(b),y,-2.8+2.72*Math.sin(b),x+3+2.72*Math.cos(a),y,-2.8+2.72*Math.sin(a),'stone',.1);}
 for(let row=0;row<5;row++)for(let col=0;col<3;col++){const xx=x+col*.21,zz=-2.75-row*.58;p.quad(xx,y,zz,xx+.2,y,zz,xx+.2,y,zz-.55,xx,y,zz-.55,'stone',row%2*.04);}
 for(let j=0;j<6;j++)p.quad(x+j,y,.3,x+j+.98,y,.3,x+j+.98,y,-.2,x+j,y,-.2,'stone');}
function wheel(p,x,y,angle,r=.7,z=1.4){const c=p.c;c.beginPath();for(let i=0;i<=24;i++){const a=i*Math.PI/12;p.v(x+Math.cos(a)*r,y,z+Math.sin(a)*r,i===0);}c.closePath();c.fillStyle='#293c3e';c.fill();c.strokeStyle='#b19c75';c.lineWidth=p.cam.scale*.10;c.stroke();for(let i=0;i<6;i++){const a=angle+i*Math.PI/3;p.line(x,y,z,x+Math.cos(a)*r*.83,y,z+Math.sin(a)*r*.83,'#a6a38b',.045);}p.line(x-.08,y,z,x+.08,y,z,'#e9ca90',.15);}
function background(p,f){sample(f.chapterMode==='station'?0:f.worldFrame,true,state);const c=p.c,W=f.viewport.width,H=f.viewport.height,im=p.assets.countryside.image,iw=Math.max(W,H*1.5),shift=mod(state.distance*1.7,iw);c.drawImage(im,shift-iw,-H*.18,iw,H*1.18);c.drawImage(im,shift,-H*.18,iw,H*1.18);
 if(f.level.board.w>=10){c.fillStyle='#27345a';c.globalAlpha=f.level.board.h===4?.52:.24;c.fillRect(0,0,W,H);c.globalAlpha=1;}}
function station(p){p.box(-12,-6.8,-.2,47,5,2.75,'cream','stone');for(let i=-12;i<35;i++)p.box(i,-2.05,2.55,.97,.25,.08,'cream');p.box(-3,-8,2.55,6,2.5,3.2,'stone');p.box(-3.15,-8.15,5.75,6.3,2.8,.18,'#8c574e');for(let i=0;i<3;i++){p.quad(-2.4+i*1.7,-5.48,3.3,-1.5+i*1.7,-5.48,3.3,-1.5+i*1.7,-5.48,4.8,-2.4+i*1.7,-5.48,4.8,'#f3ce8b');}for(let i=0;i<5;i++){const x=6+i*6;p.cylinder(x,-3.7,2.55,.065,3.6,'#31504e','#31504e');p.box(x-.19,-3.9,6.15,.38,.38,.48,'brass','#ffeab1');p.box(x-.24,-3.95,6.63,.48,.48,.08,'teal');}p.box(10,-3.8,3.75,3,.13,.8,'teal');p.text(11.5,-3.65,4.03,'MAIL COLLECTION',.19,'#f6dfb1');for(let i=0;i<3;i++)MailtrainArchitecture.parcel(p,14+i*.7,-3.4,2.55,.6,.6,.55);}
function foreground(p,f){sample(f.chapterMode==='station'?0:f.worldFrame,true,state);const W=f.viewport.width,H=f.viewport.height,iw=Math.max(W,H*1.5),shift=mod(state.distance*1.7,iw);p.c.save();if(f.level.board.w>=10)p.c.filter=f.grayscale?(f.level.board.h===4?'grayscale(1) brightness(.6)':'grayscale(1) brightness(.8)'):(f.level.board.h===4?'brightness(.6)':'brightness(.8)');p.c.drawImage(p.assets.foreground,shift-iw,-H*.18,iw,H*1.18);p.c.drawImage(p.assets.foreground,shift,-H*.18,iw,H*1.18);p.c.restore();}
function couplings(p,f,form){const shunt=f.chapterMode==='station'&&f.stationStage===2,offset=shunt?f.chapterPose.headOffset:0;
 // Underfloor hardware belongs behind every coach body. The stationary tail
 // cannot connect across the open shunting gap; the engine/coach joint moves
 // with the powered head. A narrow gangway supports the centre passage.
 for(let i=0;i<form.joints.length;i++){if(i===1&&offset<0)continue;const j=form.joints[i],shift=i===0?offset:0,x=j.a+shift,w=j.b-j.a;
  p.box(x,.35,2.4,w,3.8,.15,'#363c38');for(let y=0;y<2;y++)p.box(x,.7+y*3,2.15,w,.16,.18,'slate');
  p.box(x,1.65,3.07,w,1.1,.03,'slate');
  if(i===1&&shunt)for(let k=0;k<=f.chapterPose.joint;k++)p.line(x+k*w/4,1.7,3.105,x+k*w/4,2.7,3.105,'#b4a57c',.02);
 }
}
function world(p,f,form){sample(f.chapterMode==='station'?0:f.worldFrame,true,state);
 if(f.chapterMode==='station')station(p);
 // Both bridge edges repeat continuously; the camera follows the train, not the masonry.
 for(let i=-5;i<8;i++)arch(p,i*6+state.arch,-.1);
 p.plane(-35,-.1,.32,90,4.9,'#bba08a');
 for(let i=-5;i<8;i++)arch(p,i*6+state.arch,4.8);
 for(let i=-40;i<80;i++){const x=i*.8+state.sleeper;p.box(x,.05,.34,.23,4.3,.14,'#7b6552');}
 p.box(-35,.665,.48,90,.07,.22,'#c9c6ab','#5e6b65');p.box(-35,3.665,.48,90,.07,.22,'#c9c6ab','#5e6b65');
 couplings(p,f,form);
 for(const v of form.vehicles){const shift=f.chapterMode==='station'&&f.stationStage===2&&(v.kind==='engine'||v.kind==='sorting')?f.chapterPose.headOffset:0;p.c.save();p.c.translate(shift*p.cam.scale,shift*p.cam.scale*.5);p.box(v.a+.2,.4,1.65,v.b-v.a-.4,3.9,.62,'#263c3c');for(const x of v.axles){wheel(p,x,.7,(shift?-shift:state.distance)/v.radius,v.radius,v.wheelZ);wheel(p,x,3.7,(shift?-shift:state.distance)/v.radius,v.radius,v.wheelZ);p.box(x-.5,.4,1.85,1,3.5,.18,'#3f4b43');}if(v.kind==='engine'){const a=(shift?-shift:state.distance)/v.radius,dx=Math.cos(a)*.24,dz=Math.sin(a)*.24;p.line(v.axles[0]+dx,3.76,v.wheelZ+dz,v.axles[2]+dx,3.76,v.wheelZ+dz,'#c1b690',.10);}p.c.restore();}
 // One restrained distance-driven steam trail behind the funnel, outside live tiles.
 if(f.motion)for(let i=0;i<4;i++){const age=mod(f.worldFrame/60+i*.65,2.6);const c=p.c;c.save();c.globalAlpha=.2*(1-age/2.6);p.disk(-8.05+age*.8,2.2,6.2+age*.65,.2+age*.12,'#fff1cf');c.restore();}
}
function departure(frame,o){let d=Math.max(0,Math.min(1,(frame-24)/180))*15.45;o.workerZ=3.1;o.mirror=false;
 // Follow the clear aisle around the front of both desk and trolley, then
 // cross the centre gangway. The attached coach occludes the final pose.
 if(d<5.05){o.workerX=6.5+d;o.workerY=.35;}
 else if((d-=5.05)<3.2){o.workerX=11.55;o.workerY=.35+d;o.mirror=true;}
 else if((d-=3.2)<3.85){o.workerX=11.55+d;o.workerY=3.55;}
 else if((d-=3.85)<1.35){o.workerX=15.4;o.workerY=3.55-d;}
 else{o.workerX=15.4+d-1.35;o.workerY=2.2;}
 o.workerPose=Math.floor(frame/16)%2?'walk-0':'walk-1';return o;
}
function people(p,f){sample(f.chapterMode==='station'?0:f.worldFrame,true,state);if(f.chapterMode==='exit')departure(f.chapterFrame,state);
 p.shadow(state.workerX,state.workerY,state.workerZ,.31,.12,.2);p.sprite('worker',state.workerPose,state.workerX,state.workerY,state.workerZ,2.1,state.mirror);
}
return {sample,illumination,light,details,background,foreground,couplings,world,departure,people};
});
