/* Read-only artwork registration. Floor contacts use the room's 2:1 projection;
   each vertical source column retains its relief above that contact. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MailtrainRegistration=factory();})(globalThis,function(){'use strict';
function fit(bottom,lo,hi){let n=0,X=0,Y=0,XX=0,XY=0;for(let x=lo;x<=hi;x++){n++;X+=x;Y+=bottom[x];XX+=x*x;XY+=x*bottom[x];}const m=(n*XY-X*Y)/(n*XX-X*X);return{m,b:(Y-m*X)/n};}
function profile(w,h,bottom,square){const sy=.78,pad=16,offset=new Float64Array(w),front=new Float64Array(w);let cx=(w-1)/2,root;
 if(square){const L=fit(bottom,Math.round(w*.113),Math.round(w*.334)),R=fit(bottom,Math.round(w*.659),Math.round(w*.881));cx=(R.b-L.b)/(L.m-R.m);const apex=L.m*cx+L.b,target=pad+apex*sy;root=target-w/4;
  for(let x=0;x<w;x++){const line=x<cx?L:R,ground=target-.5*Math.abs(x-cx);offset[x]=ground-sy*(line.m*x+line.b);front[x]=bottom[x]*sy+offset[x]-h*.20*sy;}
 }else{const radius=w*.47;let n=0,Q=0,Y=0,QQ=0,QY=0;for(let x=Math.ceil(w*.17);x<w*.83;x++){const q=Math.sqrt(Math.max(0,1-((x-cx)/radius)**2));n++;Q+=q;Y+=bottom[x];QQ+=q*q;QY+=q*bottom[x];}const ry=(n*QY-Q*Y)/(n*QQ-Q*Q),cy=(Y-ry*Q)/n;root=pad+cy*sy;
  for(let x=0;x<w;x++){const q=Math.sqrt(Math.max(0,1-((x-cx)/radius)**2)),ground=root+radius*.5*q;offset[x]=ground-sy*(cy+ry*q);front[x]=h*(.48+.29*(1-((x-cx)/(w/2))**2))*sy+offset[x];}
 }return{sy,offset,front,anchorX:cx,anchorY:root,width:w,height:Math.ceil(h+pad*2),units:1.44};
}
function prepare(acting){const result={};for(const name of ['basket-ginger','basket-blue']){const r=acting.sprites[name].rect,source=document.createElement('canvas');source.width=r[2];source.height=r[3];const sc=source.getContext('2d');sc.drawImage(acting.image,r[0],r[1],r[2],r[3],0,0,r[2],r[3]);const pixels=sc.getImageData(0,0,r[2],r[3]).data,bottom=new Float64Array(r[2]);for(let x=0;x<r[2];x++){let y=r[3]-1;while(y>=0&&pixels[(y*r[2]+x)*4+3]<200)y--;bottom[x]=y;}const q=profile(r[2],r[3],bottom,name==='basket-blue'),full=document.createElement('canvas'),front=document.createElement('canvas');full.width=front.width=q.width;full.height=front.height=q.height;const fc=full.getContext('2d'),nc=front.getContext('2d');
 for(let x=0;x<q.width;x++){fc.drawImage(source,x,0,1,r[3],x,q.offset[x],1,r[3]*q.sy);const first=Math.max(0,(q.front[x]-q.offset[x])/q.sy);if(first<r[3])nc.drawImage(source,x,first,1,r[3]-first,x,q.front[x],1,(r[3]-first)*q.sy);}
 source.width=source.height=0;result[name]={full,front,anchorX:q.anchorX,anchorY:q.anchorY,units:q.units};}return result;}
return{profile,prepare};
});
