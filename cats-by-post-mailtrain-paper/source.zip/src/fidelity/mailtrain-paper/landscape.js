/* Separate far valley, bank roots and near foliage. All nearby terrain uses
   the bridge's ground plane, with a continuous meandering river between banks. */
(function(root){'use strict';const names=['oak','fir','maple','twins'];
function riverStart(frame){return -8+((frame/30%60)+60)%60;}
function bend(y){return Math.sin(y*.15)*1.25;}
function ground(p,f){const phase=f.chapterMode==='station'?0:f.worldFrame,r=riverStart(phase),z=-5.78;p.meshMode=true;
 for(let j=-1;j<=1;j++){const x=r+j*60;for(let y=-12;y<48;y+=2){const a=bend(y),b=bend(y+2);p.quad(x+a,y,z-.08,x+10+a,y,z-.08,x+10+b,y+2,z-.08,x+b,y+2,z-.08,'river');}
 for(let k=0;k<34;k++){const yy=-10+k*1.2,xx=x+bend(yy)+.5+(k*2.37)%9;p.line(xx,yy,z-.075,xx+.4+(k%3)*.2,yy,z-.075,k%3?'#adc7bd':'#d1d3b8',.018);}}
 p.meshMode=false;const d=((phase/30%3)+3)%3;
 for(let row=0;row<2;row++)for(let i=-12;i<24;i++){const x=i*3+d,y=-7.2+row*2.5;if(((x-r-bend(y))%60+60)%60<10)continue;p.shadow(x,y,z,1,.32,.13);p.sprite('foliage',names[(i+row+12)%4],x,y,z,4.2+((i+12)%3)*.55);}
}
function foreground(p,f){const phase=f.chapterMode==='station'?0:f.worldFrame,r=riverStart(phase),z=-5.74;p.meshMode=true;
 for(let j=-2;j<=1;j++){const x=r+j*60;for(let y=7;y<57;y+=2){const a=bend(y),b=bend(y+2);p.quad(x+10+a,y,z,x+60+a,y,z,x+60+b,y+2,z,x+10+b,y+2,z,'meadow');p.quad(x+10+a,y,z+.01,x+10.35+a,y,z+.01,x+10.35+b,y+2,z+.01,x+10+b,y+2,z+.01,'#b8aa7c');p.quad(x+59.65+a,y,z+.01,x+60+a,y,z+.01,x+60+b,y+2,z+.01,x+59.65+b,y+2,z+.01,'#b8aa7c');}}
 p.meshMode=false;const d=((phase/30%3)+3)%3;
 for(let row=0;row<3;row++)for(let i=-12;i<24;i++){const x=i*3+d+(row%2)*1.3,y=8.6+row*3.3+Math.sin(i*2.1)*.5,river=((x-r-bend(y))%60+60)%60;if(river<10.5||river>59.5)continue;const h=4.8+((i+row+12)%4)*.6;p.shadow(x,y,z,1.5,.4,.18);p.sprite('foliage',names[(i+row+12)%4],x,y,z,h);if(i%3===0)p.sprite('foliage','shrubs',x+1.3,y+1.5,z,1.7);}
 for(let j=-1;j<=1;j++){const x=r+j*60;p.sprite('foliage','reeds',x+bend(8.5)-.35,8.5,z,2.2);p.sprite('foliage','reeds',x+10.4+bend(11),11,z,2.1);}
}
root.MailtrainLandscape={riverStart,ground,foreground};
})(globalThis);
