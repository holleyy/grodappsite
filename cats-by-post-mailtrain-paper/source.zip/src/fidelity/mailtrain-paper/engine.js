/* Room-owned locomotive mesh. Faces are ordered in the SAME (x-y, (x+y)/2-z)
   projection as the board. The camera looks from +x,+y,+z: the -x smokebox
   face is on the far end and must never be pasted over the barrel. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MailtrainEngine=factory();})(globalThis,function(){
'use strict';let mesh=null;
function build(){
 const faces=[];
 function face(A,B,C,D,mat,shade=0,tag='body'){const depth=(A[0]+A[1]+A[2]+B[0]+B[1]+B[2]+C[0]+C[1]+C[2]+D[0]+D[1]+D[2])/4;faces.push({v:[A,B,C,D],mat,shade,depth,tag});}
 function plane(A,B,D,mat,shade,tag){const U=[B[0]-A[0],B[1]-A[1],B[2]-A[2]],V=[D[0]-A[0],D[1]-A[1],D[2]-A[2]],nx=Math.max(1,Math.ceil(Math.hypot(...U)/.5)),ny=Math.max(1,Math.ceil(Math.hypot(...V)/.5));for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){const point=(u,v)=>[A[0]+U[0]*u+V[0]*v,A[1]+U[1]*u+V[1]*v,A[2]+U[2]*u+V[2]*v];face(point(i/nx,j/ny),point((i+1)/nx,j/ny),point((i+1)/nx,(j+1)/ny),point(i/nx,(j+1)/ny),mat,shade,tag);}}
 function box(x,y,z,w,d,h,mat='teal',tag='body'){
 plane([x+w,y,z],[x+w,y+d,z],[x+w,y,z+h],mat,.18,tag);
 plane([x,y+d,z],[x+w,y+d,z],[x,y+d,z+h],mat,.07,tag);
 plane([x,y,z+h],[x+w,y,z+h],[x,y+d,z+h],mat,-.05,tag);
 }
 function cylinderX(x,len,cy,cz,r,mat,tag='boiler',caps=true){const slices=Math.max(1,Math.ceil(len/.5)),N=32;
 for(let k=0;k<slices;k++)for(let i=0;i<N;i++){const a=i*Math.PI*2/N,b=(i+1)*Math.PI*2/N,mid=(a+b)*.5;if(Math.cos(mid)+Math.sin(mid)<=0)continue;const xx=x+k*len/slices,xe=xx+len/slices;
 face([xx,cy+r*Math.cos(a),cz+r*Math.sin(a)],[xe,cy+r*Math.cos(a),cz+r*Math.sin(a)],[xe,cy+r*Math.cos(b),cz+r*Math.sin(b)],[xx,cy+r*Math.cos(b),cz+r*Math.sin(b)],mat,.03+Math.max(0,Math.cos(mid))*.18,tag);}
 if(caps)for(let i=0;i<N;i++){const a=i*Math.PI*2/N,b=(i+1)*Math.PI*2/N;face([x+len,cy,cz],[x+len,cy+r*Math.cos(a),cz+r*Math.sin(a)],[x+len,cy+r*Math.cos(b),cz+r*Math.sin(b)],[x+len,cy,cz],'#253e3d',0,'boiler-back');}
 }
 function cylinderZ(x,y,z,r,h,mat,top=mat){const N=20;for(let i=0;i<N;i++){const a=i*Math.PI*2/N,b=(i+1)*Math.PI*2/N,mid=(a+b)*.5;if(Math.cos(mid)+Math.sin(mid)>0)face([x+r*Math.cos(a),y+r*Math.sin(a),z],[x+r*Math.cos(b),y+r*Math.sin(b),z],[x+r*Math.cos(b),y+r*Math.sin(b),z+h],[x+r*Math.cos(a),y+r*Math.sin(a),z+h],mat,.05+Math.max(0,Math.cos(mid))*.12,'chimney');face([x,y,z+h],[x+r*Math.cos(a),y+r*Math.sin(a),z+h],[x+r*Math.cos(b),y+r*Math.sin(b),z+h],[x,y,z+h],top,0,'chimney-rim');}}
 function lining(x,y,z,w,h){const t=.025;box(x,y,z,w,.018,t,'brass');box(x,y,z+h,w,.018,t,'brass');box(x,y,z,t,.018,h,'brass');box(x+w-t,y,z,t,.018,h,'brass');}
 // A long 0-6-0 tank engine, centred on the existing gauge (0.7, 3.7).
 box(-9.1,.2,2.35,8.75,4,.24,'#29423f','running-plate');
 box(-8.7,.75,1.95,7.95,2.9,.4,'#243737','chassis');
 // Front buffer beam and two physically attached buffer stocks.
 box(-9.23,.05,2.04,.22,4.3,.38,'#a84a36','front-beam');
 cylinderX(-9.55,.4,.7,2.22,.18,'#303e3a','buffer');cylinderX(-9.55,.4,3.7,2.22,.18,'#303e3a','buffer');box(-9.58,2.04,1.93,.42,.32,.12,'#373c35','front-coupler');
 // Separate far tank, boiler and near tank. No end-disc drawn on the hidden side.
 box(-7.9,.1,2.6,4.8,.9,1.17,'teal','far-tank');
 cylinderX(-8.65,5.55,2.2,3.83,1.2,'teal');
 cylinderX(-8.65,.85,2.2,3.83,1.215,'#304342','smokebox');
 for(const x of [-7.76,-6.45,-4.8,-3.17])cylinderX(x,.065,2.2,3.83,1.222,'brass','boiler-band',false);
 // Chimney foot meets the barrel crown, then flares at the open rim.
 cylinderZ(-8.05,2.2,4.96,.32,.15,'#2b4240');cylinderZ(-8.05,2.2,5.1,.24,.95,'#29413e');cylinderZ(-8.05,2.2,6.05,.32,.10,'brass','#1f302e');
 cylinderZ(-5.55,2.2,4.98,.32,.38,'brass');cylinderZ(-5.55,2.2,5.36,.24,.15,'brass');
 box(-7.9,3.38,2.6,4.8,.92,1.17,'teal','near-tank');lining(-7.73,4.322,2.77,4.46,.81);
 // Printed envelope badge on the water tank's near side.
 box(-6.13,4.345,2.96,.92,.025,.42,'#ad4a38','postal-badge');
 face([-6.03,4.376,3.31],[-5.67,4.376,3.07],[-5.31,4.376,3.31],[-5.67,4.376,3.22],'#f0d39d',0,'postal-badge');
 // Cab floor, far wall and backhead. Rear doorway and side window are holes,
 // bounded by real posts; there is no solid cuboid under a painted window.
 box(-3.05,.05,2.59,2.7,4.3,.12,'wood','cab-floor');
 box(-3.05,.05,2.7,2.7,.12,3.35,'teal','cab-far-wall');
 box(-3.05,.05,2.7,.13,4.3,.95,'teal','cab-front');
 box(-3.07,1.14,2.7,.15,2.12,1.85,'#283b39','backhead');
 box(-2.9,1.77,2.8,.04,.8,.44,'#5b3228','firebox');box(-2.855,1.89,2.88,.02,.56,.26,'#efb166','fire');
 // The near side has a low panel, two corner posts, a bright sill and a roof beam.
 box(-3.05,4.23,2.7,2.7,.12,1.1,'teal','cab-side');lining(-2.9,4.36,2.9,2.38,.68);
 box(-3.05,4.23,3.8,.18,.12,2.25,'teal','cab-side-post');box(-.53,4.23,3.8,.18,.12,2.25,'teal','cab-side-post');
 box(-3.05,4.2,3.8,2.7,.21,.09,'brass','cab-sill');box(-3.05,4.23,5.88,2.7,.12,.17,'teal','cab-beam');
 // Rear posts frame an open gangway above two supported steps.
 box(-.53,.05,2.7,.18,1.03,3.35,'teal','cab-rear-post');box(-.53,3.32,2.7,.18,1.03,3.35,'teal','cab-rear-post');box(-.53,1.08,5.78,.18,2.24,.27,'teal','cab-rear-beam');
 box(-.35,1.36,2.39,.35,1.68,.15,'#3c4943','rear-step');box(-.22,1.56,2.15,.22,1.28,.13,'#3c4943','rear-step');
 box(-2.6,4.35,2.12,1.6,.32,.13,'#45524b','side-step');
 // A shallow curved cream roof with thickness and scored cross seams.
 const ry=2.2,r=2.42,z=6.05;
 for(let k=0;k<5;k++)for(let i=0;i<20;i++){const x=-3.18+k*.59,xe=x+.59,a=i*Math.PI/20,b=(i+1)*Math.PI/20;face([x,ry+r*Math.cos(a),z+.46*Math.sin(a)],[xe,ry+r*Math.cos(a),z+.46*Math.sin(a)],[xe,ry+r*Math.cos(b),z+.46*Math.sin(b)],[x,ry+r*Math.cos(b),z+.46*Math.sin(b)],'cream',i%2*.02,'cab-roof');}
 box(-3.18,4.59,5.96,2.95,.09,.11,'cream','roof-edge');
 // Driver is sorted with the mesh; doorway posts can occlude the silhouette.
 faces.push({kind:'sprite',sheet:'worker',name:'watch',x:-1.4,y:2.55,z:2.72,height:2.3,depth:-1.4+2.55+3.6,tag:'driver'});
 faces.sort((a,b)=>a.depth-b.depth);
 return {faces,actor:true,bounds:{a:-9.58,b:-.35,width:4.84},boiler:{start:-8.65,end:-3.1,length:5.55,radius:1.2},cab:{start:-3.05,end:-.35,opening:2.24},beam:{x:-9.23,width:4.3,depth:.22},chimney:{x:-8.05}};
}
/* Static engine bake with per-pixel depth. Long overlapping cylindrical and
   cabin surfaces cannot be ordered reliably by one face-centre depth. All
   allocations/readbacks happen at scene preparation, never in the live loop. */
function raster(model,scale,assets){
 let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
 for(const f of model.faces)if(f.v)for(const v of f.v){const x=(v[0]-v[1])*scale,y=((v[0]+v[1])*.5-v[2])*scale;minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
 const stockSize=assets.stockSize||128,frequency=stockSize/128;
 const left=Math.floor(minX)-2,top=Math.floor(minY)-2,W=Math.ceil(maxX)-left+3,H=Math.ceil(maxY)-top+3,pixels=new Uint8ClampedArray(W*H*4),depth=new Float64Array(W*H),priority=new Int32Array(W*H);depth.fill(-Infinity);
 function colour(mat){if(mat[0]!=='#')return null;const n=parseInt(mat.slice(1),16);return [(n>>16)&255,(n>>8)&255,n&255];}
 function triangle(a,b,c,mat,shade,rank=0){const ax=(a[0]-a[1])*scale-left,ay=((a[0]+a[1])*.5-a[2])*scale-top,bx=(b[0]-b[1])*scale-left,by=((b[0]+b[1])*.5-b[2])*scale-top,cx=(c[0]-c[1])*scale-left,cy=((c[0]+c[1])*.5-c[2])*scale-top,den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy);if(Math.abs(den)<1e-8)return;
 const loX=Math.max(0,Math.floor(Math.min(ax,bx,cx))),hiX=Math.min(W-1,Math.ceil(Math.max(ax,bx,cx))),loY=Math.max(0,Math.floor(Math.min(ay,by,cy))),hiY=Math.min(H-1,Math.ceil(Math.max(ay,by,cy))),rgb=colour(mat),tex=assets.stockPixels[mat],da=a[0]+a[1]+a[2],db=b[0]+b[1]+b[2],dc=c[0]+c[1]+c[2],alpha=Math.abs(shade),rr=shade>0?21:255,gg=shade>0?43:240,bb=shade>0?51:204;
 for(let y=loY;y<=hiY;y++)for(let x=loX;x<=hiX;x++){const u=((by-cy)*(x+.5-cx)+(cx-bx)*(y+.5-cy))/den,v=((cy-ay)*(x+.5-cx)+(ax-cx)*(y+.5-cy))/den,w=1-u-v;if(u<-.00001||v<-.00001||w<-.00001)continue;const z=u*da+v*db+w*dc,k=y*W+x;if(z<depth[k]-1e-7||Math.abs(z-depth[k])<1e-7&&rank<priority[k])continue;depth[k]=z;priority[k]=rank;let r,g,blue;
 if(tex){const wx=u*a[0]+v*b[0]+w*c[0],wy=u*a[1]+v*b[1]+w*c[1],wz=u*a[2]+v*b[2]+w*c[2],tx=((Math.floor((wx*51+wy*11)*frequency)%stockSize)+stockSize)%stockSize,ty=((Math.floor((wy*37+wz*49)*frequency)%stockSize)+stockSize)%stockSize,t=(ty*stockSize+tx)*4;r=tex[t];g=tex[t+1];blue=tex[t+2];}else{r=rgb[0];g=rgb[1];blue=rgb[2];}const i=k*4;pixels[i]=r*(1-alpha)+rr*alpha;pixels[i+1]=g*(1-alpha)+gg*alpha;pixels[i+2]=blue*(1-alpha)+bb*alpha;pixels[i+3]=255;}
 }
 for(const f of model.faces){if(!f.v)continue;triangle(f.v[0],f.v[1],f.v[2],f.mat,f.shade,f.priority);triangle(f.v[0],f.v[2],f.v[3],f.mat,f.shade,f.priority);}
 // A registered upright cutout gets the same depth test as the cab apertures.
 if(model.actor){const actor=assets.worker.sprites.watch,rect=actor.rect,anchor=actor.anchor,height=2.3*scale,width=height*rect[2]/rect[3],x=-.85,y=2.4,z=2.72,sx=(x-y)*scale-left-width*anchor[0],sy=((x+y)*.5-z)*scale-top-height*anchor[1],source=assets.workerPixels,sourceW=assets.worker.image.width;
 for(let py=Math.max(0,Math.floor(sy));py<Math.min(H,sy+height);py++)for(let px=Math.max(0,Math.floor(sx));px<Math.min(W,sx+width);px++){const u=(px-sx)/width,v=(py-sy)/height,ix=rect[0]+Math.min(rect[2]-1,Math.floor(u*rect[2])),iy=rect[1]+Math.min(rect[3]-1,Math.floor(v*rect[3])),k=(iy*sourceW+ix)*4,alpha=source[k+3]/255,d=x+y+z+(anchor[1]-v)*2.3,q=py*W+px;if(alpha<.1||d<depth[q])continue;const j=q*4;pixels[j]=source[k]*alpha+pixels[j]*(1-alpha);pixels[j+1]=source[k+1]*alpha+pixels[j+1]*(1-alpha);pixels[j+2]=source[k+2]*alpha+pixels[j+2]*(1-alpha);pixels[j+3]=Math.max(pixels[j+3],source[k+3]);depth[q]=d;}
 }
 return {pixels,width:W,height:H,left,top};
}
function draw(p){if(!mesh)mesh=build();p.solid(mesh);}
return {build,raster,draw};
});
