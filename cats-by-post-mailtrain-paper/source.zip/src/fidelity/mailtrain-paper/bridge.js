/* One solid arch section, translated at the original scenery speed. Its curved
   soffit and pier reveals connect both facades; a depth bake resolves the vault. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MailtrainBridge=factory();})(globalThis,function(){
'use strict';let model;
function build(){
 const faces=[],far=-.1,near=4.8,spring=-3.55,radius=3.1,foot=-66.52,N=32;
 function face(A,B,C,D,mat='stone',shade=0,tag='wall'){faces.push({v:[A,B,C,D],mat,shade,tag,priority:faces.length});}
 function rect(x0,x1,y,z0,z1,shade=0,mat='stone',tag='wall'){face([x0,y,z0],[x1,y,z0],[x1,y,z1],[x0,y,z1],mat,shade,tag);}
 function box(x,y,z,w,d,h,shade=0,tag='pier'){
  face([x+w,y,z],[x+w,y+d,z],[x+w,y+d,z+h],[x+w,y,z+h],'stone',shade+.13,tag);
  rect(x,x+w,y+d,z,z+h,shade,'stone',tag);
  face([x,y,z+h],[x+w,y,z+h],[x+w,y+d,z+h],[x,y+d,z+h],'stone',shade-.08,tag);
 }
 // Both facades bound the same opening. The top strips follow the arch exactly.
 for(const y of [far,near]){
  const shade=y===far?.24:.035;
  rect(0,.65,y,foot,.3,shade);rect(6.85,7.5,y,foot,.3,shade);
  for(let i=0;i<N;i++){const a=Math.PI-i*Math.PI/N,b=Math.PI-(i+1)*Math.PI/N,x0=3.75+radius*Math.cos(a),x1=3.75+radius*Math.cos(b),z0=spring+radius*Math.sin(a),z1=spring+radius*Math.sin(b);
   face([x0,y,z0],[x1,y,z1],[x1,y,.3],[x0,y,.3],'stone',shade);
  }
 }
 // The tunnel is genuinely 4.9 units deep; darker material sits under the vault.
 for(let i=0;i<N;i++){const a=Math.PI-i*Math.PI/N,b=Math.PI-(i+1)*Math.PI/N,x0=3.75+radius*Math.cos(a),x1=3.75+radius*Math.cos(b),z0=spring+radius*Math.sin(a),z1=spring+radius*Math.sin(b);
  face([x0,far,z0],[x1,far,z1],[x1,near,z1],[x0,near,z0],'stone',.65,'soffit');
  for(let course=0;course<7;course++){const y0=far+course*.7+.012,y1=y0+.676,u=.014,v=.986;
   face([x0+(x1-x0)*u,y0,z0+(z1-z0)*u],[x0+(x1-x0)*v,y0,z0+(z1-z0)*v],[x0+(x1-x0)*v,y1,z0+(z1-z0)*v],[x0+(x1-x0)*u,y1,z0+(z1-z0)*u],'stone',.32+.18*Math.sin((a+b)/2)+(course%2)*.025,'vault-course');
  }
 }
 face([.65,far,foot],[.65,near,foot],[.65,near,spring],[.65,far,spring],'stone',.38,'reveal');
 face([6.85,near,foot],[6.85,far,foot],[6.85,far,spring],[6.85,near,spring],'stone',.46,'reveal');
 // Scored reveal courses give the inner pier wall a scale and a clear receding axis.
 for(let row=0;row<Math.ceil((spring-foot-.42)/.48);row++)for(let col=0;col<7;col++){
  const z0=foot+.42+row*.48+.012,z1=Math.min(spring,z0+.456),y0=far+col*.7+.012,y1=y0+.676;if(z1<=z0)continue;
  face([.65,y0,z0],[.65,y1,z0],[.65,y1,z1],[.65,y0,z1],'stone',.31+(row%3)*.025,'reveal-course');
 }
 // Recessed scored joints follow the masonry, stopping at the curved opening.
 const mortar='#997660',joint=.018;
 function opening(z){return z<spring?radius:z>spring+radius?0:Math.sqrt(radius*radius-(z-spring)*(z-spring));}
 for(let row=0;row<Math.ceil((.16-foot-.58)/.46);row++){
  const z=.16-row*.46,hole=opening(z),lo=hole?3.75-hole:7.5,hi=hole?3.75+hole:7.5;
  rect(0,lo,near+.003,z,z+joint,0,mortar,'joint');if(hole)rect(hi,7.5,near+.003,z,z+joint,0,mortar,'joint');
  for(let col=0;col<10;col++){const x=col*.83+(row%2)*.415;if(x>=7.5)continue;const arc=Math.abs(x-3.75)<radius?spring+Math.sqrt(radius*radius-(x-3.75)*(x-3.75)):foot;
   const bottom=Math.max(foot+.58,z-.46+joint,arc);if(bottom<z)rect(x,x+joint,near+.004,bottom,z,0,mortar,'joint');
  }
 }
 // Individually cut facing stones: extruded wedges with lit card edges.
 const inner=3.1,outer=3.47,front=near+.23,count=17;
 for(let i=0;i<count;i++){
  const a=i*Math.PI/count+.005,b=(i+1)*Math.PI/count-.005,shade=(i%4)*.026-.2;
  const A=[3.75+inner*Math.cos(a),front,spring+inner*Math.sin(a)],B=[3.75+inner*Math.cos(b),front,spring+inner*Math.sin(b)],C=[3.75+outer*Math.cos(b),front,spring+outer*Math.sin(b)],D=[3.75+outer*Math.cos(a),front,spring+outer*Math.sin(a)];
  face(A,B,C,D,'stone',shade,'arch-stone');
  face([A[0],near,A[2]],[B[0],near,B[2]],B,A,'stone',.24,'arch-edge');
  face(D,C,[C[0],near,C[2]],[D[0],near,D[2]],'stone',-.14,'arch-edge');
  face(B,[B[0],near,B[2]],[C[0],near,C[2]],C,'stone',.19,'arch-edge');
 }
 // Tall connected piers descend behind the existing near bank and lower crop.
 // Their foundations never hang in front of the distant trees or upper riverbank.
 for(let row=0;row<Math.ceil((spring-foot-.42)/.48);row++){const z=Math.max(foot+.42,spring-.48*(row+1)),top=spring-.48*row-.025;if(top<=z)continue;for(const x of [0,6.85])box(x,near,z,.65,.09,top-z,(row%3)*.025-.035,'pier-course');}
 for(const x of [0,6.85]){box(x,far-.16,foot,.65,5.22,.42,.12,'footing');box(x,near-.02,foot+.42,.65,.24,.16,.06,'footing');}
 // A two-layer cap carries the unchanged sleepers; the lower edge casts a narrow shadow.
 box(0,far-.14,.02,7.5,5.18,.15,.2,'ledge-shadow');
 box(0,far-.2,.17,7.5,5.3,.15,-.09,'cap');
 face([0,far-.2,.32],[7.5,far-.2,.32],[7.5,near+.2,.32],[0,near+.2,.32],'cream',.13,'cap-top');
 rect(0,7.5,near+.2,.17,.32,.09,'cream','cap-edge');
 for(let x=0;x<7.5;x+=.75)rect(x,x+.014,near+.2,.175,.32,.05,mortar,'cap-joint');
 for(const f of faces)f.v=f.v.map(v=>[v[0]*1.6,v[1],v[2]]);
 return {faces,period:12,far,near,foot,radius,spring};
}
function prepare(p){if(!model)model=build();p.c.save();p.c.globalAlpha=0;p.solid(model,0,0,0,64);p.c.restore();}
function draw(p,distance){const shift=((distance%12)+12)%12;for(let i=-5;i<8;i++)p.preparedSolid(model,i*12+shift);}
return {build,prepare,draw};
});
