/* One floor projection in tile units. A tile has equal axes and a 2:1 diamond. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MailtrainGeometry=factory();})(globalThis,function(){
 'use strict';
 const layout=Object.freeze({floor:3.1,boardX:1,boardY:.8,end:16,back:-1.15,front:5.4,railBack:.7,railFront:3.7,railZ:.7,wheelR:.7,engineEnd:-.35,vanStart:16.35});
 function createCamera(){return {x:0,y:0,scale:40,zoom:1,panX:0,panY:0};}
 function project(c,x,y,z,o){o.x=c.x+(x-y)*c.scale;o.y=c.y+((x+y)*.5-z)*c.scale;return o;}
 function inverse(c,x,y,z,o){const a=(x-c.x)/c.scale,b=(y-c.y)/c.scale+z;o.x=b+a*.5;o.y=b-a*.5;return o;}
 function cell(c,l,x,y,o){return project(c,x+layout.boardX+(l.board.roomX||0),y+layout.boardY+(l.board.roomY||0),layout.floor+.025,o);}
 function pick(c,l,x,y,o){inverse(c,x,y,layout.floor+.025,o);const fx=o.x-layout.boardX-(l.board.roomX||0),fy=o.y-layout.boardY-(l.board.roomY||0),b=l.board;
 if(fx< -1||fy< -1||fx>b.w+1||fy>b.h+1){o.valid=false;o.x=o.y=-1;}else{o.valid=true;o.x=Math.max(0,Math.min(b.w-1,Math.floor(fx)));o.y=Math.max(0,Math.min(b.h-1,Math.floor(fy)));}return o;}
 function hatchLid(x,y,z,d,open,out){const lo=.12,hi=.88,angle=open*.52;
  for(let i=0;i<4;i++){let u=i===1||i===2?hi:lo,v=i>=2?hi:lo,dist;
   if(d===0){dist=u-lo;u=lo+dist*Math.cos(angle);}else if(d===2){dist=hi-u;u=hi-dist*Math.cos(angle);}else if(d===1){dist=v-lo;v=lo+dist*Math.cos(angle);}else{dist=hi-v;v=hi-dist*Math.cos(angle);}
   out[i].x=x+u;out[i].y=y+v;out[i].z=z+.04+dist*Math.sin(angle);
  }return out;
 }
 function fit(c,l,w,h,insets,mode){
 const left=insets.left+12,top=insets.top+14,W=Math.max(100,w-left-insets.right-12),H=Math.max(100,h-top-insets.bottom-16);
 // Bounds in projected coordinates, including roof and wheel contacts.
 const bx=1+(l.board.roomX||0),by=.8+(l.board.roomY||0);
 const minX=mode==='journey'?-15:bx-by-l.board.h-.5,maxX=mode==='journey'?(+l.id.slice(2)>=8?29:23):bx+l.board.w-by+.6,minY=mode==='journey'?-10:(bx+by)*.5-7.5,maxY=mode==='journey'?16:(bx+by+l.board.w+l.board.h)*.5-2.1;
 const s=Math.min(W/(maxX-minX),H/(maxY-minY))*c.zoom;
 c.scale=s;c.x=left+W*.5-(minX+maxX)*.5*s+c.panX;c.y=top+H*.5-(minY+maxY)*.5*s+c.panY;return c;
 }
 return {layout,createCamera,project,inverse,cell,pick,fit,hatchLid};
});
