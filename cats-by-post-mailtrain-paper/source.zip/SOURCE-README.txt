Mail Train room-owned source overlay. Apply to a checkout of holleyy/cosysortie
at base 923b40d7c3ef2b9e4fab49d290267f0094a1a9bb. Canonical files are intentionally not bundled.
Build: python3 studies/mailtrain-paper/build-study.py
Verify: node --test tests/mailtrain-paper-*.test.js
The playable HTML and review evidence are published alongside this archive.
Integration proposal: studies/mailtrain-paper/INTEGRATION.md
Current phase: studies/mailtrain-paper/FACING.md
