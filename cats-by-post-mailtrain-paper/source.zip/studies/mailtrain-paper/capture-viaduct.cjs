const{chromium}=require('playwright'),fs=require('node:fs');
(async()=>{const out='docs/review-images/mailtrain-paper/viaduct';fs.mkdirSync(out,{recursive:true});const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),p=await b.newPage({viewport:{width:1440,height:1000}}),rows=[],errors=[];p.on('pageerror',e=>errors.push(e.message));
 for(const phase of ['before','after']){
  await p.goto('http://127.0.0.1:8801/'+(phase==='before'?'work/mailtrain-paper/viaduct/before.html':'studies/mailtrain-paper/playable.html'));await p.waitForFunction(()=>window.MailtrainStudy?.ready);await p.evaluate(()=>{requestAnimationFrame=()=>0;document.getElementById('mp-view').click();});await p.waitForTimeout(100);
  for(const id of ['5-1','5-4','5-8','5-15']){
   await p.evaluate(id=>{const s=MailtrainStudy;s.select(id);s.renderer.setView('journey');const f=s.frame();f.worldFrame=300;s.renderer.prepare(f);s.renderer.draw(f);},id);
   const file=phase+'-'+id+'-journey.jpg';await p.screenshot({path:out+'/'+file,type:'jpeg',quality:92});rows.push({phase,id,file});
  }
  await p.evaluate(()=>{const s=MailtrainStudy,r=s.renderer;s.select('5-1');r.setView('journey');const f=s.frame();f.worldFrame=300;r.prepare(f);const at=MailtrainGeometry.project(r.camera,8,4.8,-2.8,{});r.zoomAt(at.x,at.y,2.2);r.prepare(f);r.draw(f);});
  const file=phase+'-arch-close.jpg';await p.screenshot({path:out+'/'+file,type:'jpeg',quality:94});rows.push({phase,id:'5-1',file,zoom:2.2});console.log(phase+' captured');
 }
 fs.writeFileSync(out+'/captures.json',JSON.stringify({base:'f2173ec3311273e656c444b6f020b3ebb84cf157',build:JSON.parse(fs.readFileSync('studies/mailtrain-paper/build.json')),rows,errors},null,2));await b.close();if(errors.length)throw Error(errors.join('\n'));
})().catch(e=>{console.error(e);process.exit(1);});
