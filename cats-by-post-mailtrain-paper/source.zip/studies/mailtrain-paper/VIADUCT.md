# Papercraft viaduct implementation plan

> Execute inline using the executing-plans skill; one fresh Astra review at the end.

**Goal:** Give the existing warm viaduct convincing vaulted openings, layered
card masonry and supported piers, without changing the train or landscape art.
**Architecture:** One repeatable, depth-resolved arch mesh on the existing floor
projection. Prepare its textured raster once per effective scale; translate
the same prepared section at the original scenery travel speed.
**Tech stack:** Existing plain JavaScript/Canvas painter and room mesh rasteriser.
**Spec:** Alex approved the arch-depth proposal in this chat on 17 November:
deep openings, raised arch stones, projecting ledge, grounded bases and warm
outer/cool recessed faces. Keep the water texture, large trees and train intact.

Phase base: `f2173ec3311273e656c444b6f020b3ebb84cf157` on the existing `codex/mailtrain-paper-fidelity` worktree.
Original main base: `923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`.

## Constraints and ownership

Own `src/fidelity/mailtrain-paper/bridge.js`, its calls in room `life.js` and
`renderer.js`, room `materials.js`, the room builder, tests, study/review tools and evidence here.
Canonical data/rules/clocks/saves, original artwork, other rooms, shared files
and native remain untouched. Publication is authorised only to the existing
`grodappsite/cats-by-post-mailtrain-paper/` prefix. No source-main merge.
Keep the existing scratch directory and earlier evidence. This room-owned
ledger replaces generic skill workspace files to respect file ownership.

## Review focus

- Solid geometry must occlude the far wall correctly through the near opening.
- Twelve-unit wrap must not pop or leave seams as the bridge moves beneath the train.
- Pier feet must settle into the scene without painting over the river artwork.
- Zoom, entry transforms and high DPR must reuse bounded prepared resources.
- Board pixels, picks and canonical motion remain independent of the viaduct.

## Tasks

1. **Build and inspect one complete arch.**
   - [x] Add regression checks for a real vault across the rail width, nonzero
     facing-stone thickness, pier support, open aperture and exact repeat period.
     Run them against the old rendering and retain the expected failures.
   - [x] Build `MailtrainBridge.prepare(p)` / `draw(p,distance)` using the existing
     paper material and depth raster. Integrate through room lifecycle only.
   - [x] Capture matching before/after close-ups and journey views; inspect them.
2. **Verify the full moving scene.**
   - [x] Check all four board sizes, first/largest boards, station/entry states,
     near/far tree occlusion and a complete bridge wrap. Capture a short clip.
   - [x] Run room tests, board/camera/resource checks and chapter preservation.
     Compare board pixels and original assets against the phase base.
   - [x] Obtain one fresh Astra review; resolve material findings and record limits.
3. **Deliver the refinement.**
   - [x] Update the gallery, provenance and integration handover. Package and check
     phone/landscape/desktop from exact served bytes; commit room-owned source.
   - [ ] Refresh grodappsite main, preserve every other prefix, publish only this
     study and verify provider deployment. Record source/site commits and hashes.

## Ledger

Pre-flight: the bridge uses the existing Painter.solid cache and rasteriser;
prepare must warm the cache before any live draw. No shared API is introduced.
The same scoped geometry supplies all 15 deliveries; no new image generation
is needed because the existing paper stock is applied to new physical faces.

Ruling: widen the spans from six to twelve floor units and use shallower segmental
arches. A full-depth vault on the old narrow span nearly closed the opening from
this camera. The new spacing keeps landscape visible. Travel remains frame/30;
only the decorative masonry repeat becomes six seconds. All gameplay and chapter
timing is unchanged. Cost: a different, broader viaduct rhythm for visual review. The initial eight-unit
prototype was broadened again when the review exposed the suspended pier bases;
the taller connected piers need larger openings to retain the river view.

Task 1 complete: two missing-depth assertions failed on the previous bridge.
The corrected mesh and repeat checks pass in the 47-test room suite.
A prototype scaling defect in shared wedge vertices was caught in the close-up
and corrected before this checkpoint; the bay-bounds regression covers it.

Task 2 evidence: 1,089 board samples, 121 picks and all four cameras match the
previous runtime exactly. Both scenery movement and chapter entry make zero
mesh raster calls after preparation. Full-wrap images match byte for byte.
Canonical chapters, private saves and scenery-off/game-clock independence pass.
20 room surfaces remain stable over 20 level cycles; one is the new arch cache.
First/largest motion clips span frames 180–540 and the join at 360.

The six existing artwork files remain byte-identical. Pier faces are resolved
against their full depth; the scenery remains the existing layered image.
Physical river hydrodynamics/reflections and terrain intersections are not
modelled by this visual study. Physical iPhone/Safari performance is unqualified.

Final author correction: one independent Astra review confirmed the deeper
construction and cache stability but found suspended pier bases and detached
mortar strokes. Both are corrected in the single author fix pass, with explicit
failing regressions followed by passing geometry/grounding checks. The footing
probe now resolves its markers in the actual depth mesh; all 78 phone/landscape/desktop journey
states hide the bottoms behind the foreground/crop. Independent-review.md records
the original findings and author decisions; no second review is claimed.

The pier foundations extend to -66.52; final spans are 12, with 9.92-wide openings
and a 3.1 rise. The one bridge raster is capped at 64 pixels per world unit to
bound its high-zoom memory. Existing painter users retain their previous density.

Final exact-package checks pass in portrait 390×844 DPR3, landscape 720×400
DPR2 and desktop 1440×1000 DPR1: touch wins, saved reloads, maximum board,
Journey view and controls. The review gallery decodes four images and two
clips, has five working navigation links and no phone-width overflow.
Runtime SHA-256: `b8f5e45dedee151d9cd2383cf3b000a3a74a9b121b807b33b4f6a3c15d6cff1e`.

Portrait follow-up before delivery: visual inspection of the packaged phone
journey exposed a base under the trees despite the desktop grounding check.
The DPR-aware regression now checks 78 states across portrait, landscape and
desktop. The prior geometry fails with up to 448 exposed phone pixels and
3 landscape pixels; the final version has zero in every state. Foundations
extend farther below the view, while the raster cap drops to 64 so its maximum
area remains about the same. No new independent review was requested.
