# Walking direction correction

User report: the worker faces away from his walking direction. This is a
presentation bug, not optional expressive acting. Phase base
`fd257438bd666819c5ae64340bd4476a7dd3feca`; original main base
`923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`.

## Cause and correction

Both existing walking cutouts show the worker's back. Mirroring correctly
reverses screen-left/right but cannot turn a rear view into a front view.
Returning from tea along +x travels down/right on the isometric floor while
showing the original up/right rear view. The same error affects the +x and +y
sections of departure.

Two generated front-facing cutouts supply a stride and a passing step. They
match the existing worker and retain the satchel. Only crop/scale registration
packs them into `worker-front.webp`; masters and coordinates are retained.
The original worker atlas, every other previous image and all canonical files
remain unchanged.

| Floor travel | Screen travel | Cutout |
| --- | --- | --- |
| +x | down/right | front, unmirrored |
| +y | down/left | front, mirrored |
| −x | up/left | original rear, mirrored |
| −y | up/right | original rear, unmirrored |

The existing routes, phase lengths, foot-root positions and walking cadence are
unchanged. Front cells use 576px height at 2.3625 world units, matching the original
512px at 2.1 scale. Explicit anchors register the projected ground point between
the shoes. All art changes stay in the Train-owned asset folder.

The renderer now loads 6 images. The additional 768×576 decoded front atlas adds
one bounded image; it adds no retained canvas or new frame allocation. The
resource census still counts 19 room surfaces. `textureBytes` continues to count
retained CPU stock/worker pixel arrays, excluding browser-decoded image memory.
The shared frame/lifecycle contract and original engine driver art are unchanged.

## Verification and evidence

Two directional regressions fail on the old renderer and pass on the correction.
They sample every half-frame of both walks and every departure leg, compare
actual projected movement with the sheet/mirror sent to the live sprite draw,
and cover both alternating steps. All 42 room tests pass. A separate comparison
against the previous runtime checks 6,362 half-frame route samples: positions,
pose cadence and mirror flags are unchanged.

The final browser depth probes remain zero at all eight desk/trolley crossings;
the courier is naturally hidden by the attached coach at frames 204 and 300.
Before/after screenshots and current tea/departure clips are in the
[facing review](facing-review.html). Captures identify the exact runtime in
`docs/review-images/mailtrain-paper/facing/`. Historical whole-journey evidence
remains linked as the prior checkpoint, rather than being relabelled as fresh.

The exact packaged page passes touch play, saved reload, maximum board, Journey
view and controls checks at portrait 390×844 DPR3, landscape 720×400 DPR2 and
desktop 1440×1000 DPR1. Its phone review gallery decodes all three images, loads
both clips and has four working links with no horizontal overflow. These are
Chromium emulations; physical iPhone/Safari testing is not claimed.

Playable SHA-256:
`8d1f7c6b3283cccf37b4a7b3dd7207a8dce8336beb6b1803fc9b3f15ba3aee3c`.
Prepared site base: `8fb9c3109dee254e79ab1f8a1f3be61e5bea734d`.
The final publication record is in PUBLICATION.md. No new independent review
was commissioned for this focused correction; previous Astra reviews remain
labelled as their original checkpoints.

Ownership: room life.js and renderer census; the new front atlas, metadata and
masters; room builder/packing/capture/review tools; facing tests and evidence.
No shared file, native source, other room, canonical data or save code changes.
Publication updates only the already-authorised `cats-by-post-mailtrain-paper/`
prefix on grodappsite, preserving other chats' updates. No source-main merge.
