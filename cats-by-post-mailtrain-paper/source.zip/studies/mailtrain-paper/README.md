# Valley Mail — playable fidelity study

Latest follow-up: [carrier/basket depth and jump clearance](ARRIVAL.md),
with [before/after and slow-motion evidence](arrival-review.html).
35 room tests and all 15 canonical deliveries pass.

Latest: [end-wall and atmosphere phase](ATMOSPHERE.md) · [new comparison gallery](atmosphere-review.html).
The coach end is closed around a real cab doorway; dusk/night lamps, clock,
tea steam and a continuous postal route are implemented. All31 room tests pass.

Earlier: [shelf, box and piece geometry corrections](GEOMETRY.md), including
depth-resolved cubbies, wrapped parcel tape, directional open hatches and
registered basket contacts. The user authorised the `holleyy/grodappsite`
publication on 15 November 2026: [open the published study](https://holleyy.github.io/grodappsite/cats-by-post-mailtrain-paper/).

[Open the review gallery](index.html) · [Play the study](playable.html) ·
[Handover](HANDOFF.md) · [Visual QA](design-qa.md)

The selected viaduct direction now runs the original game across all fifteen
Train deliveries. This is a visual review checkpoint. Artwork acceptance,
production integration and physical-device qualification remain open.

The original textured river, large trees and warm valley are restored after
Alex rejected the flat-water/small-tree layering experiment. A mask reuses the
original near-bank pixels in front of bridge masonry. The locomotive has been
rebuilt with a longitudinal boiler, separate cab and three driving axles.

## Workspace and ownership

Branch `codex/mailtrain-paper-fidelity`, worktree `/workspace/cosysortie-mailtrain`.
Exact verified main base: `923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`.
The original checkout remains untouched on `work` at
`032382eb3b8a5551c43a09f0f564f9c38db7fbea`. The refresh used a shallow,
blob-filtered HTTPS fetch, normal TLS/proxy settings and a separate sparse
worktree. No reset, clean or branch replacement was used.

Owned paths: `src/fidelity/mailtrain-paper/`, `studies/mailtrain-paper/`,
`tests/mailtrain-paper-*.test.js`, `docs/review-images/mailtrain-paper/`.
Shared renderer/build/bridge/interface, accepted Office, other rooms, canonical
content, saves and native remain untouched. The standalone site owns only
`cats-by-post-mailtrain-paper/`; see [publication record](PUBLICATION.md).
The source feature branch has not been merged into production.

## Review locally

From the worktree:

```sh
python3 -m http.server 8801 --bind 127.0.0.1
```

Open `http://127.0.0.1:8801/studies/mailtrain-paper/`.
The self-contained playable HTML also opens directly. The delivery picker gives
access to 5-1–5-15; it does not fabricate wins. Arrangements start empty. Review →
Fill original solution is an explicit convenience. Original Hint, Clear,
Send/Stop, results, chapter story and Next actions remain available.
Study progress uses `catsByPost.mailtrainPaper.study.v1:` before its first read.

## Scope

| Deliveries | Board |
|---|---|
| 5-1–5-3 | 8×3 |
| 5-4–5-7 | 9×3 |
| 5-8–5-11 | 10×3 |
| 5-12–5-15 | 10×4 |

The original four-cat teaching demo, 72-frame entry, three station stops,
carriage addition and finished-board departure remain driven by canonical clocks.
The camera follows the connected train; scenery passes around a stable board.

## Sources and history

[Specification](IMPLEMENTATION-SPEC.md), [execution plan](IMPLEMENTATION-PLAN.md),
[execution ledger](PROGRESS.md), [integration proposal](INTEGRATION.md),
[asset provenance](../../src/fidelity/mailtrain-paper/assets/PROMPTS.md).
The [refinement checkpoint](refinement-checkpoint.html), earlier composition
options and disposable motion model remain historical evidence, not current
playable screenshots. See HANDOFF for reproduction and verified limits.
