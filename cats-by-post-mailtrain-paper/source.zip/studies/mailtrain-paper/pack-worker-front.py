"""Pack generated cutouts; crop/scale registration only, no painted pixel edits."""
from pathlib import Path
from PIL import Image
import hashlib,json,shutil
root=Path(__file__).resolve().parents[2];assets=root/'src/fidelity/mailtrain-paper/assets'
inputs=[('exec-bbb1d436-8edb-4078-88be-e0a4c3a9b863.png',(0,0,887,887),(565,786)),('exec-35afd730-e7f2-491a-b234-35c066ab9503.png',None,(550,1380))]
out=Image.new('RGBA',(768,576));meta={'sprites':{},'notes':'Front-facing southeast steps. Roots register the projected centre between shoe contacts; 576px cells use 2.3625 world height to retain the original 512px / 2.1 scale. Artwork from retained image-generation masters; crop/scale only.'};sources=[]
for i,(name,crop,root_at) in enumerate(inputs):
 dst=assets/'masters'/name
 if not dst.exists():shutil.copyfile(Path('/workspace/generated_images')/name,dst)
 im=Image.open(dst).convert('RGBA');im=im.crop(crop) if crop else im
 # The alpha bounding rectangle preserves antialiased source edges.
 b=im.getchannel('A').point(lambda v:255 if v>=32 else 0).getbbox();box=(max(0,b[0]-2),max(0,b[1]-2),min(im.width,b[2]+2),min(im.height,b[3]+2));im=im.crop(box);scale=479/(root_at[1]-box[1]);size=(round(im.width*scale),round(im.height*scale));im=im.resize(size,Image.Resampling.LANCZOS);left=round((384-size[0])/2);top=20
 assert left>=0 and top+size[1]<=576
 out.alpha_composite(im,(i*384+left,top));anchor=[(left+(root_at[0]-box[0])*scale)/384,(top+479)/576]
 meta['sprites']['walk-'+str(i)]={'rect':[i*384,0,384,576],'anchor':anchor,'heading':[1,.5]}
 sources.append({'master':name,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'crop':crop,'alphaBounds':box,'groundRoot':root_at,'scale':scale})
out.save(assets/'worker-front.webp',lossless=True,method=6);(assets/'worker-front.json').write_text(json.dumps(meta,indent=2)+'\n')
p=assets/'manifest.json';manifest=json.loads(p.read_text());manifest['generated']['worker-front']={'masters':sources,'image':'worker-front.webp','sha256':hashlib.sha256((assets/'worker-front.webp').read_bytes()).hexdigest(),'size':list(out.size),'purpose':'Correct front/back facing for southeast/southwest travel; original rear walk art unchanged.'};p.write_text(json.dumps(manifest,indent=2)+'\n');print(sources)
