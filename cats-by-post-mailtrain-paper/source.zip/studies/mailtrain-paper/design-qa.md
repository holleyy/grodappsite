# Visual QA — review checkpoint, not art acceptance

Latest follow-up: [carrier/basket depth and jump clearance](ARRIVAL.md),
with [before/after and slow-motion evidence](arrival-review.html).
35 room tests and all 15 canonical deliveries pass.

Latest follow-up: [end-wall and atmosphere phase](ATMOSPHERE.md). The seat-side
opening is now a solid curved end bulkhead with an aligned cab doorway. Dusk
and night architecture receive restrained grading/warm lamps; sampled board
colours remain exact. The workman no longer jumps sideways at the tea stop.
The real wall clock and a small hot-mug curl use the existing ambient clock.

Latest geometry findings/fixes and fresh evidence: [GEOMETRY.md](GEOMETRY.md).
The engine pan-cache limitation described historically below is now corrected.

The selected target remains the refined Valley Mail viaduct composition.
The current gallery contains actual playable screenshots and separately labelled
concept history. No claim is made that the screenshot now equals Lantern Quay's
finish in every material or that Alex has accepted the new locomotive.

## Latest feedback

The flat procedural river and smaller repeated trees were rejected. The active
build restores the original `countryside.webp`: textured ripples, warm reflected
light and the large bank trees. `foreground-mask.webp` supplies only alpha;
foreground colour comes from the original landscape. It draws above bridge
masonry and below the clear train/board. Its screen registration matches the
background even during the entry camera transform. The unused alternate art
and `landscape.js` are historical prototypes and are excluded from the builder.

The earlier engine was too short and broad, with a hidden boiler cap incorrectly
painted across its body. The new tank engine has a longitudinal boiler, separate
rear cab, front beam, three driving axles and rods. A prepare-only depth raster
resolves intersecting faces in the same projection as the carriage.

## Author checks

- First8×3 and maximum10×4: full board visible in sorting view; attached van
  does not cover sampled tile interiors. Journey view establishes complete ends.
- Equal floor axes, matching camera/picking inverse, wheel bottoms on the rails,
  filled couplings and a dedicated dispatch bay. The bridge runs beyond the frame.
- Warm timber/teal/cream faces, supported cabinet bases, seat, tea desk, mail
  slots, bags, trolley, parcels and lamps. Working actor stays behind the board.
- Registered accepted cat artwork and complete card carriers; fixed hind-sole
  anchors now hold through the original .4s takeoff boundary. Original timing
  and the .2s flight remain unchanged. Front carrier rim is restored during hold.
- Dusk/max-board grading retains the same readable board colours. Grayscale
  capture is available. No pulsing board light is introduced.
- Canonical story/demo/station/growth/departure states are live. Motion and
  scenery-off checks leave the board and gameplay clock independent.

## Still open

Visual acceptance, mask-edge refinement in all moving compositions and nuanced
secondary acting remain open. Postmistress is a
supported held pose; blinking and bag/lamp sway are not represented as finished.
The scenery uses a repeated layered plate rather than fully modelled terrain.
The shared original HUD is retained in the study and is not a final interface.

The single independent Astra review found no Critical issues and three Important
ones; all three have author regression fixes. Its original Minor prepare-time issue is corrected: panning reuses prepared
engine/cabinet rasters. Static architecture compositing still costs time. Cloud
measurements are not a phone performance result. Physical iPhone/Safari/Metal,
whole-page memory and sustained frame-rate qualification remain untested.

Do not publish or integrate on the strength of rule checks alone. Final shared
integration and any preview prefix belong to the integration owner after the
user's explicit authorisation.
