"""Only writes the isolated Train study. Canonical inputs fail closed."""
from pathlib import Path
import hashlib,json,base64
ROOT=Path(__file__).resolve().parents[2]; HERE=Path(__file__).resolve().parent
PIN={
 'sorting_office.html':'b2dd563faa7e8ae40e14169c7f626de0454ae3cb4fc4befbb20e050444c89c66',
 'src/data/levels.json':'be1c22ee6456819c200e42d6f8abb48b9c4cc4db9c414928c7fc60ea10cf40a7',
 'src/sim/10_rules.js':'eaeeff8565f68d32ae6d8489be34664dacf4948a71f2bdf0b0835579454691c4',
 'src/sim/12_boardanim.js':'5c181265db6570a822ee9fc08400a19cf4eff91beea5e12a6779d46876c88885',
 'src/app/43e_train_chapter.js':'87d330ddb51a860e020b4e10e11f9fa625a7a2dc542a71ad4f2fc9fb243a1fc4'}
for p,h in PIN.items():
 assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,'Protected input changed: '+p
html=(ROOT/'sorting_office.html').read_text()
store=(ROOT/'src/app/42b_progress.js').read_text().split('const LOCAL_STORE = ',1)[1].split('\nlet progressStore',1)[0]
old='const LOCAL_STORE = '+store
assert html.count(old)==1
html=html.replace(old,(HERE/'store.js').read_text()+'\nconst LOCAL_STORE = MailtrainStudyStore.create(()=>window.localStorage);')
src=ROOT/'src/fidelity/mailtrain-paper';parts=[];assets={}
for name in ['acting','worker','worker-front','paper-stock','countryside','foreground-mask']:
 p=src/'assets'/(name+'.webp')
 a={'src':'data:image/webp;base64,'+base64.b64encode(p.read_bytes()).decode()}
 if p.with_suffix('.json').exists(): a.update(json.loads(p.with_suffix('.json').read_text()))
 assets[p.stem]=a
parts.append('const MP_ASSETS='+json.dumps(assets,separators=(',',':'))+';')
for name in ['geometry','registration','materials','engine','architecture','acting','pieces','life','chapter','renderer']:
 p=src/(name+'.js')
 if p.exists():parts.append(p.read_text())
parts.append((HERE/'host.js').read_text())
marker='// Start once every module above has been defined.\nboot();'
assert html.count(marker)==1
html=html.replace(marker,'\n'.join(parts)+'\nboot();\nmpInit();')
html=html.replace('</head>','<style>'+ (HERE/'style.css').read_text()+'</style></head>')
html=html.replace('<title>Cats by Post</title>','<title>Valley Mail · Cats by Post study</title>')
(HERE/'playable.html').write_text(html)
report={'sha256':hashlib.sha256(html.encode()).hexdigest(),'bytes':len(html.encode()),'canonicalInputs':PIN,'base':'923b40d7c3ef2b9e4fab49d290267f0094a1a9bb'}
(HERE/'build.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['sha256','bytes']}))
