# Independent review and author fixes

One read-only GPT-6 Astra review of base923b40d7 through1da322ff. No repository
edits by the reviewer; no second review pass. It found no Critical issues,
three Important findings and one Minor. Current build identity is in build.json.

| Finding | Disposition and evidence |
|---|---|
| Takeoff feet leave support before .4s | Fixed: accepted Office hind-sole anchors, held carrier root, .2s flight interpolation and front rim. A failing room regression now passes; actual browser captures at ages .25/.35/.5 are retained. |
| Zoomed chapter replay snaps56% at entry end | Fixed: prepared target copies the live view, zoom and pan. Regression covers both views. Actual Chromium endpoint error is below.0001 CSS pixel (canvas transform precision). |
| Pinch/pan drops same-event translation | Fixed: camera fit is applied before reading the zoom anchor. With and without an intervening render now produce identical camera records. |
| Every pan rasterises the engine | Deferred Minor. Reviewer measured136–163ms for1px pans at390×844 DPR3,1.25× in the shared cloud host. Cache-by-scale proposal is documented in INTEGRATION.md. No device performance claim. |

Reviewer independently passed18 pre-fix room tests, all15 canonical campaign
comparisons,1,380 centre picks, actual input/Hint/Clear/Stop/failure/retry,
chapter preservation/stations/entry/exit/City Hall fallback and storage cases.
It reproduced the1da322ff build and confirmed changed paths remained room-owned.
The full1682-test run was author evidence, not independently repeated.

The reviewer declined to judge human visual acceptance, physical
phone/Safari/Metal/sustained performance, whole-page memory or production
integration/publication. Its review used the restored original river/tree
landscape, not the discarded procedural-bank experiment.

Author verification after fixes:21 room tests, actual browser camera reproduction
and takeoff captures, current capture/clip manifests, pixel/stability/resource
checks and protected-path comparison. Machine reports are retained under
`docs/review-images/mailtrain-paper/implementation/`.

## Subsequent user-requested geometry review

Astra independently diagnosed and verified the shelf/parcel/hatch/basket
revision above ae90c761. See GEOMETRY.md and its baseline/after evidence.
All four Important findings closed at d87c7647, with27 independently passing
room tests and browser geometry checks. Its one rounded-mask Minor was then
corrected by the author with an additional failing-to-passing regression.
Current room suite:28. No second independent pass is claimed for that narrow
mask correction. The earlier engine pan-raster Minor is now fixed by caching.
