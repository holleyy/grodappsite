/* Bind before the canonical game's first progress read. Serialisation is unchanged. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MailtrainStudyStore=factory();})(globalThis,function(){
 'use strict';const prefix='catsByPost.mailtrainPaper.study.v1:';
 return {prefix,create(access){return {get(key){try{return access().getItem(prefix+key);}catch(e){return null;}},set(key,value){try{access().setItem(prefix+key,value);}catch(e){/* Private study can run without persistence. */}}};}};
});
