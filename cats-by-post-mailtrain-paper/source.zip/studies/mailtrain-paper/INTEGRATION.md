# Proposed Train presentation integration

The integration chat owns the shared renderer/camera contract, room manager,
build, bridge, interface and final merge. This proposal changes no shared file.
The user authorised standalone publication to `holleyy/grodappsite` on
15 November 2026. This study now owns `cats-by-post-mailtrain-paper/`, which
was absent from the current site tree. Ownership and exact source/build identity
are recorded under that prefix. See [publication record](PUBLICATION.md).
Office and all other existing prefixes retain their original Git object IDs.
No integration-owner acknowledgement is claimed; this record provides the
deployment handoff for that owner. Shared source integration remains separate.

## Calling contract

Load the five active embedded image assets once, then call
`MailtrainPaper.create({canvas,assets,BOARDANIM})`. `prepare(frame)` reads the
current record and synchronously rebuilds bounded static layers only when its
level, chapter, view, camera or viewport inputs change. Asset decoding completes
before attachment; the study then reads the current canonical level, avoiding
stale asynchronous per-level scenes.

The caller reuses one frame with `level`, `boardSource`, `traces`, `time`,
`chapterMode`, `chapterFrame`, `stationStage`, `chapterPose`, `worldFrame`,
`motion`, `grayscale`, `viewport={width,height,dpr}` and
`insets={top,right,bottom,left}`. Dimensions/insets are CSS pixels, gameplay time
is seconds, chapter/ambient frames are60Hz. `chapterPose` is a private reusable
output of `MailtrainChapter.sample(frame,TRAINCHAPTER,out)`.

`draw(frame)` consumes the prepared state. Live board sources/traces come from
the original engine; the renderer does not advance the puzzle. Keep original
input classification, but route CSS coordinates through `pick(x,y,out)`,
`panBy(dx,dy)` and `zoomAt(x,y,factor)`. Invalid pick is exactly
`{valid:false,x:-1,y:-1}`; valid picks preserve the canonical one-tile edge snap.
`setView('board'|'journey')` resets that study camera. Pan and zoom update one
camera immediately, including multiple pointer actions before a draw. Entry's
endpoint now retains the actual selected view/zoom/pan.

The caller supplies measured stable HUD/card insets, chapter input blocking,
visibility and reduced-motion preferences. The study's independent ambient
counter stops when scenery is off or the document is hidden. Original puzzle,
release, result and chapter clocks continue unchanged. No shared new clock is
proposed.

## Lifecycle and resources

The standalone build retains the old renderer as fallback. Its Train-only hooks
are a review adapter, not a proposed patch to every shared global. Continuing
into City Hall uses the original implementation. The production owner should
route equivalent frame/input calls through its existing room lifecycle instead.

`resources()` is a diagnostic room census, not an allocation-free frame call or
whole-page memory measurement. It currently reports17 room surfaces: screen/head/tail, six stock tiles,
foreground composite, four registered basket layers and three cached solid
rasters. At1440×1000 DPR1/max board:6,858,477 surface pixels and12,582,912
retained texture bytes, stable across20 level cycles. These exclude browser
overhead, canonical page/atlas and temporary preparation buffers.
`dispose()` clears prepared layers, solid caches and pattern references; the
caller owns the destination canvas and decoded asset bundle/cache lifecycle.

The prior engine-rebake-on-pan proposal is implemented locally: cabinet and
engine rasters are keyed by model/effective scale, and translation reuses them.
Four pans triggered zero raster calls. Complete static-layer preparation still
costs time; no physical-device or sustained-performance claim is made.
No shared renderer change was needed for this standalone checkpoint.

The atmosphere follow-up adds a real end bulkhead, continuous worker route,
prepared architecture-only light grading and live clock/mug details. Grading
runs before the live floor is painted; 1,089 board pixels across four sizes
match the prior study. Dynamic details read `worldFrame` only and add no new
clock, surfaces or shared API. The frame and lifecycle contract above is unchanged.

## Portability mapping for the integration owner

| Room module | Future shared/native responsibility |
|---|---|
| geometry | Orthographic camera, floor inverse and cell snapping |
| materials/architecture/engine | Complete mesh faces, paper textures, prepared depth |
| acting/pieces | Read-only canonical traces → registered poses/contacts |
| life | Independent seekable decorative world and supported staff poses |
| chapter | Original chapter clock → presentation-only camera/formation |
| renderer | Bounded layer lifecycle, draw order, resource accounting |

This table is a proposal; shared PLAN.md and native files remain untouched.

## Privacy and evidence

The builder pins protected canonical inputs and creates only its own HTML.
Its private `LOCAL_STORE` binding precedes first read, retains original
serialization and never patches Storage.prototype. Study access to all15
records is not a production unlock or win. Review → Fill original solution is
explicit. Any future published study must keep private storage and use a prefix
agreed with the integration owner. Handoff and gallery link reproduction logs,
all-board browser checks, the independent review and remaining visual limits.
