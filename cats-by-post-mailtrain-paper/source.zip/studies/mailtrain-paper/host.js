/* Study-only adapter: original game, progress serializer, rules and chapter clock. */
const MP_HOST={renderer:null,ready:false,motion:!matchMedia('(prefers-reduced-motion: reduce)').matches,view:'board',pick:{valid:false,x:-1,y:-1},
 frame:{level:null,boardSource:null,traces:null,time:0,chapterMode:'',chapterFrame:0,stationStage:0,worldFrame:0,motion:true,grayscale:false,chapterPose:null,viewport:{width:0,height:0,dpr:1},insets:{top:64,right:0,bottom:0,left:0}},
 original:{update,present,renderFrame,gPick,zoomStep,panBy,resetView,tcPrepareStation,cpPrepareEntry}};
let MP_AMBIENT=0;
update=function(){MP_HOST.original.update();if(MP_HOST.motion&&!document.hidden)MP_AMBIENT++;};
const MP_CHAPTER=MailtrainChapter.makeOut();
tcPrepareStation=function(){if(mpIsTrain()&&MP_HOST.ready){TC.preparing=false;return;}MP_HOST.original.tcPrepareStation();};
cpPrepareEntry=function(){if(mpIsTrain()&&MP_HOST.ready){CP.sourceView=CP.targetView=null;CP.targetScale=scale;return;}MP_HOST.original.cpPrepareEntry();};
function mpIsTrain(){return !!gm.L&&gm.L.room==='train';}
function mpRead(){
 if(MP_HOST.picker&&MP_HOST.picker.value!==gm.L.id)MP_HOST.picker.value=gm.L.id;
 const f=MP_HOST.frame,demo=CP.train&&CP.mode==='demo';gPrepareSrc();
 f.level=demo?CP.demo.level:gm.L;f.boardSource=gBoardSource();f.traces=f.boardSource.traces;f.time=demo?(CP.frame%(CP.demo.loop*60))/60:gm.t;
 f.chapterMode=CP.train?CP.mode:'';f.chapterFrame=CP.frame;f.stationStage=TC.stage;f.chapterPose=MailtrainChapter.sample(f,TRAINCHAPTER,MP_CHAPTER);f.worldFrame=MP_AMBIENT;f.motion=MP_HOST.motion;f.grayscale=grayscale;
 f.viewport.width=innerWidth;f.viewport.height=innerHeight;f.viewport.dpr=devicePixelRatio||1;
 const side=innerWidth>innerHeight&&innerHeight<=520,card=cpActive()&&CP.mode!=='enter'?CP.card:hud.root;
 f.insets.top=64;f.insets.bottom=side?12:card.offsetHeight+16;f.insets.right=side?card.offsetWidth+24:0;
 return f;
}
present=function(){if(mpIsTrain()&&MP_HOST.ready){const f=mpRead();MP_HOST.renderer.prepare(f);MP_HOST.renderer.draw(f);}else MP_HOST.original.present();};
renderFrame=function(){if(!(mpIsTrain()&&MP_HOST.ready))MP_HOST.original.renderFrame();};
gPick=function(x,y){if(!(mpIsTrain()&&MP_HOST.ready))return MP_HOST.original.gPick(x,y);const h=MP_HOST.pick;MP_HOST.renderer.pick(x,y,h);return h.valid?h.y*gm.L.board.w+h.x:-1;};
zoomStep=function(d,x,y){if(!(mpIsTrain()&&MP_HOST.ready))return MP_HOST.original.zoomStep(d,x,y);if(!cpActive())MP_HOST.renderer.zoomAt(x/devDpr,y/devDpr,d>0?1.25:.8);dirty=true;};
panBy=function(x,y){if(!(mpIsTrain()&&MP_HOST.ready))return MP_HOST.original.panBy(x,y);if(!cpActive())MP_HOST.renderer.panBy(-x*scale/devDpr,-y*scale/devDpr);dirty=true;};
resetView=function(){if(!(mpIsTrain()&&MP_HOST.ready))return MP_HOST.original.resetView();if(!cpActive())MP_HOST.renderer.setView(MP_HOST.view);dirty=true;};
function mpSelect(id){const n=LEVELS.findIndex(l=>l.id===id&&/^5-/.test(id));if(n<0)throw Error('Not a Train delivery');gLoad(n);cpCancel();if(MP_HOST.ready)MP_HOST.renderer.setView(MP_HOST.view);document.getElementById('mp-level').value=id;dirty=true;}
function mpSolution(){if(cpActive()||gm.mode==='running')return;gClear();for(const c of gm.L.solution){if(gChuteAt(c.x,c.y)>=0)continue;gm.chutes.push({...c});gm.tray[c.type]--;}gHud();}
function mpInit(){
 const bar=document.createElement('nav');bar.id='mp-review';bar.setAttribute('aria-label','Mail Train study');
 bar.innerHTML='<strong>Valley Mail <small>PLAYABLE STUDY</small></strong><label>Delivery <select id="mp-level"></select></label><button id="mp-view">Journey view</button><button id="mp-motion">Scenery motion</button><details><summary>Review</summary><button id="mp-solution">Fill original solution</button><button id="mp-story">Chapter story</button><button id="mp-grey">Grayscale</button></details>';
 document.body.appendChild(bar);const select=MP_HOST.picker=document.getElementById('mp-level');
 for(const l of LEVELS)if(/^5-/.test(l.id)){const o=document.createElement('option');o.value=l.id;o.textContent=l.id+' · '+l.board.w+' × '+l.board.h;select.appendChild(o);}
 select.onchange=()=>mpSelect(select.value);
 document.getElementById('mp-view').onclick=e=>{MP_HOST.view=MP_HOST.view==='board'?'journey':'board';if(MP_HOST.ready)MP_HOST.renderer.setView(MP_HOST.view);e.target.textContent=MP_HOST.view==='board'?'Journey view':'Sorting floor';dirty=true;};
 document.getElementById('mp-motion').onclick=e=>{MP_HOST.motion=!MP_HOST.motion;e.target.setAttribute('aria-pressed',String(MP_HOST.motion));dirty=true;};
 document.getElementById('mp-solution').onclick=mpSolution;document.getElementById('mp-story').onclick=()=>{cpIntro();bar.querySelector('details').open=false;};
 document.getElementById('mp-grey').onclick=()=>{grayscale=!grayscale;dirty=true;};
 const id=new URLSearchParams(location.search).get('level')||(/^5-/.test(progress.current)?progress.current:'5-1');mpSelect(id);
 if(typeof MailtrainPaper!=='undefined')MailtrainPaper.load(MP_ASSETS).then(assets=>{MP_HOST.renderer=MailtrainPaper.create({canvas:screen,assets,BOARDANIM});MP_HOST.ready=true;dirty=true;}).catch(e=>{bar.dataset.error=e.message;console.error(e);});
 window.MailtrainStudy={select:mpSelect,solution:mpSolution,frame:mpRead,get renderer(){return MP_HOST.renderer;},get ready(){return MP_HOST.ready;},get state(){return gm;},get chapter(){return CP;},get progress(){return progress;},get host(){return MP_HOST;},intro:tcIntro,demo:tcDemo,next:gNext,begin:cpBegin,send:gSend,clear:gClear,hint:gHint};
}
