# Mail Train publication — 15 November 2026

The user explicitly authorised pushing this study to `holleyy/grodappsite`
for phone review. This authorisation covers the standalone deployment, not a
merge into `cosysortie/main`.

URL: https://holleyy.github.io/grodappsite/cats-by-post-mailtrain-paper/
Maximum board: https://holleyy.github.io/grodappsite/cats-by-post-mailtrain-paper/?level=5-15

## Ownership and preservation

Fresh isolated site checkout: `/workspace/grodappsite-mailtrain-publish`,
branch `codex/publish-mailtrain-paper`, from site main
`63e8cb87af0f888406c9af15b61475d38cfbdb72`.
The new prefix was absent from that tree. Its own `ownership.json` records the
Train chat's scope; no acknowledgement from a separate integration chat is
claimed. This is the prefix handoff for the integration owner.

The only deployed files are `index.html`, `build.json`, `ownership.json` and
`README.md` beneath `cats-by-post-mailtrain-paper/`. All pre-existing root
entries retain exactly their original Git object IDs. The HTML is copied from
the room-owned playable build, with no gameplay, save or level changes.
Private storage remains `catsByPost.mailtrainPaper.study.v1:`.

## Current published revision

Site commit: `c59a50109b9863c6376fd374f6f5807e3ed98fe5`.
Source commit: `ad9e604a2e72a03e34c5535d60b629c4c71f8532`.
SHA-256: `c0af831e74727b133ecb7d3abc066e0a3a1c955beb4f289911c95f0e5fd0d1ef`.
All 22 pre-existing site root entries retain their original Git object IDs.
GitHub Pages build, report and deploy jobs all succeeded for this final commit:
https://github.com/holleyy/grodappsite/actions/runs/43717290512 .
The connector response is retained as `publication/deployment.json` in review evidence.

## Verification

The initial deployment was commit `5bb3216df64ea38a62176e546ca092240fa325eb`;
GitHub Pages build, report and deploy jobs all succeeded in
https://github.com/holleyy/grodappsite/actions/runs/43716735707 .

Inspection of the initial package's landscape screenshot exposed a retained
legacy HUD on the left, despite the camera reserving room on the right. The
study stylesheet now places the HUD and chapter card on the reserved right
side below the review bar, with scrolling for short screens. A browser check
also verifies that all 40 maximum-board cell centres clear the actual HUD.

`check-publication.cjs` checks the exact served package hash, 15 selector
entries, real touch placement and win, saved win after reload, maximum board,
Journey view, viewport width, controls and private storage at 390×844 DPR3,
720×400 DPR2 and 1440×1000 DPR1. Evidence lives under
`docs/review-images/mailtrain-paper/publication/`. All three checks passed
against the final SHA above; all28 room tests also passed. The landscape chapter
card was checked separately: its top is76px below the68px header and its bounds
remain within720×400, with no page exceptions.

Direct browsing of `holleyy.github.io` is blocked by this cloud environment's
enforced destination allowlist (HTTP CONNECT 403); the external web tool also
could not retrieve it. Deployment is verified through GitHub, while browser
checks use the byte-identical site checkout served locally on port8802.
No live-origin browser or physical iPhone/Safari qualification is claimed.
