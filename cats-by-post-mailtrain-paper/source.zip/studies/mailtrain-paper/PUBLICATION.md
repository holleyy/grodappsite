# Mail Train publication — 15 November 2026

The user explicitly authorised pushing this study to `holleyy/grodappsite`
for phone review. This authorisation covers the standalone deployment, not a
merge into `cosysortie/main`.

URL: https://holleyy.github.io/grodappsite/cats-by-post-mailtrain-paper/
Maximum board: https://holleyy.github.io/grodappsite/cats-by-post-mailtrain-paper/?level=5-15

## Prepared whole-journey update

Current playable SHA-256:
`d1752ab292e0c6623a09f96f5d39d205d0a94026da3da208f5a6cb5796c292a3`.
The phase owns the same prefix and updates its review gallery with89 final
views, carton/departure/tea clips and the integration handover. Previous arrival
and atmosphere galleries remain available at `review/arrival.html` and
`review/atmosphere.html`.40 room tests, all15 canonical wins,1,380 picks and
exact-package desktop/phone touch/save/HUD checks pass. Astra's one foreground
depth finding and tea-clip gap are author-corrected. See POLISH.md and the current
`docs/review-images/mailtrain-paper/polish/` evidence for details.

Prepared against fresh site base `256dcc23fbfb25d6ec4a9e5bcec694a1263f5b21`,
preserving both newer City Hall study updates. The source main is not merged.
The final deployment record will be added after the authorised Pages run.

## Carrier depth and rim clearance update

Site commit `671b1222dc3d4635c58f9bd7bc04837395f866a0` follows site base
`5a3c5f0e36e3449a9e44daad87bc265e13e13277`. Runtime checkpoint `5292d04e`;
source archive checkpoint `bd81b84a0a52a39a96f8746acf6dde8796eae7a1`.
Playable SHA-256: `c46ea9689d49e68815c7d2777623264a47e9fdc1c8d017530e7feb57452c2caa`.
Source archive: 18,775,205 bytes, SHA-256
`0aaa46c72f130a9ab4b2a3586bfe349654b512116c0722b19127f52ea0f13858`.

The existing `/review/` now shows carrier/basket before-and-after comparisons,
all four direction fixtures and a quarter-speed clip of both real5-1 arrivals.
The prior atmosphere gallery is retained at `/review/atmosphere.html`.
All22 other root entries retain their previous Git object IDs.

35 room tests and all15 canonical deliveries pass. The exact packaged HTML
was tested locally at portrait390×844 DPR3, landscape720×400 DPR2 and
1440×1000 DPR1: touch wins, private saved reloads, 15-level picker, maximum-board
HUD clearance and Journey view pass. The phone gallery decodes all five images,
loads the8.667-second video, and has four working navigation links with no
horizontal overflow. Independent Astra review has no Critical/Important issues.
See `docs/review-images/mailtrain-paper/arrival-clearance/` for evidence.

GitHub Pages run: https://github.com/holleyy/grodappsite/actions/runs/43737739527 .
Build, report and deploy jobs all succeeded for this exact commit. The provider
response is saved in the current evidence's `deployment.json`. The workspace's enforced network policy
still prevents direct navigation to `holleyy.github.io`; local package tests
and provider deployment status are the available evidence. Physical-device
qualification is separate. Source-main remains unmerged.

## End-wall and atmosphere update

Site commit `5a3c5f0e36e3449a9e44daad87bc265e13e13277` follows site base
`c59a50109b9863c6376fd374f6f5807e3ed98fe5`. Room source checkpoint is
`e8a99942` (runtime changes at `3f7c80ce`).
Playable SHA-256: `2bf6318b1177aa4e46dd765b3e87b0f72ff6a4bbbf47de72eaa0d2ed72e6f421`.

[Comparison and motion gallery](https://holleyy.github.io/grodappsite/cats-by-post-mailtrain-paper/review/)
and [room source bundle](https://holleyy.github.io/grodappsite/cats-by-post-mailtrain-paper/source.zip)
are added inside the same owned prefix. The archive has78 entries, passes CRC
verification, and documents applying the room-owned overlay to canonical base
923b40d7. Its SHA-256 is
`3e0d7f9b8f69e9a28354d5c3d739a719abfc26dbf02ef2c414eb7d64ea7892cb`.
All22 other root entries retain their prior Git object IDs. The packaged gallery
decodes allsix images at phone width without overflow; allthree navigation links
return200 from the local packaged-site server. Original publication evidence
below is retained; current phase evidence lives in `review-images/mailtrain-paper/atmosphere/`.
GitHub Pages build, report and deploy jobs all succeeded for this exact commit:
https://github.com/holleyy/grodappsite/actions/runs/43720500695 .
The provider response is retained in the current evidence's `deployment.json`.

## Ownership and preservation

Fresh isolated site checkout: `/workspace/grodappsite-mailtrain-publish`,
branch `codex/publish-mailtrain-paper`, from site main
`63e8cb87af0f888406c9af15b61475d38cfbdb72`.
The new prefix was absent from that tree. Its own `ownership.json` records the
Train chat's scope; no acknowledgement from a separate integration chat is
claimed. This is the prefix handoff for the integration owner.

The initial deployment added `index.html`, `build.json`, `ownership.json` and
`README.md` beneath `cats-by-post-mailtrain-paper/`. All pre-existing root
entries retain exactly their original Git object IDs. The HTML is copied from
the room-owned playable build, with no gameplay, save or level changes.
Private storage remains `catsByPost.mailtrainPaper.study.v1:`.

## Initial mobile revision

Site commit: `c59a50109b9863c6376fd374f6f5807e3ed98fe5`.
Source commit: `ad9e604a2e72a03e34c5535d60b629c4c71f8532`.
SHA-256: `c0af831e74727b133ecb7d3abc066e0a3a1c955beb4f289911c95f0e5fd0d1ef`.
All 22 pre-existing site root entries retain their original Git object IDs.
GitHub Pages build, report and deploy jobs all succeeded for this final commit:
https://github.com/holleyy/grodappsite/actions/runs/43717290512 .
The connector response is retained as `publication/deployment.json` in review evidence.

## Verification

The initial deployment was commit `5bb3216df64ea38a62176e546ca092240fa325eb`;
GitHub Pages build, report and deploy jobs all succeeded in
https://github.com/holleyy/grodappsite/actions/runs/43716735707 .

Inspection of the initial package's landscape screenshot exposed a retained
legacy HUD on the left, despite the camera reserving room on the right. The
study stylesheet now places the HUD and chapter card on the reserved right
side below the review bar, with scrolling for short screens. A browser check
also verifies that all 40 maximum-board cell centres clear the actual HUD.

`check-publication.cjs` checks the exact served package hash, 15 selector
entries, real touch placement and win, saved win after reload, maximum board,
Journey view, viewport width, controls and private storage at 390×844 DPR3,
720×400 DPR2 and 1440×1000 DPR1. Evidence lives under
`docs/review-images/mailtrain-paper/publication/`. All three checks passed
against the final SHA above; all28 room tests also passed. The landscape chapter
card was checked separately: its top is76px below the68px header and its bounds
remain within720×400, with no page exceptions.

Direct browsing of `holleyy.github.io` is blocked by this cloud environment's
enforced destination allowlist (HTTP CONNECT 403); the external web tool also
could not retrieve it. Deployment is verified through GitHub, while browser
checks use the byte-identical site checkout served locally on port8802.
No live-origin browser or physical iPhone/Safari qualification is claimed.
