/* Full authored campaign visual sweep. No levels or clocks are changed. */
const{chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path');
(async()=>{const out=process.argv[2]||'work/mailtrain-paper/polish/before';fs.mkdirSync(out,{recursive:true});const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),rows=[],errors=[];
 for(const[name,w,h,dpr]of[['desktop',1440,1000,1],['phone',390,844,2],['landscape',720,400,2]]){
  const p=await b.newPage({viewport:{width:w,height:h},deviceScaleFactor:dpr});p.on('pageerror',e=>errors.push(e.message));await p.goto('http://127.0.0.1:8801/studies/mailtrain-paper/playable.html');await p.waitForFunction(()=>window.MailtrainStudy?.ready);await p.evaluate(()=>window.requestAnimationFrame=()=>0);await p.waitForTimeout(100);
  async function shot(label,meta){const file=name+'-'+label+'.jpg';await p.screenshot({path:path.join(out,file),type:'jpeg',quality:88});rows.push({file,layout:name,viewport:[w,h],dpr,...meta});}
  for(let n=1;n<=15;n++){
   const id='5-'+n;const meta=await p.evaluate(id=>{const s=MailtrainStudy;s.select(id);s.solution();gSend();while(gm.mode==='running')gUpdate();const traces=G_TRACES.slice(0,gm.sim.n),target=Math.max(.4,Math.min(...traces.map(t=>t.rel+t.n*t.tick))*.55);s.select(id);s.solution();gSend();while(gm.mode==='running'&&gm.t<target)gUpdate();const f=s.frame();f.worldFrame=300;s.renderer.prepare(f);s.renderer.draw(f);return{level:id,board:[gm.L.board.w,gm.L.board.h],time:gm.t,mode:gm.mode,phase:'active',worldFrame:300};},id);await shot(id+'-active',meta);
   if(name==='desktop'){const time=await p.evaluate(()=>{while(gm.mode==='running')gUpdate();gm.t=Math.max(...G_TRACES.slice(0,gm.sim.n).map(t=>t.rel+t.n*t.tick))+1.3;const s=MailtrainStudy,f=s.frame();f.worldFrame=300;s.renderer.prepare(f);s.renderer.draw(f);return gm.t;});await shot(id+'-settled',{...meta,time,mode:'won',phase:'settled'});}
   if(n%5===0)console.log(name+' deliveries 1–'+n);
  }
  for(const kind of ['story','demo','entry','station-4','station-8','station-12','exit']){
   const meta=await p.evaluate(kind=>{const s=MailtrainStudy;const id=kind==='station-4'?'5-3':kind==='station-8'?'5-7':kind==='station-12'?'5-11':kind==='exit'?'5-15':'5-1';s.select(id);
    if(kind.startsWith('station')||kind==='exit'){s.solution();gSend();while(gm.mode==='running')gUpdate();for(let i=0;i<90;i++)gUpdate();gNext();CP.frame=kind==='exit'?130:110;}
    else{tcIntro();if(kind!=='story'){tcDemo();CP.frame=150;}if(kind==='entry'){cpBegin();CP.frame=36;}}
    const f=s.frame();f.worldFrame=300;s.renderer.prepare(f);s.renderer.draw(f);return{level:gm.L.id,phase:kind,chapter:CP.mode,chapterFrame:CP.frame,worldFrame:300};},kind);await shot(kind,meta);
  }
  if(name==='desktop')for(const id of ['5-1','5-4','5-8','5-15'])for(const view of ['journey','grayscale']){await p.evaluate(({id,view})=>{const s=MailtrainStudy;s.select(id);s.renderer.setView(view==='journey'?'journey':'board');const f=s.frame();f.worldFrame=300;f.grayscale=view==='grayscale';s.renderer.prepare(f);s.renderer.draw(f);},{id,view});await shot(id+'-'+view,{level:id,phase:view,worldFrame:300});}
  console.log(name+' chapters complete');await p.close();
 }
 if(errors.length)throw Error(errors.join('\n'));const report={build:JSON.parse(fs.readFileSync('studies/mailtrain-paper/build.json')),rows,errors};fs.writeFileSync(path.join(out,'matrix.json'),JSON.stringify(report,null,2));
 const html='<!doctype html><meta name="viewport" content="width=device-width"><style>body{background:#eee5d5;color:#234e50;font:14px sans-serif;margin:10px}section{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}figure{margin:0;background:#fff8e9}img{width:100%;display:block}figcaption{padding:8px}h2{break-before:page}a{color:inherit}@media(max-width:650px){section{grid-template-columns:1fr}}</style><h1>Mail Train · visual matrix</h1>'+['desktop','phone','landscape'].map(layout=>'<h2>'+layout+'</h2><section>'+rows.filter(r=>r.layout===layout).map(r=>'<figure><a href="'+r.file+'"><img loading="lazy" src="'+r.file+'"></a><figcaption>'+r.level+' · '+r.phase+'</figcaption></figure>').join('')+'</section>').join('');fs.writeFileSync(path.join(out,'index.html'),html);await b.close();console.log(rows.length+' actual study captures');
})().catch(e=>{console.error(e);process.exit(1);});
