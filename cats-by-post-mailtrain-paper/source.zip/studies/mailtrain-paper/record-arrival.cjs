/* Actual study arrivals plus a labelled four-direction renderer fixture. */
const{chromium}=require('playwright'),fs=require('node:fs'),{spawnSync}=require('node:child_process');
(async()=>{const out='docs/review-images/mailtrain-paper/arrival-clearance',scratch='work/mailtrain-paper/arrival-clearance/frames';fs.mkdirSync(scratch,{recursive:true});
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),p=await b.newPage({viewport:{width:1440,height:1000}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.goto('http://127.0.0.1:8801/studies/mailtrain-paper/playable.html');await p.waitForFunction(()=>window.MailtrainStudy?.ready);await p.evaluate(()=>window.requestAnimationFrame=()=>0);await p.waitForTimeout(100);
 let frame=0;for(const coat of process.argv.includes('--fixture-only')?[]:[1,2]){
  const clip=await p.evaluate(coat=>{const s=MailtrainStudy;s.select('5-1');s.solution();gSend();while(gm.mode==='running')gUpdate();const tr=G_TRACES.find(t=>t.coat===coat),j=tr.n-1;gm.t=tr.rel+tr.n*tr.tick+.1;const f=s.frame(),r=s.renderer;f.worldFrame=300;r.prepare(f);r.draw(f);const at=MailtrainGeometry.cell(r.camera,gm.L,tr.x1[j]+.5,tr.y1[j]+.5,{});r.zoomAt(at.x,at.y,2);r.prepare(f);r.draw(f);MailtrainGeometry.cell(r.camera,gm.L,tr.x1[j]+.5,tr.y1[j]+.5,at);return{x:Math.max(0,Math.min(880,Math.floor(at.x-280))),y:Math.max(0,Math.min(560,Math.floor(at.y-310))),width:560,height:440};},coat);
  for(let i=0;i<33;i++){await p.evaluate(({coat,i})=>{const s=MailtrainStudy,tr=G_TRACES.find(t=>t.coat===coat);gm.t=tr.rel+tr.n*tr.tick+.1+i/30;const f=s.frame();f.worldFrame=300;s.renderer.prepare(f);s.renderer.draw(f);},{coat,i});await p.screenshot({path:scratch+'/'+String(frame++).padStart(3,'0')+'.png',clip});}
 }
 if(frame){const ff=spawnSync('/usr/bin/ffmpeg',['-hide_banner','-loglevel','error','-y','-framerate','30','-i',scratch+'/%03d.png','-vf','setpts=4*PTS','-c:v','libvpx-vp9','-deadline','realtime','-cpu-used','6','-crf','28','-b:v','0','-pix_fmt','yuv420p',out+'/arrivals-slow.webm'],{encoding:'utf8'});if(ff.status)throw Error(ff.stderr);}
 const fixture=await p.evaluate(async()=>{
  MailtrainStudy.select('5-1');MailtrainStudy.solution();gSend();while(gm.mode==='running')gUpdate();
  const assets=await MailtrainPaper.load(MP_ASSETS),canvas=document.createElement('canvas');canvas.width=640;canvas.height=440;const c=canvas.getContext('2d'),cam={x:292,y:241.5,scale:140},painter=new MailtrainMaterials.Painter(c,cam,assets),pieces=new MailtrainPieces(painter,BOARDANIM),sheet=document.createElement('canvas');sheet.width=1280;sheet.height=2640;const sc=sheet.getContext('2d'),rows=[];
  for(let d=0;d<4;d++)for(let k=0;k<3;k++){
   const age=[.25,.45,.55][k],tr=structuredClone(G_TRACES[1]),j=tr.n-1;tr.ox=tr.oy=0;tr.x1[j]=2;tr.y1[j]=2;tr.d0[j]=d;tr.end=BOARDANIM.END_HOME;tr.homeDX=tr.homeDY=0;tr.napUntil=Infinity;
   const time=tr.rel+tr.n*tr.tick+age;c.fillStyle='#e9ddc7';c.fillRect(0,0,640,440);for(let y=0;y<5;y++)for(let x=0;x<5;x++)painter.plane(1+x+.012,.8+y+.012,3.125,.976,.976,'slate',((x+y)&1)?-.04:.02);
   pieces.draw({level:{board:{}},boardSource:{n:1,traces:[tr],times:[time],hatches:[],queues:[],baskets:[{x:2,y:2,coat:2}],gates:[],turntables:[],dogs:[],cursor:-1},time});
   c.fillStyle='#fff5df';c.fillRect(12,10,290,32);c.fillStyle='#254d50';c.font='16px sans-serif';c.fillText(['R','D','L','U'][d]+' approach · '+age+' seconds',22,32);
   sc.drawImage(canvas,(d%2)*640,Math.floor(d/2)*1320+k*440,640,440);
   rows.push({direction:d,age,fixture:'Canonical terminal trace copied and rotated for renderer coverage; not a new level.'});
  }return{png:sheet.toDataURL('image/png'),rows};
 });
 fs.writeFileSync(out+'/four-directions.png',Buffer.from(fixture.png.split(',')[1],'base64'));
 fs.writeFileSync(out+'/motion.json',JSON.stringify({build:JSON.parse(fs.readFileSync('studies/mailtrain-paper/build.json')),level:'5-1',coats:[1,2],ages:[.1,.1+32/30],sampleHz:30,playback:'quarter speed; timing in the playable study is unchanged',sourceFrames:frame||66,fixture:fixture.rows,errors},null,2));
 if(errors.length)throw Error(errors.join('\n'));await b.close();console.log(frame+' actual study frames; 12 directional fixture poses');
})().catch(e=>{console.error(e);process.exit(1);});
