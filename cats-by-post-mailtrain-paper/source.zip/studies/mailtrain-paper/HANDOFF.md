# Valley Mail review handover

Latest follow-up: [carrier/basket depth and jump clearance](ARRIVAL.md),
with [before/after and slow-motion evidence](arrival-review.html).
35 room tests and all 15 canonical deliveries pass.

**Previous phase:** [end-wall and atmosphere deliverable](ATMOSPHERE.md), code
checkpoint `3f7c80ce`, [comparison and motion gallery](atmosphere-review.html).
The exposed seat-side gap is closed with a real bulkhead/cab doorway. The
worker's half-tile tea-stop jump is corrected. Prepared architecture receives
dusk/night shade and lamp warmth; the wall clock and supported hot mug use
the existing ambient clock.31 room tests, all15 canonical deliveries, chapter
preservation and phone touch/save checks pass.1,089 board pixel samples remain
identical to the prior published build; original river/tree/actor assets remain
byte-identical. Fresh evidence is under `docs/review-images/mailtrain-paper/atmosphere/`.

**Latest geometry revision:** [GEOMETRY.md](GEOMETRY.md) supersedes the earlier
geometry/performance limits below. Shelves, parcel bands, hatch recess/POP,
basket footprints and points are corrected. The engine now reuses its raster
on pan. That checkpoint's room suite:28 tests. The user subsequently authorised publication
to `holleyy/grodappsite`: [published study](https://holleyy.github.io/grodappsite/cats-by-post-mailtrain-paper/)
and [publication record](PUBLICATION.md).

15 November 2026. Local branch `codex/mailtrain-paper-fidelity`, based on
`923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`. Source-main integration remains unmerged.

[Gallery](index.html) · [Playable HTML](playable.html) · [QA](design-qa.md).
Serve this worktree on port 8801 and open `/studies/mailtrain-paper/`.
Build identity and protected input hashes are in [build.json](build.json).

## What is implemented

All 5-1–5-15 use their canonical board sizes, placements, queues, railway points,
answers, rules, timing and progress serializer. Original game functions remain
inside the standalone export. The study replaces presentation and binds storage
to a private namespace before boot; it does not alter production saves.

One projection serves the cutaway carriage, board, furniture, pieces, actors,
wheels, rails and picking. A complete locomotive and unique rear brake van
explain the moving formation. A dispatch bay protects the 10×4 board from the
attached vehicle. The original station clock stages the powered head backing
onto a stationary coach/van section. The chapter demo remains a real four-cat
simulation; departure retains the finished board and restores City Hall's
original renderer when the user continues.

Latest feedback is incorporated: the original richly textured water and large
trees are active again. Foreground pixels are masked from that same landscape
above the masonry. The separate procedural river and small-tree prototype is
inactive. The locomotive geometry has been rebuilt. These visual revisions
still need Alex's review; passing rules tests is not visual acceptance.

## Verification

- One full repository invocation: 1682/1682 passed in 936.95 seconds. It predates
  the later engine/camera/arrival regressions; it is not a fresh whole-suite run
  of the final added test count. Earlier checkpoint room suite:21/21; current geometry suite:28/28.
- Actual Chromium compares all fifteen wins, update counts, results, routes,
  release times and gate histories with the protected canonical executable.
- All 460 cell centres at desktop 1440×1000 DPR1, portrait390×844 DPR3 and
  landscape720×400 DPR2 pick correctly and are visible: 1,380 checks. Real
  pointer rotation/removal, drag suppression, wheel, Hint/Clear, Stop,
  failed attempts and retry pass.
- Chapter checks cover preserved arrangement/progress, teaching trace, entry
  boundary, stops before5-4/5-8/5-12, all coupling poses, blocked input, settled
  exit and City Hall fallback. Private sentinels, malformed and denied storage
  pass. Browser checks reported no page exceptions.
- At360 sampled interior board pixels, withholding attachments changes none;
  scenery motion changes none. Scenery-off holds ambient time while gameplay
  advances. Twenty level cycles retain the same room surface count/pixel area.
- One read-only independent GPT-6 Astra review repeated the room tests,
  campaign, chapter/privacy checks, builder reproducibility and ownership scan.
  Its three Important findings were reproduced, fixed and regression-tested:
  supported takeoff soles, zoomed chapter-entry continuity, simultaneous
  pinch/pan. The author verified the fixes; no second independent pass is claimed.

Machine reports, screenshots, clips and the full-run log are under
`docs/review-images/mailtrain-paper/implementation/`. Clips are deterministic
browser screenshots sampled at12fps from the60Hz canonical clock. They are
motion evidence, not measured sustained frame rates.

## Remaining limits

See [design-qa.md](design-qa.md). The appearance is WIP, not accepted fidelity.
The earlier engine rebake cost is now corrected by the geometry cache;
see GEOMETRY.md for current measurements and limits. The census measures room-owned surfaces,
not the retained canonical page's complete memory. Postmistress blink and fixture
sway remain visual polish; the current seated pose is
held. No iPhone, Safari, Metal or sustained performance qualification occurred.

The integration owner must supply the production presentation adapter, shared
camera/insets lifecycle, room manager, interface and any approved preview
prefix. This study changes none of those owned files.

## Reproduce

```sh
python3 studies/mailtrain-paper/build-study.py
node --test tests/mailtrain-paper-*.test.js
node studies/mailtrain-paper/check-campaign.cjs
node studies/mailtrain-paper/check-chapters.cjs
node studies/mailtrain-paper/check-review.cjs
node studies/mailtrain-paper/check-visual.cjs
node studies/mailtrain-paper/capture-playable.cjs
node studies/mailtrain-paper/record-playable.cjs
```

Browser scripts expect the local server on8801 and `/usr/bin/chromium`.
Recording also uses system ffmpeg. Rebuild only this study: the shared canonical
export is a protected input. Asset master hashes/import provenance are retained.
