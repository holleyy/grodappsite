const {chromium}=require('playwright');
const fs=require('node:fs');
(async()=>{
 const out='work/mailtrain-paper';
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const context=await browser.newContext({viewport:{width:1440,height:1000},reducedMotion:'reduce'});
 const page=await context.newPage();const errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 const host='http://127.0.0.1:8796/';
 await page.goto(host+'studies/civic-mail-hall/foundation/index.html?view=hall');
 await page.waitForFunction(()=>window.__foundation?.ready,{},{timeout:90000});
 await page.evaluate(()=>{__foundation.motion(false);__foundation.pause(true);});
 await page.screenshot({path:out+'/office-local.png'});
 const office=await page.evaluate(()=>({ready:__foundation.ready,level:__foundation.session.level.id,mode:__foundation.renderer.config.mode}));
 await page.goto(host+'docs/experiments/office-fidelity/train/craft/playable.html');
 await page.waitForFunction(()=>typeof trainStudySelect==='function'&&window.__so&&typeof TRAIN_FIDELITY!=='undefined'&&TRAIN_FIDELITY.ready,{},{timeout:90000});
 const train=[];
 for(const id of ['5-1','5-4','5-8','5-15']){
  const state=await page.evaluate(id=>{trainStudySelect(id);trainStudyLight('day');__so.pause(true);__so.seek(240);renderFrame();present();return {id:LEVELS[gm.li].id,board:LEVELS[gm.li].board,build:BUILD_ID};},id);
  await page.screenshot({path:out+'/train-'+id+'.png'});train.push(state);
 }
 fs.writeFileSync(out+'/reference-browser.json',JSON.stringify({office,train,errors},null,2)+'\n');
 console.log(JSON.stringify({office,train,errors}));
 await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1;});
