# Mail Train — end wall and atmosphere deliverable

Continue from source `43bd6430` on the owned worktree; canonical base remains
`923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`.

The user identified the open seam beside the seat and authorised the next
deliverable phase. The earlier plan's Tasks2/4 still have presentation work;
Tasks3/5 already have gameplay/chapter evidence. This phase closes the visible
end wall and advances the existing atmosphere/postal-life work, then supplies
a review package. Shared integration/native work remains with its owner.

Scope:
- Build a solid end bulkhead behind the seat with a real framed cab doorway.
- Remove the worker's sideways jumps at tea/watch route boundaries.
- Give dusk/night architecture restrained cool shade and local warm lamp pools,
  preserving exact board pixels and the original river/tree artwork.
- Animate the physical wall clock and a small curl from the supported hot mug
  using the existing independent scenery clock.
- Verify all15 deliveries, chapters, board visibility, scenery-off and phones;
  update the already-authorised standalone prefix with evidence and provenance.

Ruling: continue the existing plan with this focused presentation phase rather
than repeat completed campaign/engine work. Supported held Postmistress artwork
is retained; new facial poses and swinging fixtures are not improvised by
distorting it. This keeps the current art identity while those details remain
available for a later polish pass. No broad art-acceptance claim is made.

Use the existing room-owned ledger and scratch paths. Preserve prior files and
records. Publication authorisation and prefix persist from the previous turn.


Author verification before review:31 room tests pass. Real Chromium passes
all15 canonical result/trace/update comparisons,1,380 cell-centre picks across
three viewports, original input/failure/retry, chapter/demo/entry/stops/coupling/
settled exit and isolated/malformed/denied storage. Across allfour board sizes,
1,089 rendered board samples match the previous published build exactly.
Sixteen end-wall probes resist changing background colours; the unobstructed
sky control changes. Clock hands advance and repeated held-frame draws agree.
At360 maximum-board samples there is no attachment/scenery overlap, and
scenery-off holds ambient time while gameplay advances. Twenty level cycles
retain17 room surfaces and6,858,477 surface pixels; whole-page/device memory
and sustained frame rate remain unmeasured.

One fresh-context GPT-6 Astra review independently reproduced the31 room tests,
all15 campaign comparisons, chapter/input/privacy checks, rendered wall/board/
clock probes, reduced-motion/hidden ambient hold and builder identity. It found
zero Critical, Important or Minor issues. Its separate architecture alpha probe
found zero altered alpha or newly exposed pixels. See the evidence directory's
ASTRA-REVIEW.md. Human art acceptance, hardware/sustained performance and final
shared integration remain separate; this phase is ready for standalone review.
