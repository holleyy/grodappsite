# Carrier and basket clearance

15 November 2026. Original base `923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`.
Follow-up starts at `d28929ec6f4427a12531db91c9c86ed4522b59a7` on
`codex/mailtrain-paper-fidelity`. [Visual comparison](arrival-review.html).

The user's close-up exposed two reproducible presentation defects. Basket
front masks were drawn after every carrier and cat, so the farther basket rim
cut across a supported cat in a nearer carrier. The previous jump lifted its
anchor by only 0.347 tile above a 0.34-tile carrier, without allowing for the
sprite's feet below that anchor.

`pieces.js` now sorts basket walls, carriers, cats and dogs together using
their floor roots. Basket wall keys straddle the basket centre by 0.36 tile;
empty carriers have their own key, separate from the departing cat. The flight
uses the same world root for drawing and ordering. Fixed buffers hold up to
128 entries and one reused flight record; no new canvases or frame readbacks.

The visual flight rises 0.82 tile. Its lower sprite envelope clears both rims,
and the endpoint matches the canonical snapped destination and cushion/rim
height. Existing support through 0.4 seconds and landing at 0.6 seconds remain
unchanged, as do all canonical pose fields, folding/fading deadlines and traces.
This also removes a small endpoint mismatch for wrong-basket arrivals.

Ownership: runtime changes only `src/fidelity/mailtrain-paper/pieces.js`.
New tests, capture tools, review pages and evidence stay in the room-owned
paths. No shared, canonical, Office, other-room, native or original asset edits.

Verification: 35 room tests pass, including a reproduced failing near/far
ordering regression, all four approaches, both coats, fixed-clock clearance,
canonical landing offsets and record reuse. Actual Chromium passes all 15
canonical wins and 1,380 cell picks across desktop/portrait/landscape, chapter
and private-save checks, hatch/POP geometry, scenery and resource stability.
Basket contact slopes remain +0.49964/-0.49969 against the board's +/-0.5.

Evidence: `docs/review-images/mailtrain-paper/arrival-clearance/`. Before images
come from the previous published build; after images and the quarter-speed
clip come from the actual study. The four-direction contact sheet is labelled
as a rotated terminal-trace fixture. Human art acceptance and physical-device
performance are not inferred from these checks. Source-main remains unmerged.

Independent GPT-6 Astra review found no Critical or Important issues; its one
Minor test gap is now covered by the permanent 32-trace draw-path regression.
The exact site package passes touch wins, saved reloads and maximum-board HUD
clearance at 390×844 DPR3, 720×400 DPR2 and 1440×1000 DPR1. The phone gallery
decodes all five images and the 8.667-second video, without horizontal overflow.
[Review report](../../docs/review-images/mailtrain-paper/arrival-clearance/ASTRA-REVIEW.md).
