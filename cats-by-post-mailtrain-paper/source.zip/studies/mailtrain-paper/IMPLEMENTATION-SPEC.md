# Valley Mail implementation specification

15 November 2026. Alex selected and refined direction 3, then authorised building
it and requested an implementation plan. This file records that visual target
and the boundaries of the proposed work. It does not authorise merge/publication.

## Experience

A complete locomotive-hauled night-mail train crosses a layered paper river
valley and continuous viaduct. The postal interior is cosy: warm timber, teal
and green panelling, cream curved roof construction, brass lamps, hanging bags,
red/blue cubbies, burgundy seat and tea setting. The scene has convincing card
thickness, complete objects and grounded postal work, at the quality of Lantern
Quay and the approved Sorting Office.

The selected target is
`docs/review-images/mailtrain-paper/refinement/refined-target.webp`, generated
from `exec-0631ae9c-4df8-4bff-a23f-4915d4c3485e.png`. The previous alternatives
are history. The block motion model proves framing/continuity only; its crude
figures, colours and interfaces are not approved final artwork.

## Layout and travel

Use a wide journey view for the introduction, station departures and optional
exploration. Use a close working view for puzzles. One continuous main coach
holds all board sizes; a real dispatch bay between board and rear coupling
keeps the tall connected rear vehicle clear of the board and houses the parcel
desk/trolley/mailbags. No invented gap or elongated floating gangway.

Every wheel sits on the same pair of continuous rails; bodies have supported
bogies and physical couplings. A visible complete train has a locomotive at
the front and an unambiguous last vehicle with rear marker. Close views may crop
those real ends, provided the establishing view explains their continuation.

The camera tracks the connected train. Sleepers, viaduct sections and scenery
pass at appropriate depths; wheels rotate by signed distance. The live board
remains stationary relative to the camera during play. Gentle ambient movement
must never move picking targets. A bridge is connected scenery, not a pedestal
travelling with the train.

## Exact gameplay scope

| Existing deliveries | Board size |
|---|---|
|5-1–5-3|8×3|
|5-4–5-7|9×3|
|5-8–5-11|10×3|
|5-12–5-15|10×4|

Retain canonical level IDs, records, answers, inventory, hatches/releases,
points, dogs, baskets, rule outcomes, time limits and progress format. Preserve
the 300 ms game beat and original turn/bounce/arrival/folding/settlement deadlines.
Smooth presentation must not change actions or timing. Points remain two-arrow
discs with clear active/inactive states and original serial switch behaviour.

Retain story, actual four-cat 12-second teaching loop, 72-frame entry, stops before
5-4/5-8/5-12 and the 5-15 settled-board satchel departure. Use the existing station
clock, with phase changes at 45, 165 and 213 frames. Coupling remains outside the
live floor. The extra coach belongs before the last brake van. Proposed visual
staging: the station cut establishes that coach/van section as stabled, then the
locomotive backs its sorting coach onto it using the existing relative-gap
approach clock. This is the builder's staging choice, not a user-supplied scene
script or new chapter logic. Do not show an unpowered vehicle floating along,
two rear vans, or active sorting while the train is detached for the shunt.

The review study can directly select all 15 deliveries but defaults to empty
placements. Any solution-fill/watch control is explicitly a review action.
No artificial campaign wins or production unlocks are needed for review access.

## Characters, art and light

The sorter handles actual mail, checks the watch and takes tea; the Postmistress
sits on a supported seat and watches the journey. Hands, soles, mugs, letters,
satchel, trolley wheels and props have explicit supports/attachments. Routes
stay in the rear aisle or end bay, clear of the board and furniture.

Use generated room-specific paper stocks and printed details on real geometry,
not whole painted fixtures with conflicting perspective. Finish side/top/end
faces, including the engine, cabinet cases, roof, tea objects and desk parcels.
Use accepted character/arrival artwork as read-only registered sources where
appropriate, with imported hashes and anchor provenance. Do not modify Office
or other rooms' originals. New poses must be generated/registered if the old
art does not supply the required action; do not stretch a parked pose into a gait.

Protect board contrast/coat identities through dusk, night and grayscale. Lamps
may warm room surfaces; board colours and targets do not pulse with signals.
Scenery-off/reduced motion holds coherent supported poses while puzzle time
continues. No new canonical palette entries or indexed-renderer migration.

### Initial asset catalogue

| Room-owned asset | Source and use |
|---|---|
|`assets/paper-stock.webp` + metadata|Generate a neutral, flat six-stock sheet: teak, painted teal/green card, cream roof card, warm stone, brass paper and slate board paper. Map albedo to actual faces; lighting is not painted into incompatible perspectives.|
|`assets/postal-print.webp` + crop metadata|Generate flat clock/route/paw-postal graphics and small printed details matching the selected target. Keep text that belongs to a printed graphic in that graphic.|
|`assets/countryside-far.webp`, `assets/village-strip.webp`|Generate independent rural layers without a train, bridge or playable board baked into them. Register ground/horizon and wrapping explicitly.|
|`assets/acting.webp` + anchor metadata|Read-only import/copy of accepted cat, dog and arrival art where suitable. Pin source hashes, native crops and physical anchors.|
|`assets/worker.webp` + pose metadata|Use sufficient accepted directional/action artwork read-only; generate and register missing walk/sort/tea/watch poses if necessary. No static parked sprite stretched into a walk.|
|Geometry-owned objects|Engine/coach/van, bogies, roof, bridge, cubbies, letters, tea objects, desk, trolley and bags are complete projected volumes finished with the stocks/decals above. No whole-object painting substitutes for an unsupported proxy.|

Inspect each generated sheet before packing. Retain prompts and untouched
masters or exact source hashes, then record every crop/anchor and consuming
component. Asset counts may be reduced by reuse; missing required actions or
unfinished object faces may not be hidden behind a lower count.

## Viewports and resources

Check desktop 1440×1000, phone 390×844and compact landscape 720×400, with representative
DPR 1/2/3 where applicable. Reserve actual HUD/card insets and test resize during
play and chapter scenes. The maximum board fits the phone overview, but the
refinement measured only about 29 px between adjacent square centres there. At 1.7×
zoom it measured about 50 px and required panning. Retain zoom/pan; do not promise
all 40squares as simultaneous large tap targets.

No per-frame JS allocations, texture rebuilding or pixel readbacks. Preallocate
poses/draw records and prepare camera-bounded surfaces/caches on changes. Keep
resource accounting explicit and check repeated transitions for growth. Cloud
browser checks are not physical iPhone/Safari/Metal or sustained-fps evidence.

## Ownership and preservation

Existing worktree `/workspace/cosysortie-mailtrain`, branch
`codex/mailtrain-paper-fidelity`, main base
`923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`.

Own `src/fidelity/mailtrain-paper/` including its assets,
`studies/mailtrain-paper/`, `tests/mailtrain-paper-*.test.js`, and
`docs/review-images/mailtrain-paper/`. The integration owner retains shared
renderer/camera contracts, manager, build/bridge/interface and final integration.
Propose shared changes rather than making them. Retain the standalone study.

Protected canonical-input SHA256:

| Input | SHA256 |
|---|---|
|sorting_office.html|b2dd563faa7e8ae40e14169c7f626de0454ae3cb4fc4befbb20e050444c89c66|
|src/data/levels.json|be1c22ee6456819c200e42d6f8abb48b9c4cc4db9c414928c7fc60ea10cf40a7|
|src/sim/10_rules.js|eaeeff8565f68d32ae6d8489be34664dacf4948a71f2bdf0b0835579454691c4|
|src/sim/12_boardanim.js|5c181265db6570a822ee9fc08400a19cf4eff91beea5e12a6779d46876c88885|
|src/app/43e_train_chapter.js|87d330ddb51a860e020b4e10e11f9fa625a7a2dc542a71ad4f2fc9fb243a1fc4|

The standalone builder may create its own study copy of the canonical game,
with a private store binding and room-owned presentation hooks. The original
export, rules, data and clock functions remain byte-identical on disk. The
study must not access production keys even during initial bootstrap.

Leave other rooms, accepted Office source/assets, native, `AGENTS.md`, `PLAN.md`
and generated shared outputs untouched. No push, merge or publication. No preview
prefix is assigned by this plan; coordinate any later one with the integration
owner after explicit user authorisation.

## Delivery and non-goals

Deliver reproducible playable study HTML, room source/assets/provenance, real
browser evidence for all sizes/mechanisms/chapter states, visual comparison with
the chosen target, resource/verification limits and an integration note.

This task does not redesign the shared interface, build new puzzles, rewrite
rules/progress, migrate the renderer globally, port native, publish a preview,
merge the branch or certify physical-device performance.
