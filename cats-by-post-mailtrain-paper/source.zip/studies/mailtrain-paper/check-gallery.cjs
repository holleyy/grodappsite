const {chromium}=require('playwright');const fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 try{
 const host=process.env.MAILTRAIN_PREVIEW_URL||'http://127.0.0.1:8796';
 const page=await browser.newPage({viewport:{width:1100,height:920}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(host+'/studies/mailtrain-paper/revised-options.html');
 const images=await page.locator('img').evaluateAll(async items=>{await Promise.all(items.map(i=>i.decode()));return items.map(i=>({src:i.getAttribute('src'),width:i.naturalWidth,height:i.naturalHeight}));});
 if(images.some(i=>!i.width))throw Error('Unloaded review image');
 const desktopWidth=await page.evaluate(()=>({inner:innerWidth,scroll:document.documentElement.scrollWidth}));
 await page.setViewportSize({width:390,height:844});
 const phoneWidth=await page.evaluate(()=>({inner:innerWidth,scroll:document.documentElement.scrollWidth}));
 await page.setViewportSize({width:1100,height:1250});
 await page.goto(host+'/studies/mailtrain-paper/revised-options.html');
 await page.screenshot({path:'work/mailtrain-paper/gallery-checked.png'});
 const report={images,desktopWidth,phoneWidth,errors};
 fs.writeFileSync('docs/review-images/mailtrain-paper/revision-2/gallery-check.json',JSON.stringify(report,null,2)+'\n');
 if(errors.length||phoneWidth.scroll>phoneWidth.inner||desktopWidth.scroll>desktopWidth.inner)throw Error(JSON.stringify(report));
 console.log(JSON.stringify(report));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
