/* Actual rendered end-wall opacity and unchanged boards versus published c0af. */
const{chromium}=require('playwright'),a=require('node:assert/strict'),fs=require('node:fs'),cp=require('node:child_process');
const out='docs/review-images/mailtrain-paper/atmosphere',scratch='work/mailtrain-paper/atmosphere';
(async()=>{
 fs.mkdirSync(out,{recursive:true});fs.mkdirSync(scratch,{recursive:true});
 fs.writeFileSync(scratch+'/baseline.html',cp.execFileSync('git',['show','43bd6430:studies/mailtrain-paper/playable.html'],{maxBuffer:32*1024*1024}));
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),pages=[],errors=[],report={build:JSON.parse(fs.readFileSync('studies/mailtrain-paper/build.json')),baseline:'43bd6430',boards:[]};
 try{
  for(const path of [scratch+'/baseline.html','studies/mailtrain-paper/playable.html']){
   const p=await b.newPage({viewport:{width:1440,height:1000}});p.on('pageerror',e=>errors.push(e.message));await p.goto('http://127.0.0.1:8801/'+path);await p.waitForFunction(()=>window.MailtrainStudy?.ready);await p.evaluate(()=>{window.requestAnimationFrame=()=>0;});await p.waitForTimeout(100);pages.push(p);
  }
  for(const id of ['5-1','5-4','5-8','5-15']){
   const samples=[];for(const p of pages)samples.push(await p.evaluate(id=>{
    const s=MailtrainStudy;s.select(id);const f=s.frame();f.worldFrame=300;s.renderer.prepare(f);s.renderer.draw(f);const pixels=screen.getContext('2d').getImageData(0,0,screen.width,screen.height).data,o={},v=[];
    for(let y=0;y<s.state.L.board.h;y++)for(let x=0;x<s.state.L.board.w;x++)for(const dx of [.2,.5,.8])for(const dy of [.2,.5,.8]){MailtrainGeometry.cell(s.renderer.camera,s.state.L,x+dx,y+dy,o);const i=(Math.round(o.y)*screen.width+Math.round(o.x))*4;v.push(pixels[i],pixels[i+1],pixels[i+2],pixels[i+3]);}return v;
   },id));
   a.deepEqual(samples[1],samples[0],id+' board pixels changed');report.boards.push({id,identicalSamples:samples[0].length/4});
  }
  // Change only scenery colour. A solid end wall must not inherit either colour.
  const p=pages[1];report.wall=await p.evaluate(()=>{
   const s=MailtrainStudy,r=s.renderer;s.select('5-1');const f=s.frame();f.worldFrame=300;r.prepare(f);const bg=MailtrainLife.background,fg=MailtrainLife.foreground,rows=[];MailtrainLife.foreground=()=>{};
   for(const col of ['#ff00ff','#00ff00']){MailtrainLife.background=(p,f)=>{p.c.fillStyle=col;p.c.fillRect(0,0,f.viewport.width,f.viewport.height);};r.draw(f);const ctx=screen.getContext('2d'),o={},v=[];for(const y of [-.85,-.45,0,.6])for(const z of [4.4,5.1,5.7,6.3]){MailtrainGeometry.project(r.camera,.064,y,z,o);v.push(Array.from(ctx.getImageData(Math.round(o.x),Math.round(o.y),1,1).data));}const sky=Array.from(ctx.getImageData(1300,150,1,1).data);rows.push({v,sky});}
   MailtrainLife.background=bg;MailtrainLife.foreground=fg;r.draw(f);return{samples:rows[0].v.length,unchanged:JSON.stringify(rows[0].v)===JSON.stringify(rows[1].v),controlChanged:JSON.stringify(rows[0].sky)!==JSON.stringify(rows[1].sky)};
  });a(report.wall.unchanged&&report.wall.controlChanged);
  report.clock=await p.evaluate(()=>{const s=MailtrainStudy,r=s.renderer,f=s.frame(),ctx=screen.getContext('2d'),o={};MailtrainGeometry.project(r.camera,.5,-1.02,5.67,o);const x=Math.floor(o.x-18),y=Math.floor(o.y-18),read=()=>Array.from(ctx.getImageData(x,y,36,36).data);f.worldFrame=0;r.draw(f);const first=read();f.worldFrame=900;r.draw(f);const later=read();r.draw(f);return{moves:JSON.stringify(first)!==JSON.stringify(later),held:JSON.stringify(later)===JSON.stringify(read())};});a(report.clock.moves&&report.clock.held);
  a.deepEqual(errors,[]);report.errors=errors;fs.writeFileSync(out+'/verification.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({boards:report.boards,wall:report.wall,clock:report.clock,errors}));
 }finally{await b.close();}
})().catch(e=>{console.error(e);process.exit(1);});
