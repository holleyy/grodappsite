# Execution ledger — studies/mailtrain-paper/IMPLEMENTATION-PLAN.md

Latest follow-up: [carrier/basket depth and jump clearance](ARRIVAL.md),
with [before/after and slow-motion evidence](arrival-review.html).
35 room tests and all 15 canonical deliveries pass.

Authorisation: Alex said “Ok lets do it” after the implementation plan.
Main base: 923b40d7c3ef2b9e4fab49d290267f0094a1a9bb. Execution base: 3ada3058.
Own source/assets, study, prefixed tests and review evidence only.

Pre-flight interfaces: tasks 1→2→3 share the reusable frame and one geometry;
2→4 shares supported object anchors; 1/3/4→5 shares original CP clock and
read-only traces; 1–5→6 shares builder, browser harness and resource census.
No conflicts found. Synchronous preparation after all asset decoding avoids
an asynchronous per-level scene race. No new gameplay clock.

The cloud skill scripts are not executor files. This room-owned ledger and
work/mailtrain-paper/implementation logs retain the equivalent task evidence.

Task 1: in progress. Initial retained renderer host, namespace and geometry.

Task 1: complete at the retained-renderer boundary. Six focused tests passed
(after six expected missing-feature failures). Chromium opened all 15 canonical
records empty, rotated the original turntable, won 5-1 in seven ticks through
Send, and retained private progress on reload. All observed storage accesses
use the study prefix; no page errors. Browser log: implementation/browser.json.
The late asset attachment always reads the current canonical frame, so a level
changed while decoding cannot attach an obsolete scene. Pointer/zoom/modal
coverage continues with the new renderer in tasks 2/3/5.

Tasks 2–5: implementation present, final visual/browser review in progress.
Canonical Chromium campaign comparison: all 15 solutions win with identical
results, release/route/gate histories and update counts. All 460 centres at
1440×1000 DPR1,390×844 DPR3,720×400 DPR2 are visible and pick correctly.
Real pointer cycles, wheel/drag, hint lock/Clear, Stop, failure/retry pass.
Chapter browser checks preserve live arrangements/progress, four-cat demo,
72-frame entry, all three stops and stage-2 joint poses; final exit restores
untouched City Hall. Malformed/denied storage and production sentinels pass.
Evidence: work/mailtrain-paper/implementation/{campaign,chapters}.json.

Full regression run: 1682/1682 passed, 936.95 seconds. This invocation predates
the later engine depth regression; later room changes require focused/browser
checks, not another unchanged exhaustive solver run.

Ruling: wheel/landscape and chapter scaffolding were brought into the visual
pilot because a floating engine cannot pass the geometry gate. Task-specific
checks remain separate. No shared framework files changed.

User feedback during implementation rejected the locomotive geometry and asked
for scenery in front of/behind the bridge. Root causes: hidden -x smokebox cap
painted over the barrel, short/wide engine proportions, and centroid-only paint
order for overlapping long surfaces. Engine rebuilt as a long tank engine,
open cab, transverse beam, three driving axles; static room-owned pixel-depth
bake now resolves actual geometry instead of guessing face order. New engine
regression covers a nearer raised face under an incorrectly-centred floor.
No replacement of the board projection or shared renderer.

Separate distant plate, grounded far trees, world-plane river/banks and near
foliage now replace the single-plane landscape. These are feedback revisions,
not yet a final accepted appearance. Captures are being refreshed.

Ruling: the original station approach output moves the powered locomotive and
sorting coach toward the stationary extra coach/brake van. Same clock, no new
rule or input phase. Entry uses a prepared wide image, then scales toward the
board endpoint without rebuilding every frame. Pixel-depth engine baking is
prepare-only; it does not run in the live drawing path.

Further user clarification: the large trees in the original valley plate must
sit in front of the bridge. The procedural bank prototype did not preserve
those exact trees. The active build now registers a generated foreground mask
to the original countryside pixels, drawing the near-bank artwork above the
masonry and beneath the clear train/board. Distant scenery remains behind.
The separate-bank prototype and alternate art are retained as unused studies;
the builder explicitly includes only the five active image assets. The stray
rectangle outline through arch openings is removed. No final art acceptance
is inferred from passing game tests.

Final checkpoint update: the preceding separate-bank prototype entry is
superseded by the original-water restoration. Task1 and the browser gameplay/
chapter work in Tasks3/5 are implemented. Tasks2/4 have a playable visual review
checkpoint; their art acceptance/secondary polish is still open. Task6 evidence
and handover are recorded without claiming those visual gates accepted.

One read-only GPT-6 Astra reviewer passed the exercised campaign/chapter/privacy
checks and found3 Important issues: takeoff support, zoomed entry endpoint,
simultaneous pinch/pan. All3 were reproduced with failing tests, then fixed in
room-owned code. Current21 room tests pass; actual Chromium camera continuity
agrees within.0001 CSS pixel. The user requested Astra explicitly during final
verification; the reviewer was already Astra. Main chat model selection is not
controlled by the workspace.

The review's Minor engine-rebake-on-pan cost is deferred and proposed in
INTEGRATION.md. No second independent review is claimed. Source no longer
rebuilds twice per zoom action, but every translated static layer still bakes.
The original landscape/foreground remain registered during entry. The review
picker also follows canonical Next-level navigation.

Current evidence includes19 screenshots,3 deterministic browser-frame clips,
all-board/play/privacy reports,360 board pixel comparisons and20-cycle resource
stability. No test was used as a substitute for human visual acceptance. This
is a local WIP fidelity review checkpoint, with no merge, push, public prefix,
shared framework edits or native work.

User geometry follow-up after ae90c761: continued within the existing ownership
boundary. Independent Astra diagnosis proved shelf depth-order, interior parcel
slabs, capped/incorrectly hinged hatches with below-floor POP, basket footprint
and arrow-radius issues. GEOMETRY.md records fixes and exact evidence. New
prepared solid caching also resolves the prior engine raster cost on translation.
The original river/large trees stay exact. Substantive independent verification
found no remaining Important issues; its rounded blue mask Minor received an
author RED→GREEN correction. Current28 room tests plus actual object/campaign/
chapter/camera/privacy checks pass. Physical/human acceptance remains open.

Publication preference persists: use holleyy/grodappsite for future studies.
No deployment is requested or performed in this geometry pass; coordinate a
unique preview prefix with the integration owner before any later publication.


15 November 2026 — publication explicitly authorised in this chat. Added only
`cats-by-post-mailtrain-paper/` to `holleyy/grodappsite`, with an ownership
manifest and exact build provenance; all22 existing root entries unchanged.
The screenshot check caught and corrected a study-only landscape HUD placement
mismatch. Final package phone390×844 DPR3, landscape720×400 DPR2 and
desktop1440×1000 DPR1 checks pass: actual touch win, saved reload, all15
selector entries, maximum board40 cell centres clear of the HUD, Journey view,
private storage and no page exceptions. Current28 room tests pass. See
PUBLICATION.md for commits, URL, deployment and live-access limits. Source main
and shared/other-room/native code remain untouched.

15 November — the user requests closing the seat-side gap and continuing the
next deliverable phase. Code checkpoint3f7c80ce closes the missing coach end
around an aligned cab doorway. The next remaining presentation work is the
atmosphere/postal-life pass (ATMOSPHERE.md records the scope ruling): continuous
tea/watch routes, architecture-only dusk/night light, working clock and hot-mug
steam. Three new regressions failed first (missing wall, route jump, lighting)
and now31 room tests pass. The camera harness gained the two new drawing stubs;
its original camera assertions are unchanged. All15 canonical wins/traces,
1,380 picks, chapters/storage and phone touch/save checks pass;1,089 board
samples match the published baseline,16 endwall probes are opaque, and20 cycles
retain the previous surface census. A48-second eight-fps sampled clip and
comparison gallery are prepared. Original water/trees/assets remain exact.

Final atmosphere review: one fresh GPT-6 Astra reviewer, read-only, independently
reproduces the31 tests and key actual-browser/canonical/opacity/resource checks.
Zero findings. Its declined hardware/performance/integration/art-acceptance
claims remain explicit limits of this standalone deliverable. The held seated
pose remains a deliberate asset-preservation choice, not completed facial acting.

Published atmosphere phase: grodappsite5a3c5f0, exact Pages run43720500695,
build/report/deploy all successful. The existing Mail Train URL now includes the
fix, gallery/48-second clip and78-entry room-source archive. All22 other site
root entries remain byte-identical. No shared integration or source-main merge.
