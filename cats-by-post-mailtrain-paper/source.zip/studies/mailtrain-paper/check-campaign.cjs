/* Actual Chromium: compare the retained game against the canonical executable. */
const{chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const base='http://127.0.0.1:8801/';
const run=()=>{
 const rows=[];for(let n=1;n<=15;n++){
  const id='5-'+n;gLoad(LEVELS.findIndex(l=>l.id===id));cpCancel();for(const c of gm.L.solution){gm.chutes.push({...c});gm.tray[c.type]--;}gHud();gSend();
  let updates=0;while(gm.mode==='running'&&updates<5000){gUpdate();updates++;}for(let j=0;j<90;j++)gUpdate();
  rows.push({id,mode:gm.mode,updates,t:gm.t,result:grResult(gm.sim),gates:gm.gateTrace?{n:gm.gateTrace.n,from:Array.from(gm.gateTrace.from.slice(0,gm.gateTrace.n))}:null,traces:G_TRACES.slice(0,gm.sim.n).map(t=>({rel:t.rel,n:t.n,end:t.end,x:Array.from(t.x1.slice(0,t.n)),y:Array.from(t.y1.slice(0,t.n)),dir:Array.from(t.d1.slice(0,t.n)),ev:Array.from(t.ev.slice(0,t.n))}))});
 }return rows;
};
(async()=>{
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),p=await b.newPage({viewport:{width:1440,height:1000}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.goto(base+'sorting_office.html');await p.waitForFunction(()=>typeof gm!=='undefined');const canonical=await p.evaluate(run);
 await p.goto(base+'studies/mailtrain-paper/playable.html');await p.waitForFunction(()=>window.MailtrainStudy?.ready);const study=await p.evaluate(run);assert.deepEqual(study,canonical);assert(study.every(x=>x.mode==='won'));
 const geometry=[];
 for(const [w,h,dpr]of [[1440,1000,1],[390,844,3],[720,400,2]]){
  const context=await b.newContext({viewport:{width:w,height:h},deviceScaleFactor:dpr}),q=await context.newPage();q.on('pageerror',e=>errors.push(e.message));await q.goto(base+'studies/mailtrain-paper/playable.html');await q.waitForFunction(()=>window.MailtrainStudy?.ready);
  geometry.push(await q.evaluate(()=>{let count=0,bad=0,visible=0;const hit={},pt={};for(let n=1;n<=15;n++){MailtrainStudy.select('5-'+n);const f=MailtrainStudy.frame(),r=MailtrainStudy.renderer;r.prepare(f);r.draw(f);for(let y=0;y<gm.L.board.h;y++)for(let x=0;x<gm.L.board.w;x++){MailtrainGeometry.cell(r.camera,gm.L,x+.5,y+.5,pt);r.pick(pt.x,pt.y,hit);if(!hit.valid||hit.x!==x||hit.y!==y)bad++;if(pt.x>=0&&pt.x<innerWidth&&pt.y>=64&&pt.y<innerHeight-f.insets.bottom)visible++;count++;}}return{width:innerWidth,height:innerHeight,dpr:devicePixelRatio,count,bad,visible};}));
  assert.equal(geometry.at(-1).bad,0);assert.equal(geometry.at(-1).visible,460);
  // Real pointer placements/rotation/removal, then wheel and drag classification.
  await q.evaluate(()=>{MailtrainStudy.select('5-1');const f=MailtrainStudy.frame();MailtrainStudy.renderer.prepare(f);MailtrainStudy.renderer.draw(f);});
  const point=await q.evaluate(()=>MailtrainGeometry.cell(MailtrainStudy.renderer.camera,gm.L,7.5,1.5,{}));
  await q.mouse.click(point.x,point.y);assert.equal(await q.evaluate(()=>gm.chutes[0]?.dir),'U');
  for(const d of ['R','D','L']){await q.mouse.click(point.x,point.y);assert.equal(await q.evaluate(()=>gm.chutes[0]?.dir),d);}
  await q.mouse.click(point.x,point.y);assert.equal(await q.evaluate(()=>gm.chutes.length),0);
  await q.mouse.move(point.x,point.y);await q.mouse.wheel(0,-100);await q.waitForTimeout(100);const before=await q.evaluate(()=>gm.chutes.length);await q.mouse.down();await q.mouse.move(point.x+50,point.y+20,{steps:4});await q.mouse.up();assert.equal(await q.evaluate(()=>gm.chutes.length),before);
  const z=await q.evaluate(()=>{const r=MailtrainStudy.renderer,f=MailtrainStudy.frame(),p={},hit={};r.prepare(f);MailtrainGeometry.cell(r.camera,gm.L,3.5,1.5,p);r.pick(p.x,p.y,hit);return hit;});assert.deepEqual(z,{valid:true,x:3,y:1});
  await context.close();
 }
 // Original hint locks, clear, stop and failed retry.
 const interactions=await p.evaluate(()=>{
 MailtrainStudy.select('5-1');gHint();const locked=gm.chutes.filter(c=>c.locked).map(c=>({...c}));const t=gm.chutes[0];gTap(t.x,t.y);gClear();const lockSurvives=JSON.stringify(gm.chutes)===JSON.stringify(locked);
 MailtrainStudy.select('5-1');gSend();for(let i=0;i<20;i++)gUpdate();gSend();const stopped=gm.mode==='edit';gSend();while(gm.mode==='running')gUpdate();const failed=gm.mode;MailtrainStudy.solution();gSend();while(gm.mode==='running')gUpdate();return{lockSurvives,stopped,failed,retry:gm.mode};});
 assert(interactions.lockSurvives&&interactions.stopped);assert.equal(interactions.retry,'won');assert.notEqual(interactions.failed,'won');
 assert.deepEqual(errors,[]);const report={campaign:study,geometry,interactions,errors};fs.writeFileSync('work/mailtrain-paper/implementation/campaign.json',JSON.stringify(report,null,2));console.log(JSON.stringify({wins:study.length,geometry,interactions,errors}));await b.close();
})().catch(e=>{console.error(e);process.exit(1);});
