# Mail Train · connected-train revision

15 November 2026. The user rejected all first-pass compositions: visible groups
of middle carriages ended in empty track, without a locomotive, meaningful rear
end or continuation. Their gaps made travel physically unexplained. No direction
was selected. This correction supersedes the first-pass recommendation and its
carriage-placement diagrams; those remain historical board-layout references,
not approved train arrangements.

The base, branch, scope and proposed ownership remain as recorded in README.
Only room-owned composition art, gallery and notes change in this revision.

## Revised displayed order

1. **Complete Branch-Line Mail.** Front-facing tank locomotive, one playable
   sorting coach, last enclosed brake van with red tail lamp. The entire short
   train is visible, all couplings join, and the rails continue off both edges.
2. **Aboard the Through Mail.** An establishing strip shows the locomotive,
   longer connected train, highlighted sorting coach and actual last brake van.
   In the close play view, adjacent coaches continue beyond both image edges;
   no exposed outer coach end or unexplained gap occurs inside that frame.
3. **The Valley Mail.** A complete locomotive, sorting coach and last brake van
   cross a continuous viaduct. The front and rear are explicit, and both rails
   extend naturally beyond the view. More scenery trades against board scale.

Every direction compares first8×3 and maximum10×4. As before, the generated
grids are illustrative, not authoritative cell counts or puzzle placements.
All later board/piece geometry must read the unchanged canonical records.
The first two pictures' frontal treatment also remains an art proposal; final
projection must agree with architecture, feet, furniture, depth and picking.

## Physical continuity requirements

- One common longitudinal axis, rail gauge and travel coordinate for the whole
  train. Bogies support bodies; every wheel stays on its rail.
- Every adjacent vehicle has a real coupling reaching both buffer beams.
  Buffers and flexible gangways bridge only normal inter-vehicle clearance.
  No decorative floating gangway or open track-sized gap between coaches.
- If both train ends are visible, show the locomotive at the leading end and
  an explicit last vehicle with rear marker. A view of middle coaches must
  instead continue their bodies beyond both crop edges and establish the
  complete train elsewhere. Do not place a tail lamp on a middle coach.
- Rails and sleepers continue through and beyond the scene. A viaduct joins
  land or continues out of frame; neither railway nor bridge is an island.
- All vehicles follow the same train position. No disconnected sorting coach
  moves independently while mail is sorted.

## Proposed movement, not implemented

The play camera tracks the sorting coach. The connected train therefore stays
steady relative to the board; wheels rotate by signed travel distance, while
sleepers, telegraph poles, hedges and distant scenery pass at their respective
depths. A rigid scenery-only sway may affect bags/lamps, never tile picking or
the live board. At stations the whole train stops, with supported coupling
choreography confined to the existing between-level presentations. Reduced
motion holds a coherent complete pose and leaves puzzle time unchanged.

## Evidence and stop

Three independent image-generation calls received local first-pass art, the
approved Office screenshot and, for later directions, the revised complete-train
reference. Sources remain unchanged in `/workspace/generated_images`. Compact
review copies and SHA256 provenance are under
`docs/review-images/mailtrain-paper/revision-2/`.

The gallery is updated; `first-pass.html` retains the rejected set. No product
source or gameplay has changed. The prior full baseline plus fixture-recovery
evidence remains scoped to unchanged production inputs. Check this revised
static gallery; do not repeat the unrelated full solver suite for art-only edits.
Return for selection or refinement before implementation. No push, merge or
publication is authorised.

The revised gallery passes in local Chromium: all six displayed images decode,
zero page exceptions, no horizontal overflow at1100px or390px. The fresh local
server uses8797 because the old8796 listener returned empty responses; no
unknown listener was removed. To repeat:

```sh
python3 -m http.server 8797 --bind 127.0.0.1
MAILTRAIN_PREVIEW_URL=http://127.0.0.1:8797 node studies/mailtrain-paper/check-gallery.cjs
```

`git diff --check` passes. Protected source/data/shared/native paths compare
unchanged to the first checkpoint. No unrelated full solver rerun was needed
for these composition/gallery changes. No runtime movement is claimed.
