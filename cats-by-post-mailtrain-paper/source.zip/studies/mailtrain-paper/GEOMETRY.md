# Shelf, box and piece geometry follow-up

User direction: continue and check shelves, boxes and pieces; use
`holleyy/grodappsite` for future study publication. This revision remains local.
No preview prefix is agreed and no publication, push or merge has occurred.

Starting checkpoint: `ae90c761`. Original main base remains
`923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`. Same room-owned paths and worktree.

## Findings and corrections

A read-only GPT-6 Astra diagnosis confirmed that the shared floor projection
was sound. The incorrect appearance had specific causes:

- **Shelves:** full-height dividers and the plinth were painted over nearer shelf
  floors and letters. The same177 faces yielded wrong depth on51,321 of169,413
  covered pixels (30.3%). Cabinets now use a prepared depth-resolved surface,
  retaining their dimensions and exposing all rows. A footprint-bound contact
  replaces the broad detached-looking oval shadow.
- **Parcels:** full-height intersecting slabs represented tape. Their interior
  faces showed through the carton. Tape now wraps only the exterior top/front/
  end faces; labels stay attached to the top.
- **Hatches:** a solid wooden cap covered the recess even when open; the lid
  ignored direction and emerging carriers were drawn below the floor. The
  frame now surrounds a visible aperture, each direction has its proper hinge,
  near lids draw on the near side, and POP art is clipped against the opening.
- **Baskets:** the blue source cutout had contact slopes+.650/−.789 against a
  ±.5 floor. Registered source columns now measure+.499641/−.499694. The
  rounded contact shape and vertical relief are retained. Both basket shapes
  have separate near-wall masks, replacing the horizontal clipping strip.
- **Points:** active arrows extended.02 tile beyond the disc. Their printed
  offset is reduced; all twelve direction pairs fit within the plate.
- **Carriers:** their square projection was already correct. Paper panels now
  have folded flaps, scored edges, a floor seam and attached lower creases,
  replacing the wood-lined tray appearance. Pose roots and deadlines are exact.

The original river/water/large-tree artwork is unchanged. No generated asset
was repainted. Registration reads accepted copied artwork and prepares local
surfaces once; the original Office assets/source remain untouched.

## Cache and resource consequences

The same depth preparation is now reusable for the locomotive and cabinets.
Camera translation draws cached geometry; only effective scale changes replace
its raster. Four pans trigger zero raster calls. Shared-cloud samples range
from about5–31ms per complete static-layer preparation while other checks run;
these are not device benchmarks. The prior136–163ms engine-rebake item is closed
at its root cause. Physical phone/Safari performance remains unqualified.

Full-resolution stock pixels avoid coarse albedo pixels in prepared fixtures.
The small128px world-pattern tiles remain unchanged. Current room census:
17 surfaces,12,582,912 retained texture bytes. At1440×1000 DPR1/max board it
reports6,858,477 surface pixels, stable over20 level cycles. Counts include
four registered basket surfaces and three prepared solid surfaces; they exclude
canonical-page resources, browser overhead and temporary bake buffers. No live
frame pixel readback or texture generation was added.

## Verification and review

Current28 room tests pass. New regressions cover exterior parcel bands,
order-independent cabinet depth, pan-cache reuse, all four hinge directions,
all twelve points pairs, basket contact slopes and rounded mask coverage.
Actual Chromium confirms a visible recess in each direction, zero below-floor
POP pixels at four sampled ages, corrected basket slopes and no raster calls
on translation.

All15 original deliveries still win with matching rules, update counts, routes,
release times and gate histories. All1,380 centre picks across the three target
viewports pass. Real pointer/Hint/Clear/Stop/retry, chapter/station/settled-exit,
private-storage and previous camera/takeoff regression checks pass. At360
sampled board pixels, attachments/scenery do not alter the board. Canonical
source/content/export, other rooms, Office and native remain unchanged.

Astra independently verified the substantive revision at build`d87c7647`:
27 tests, browser object checks, four-direction POP compositions, maximum board
and reproducible packaging. All four Important findings closed, with no new
Critical/Important issue. It found one Minor: the blue near-wall mask used a
sharp V and omitted a strip at the rounded centre. The author reproduced that
with a failing regression, then preserved the measured contour in the mask.
The final28-test and object checks pass. No second independent review is claimed
for that narrow correction. Capture manifests retain their actual build hashes.

The earlier full1682-test invocation remains the full-repository evidence;
this geometry-only follow-up ran the affected suite and actual browser campaign
instead of repeating unchanged exhaustive solvers. Human art acceptance and
physical-device qualification are still open.

## Evidence and reproduction

[Current gallery](index.html). Compact before/after close-ups, actual first/max/
phone/landscape views, emergence samples, motion clips and reports are under
`docs/review-images/mailtrain-paper/geometry/`. Existing implementation and
concept evidence remains archived and labelled separately.

```sh
python3 studies/mailtrain-paper/build-study.py
node --test tests/mailtrain-paper-*.test.js
node studies/mailtrain-paper/check-object-geometry.cjs
node studies/mailtrain-paper/check-campaign.cjs
node studies/mailtrain-paper/check-chapters.cjs
node studies/mailtrain-paper/check-review.cjs
node studies/mailtrain-paper/check-visual.cjs
node studies/mailtrain-paper/capture-geometry.cjs before
node studies/mailtrain-paper/capture-geometry.cjs after
node studies/mailtrain-paper/capture-geometry-play.cjs
```

Serve the worktree on127.0.0.1:8801. Before close-ups load exact room classes
from`ae90c761` inside an isolated browser diagnostic canvas; after close-ups
use current classes. Full-room images are actual playable renders. All source
edits and outputs stay inside the existing ownership boundary.
