"""Composition-only plates. Read canonical records; never write game data."""
import html
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'docs/review-images/mailtrain-paper'
LEVELS = json.loads((ROOT / 'src/data/levels.json').read_text())['levels']
CASES = [next(l for l in LEVELS if l['id'] == key) for key in ('5-1', '5-15')]
NAMES = ('Connected Night Mail', 'Roof-Rib Workshop', 'Lantern Viaduct')


def plate(direction):
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="1250" viewBox="0 0 1100 1250">',
             '<rect width="1100" height="1250" fill="#f7f2e5"/>',
             '<g font-family="sans-serif" fill="#244a4a">',
             f'<text x="30" y="34" font-size="23">{NAMES[direction]} · measured composition</text>',
             '<text x="30" y="59" font-size="14">Canonical board records · one orthographic floor basis · not a playable study</text>']
    report = []
    for row, level in enumerate(CASES):
        w, h = level['board']['w'], level['board']['h']
        # Every object uses this exact basis; z is height above the same floor.
        def p(x, y, z=0):
            return 450 + (x-y)*26, 310 + row*550 + (x+y)*13 - z*26

        def poly(coords, fill, stroke='#5e6863', width=1):
            points = ' '.join(f'{x:.2f},{y:.2f}' for x, y in (p(*q) for q in coords))
            parts.append(f'<polygon points="{points}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')

        def rect(x, y, a, b, z, colour):
            poly([(x,y,z),(x+a,y,z),(x+a,y+b,z),(x,y+b,z)], colour)

        def label(x,y,text,colour='#fff2cf',size=10,z=0):
            X,Y=p(x,y,z)
            parts.append(f'<text x="{X:.2f}" y="{Y:.2f}" text-anchor="middle" fill="{colour}" font-size="{size}">{html.escape(text)}</text>')

        y0, y1 = -2.1, 4.65
        x0, x1 = -1.8, 11.8
        parts.append(f'<text x="30" y="{102+row*550}" font-size="20">{level["id"]} · {w} × {h} · {level["title"]}</text>')
        # Floor thickness and back panel, followed by supported fixtures.
        poly([(x0,y1,-.3),(x1,y1,-.3),(x1,y1,0),(x0,y1,0)], '#8b5842')
        rect(x0,y0,x1-x0,y1-y0,0,'#d0aa77')
        poly([(x0,y0,0),(x1,y0,0),(x1,y0,2.3),(x0,y0,2.3)], '#356468')
        # Full coaches are entirely beyond each end. A physical gap joins them.
        coaches = [(-7.4,5.3)]
        if direction != 1:
            coaches += [(12.1,5.3)]
        for cx, length in coaches:
            rect(cx,y0,length,y1-y0,0,'#294d51')
            poly([(cx,y1,0),(cx+length,y1,0),(cx+length,y1,2),(cx,y1,2)],'#2c6468')
            rect(cx,y0,length,y1-y0,2,'#eee0b8')
            for wx in (cx+.7,cx+2.7):
                poly([(wx,y1,.65),(wx+1.1,y1,.65),(wx+1.1,y1,1.45),(wx,y1,1.45)],'#e9bd69')
        # Furniture sits behind y=-.55 or beyond either end of the live floor.
        rect(2,-1.95,3.1,1.05,.8,'#a44835')
        rect(6,-1.95,3.1,1.05,.8,'#3f6d81')
        rect(-1.5,-.8,1.1,2,.45,'#7e3c53')
        rect(10.35,-1.7,1.1,1.3,.75,'#c89b62')
        # Each tile is emitted independently. Numbering is logical x,y.
        for y in range(h):
            for x in range(w):
                rect(x,y,1,1,.015,'#56758b')
                label(x+.5,y+.55,f'{x},{y}',size=8,z=.02)
        for gate in level.get('gates',[]):
            x,y=p(gate['x']+.5,gate['y']+.5,.025)
            parts.append(f'<ellipse cx="{x:.2f}" cy="{y:.2f}" rx="19" ry="9.5" fill="#d7ad57" stroke="#604c2d"/>')
            label(gate['x']+.5,gate['y']+.7,'/'.join(gate['exits']),'#352f29',10,.04)
        for i, hatch in enumerate(level['hatches']):
            rect(hatch['x']+.13,hatch['y']+.13,.74,.74,.06,'#e6c391')
            label(hatch['x']+.5,hatch['y']+.67,f'H{i+1}', '#2f474a',11,.08)
        for basket in level['baskets']:
            x,y=p(basket['x']+.5,basket['y']+.5,.08)
            colour='#bb713d' if basket['coat']=='ginger' else '#486984'
            parts.append(f'<ellipse cx="{x:.2f}" cy="{y:.2f}" rx="17" ry="8.5" fill="{colour}" stroke="#f2d6a5" stroke-width="3"/>')
        # Staff have an explicit sole at y=-.45: their footprint clears row 0.
        rect(5.25,-.7,.5,.45,.02,'#8b765d')
        label(5.5,-.45,'staff', '#244a4a',10, .4)
        if direction == 1:
            for x in (0,5,10):
                # Rear rib supports stay behind board, roof omitted for clarity.
                poly([(x,-1.98,0),(x+.12,-1.98,0),(x+.12,-1.98,2.6),(x,-1.98,2.6)],'#eee0b8')
        parts.append(f'<text x="30" y="{624+row*550}" font-size="13">{w*h} equal cells · {len(level["gates"])} points · {len(level["hatches"])} hatches · all attachments outside live board</text>')
        report.append({'id':level['id'],'board':[w,h],'cells':w*h,'points':level['gates'],'hatches':level['hatches'],'baskets':level['baskets'],'boardBounds':[0,0,w,h],'shellBounds':[x0,y0,x1,y1],'staffFootprint':[5.25,-.7,5.75,-.25],'attachedCoachRanges':[[x,x+n] for x,n in coaches]})
        assert w <= x1 and h <= y1
        assert all(x+n < 0 or x > w for x,n in coaches)
    parts.append('</g></svg>')
    return '\n'.join(parts), report


OUT.mkdir(parents=True, exist_ok=True)
reports=[]
for direction in range(3):
    svg, report=plate(direction)
    (OUT/f'geometry-{direction+1}.svg').write_text(svg+'\n')
    reports.append({'direction':direction+1,'projection':'screen=(450+26*(x-y),310+row*550+13*(x+y)-26*z)','cases':report})
(OUT/'geometry.json').write_text(json.dumps(reports,indent=2)+'\n')
print('Six canonical geometry layouts: board and attached coaches clear; generated SVG and JSON.')
