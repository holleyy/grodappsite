# Visual consistency and integration handover

User approved this phase on 15 November 2026: inspect every delivery and chapter
visually, polish existing movement, and prepare the integration handover.
Phase base: `fa367b4d3571b4986cba1bb010da03c01c5480db` on `codex/mailtrain-paper-fidelity`; original main base
`923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`.

## Scope and sequence

1. Capture all 15 deliveries at desktop, portrait and landscape sizes, plus
   story/demo, all three station stops, entry and exit. Inspect active/settled
   objects, visibility, projection, depth and continuity. Record visible issues.
2. Reproduce and correct the confirmed room-local movement/geometry defects.
   Preserve canonical clocks, traces, levels, saving and existing artwork.
   Verify behavioural corrections with a failing regression followed by a pass.
3. Capture the finished matrix and concise motion evidence; run the room,
   campaign, chapter, input/privacy and relevant geometry/resource checks.
   Obtain one independent Astra review and resolve material findings.
4. Refresh the integration contract and handover, and update only the already
   authorised `grodappsite/cats-by-post-mailtrain-paper/` publication.

Ownership stays in `src/fidelity/mailtrain-paper/`, `studies/mailtrain-paper/`,
`tests/mailtrain-paper-*.test.js` and `docs/review-images/mailtrain-paper/`.
Shared production framework, Office, other rooms, native and canonical data
remain untouched. No source-main merge. Publication authorisation persists
from the user's explicit request in this chat.

Pre-flight: capture tools consume the existing frame API; visual corrections
must retain that API so the integration contract can describe one final build.
The room-owned ledger and existing scratch directory are used in place of the
skill's generic workspace, to respect the user's file ownership boundary.
Existing scratch evidence is preserved. Tests broaden only for changes or
failures; the previous 1,682-test whole-repository run is historical evidence.

## Progress

- Baseline sweep: 89 views across all 15 deliveries, three viewports, seven
  chapter states and all four board sizes in Journey/grayscale. Original water,
  large trees and the first/max-board compositions remain intact.
- Confirmed defects: coupling bars painted through the sorting floor and brake
  van wall; empty carriers shrank in discrete steps; the departure courier
  crossed the desk and replaced the satchel with a letter at the endpoint.
- Corrections: underfloor hardware is behind coach bodies, joined passages have
  narrow decks, rigid card panels fold continuously, and the courier goes around
  the desk/trolley before entering the enclosed coach. The tea routine visits
  the real tea table. Original phase boundaries and canonical clocks are exact.
- The first proposed departure detour cleared the furniture in floor coordinates
  but its feet still overpainted the desk. Magnified browser inspection rejected
  it; the final route uses the near aisle instead. No such rejected route is
  published as the accepted result.
- Regression evidence: 915/1,600 floor pixels and 276/1,600 brake-wall pixels
  showed hardware before; both now read zero. Early departure frames contain the
  courier; frames 204 and 300 contain zero visible courier pixels behind the
  opaque coach. Rigid card lengths, smooth fold boundaries, supported gangways,
  unobstructed floor routes and tea-route continuity have focused tests.
- 40 room tests pass. Two earlier geometry fixtures incorrectly supplied numeric
  coats to runRules, which expects coat strings; these fixtures are corrected.
  The all-canonical pose comparison already supplied real strings and is unchanged.
- All 15 canonical wins/traces/update counts and 1,380 cell picks pass again.
  Chapter clocks, all three stops, City Hall fallback, private progress sentinel,
  malformed and denied storage pass again.
- One fresh independent Astra review found a remaining foreground furniture
  overlap and a missing return walk in the tea clip. Both have author corrections
  and verification; see the independent-review.md evidence record. Final
  captures are refreshed. The exact packaged HTML passes desktop, portrait
  and landscape touch wins, private saved reloads and maximum-board/HUD checks. The initial active
  pose captures rewound a won simulation and retained its delivered HUD. The
  final capture tool replays to a genuinely running state; only the corrected
  matrix is included in the review gallery.


## Reproduce and inspect

Serve this worktree on port 8801. Build with
`python3 studies/mailtrain-paper/build-study.py`, then run
`node --test tests/mailtrain-paper-*.test.js` and the room's
`check-polish.cjs`, `check-campaign.cjs`, `check-chapters.cjs`,
`check-object-geometry.cjs`, `check-review.cjs` and `check-visual.cjs`.

`capture-polish.cjs docs/review-images/mailtrain-paper/polish/matrix`
records the full matrix. `capture-polish-details.cjs` compares the phase-base
HTML saved at `work/mailtrain-paper/polish/baseline.html` with the current build.
`record-polish.cjs` records the fold at quarter speed, departure at original
speed and tea at 2.4×. They seek existing clocks, not level or rule data.
Evidence: [review gallery](polish-review.html). No measured device FPS is claimed.

## Owned changes and integration

Runtime: architecture.js, life.js, pieces.js and renderer.js under the room's
source directory. Tests: the new polish regression, updated camera harness for the two furniture
layers and corrected string-coat fixtures in arrival/pieces tests. Study: capture/check/record tools, gallery,
packaging, build output and handover. Evidence stays under the room's polish
review directory. No shared build/renderer/interface/bridge file is edited.

The caller contract remains exactly [INTEGRATION.md](INTEGRATION.md). No new
clock, atlas, decoded image or shared API is introduced. Two cropped furniture
surfaces provide the required foreground occlusion and are rebuilt/disposed with
the existing room lifecycle.
Canonical source hashes remain pinned in build.json. Original artwork remains
byte-identical. Source-main integration belongs to the integration owner.

The current resource census is19 retained room surfaces: the original17 plus
the two cropped furniture layers. See the final verification below.

The authorised site prefix remains `cats-by-post-mailtrain-paper/`. Fresh site
base is `256dcc23fbfb25d6ec4a9e5bcec694a1263f5b21`, refreshed after the initial
`f99c1dc` checkpoint. Both City Hall clock-bay and sorting-floor updates are
preserved. An isolated site worktree preserves that
update and the previous publication branch. No integration-owner acknowledgement
is claimed. This publication does not authorise a source-main merge.


## Final source verification

Playable SHA-256: `d1752ab292e0c6623a09f96f5d39d205d0a94026da3da208f5a6cb5796c292a3`.
40/40 room tests pass. All15 canonical wins and1,380 visible cell picks pass;
chapter/input/privacy, registered basket/hatch/POP geometry, camera entry and
combined pinch/pan checks pass.360 sampled board pixels are unaffected by
attachments/scenery; scenery pause leaves gameplay advancing.20 level cycles
retain19 surfaces and6,950,558 surface pixels at1440×1000 DPR1/max board.
The two cropped furniture layers add92,081 surface pixels at that view and
introduce no per-frame allocation. Original five images/12,582,912 retained
texture bytes are unchanged. This census excludes the canonical atlas/browser.

The author inspected final all-delivery active/settled, phone and landscape
contact sheets, chapter compositions, first/max boards and detail poses. All89
matrix captures identify this final runtime; every active capture has actual
running state. The disabled-foreground diagnostic deliberately restores the
reviewer's issue and fails with43–422 leaking pixels in the eight probes; the
normal final build passes with zero. Raw logs and machine reports are retained.


## Review package

The exact packaged HTML passes Chromium mobile emulation at390×844 DPR3,
720×400 DPR2 and1440×1000 DPR1: touch wins, saved reloads, maximum-board HUD
clearance, all15 picker options and Journey controls. The phone gallery decodes
all7 images and3 motion clips, has6 working navigation links and no horizontal
overflow. Physical iPhone/Safari and sustained FPS remain unqualified.
The source overlay and integration contract are ready for the integration owner;
no shared-file change or source-main merge is included.
