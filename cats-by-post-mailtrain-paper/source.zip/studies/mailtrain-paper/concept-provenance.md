# Composition art provenance

15 November 2026. Three independent `image_gen.imagegen` calls, displayed in
this order: Connected Night Mail, Roof-Rib Workshop, Lantern Viaduct. One call
per direction, no retries or repaints. Target requested:1536×1024. Each result
shows first and maximum boards within one architectural direction.

All calls received actual conversation images through
`num_last_images_to_include`:4for the first call,5for each later call. These
included the user's Lantern Quay image and the actual checked-in Office/Train
screenshots inspected immediately before generation. Later calls also saw
earlier directions so their composition could be distinguished explicitly.

Common prompt constraints: coherent orthographic isometric projection; period
travelling post office; tactile thick matte card, restrained grain, cream
barrel roofs, teal shell, warm timber, burgundy seat, red/blue cubbies, tea urn,
mailbags, brass lamps, grounded staff; stable, uninterrupted 8×3 and10×4 boards;
attached fully enclosed carriages only outside the live board; no UI redesign.
Direction-specific requests match the three descriptions in README.

Image generation does not reliably enforce exact cell counts or canonical
placements. Its grids, lever-like points in the first two options and some
furniture slopes are proposals requiring correction during implementation.
The geometric plates use actual canonical hatch/points/basket records and one
explicit projection. No painting is intended to replace the runtime board or
serve as a perspective-mismatched tabletop texture.

`docs/review-images/mailtrain-paper/provenance.json` records original generated
paths, original and review SHA256, dimensions and the sole conversion:WebP
quality92. Original PNGs remain unchanged in `/workspace/generated_images`.
The repository stores compact review copies. Reference captures are PNGs from
the locally running checked-in HTML; they are not generated artwork.
