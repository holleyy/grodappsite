/* Read-only close-ups at fixed canonical arrival ages, including wrong delivery. */
const {chromium}=require('playwright'),fs=require('node:fs');
(async()=>{
 const phase=process.argv[2]||'after',out='docs/review-images/mailtrain-paper/arrival-clearance';fs.mkdirSync(out,{recursive:true});
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),p=await b.newPage({viewport:{width:1440,height:1000}});
 await p.goto('http://127.0.0.1:8801/studies/mailtrain-paper/playable.html');await p.waitForFunction(()=>window.MailtrainStudy?.ready);await p.evaluate(()=>window.requestAnimationFrame=()=>0);await p.waitForTimeout(100);
 const report=[];
 for(const solved of [true,false])for(const coat of [1,2])for(const age of [.25,.4,.45,.5,.55,.6,.72]){
  const row=await p.evaluate(({solved,coat,age})=>{
   const s=MailtrainStudy;s.select('5-1');if(solved)s.solution();gSend();while(gm.mode==='running')gUpdate();const tr=G_TRACES.find(t=>t.coat===coat),j=tr.n-1;
   gm.t=tr.rel+tr.n*tr.tick+age;const f=s.frame(),r=s.renderer;f.worldFrame=300;r.prepare(f);r.draw(f);
   const at=MailtrainGeometry.cell(r.camera,gm.L,tr.x1[j]+.5,tr.y1[j]+.5,{});r.zoomAt(at.x,at.y,2.5);r.prepare(f);r.draw(f);MailtrainGeometry.cell(r.camera,gm.L,tr.x1[j]+.5,tr.y1[j]+.5,at);
   return{solved,coat,age,dir:tr.d0[j],end:tr.end,clip:{x:Math.max(0,Math.min(960,Math.floor(at.x-240))),y:Math.max(0,Math.min(620,Math.floor(at.y-250))),width:480,height:380}};
  },{solved,coat,age});
  const file=phase+'-'+(solved?'home':'wrong')+'-'+coat+'-'+age+'.jpg';await p.screenshot({path:out+'/'+file,clip:row.clip,type:'jpeg',quality:94});report.push({...row,file});
 }
 fs.writeFileSync(out+'/'+phase+'.json',JSON.stringify(report,null,2));await b.close();console.log(report.length+' '+phase+' arrival close-ups');
})().catch(e=>{console.error(e);process.exit(1);});
