/* Verify the byte-identical site package at phone sizes. URL can target Pages. */
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const base = process.env.MAILTRAIN_PUBLICATION_URL || 'http://127.0.0.1:8802/cats-by-post-mailtrain-paper/';
const out = process.env.MAILTRAIN_PUBLICATION_EVIDENCE || 'docs/review-images/mailtrain-paper/publication';
const expectedHash = JSON.parse(fs.readFileSync('studies/mailtrain-paper/build.json', 'utf8')).sha256;
(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
  const report = { url: base, checkedAt: new Date().toISOString(), screens: [] };
  try {
    for (const [name, width, height, dpr] of [['phone', 390, 844, 3], ['landscape', 720, 400, 2], ['desktop', 1440, 1000, 1]]) {
      const context = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: dpr, hasTouch: true, isMobile: name !== 'desktop' });
      const page = await context.newPage(), errors = [];
      page.on('pageerror', e => errors.push(e.message));
      await page.addInitScript(() => {
        window.__publicationStorage = [];
        const get = Storage.prototype.getItem, set = Storage.prototype.setItem;
        Storage.prototype.getItem = function(k) { window.__publicationStorage.push(['get', k]); return get.call(this, k); };
        Storage.prototype.setItem = function(k, v) { window.__publicationStorage.push(['set', k]); return set.call(this, k, v); };
      });
      // A 21 MB navigation exceeds Chromium's inspector body cache; fetch
      // separately for byte verification without changing browser limits.
      if (!report.sha256) {
        const packageResponse = await context.request.get(base, { timeout: 60000 });
        assert.equal(packageResponse.status(), 200);
        report.sha256 = crypto.createHash('sha256').update(await packageResponse.body()).digest('hex');
        await packageResponse.dispose();
      }
      const hash = report.sha256;
      assert.equal(hash, expectedHash);
      const response = await page.goto(base + '?level=5-1', { timeout: 60000 });
      assert.equal(response.status(), 200);
      await page.waitForFunction(() => window.MailtrainStudy?.ready, {}, { timeout: 30000 });
      assert.equal(await page.locator('#mp-level option').count(), 15);
      const point = await page.evaluate(() => {
        const s = MailtrainStudy, f = s.frame(); s.renderer.prepare(f); s.renderer.draw(f);
        return MailtrainGeometry.cell(s.renderer.camera, s.state.L, 7.5, 1.5, {});
      });
      for (let n = 0; n < 3; n++) await page.touchscreen.tap(point.x, point.y);
      assert.equal(await page.evaluate(() => MailtrainStudy.state.chutes[0]?.dir), 'D');
      await page.locator('#btnSend').tap();
      await page.waitForFunction(() => MailtrainStudy.state.mode === 'won', {}, { timeout: 25000 });
      await page.reload();
      await page.waitForFunction(() => window.MailtrainStudy?.ready);
      assert(await page.evaluate(() => !!MailtrainStudy.progress.levels['5-1']));
      await page.locator('#mp-level').selectOption('5-15');
      await page.waitForFunction(() => MailtrainStudy.state.L.id === '5-15');
      await page.waitForTimeout(500);
      const screen = await page.evaluate(() => ({
        level: MailtrainStudy.state.L.id, board: MailtrainStudy.state.L.board,
        width: innerWidth, documentWidth: document.documentElement.scrollWidth,
        allStoragePrivate: window.__publicationStorage.every(e => e[1].startsWith('catsByPost.mailtrainPaper.study.v1:')),
        controls: ['mp-level', 'mp-view', 'btnSend'].map(id => {
          const r = document.getElementById(id).getBoundingClientRect();
          return { id, x: r.x, y: r.y, width: r.width, height: r.height };
        }),
        coveredCells: (() => {
          const s = MailtrainStudy, hud = document.getElementById('hud').getBoundingClientRect();
          const bar = document.getElementById('mp-review').getBoundingClientRect(), hits = [];
          for (let y = 0; y < s.state.L.board.h; y++) for (let x = 0; x < s.state.L.board.w; x++) {
            const p = MailtrainGeometry.cell(s.renderer.camera, s.state.L, x + .5, y + .5, {});
            if (p.x < 0 || p.x > innerWidth || p.y < bar.bottom || p.y > innerHeight ||
                (p.x >= hud.left && p.x <= hud.right && p.y >= hud.top && p.y <= hud.bottom)) hits.push([x, y]);
          }
          return hits;
        })()
      }));
      assert.equal(screen.documentWidth, width);
      assert(screen.allStoragePrivate);
      assert.deepEqual(screen.coveredCells, [], name + ': every largest-board cell must be clear of the actual HUD');
      for (const r of screen.controls) assert(r.x >= 0 && r.y >= 0 && r.x + r.width <= width + 1 && r.y + r.height <= height + 1, r.id);
      await page.screenshot({ path: `${out}/${name}-maximum.jpg`, type: 'jpeg', quality: 86 });
      await page.locator('#mp-view').tap();
      assert.equal(await page.locator('#mp-view').textContent(), 'Sorting floor');
      await page.waitForTimeout(250);
      await page.screenshot({ path: `${out}/${name}-journey.jpg`, type: 'jpeg', quality: 86 });
      assert.deepEqual(errors, []);
      report.screens.push({ name, width, height, dpr, hash, touchWin: true, savedWinReloaded: true, ...screen, errors });
      console.log(name + ': touch win, saved reload, maximum board, journey and controls passed');
      await context.close();
    }
    fs.writeFileSync(out + '/browser.json', JSON.stringify(report, null, 2) + '\n');
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exit(1); });
