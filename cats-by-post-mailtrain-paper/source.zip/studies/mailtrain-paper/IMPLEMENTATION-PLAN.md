# Valley Mail Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task in the existing worktree. Steps use checkbox syntax for tracking.

**Goal:** Deliver a playable papercraft Mail Train study covering all 15 existing
deliveries and their chapter presentations, using the approved Valley Mail
direction without changing gameplay, timing, canonical content or player saves.

**Architecture:** Retain the canonical game executable as the study's gameplay
and chapter host. Add a room-owned full-colour presentation and a narrowly
scoped study adapter that reads its real board sources, traces and chapter
clock. Generate only a separate study HTML; propose the final host integration
contract to the integration owner rather than editing shared code.

**Tech stack:** Existing plain JavaScript and Canvas2D, canonical rules and
BOARDANIM, generated paper albedo/decal assets, registered accepted character
artwork as read-only inputs, Python standard library/Pillow for study packaging,
Node tests and installed Chromium/Playwright for verification. No new application
framework, remote assets, fonts or runtime dependencies.

**Spec:** [Approved direction and constraints](IMPLEMENTATION-SPEC.md),
 [refinement and measurements](refinement/NOTES.md),
 `docs/rooms/parallel-fidelity-work.md`,
 `docs/rooms/03-mail-train.md`, and the current chapter/craft handovers.

## Global constraints

- Base main: `923b40d7c3ef2b9e4fab49d290267f0094a1a9bb`. Planning starts from
  refinement checkpoint `bb1b3695ae25c000cb9a3d4dca96622a4ae0efc0` on the owned
  `codex/mailtrain-paper-fidelity` worktree at `/workspace/cosysortie-mailtrain`.
- Own source/assets only in `src/fidelity/mailtrain-paper/`, studies and plans
  in `studies/mailtrain-paper/`, tests in `tests/mailtrain-paper-*.test.js`, and
  review evidence in `docs/review-images/mailtrain-paper/`. The location of this
  plan follows that ownership boundary rather than the generic skills directory.
- Deliveries `5-1`–`5-15`; sizes 8×3, 9×3, 10×3, 10×4. Preserve the exact records,
  answers, inventories, time limits, points and release order.
- Preserve the 300 ms game beat, original action deadlines, 12-second four-cat
  teaching loop, 72-frame entry and existing station clock phases. Do not replace
  the game with a newly written simulation or retime animation actions.
- Never write `sorting_office.html`, canonical rules/data/art/hash baselines,
  existing Office source/assets, other room source/assets, native, shared
  renderer/manager/build/bridge/interface, `AGENTS.md` or `PLAN.md`.
- No merge, push or publication. A future preview prefix needs coordination and
  explicit publication authorisation; no Office prefix may be reused.
- The finished study must use real textured geometry and registered art. The
  disposable block model is evidence only, not the production implementation.
- One projection per view governs architecture, pieces, feet, shadows, depth
  and picking. The live board never moves with carriage/environment motion.
- Deterministic rendering; no `Math.random`, new arrays/objects, texture rebuilds
  or pixel readbacks in the steady drawing path. Allocate/bake on prepare/input.
- Study storage is isolated before its first read/write. Canonical progress
  serialization remains unchanged; production keys are never accessed.

## Review focus

1. Changing or restoring a delivery while artwork is loading must not publish
   an obsolete scene, wrong board size or stale pointer transform. Task 1/3.
2. At 10×4, the tall rear coach, full character silhouettes, queue tickets and
   foreground details must not obscure live squares, including mirrored poses.
   Task 2/3/4.
3. Phone zoom/pan, landscape HUD placement, resize and entry/result transitions
   must keep drawing and picking registered and avoid tap-after-pan mistakes.
   Task 1/3/5.
4. Scenery-off/reduced-motion, hidden tabs and pause/resume must leave rule and
   chapter clocks correct and hold supported complete ambient poses. Task 4/5.
5. Replay, failed attempts, hints, reloads and chapter visits must preserve
   production storage and avoid duplicate rewards or changed placements. Task 1/3/5.

---

## Files and responsibilities

| Path | Responsibility |
|---|---|
| `src/fidelity/mailtrain-paper/geometry.js` | Projection, inverse/picking, supported room layout and train connections |
| `src/fidelity/mailtrain-paper/materials.js` | Decoded stock/decal assets, face mapping, lighting and prepared material caches |
| `src/fidelity/mailtrain-paper/architecture.js` | Complete carriage, engine, rear vehicles, furniture, props and static depth/occlusion |
| `src/fidelity/mailtrain-paper/pieces.js` | Registered cats/carriers/baskets/dogs, hatches, points, arrows and queues |
| `src/fidelity/mailtrain-paper/life.js` | Seekable scenery, wheels, supported postal work and secondary movement |
| `src/fidelity/mailtrain-paper/chapter.js` | Visual interpretation of existing chapter modes/frames, no chapter rules |
| `src/fidelity/mailtrain-paper/renderer.js` | Prepared layers, draw ordering, camera, resource census and disposal |
| `src/fidelity/mailtrain-paper/assets/` | Room-owned generated/imported assets, crop/anchor metadata, source hashes and prompts |
| `studies/mailtrain-paper/store.js` | Private study storage adapter using the original serializer |
| `studies/mailtrain-paper/host.js` | Study-only connection to canonical state and input; no new rules or campaign logic |
| `studies/mailtrain-paper/build-study.py` | Fail-closed, reproducible standalone study packaging from protected inputs |
| `studies/mailtrain-paper/playable.html` | Generated playable review deliverable; canonical export remains untouched |
| `studies/mailtrain-paper/check-playable.cjs` | Actual-browser gameplay, picking, chapter, storage and viewport checks |
| `studies/mailtrain-paper/capture-playable.cjs` | Review captures/clips with a build and capture-state manifest |
| `studies/mailtrain-paper/INTEGRATION.md` | Proposed presentation contract, lifecycle and required shared-owner work |
| `studies/mailtrain-paper/PROGRESS.md` | Per-task status, evidence, decisions and any plan deviations |

### Presentation interface

`MailtrainPaper.create({canvas, assets})` returns a renderer with:

- `prepare(frame)` — prepare assets/layout when level, scene, camera or lighting
  endpoints change; obsolete asynchronous preparation must be discarded.
- `draw(frame)` — read a reusable frame record, draw with no steady allocations.
- `pick(clientX, clientY, out)` — mutate `{valid:boolean,x:number,y:number}`.
  An invalid result is exactly `{valid:false,x:-1,y:-1}`. Use the same camera
  and projection as drawing and retain canonical edge-snap rules.
- `setView(mode)`, `zoomAt(x,y,factor)`, `panBy(dx,dy)` — study camera operations;
  no board data changes. Preserve canonical tap classification and edge handling.
- `resources()` and `dispose()` — explicit surfaces/images/typed-buffer census
  and release. Resource collection is a diagnostic action, not a frame operation.

The study host fills one reusable record with `level`, `boardSource`, `traces`,
`time`, `chapterMode`, `chapterFrame`, `stationStage`, `worldFrame`, `motion`,
`grayscale`, `viewport` and `insets`. It reads original canonical state. Renderer
poses are private outputs, never mutations of canonical traces or rule state.
`time` is seconds; `chapterFrame`/`worldFrame` are original integer 60 Hz frames.
`viewport={width,height,dpr}` and `insets={top,right,bottom,left}` use CSS pixels.
For the teaching scene, `level`, traces and time refer to the real chapter demo;
otherwise they refer to the live delivery. No second gameplay clock is introduced.

## Task 1: Canonical playable host, privacy and geometric contract

**Files:** Create `geometry.js`, `store.js`, `host.js`, `build-study.py`,
 `INTEGRATION.md`, `PROGRESS.md`; create
 `tests/mailtrain-paper-host.test.js` and
 `tests/mailtrain-paper-geometry.test.js`.

**Consumes:** The protected canonical HTML, level records, existing board-source
and trace APIs, chosen room layout. **Produces:** A separate playable study host
with a tested frame reader/storage boundary and reversible presentation hooks.

- [ ] Write failing tests for storage isolation before the first read, denied
  storage, stale asynchronous prepare rejection, canonical-input hashes, all
  board-size transforms, inverse picking and unchanged level records.
- [ ] Run the two new test files and retain their failing output.
- [ ] Implement the study-only host and geometry. Its builder verifies pinned
  inputs and replaces only the exact `LOCAL_STORE` binding in its own generated
  copy, routing keys beneath `catsByPost.mailtrainPaper.study.v1:`. Do not patch
  `Storage.prototype`, alter serialization or read real player progress.
- [ ] Keep `gSend`, `gTickRules`, `gUpdate`, `gFinish`, `cpUpdate`, TRAINCHAPTER and
  BOARDANIM unchanged. Read live board sources through the existing game API.
  Any presentation hook is Train-only, saved/restored, and lives in the study
  output. The existing renderer remains the fallback for other rooms.
- [ ] Prove the host is genuinely playable using retained presentation initially:
  empty default arrangements, original placement/rotation/removal, Hint, Clear,
  Send/Stop and real outcomes. All15 deliveries are directly accessible through
  a clearly study-only picker without inventing wins or unlocking production.
- [ ] Seed production storage sentinels; launch/reload the study and verify only
  the private namespace is accessed. Test malformed and unavailable storage.
- [ ] Run focused tests, record evidence and commit the task locally.

**Gate:** An actual canonical game under the study, not the disposable model
with a new rules implementation. Source/export/hash baselines remain exact.

## Task 2: Finished visual pilot on the first and maximum boards

**Files:** Create `materials.js`, `architecture.js`, `renderer.js`, asset
manifest/prompt files and `tests/mailtrain-paper-layout.test.js`; extend
`check-playable.cjs` for real rendered contact/occlusion checks.

**Consumes:** Task 1 frame/geometry interface and the selected
`refinement/refined-target.webp` under the review directory.
**Produces:** High-fidelity geometry/materials for the complete connected train
and one actual playable cat/points/basket contact pilot at5-1 and 5-15.

- [ ] Write failing layout tests for the dispatch-bay clearance, rail/wheel
  contact, coupling endpoints, complete front/rear identity and supported
  furniture. Include withheld-attachment comparisons on the real renderer.
- [ ] Generate/collate assets described in the spec. Import accepted sprites
  read-only with provenance; generate room-specific paper stocks and printed
  details. Inspect assets before packing. No whole-scene painting replaces the
  board, architecture, props or working actors.
- [ ] Build complete faceted/folded objects: engine, connected main coach and
  rear van, bogies/rails, roof and walls, red/blue sorting banks, seat, tea urn,
  mug, parcel desk, trolley and hanging bags. Finish side/top/back faces as well
  as fronts, with coherent thickness, face shading and contact shadows.
- [ ] Prepare camera-bounded static surfaces and piece bakes; avoid allocating a
  giant full-world canvas at every frame or rebaking during an ordinary run.
- [ ] Render the first and largest actual boards at desktop, 390×844 and 720×400.
  Check cabinet bases, all wheel contacts, cat/carrier/basket registration,
  whole-board visibility, grayscale hierarchy and near-van clearance visually.
- [ ] Compare against the chosen target at matching views. Fix material,
  construction or projection failures before multiplying artwork. Keep working
  through the remaining tasks under current authorisation; this is an internal
  quality gate rather than another request to proceed.
- [ ] Run focused layout/browser checks, record before/after evidence and commit.

**Gate:** The pilot must look like the approved paper direction. Block figures,
flat colour placeholders, perspective-mismatched painted props and front-only
finishing do not satisfy this task.

## Task 3: Complete gameplay presentation for all 15 deliveries

**Files:** Create/complete `pieces.js`, extend `host.js`, `renderer.js`,
`check-playable.cjs`; create `tests/mailtrain-paper-pieces.test.js`.

**Consumes:** Canonical traces/board sources plus Task 2 assets and projection.
**Produces:** All four live board sizes with original interactions, queues,
mechanisms and fully supported arrival/folding/settlement presentation.

- [ ] Write failing tests for real points state/reset/re-entry and ordered
  same-tick arrivals; queue release order; locked hints; stopped/failed replay;
  terminal arrival deadlines; and inverse pointer registration after zoom/pan.
- [ ] Adapt accepted registered cat/box/arrival techniques inside room-owned
  source. Keep event deadlines, head/body turns, bounces, take-off, folding and
  settlement attached to the unchanged BOARDANIM traces. Smooth only permitted
  presentation interpolation, as the approved Office does.
- [ ] Complete two-arrow points discs for all 12ordered direction pairs and
  required switch poses. Preserve the active-arrow size/colour distinction.
  Render hatch preview/queue ordering, baskets, dogs and all turntable types.
- [ ] Reserve each board size and preallocate drawing/pose records. Verify full
  mirrored silhouettes and queue tickets clear all live cells and routes.
- [ ] Win every5-1..5-15 in actual Chromium using the original stored solution.
  Compare result/trace/release/gate histories with canonical reference runs.
  Exercise5-5 dog rebound,5-9 same-tick ordering and5-15 two-end queues explicitly.
- [ ] Test meaningful pointer placement, rotation/removal, Hint/Clear, failure,
  Stop/retry, keyboard input, saved study progress and reload. Merely filling
  solutions through a debug API is insufficient interaction evidence.
- [ ] Check all 460cell centres across the campaign at each target viewport/DPR;
  check boundaries and zoomed/panned cells, portrait/landscape changes and
  blocked taps during a drag/pinch/modal. Record inaccessible offscreen cells
  as zoomed-view scope rather than claiming they are all simultaneously visible.
- [ ] Run focused tests/browser checks, record evidence and commit.

**Gate:** All15 real deliveries work. Production saves remain byte-identical and
study reloads never charge duplicate attempts or fabricate production rewards.

## Task 4: Moving railway world and grounded postal life

**Files:** Create/complete `life.js`; extend materials, architecture and renderer;
create `tests/mailtrain-paper-life.test.js` and browser motion probes.

**Consumes:** Existing ambient/chapter timing, supported layout and draw/depth
contract. **Produces:** A believable journey and working post office, with
independent scenery motion and no displacement of the playable board.

- [ ] Write failing seek/wrap, wheel/ground-direction, board-stability, reduced
  motion, supported grip/release and route-clearance tests.
- [ ] Extend the proven movement model with finished assets: continuous
  viaduct/rail/sleeper sections, riverbanks, village/hills, poles and restrained
  smoke. The whole train stays connected; the bridge is not an isolated moving
  island. Keep fast features outside the playable silhouette.
- [ ] Use precomputed geometry and distance-based wheel rotation/rods. Use an
  independent deterministic scenery clock; scenery-off must not pause cats.
- [ ] Implement the sorter's mail/sort, tea and watch actions, plus the seated
  Postmistress's supported watching/blinking. Register whole bodies and soles;
  hands grip actual letters/mugs/satchel. Place routes behind/beside the board,
  never across it. Restrain lamp and bag sway to their real attachment points.
- [ ] Finish dusk/night and lamp treatment without pulsing board colours,
  obscuring arrows or changing gameplay coat identities. Check grayscale.
- [ ] Exercise normal/reduced/scenery-off motion, pause, tab hiding, reverse
  diagnostic seeks and wrap. Confirm stable supported poses and unchanged
  gameplay time. Record surface/buffer reuse and camera-cache behaviour.
- [ ] Run focused checks, capture motion evidence and commit.

**Gate:** The journey reads as a real train and postal work reads as physical
work. No floating feet, unsupported props, slipping grips or board-crossing poles.

## Task 5: Existing chapter presentations in the finished scene

**Files:** Create/complete `chapter.js`; extend study host and renderer; create
`tests/mailtrain-paper-chapter.test.js` and chapter browser scenarios.

**Consumes:** Unchanged CP modes/frame, TRAINCHAPTER.demo/station outputs and
original story text. **Produces:** Full Train welcome/demo/entry, station stops,
growth presentation and settled-board departure in the new scene.

- [ ] Write failing tests that story/demo replay preserves live placements,
  inventory, attempts and rewards; entry ends at frame72; station preparation
  never changes live coordinates; resize/input/focus remain safe.
- [ ] Render the actual four-cat 12-second teaching trace and its real R/L points
  alternation. Use prepared camera endpoints for the wide-to-board entry and
  actual HUD/card insets. Do not replace the teaching simulation with a movie.
- [ ] Cover the stops before 5-4, 5-8 and 5-12. Stage 2 must add an enclosed mail
  coach before the last brake van, retaining its identity as the last vehicle.
  Use the prepared station cut to establish a stabled coach/van section, then
  show the locomotive backing its sorting coach onto it. Drive that relative
  gap from the unchanged station approach output. This is a visual staging
  choice, not new chapter logic. It avoids an unpowered coach moving by itself.
  Check frames 0/44/45/164/165/173/181/189/212/213, including all four joint poses.
  Sorting/input stays blocked during the shunt; both complete train ends remain
  explained. Never show two rear vans or detached live sorting in motion.
- [ ] Show original 3-to-4-row growth inside the same clear sorting floor. No
  threshold, wall, joint, coupling or visual bump crosses a live board.
- [ ] Preserve the 4-15→5-1 handover using untouched Depot presentation as a
  fallback reference. Preserve the 5-15 finished board, let cats settle, then show
  the satchel depart beside the real desk/bay. No rule tick or reward repeats.
- [ ] Keep original chapter primary actions and story text. If review proceeds
  into another room, restore its existing canonical presentation rather than
  modifying it or pretending the new Train renderer supports that room.
- [ ] Verify focus/Tab/Escape, blocked live-board taps, resize, replay and reduced
  motion at chapter boundaries; run focused checks and commit.

**Gate:** All existing Train chapter states are real, replayable and timing-safe.
Final production journey/bridge integration remains the integration owner's work.

## Task 6: Fidelity review, regression proof and handover

**Files:** Complete `check-playable.cjs`, `capture-playable.cjs`, evidence manifest,
`INTEGRATION.md`, `HANDOFF.md`, `PROGRESS.md`, and a room-owned `design-qa.md`.

**Consumes:** Tasks 1–5finished study and unchanged production baseline.
**Produces:** Reproducible playable HTML, honest evidence/limits and a compact
presentation contract that the integration owner can review.

- [ ] Run the room tests and actual-browser campaign/chapter/input/privacy
  suite. Run the complete repository `npm test` once with required sparse
  fixtures present, plus appropriate canonical level checks. Do not edit pinned
  values to pass. Repeat broad checks only when changes/failures justify it.
- [ ] Compare source and final tree hashes for all protected paths, all 100level
  records, game/chapter rules, original assets and native. Rebuild only the
  room-owned study and prove reproducibility; do not rebuild shared outputs.
- [ ] Capture actual first/max/day/dusk/night/grayscale, desktop/phone/landscape,
  points/queues/dog/arrival and chapter states. Include short movement/coupling/
  dispatch clips with exact build, level, clock, viewport and capture method.
  Keep concept images clearly separate from implemented screenshots.
- [ ] Perform visual QA against the selected art at matching views. Check full
  object faces, support/occlusion, coherent projection, warm materials, scale,
  board clarity and working life. Fix material gaps before calling it finished.
- [ ] Have the whole change reviewed read-only, including the five Review Focus
  areas. Fix blocking issues with reproducing regressions and reverify. Clearly
  distinguish independent review from author review in the final evidence.
- [ ] Record browser-only vs physical-device evidence, retained resources and
  measured timings without claiming iPhone/Safari/Metal qualification. Detect
  resource growth across repeated level/scene/resize cycles.
- [ ] Deliver the standalone study alongside its source, provenance and gallery.
  Record any required shared renderer/camera/bridge change as a small calling
  contract with evidence in `INTEGRATION.md`; do not make that shared change.
- [ ] Commit the final review checkpoint locally and return it for review.
  Do not push, merge, deploy, overwrite a preview prefix or begin native work.

## Completion and execution boundary

This plan is the current requested deliverable. No new implementation or asset
generation starts as part of the planning turn. After plan review, execute the
tasks in order in this worktree, keeping one ledger and focused evidence per
stage. Do not reuse the throwaway block model as a substitute for finished art.

The plan deliberately keeps final production integration and physical-device
qualification separate. A successful standalone study is not a merged game,
a native port or a public release.
