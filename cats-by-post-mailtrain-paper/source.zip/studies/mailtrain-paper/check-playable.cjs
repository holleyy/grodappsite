const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.__storageAccess=[];const g=Storage.prototype.getItem,s=Storage.prototype.setItem;Storage.prototype.getItem=function(k){window.__storageAccess.push(['get',k]);return g.call(this,k);};Storage.prototype.setItem=function(k,v){window.__storageAccess.push(['set',k]);return s.call(this,k,v);};});
 await page.goto('http://127.0.0.1:8801/studies/mailtrain-paper/playable.html');await page.waitForFunction(()=>window.MailtrainStudy);
 const report=await page.evaluate(()=>{
 const s=MailtrainStudy,rows=[];for(let n=1;n<=15;n++){s.select('5-'+n);rows.push({id:s.state.L.id,w:s.state.L.board.w,h:s.state.L.board.h,empty:s.state.chutes.length===0});}
 s.select('5-1');return {rows,storage:window.__storageAccess};});
 assert.equal(report.rows.length,15);assert(report.rows.every(r=>r.empty));assert(report.storage.every(v=>v[1].startsWith('catsByPost.mailtrainPaper.study.v1:')));
 await page.evaluate(()=>{gTap(7,1);});assert.equal(await page.evaluate(()=>gm.chutes[0].dir),'U');
 await page.evaluate(()=>{gTap(7,1);gTap(7,1);});assert.equal(await page.evaluate(()=>gm.chutes[0].dir),'D');
 await page.click('#btnSend');await page.waitForFunction(()=>gm.mode==='won',{},{timeout:20000});
 report.win=await page.evaluate(()=>({id:gm.L.id,mode:gm.mode,attempts:gm.attempts,ticks:gm.sim.tick}));
 await page.reload();await page.waitForFunction(()=>window.MailtrainStudy);report.reload=await page.evaluate(()=>({id:gm.L.id,progress:!!progress.levels['5-1']}));
 assert(report.reload.progress);assert.deepEqual(errors,[]);report.errors=errors;
 fs.mkdirSync('work/mailtrain-paper/implementation',{recursive:true});fs.writeFileSync('work/mailtrain-paper/implementation/browser.json',JSON.stringify(report,null,2));
 await page.screenshot({path:'work/mailtrain-paper/implementation/host.png'});console.log(JSON.stringify(report));await browser.close();
})().catch(e=>{console.error(e);process.exit(1);});
