"""Prepare only this study's already-authorised grodappsite prefix; never push."""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, zipfile

parser = argparse.ArgumentParser()
parser.add_argument('site', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
study = root / 'studies/mailtrain-paper'
dst = args.site.resolve() / 'cats-by-post-mailtrain-paper'
owner = json.loads((dst / 'ownership.json').read_text())
assert owner['owner'] == 'Mail Train fidelity chat'
assert owner['prefix'] == 'cats-by-post-mailtrain-paper/'
build = json.loads((study / 'build.json').read_text())
payload = (study / 'playable.html').read_bytes()
assert hashlib.sha256(payload).hexdigest() == build['sha256']
manifest = json.loads((dst / 'build.json').read_text())
manifest.update(build)
manifest.update(sourceCommit=subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip(),
                review='review/', sourceArchive='source.zip',
                siteBase=subprocess.check_output(['git', '-C', str(args.site), 'rev-parse', 'origin/main'], text=True).strip())
(dst / 'index.html').write_bytes(payload)
(dst / 'build.json').write_text(json.dumps(manifest, indent=2) + '\n')
(dst / 'README.md').write_text("""# Valley Mail — Mail Train playable study

[Play the study](https://holleyy.github.io/grodappsite/cats-by-post-mailtrain-paper/)
· [Latest review](review/) · [Room source and integration handover](source.zip).

All15 existing deliveries, their four board sizes and chapter presentations.
The latest visual sweep includes89 desktop/portrait/landscape views, rigid card
folding, foreground furniture depth, a complete courier departure and the full
tea routine. Previous arrival and atmosphere galleries remain linked.

Use Delivery to select any board, Journey view for the complete train, and
Review → Fill original solution for a demonstration. Maximum board: `?level=5-15`.
The exact packaged HTML passes40 room regressions, all15 canonical wins and
1,380 cell picks, plus phone-size touch/save/HUD checks. It retains original
rules, levels, timing and save serialization in a private study namespace.

`build.json` records the byte-identical HTML hash and source/archive provenance.
Publication to this owned prefix is explicitly authorised by the user.
Other site prefixes and source-main integration remain untouched. See ownership.json.
Physical iPhone/Safari and sustained performance are not qualified. The initial
HTML is approximately21MB before HTTP compression, including embedded original
engine and artwork. Review clips are sampled frames, not FPS benchmarks.
""")
review = dst / 'review'
assets = review / 'assets'
assets.mkdir(parents=True, exist_ok=True)
html = (study / 'atmosphere-review.html').read_text().replace('../../docs/review-images/mailtrain-paper/atmosphere/', 'assets/').replace('href="playable.html', 'href="../')
html = html.replace('</nav>', '<a href="../source.zip">Room source and handover</a></nav>')
(review / 'atmosphere.html').write_text(html)
arrival = (study / 'arrival-review.html').read_text().replace('../../docs/review-images/mailtrain-paper/arrival-clearance/', 'arrival/').replace('href="playable.html', 'href="../').replace('href="atmosphere-review.html"', 'href="atmosphere.html"')
arrival = arrival.replace('</nav>', '<a href="../source.zip">Room source and handover</a></nav>')
(review / 'arrival.html').write_text(arrival)
polish = (study / 'polish-review.html').read_text().replace('../../docs/review-images/mailtrain-paper/polish/', 'polish/').replace('href="playable.html', 'href="../').replace('href="arrival-review.html"', 'href="arrival.html"').replace('href="atmosphere-review.html"', 'href="atmosphere.html"')
polish = polish.replace('</nav>', '<a href="../source.zip">Room source and handover</a></nav>')
(review / 'index.html').write_text(polish)
shutil.copytree(root / 'docs/review-images/mailtrain-paper/polish', review / 'polish', dirs_exist_ok=True)
arrival_assets = review / 'arrival'
arrival_assets.mkdir(exist_ok=True)
for path in (root / 'docs/review-images/mailtrain-paper/arrival-clearance').iterdir():
    if path.suffix in ('.jpg', '.png', '.webm', '.json'):
        shutil.copyfile(path, arrival_assets / path.name)
for name in ['join-after.jpg', 'join-before.jpg', 'first-after.jpg', 'maximum-after.jpg',
             'phone-maximum.jpg', 'landscape-maximum.jpg', 'postal-routine.webm',
             'verification.json', 'phone-checks.json', 'captures.json', 'clip.json']:
    shutil.copyfile(root / 'docs/review-images/mailtrain-paper/atmosphere' / name, assets / name)

files = list((root / 'src/fidelity/mailtrain-paper').rglob('*'))
files += list((root / 'tests').glob('mailtrain-paper-*.test.js'))
files += [p for p in study.iterdir() if p.suffix in ('.md', '.js', '.py', '.css', '.cjs', '.json')]
files += [study / 'atmosphere-review.html', study / 'arrival-review.html', study / 'polish-review.html']
with zipfile.ZipFile(dst / 'source.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    readme = ('Mail Train room-owned source overlay. Apply to a checkout of holleyy/cosysortie\n'
              'at base ' + build['base'] + '. Canonical files are intentionally not bundled.\n'
              'Build: python3 studies/mailtrain-paper/build-study.py\n'
              'Verify: node --test tests/mailtrain-paper-*.test.js\n'
              'The playable HTML and review evidence are published alongside this archive.\n'
              'Integration proposal: studies/mailtrain-paper/INTEGRATION.md\n'
              'Current phase: studies/mailtrain-paper/POLISH.md\n')
    info = zipfile.ZipInfo('SOURCE-README.txt', (2026, 11, 15, 0, 0, 0))
    archive.writestr(info, readme)
    for p in sorted(set(files)):
        if p.is_file():
            info = zipfile.ZipInfo(str(p.relative_to(root)), (2026, 11, 15, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, p.read_bytes())
    assert archive.testzip() is None
manifest['sourceArchiveSha256'] = hashlib.sha256((dst / 'source.zip').read_bytes()).hexdigest()
(dst / 'build.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'prefix': str(dst), 'sha256': build['sha256'], 'sourceArchiveBytes': (dst / 'source.zip').stat().st_size}))
