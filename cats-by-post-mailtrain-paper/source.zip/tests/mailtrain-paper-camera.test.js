'use strict';
const test=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const G=require('../src/fidelity/mailtrain-paper/geometry'),level=require('../src/data/levels.json').levels.find(l=>l.id==='5-1');
function harness(){
 const transforms=[],ctx=new Proxy({transform(...v){transforms.push(v);}},{get(t,k){return t[k]||(()=>{});}}),canvas=()=>({width:0,height:0,getContext(){return ctx;}});
 class Painter{constructor(c){this.c=c;}plane(){}text(){}}class Pieces{draw(){}constructor(){this.poses=[];}}
 const scope=vm.createContext({document:{createElement:canvas},MailtrainGeometry:G,MailtrainBridge:{prepare(){}},MailtrainMaterials:{Painter},MailtrainPieces:Pieces,MailtrainArchitecture:{formation(){return {};},draw(){},dispatch(){},trolley(){}},MailtrainLife:{background(){},world(){},foreground(){},people(){},light(){},details(){}}});
 vm.runInContext(fs.readFileSync(require.resolve('../src/fidelity/mailtrain-paper/renderer'),'utf8'),scope);
 const r=scope.MailtrainPaper.create({canvas:canvas(),assets:{},BOARDANIM:{}}),f={level,chapterMode:'',chapterPose:{entry:1},viewport:{width:390,height:844,dpr:3},insets:{top:64,bottom:150,right:0,left:0}};
 r.prepare(f);return{r,f,transforms};
}
test('pinch translation and zoom agree whether a render happened between pointer actions',()=>{
 const x=harness(),y=harness();for(const h of [x,y])h.r.panBy(40,20);y.r.prepare(y.f);
 for(const h of [x,y]){h.r.zoomAt(200,300,1.25);h.r.prepare(h.f);}a.deepEqual(x.r.camera,y.r.camera);
});
test('chapter entry endpoint exactly matches live camera after custom zoom, pan and view',()=>{
 for(const mode of ['board','journey']){const{r,f,transforms}=harness();r.setView(mode);r.prepare(f);r.panBy(40,-20);r.zoomAt(200,300,1.5625);r.prepare(f);const live={...r.camera};
 f.chapterMode='enter';r.prepare(f);const from={...r.camera};r.draw(f);const[s,,,sy,tx,ty]=transforms.at(-1);
 for(const[d,e]of [[from.scale*s,live.scale],[from.x*s+tx,live.x],[from.y*sy+ty,live.y]])a(Math.abs(d-e)<1e-8,mode+' endpoint '+d+' != '+e);
 }
});
