'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const p='../studies/mailtrain-paper/store.js';
const Store=fs.existsSync(require('node:path').join(__dirname,p))?require(p):{};
test('study store never reads or overwrites the production key',()=>{
 assert.equal(typeof Store.create,'function');
 const m=new Map([['progress','real save']]);
 const s=Store.create(()=>({getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v)}));
 assert.equal(s.get('progress'),null);s.set('progress','study save');
 assert.equal(s.get('progress'),'study save');assert.equal(m.get('progress'),'real save');
 assert.equal(m.size,2);
});
test('denied storage remains playable without leaking to another store',()=>{
 assert.equal(typeof Store.create,'function');const s=Store.create(()=>{throw Error('denied');});
 assert.equal(s.get('progress'),null);assert.doesNotThrow(()=>s.set('progress','{}'));
});
test('malformed serialisation reaches canonical parser unchanged',()=>{
 assert.equal(typeof Store.create,'function');const s=Store.create(()=>({getItem:()=>'{bad',setItem(){}}));assert.equal(s.get('progress'),'{bad');
});
