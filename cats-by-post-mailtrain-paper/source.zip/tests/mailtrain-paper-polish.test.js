'use strict';
const test=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),BA=require('../src/sim/12_boardanim'),Act=require('../src/fidelity/mailtrain-paper/acting'),R=require('../src/sim/10_rules'),Life=require('../src/fidelity/mailtrain-paper/life');
function pieces(p){const scope=vm.createContext({MailtrainActing:Act});vm.runInContext(fs.readFileSync(require.resolve('../src/fidelity/mailtrain-paper/pieces'),'utf8'),scope);return new scope.MailtrainPieces(p,BA);}
test('folding carton panels retain their card length as they rotate flat',()=>{
 const faces=[],p={c:{save(){},restore(){},globalAlpha:1},shadow(){},quad(...v){faces.push(v);},plane(){},line(){}};const piece=pieces(p);
 for(const fold of [0,.1,1,2,3,4]){faces.length=0;piece.carrier(0,0,0,false,fold);for(const v of faces.slice(0,2))a(Math.abs(Math.hypot(v[6]-v[3],v[7]-v[4],v[8]-v[5])-.34)<1e-8,'card wall shrinks at fold '+fold);}
});
test('empty carrier folding is continuous across canonical frame boundaries',()=>{
 const p={},piece=pieces(p),L=require('../src/data/levels.json').levels.find(l=>l.id==='5-1'),tr=BA.runRules(R,L,L.solution,'ginger',.3,.3,BA.makeTrace(256));let value;
 piece.carrier=(x,y,z,front,fold)=>{if(!front)value=fold;};piece.loose=piece.boxed=()=>{};
 const source={n:1,traces:[tr],times:[0],hatches:[],queues:[],baskets:[],gates:[],turntables:[],dogs:[],cursor:-1};
 function sample(age){source.times[0]=tr.rel+tr.n*tr.tick+age;piece.draw({level:{board:{}},boardSource:source});return value;}
 for(const t of [.45,.55,.65,.75])a(Math.abs(sample(t+1e-5)-sample(t-1e-5))<.001,'fold jumps at '+t);
 a(Math.abs(sample(.45))<1e-6);a.equal(sample(.75),4);
});
test('departure keeps the carried satchel and reaches the enclosed coach along a clear floor route',()=>{
 let pose;const p={shadow(){},sprite(sheet,name,x,y,z,height,mirror){pose={name,x,y,z,mirror};}};let last;
 const obstacles=[{x:1,y:.8,w:10,d:4},{x:12.2,y:.4,w:2.65,d:1.25},{x:12.5,y:2.25,w:1.45,d:.86}];
 for(let frame=0;frame<=300;frame++){Life.people(p,{worldFrame:300,chapterMode:'exit',chapterFrame:frame});a(pose.name.startsWith('walk-'),'satchel replaced by another prop at '+frame);a.equal(pose.z,3.1);
  for(const o of obstacles)a(pose.x+.22<=o.x||pose.x-.22>=o.x+o.w||pose.y+.22<=o.y||pose.y-.22>=o.y+o.d,'courier walks into furniture/board at '+frame);
  if(pose.x>12.2&&pose.x<14.85)a(pose.y>3.33,'courier passes behind the foreground desk/trolley');
  if(last)a(Math.hypot(pose.x-last.x,pose.y-last.y)<.09,'courier position jumps');last=pose;
 }
 a(pose.x>17&&Math.abs(pose.y-2.2)<1e-8,'courier stops before the enclosed coach');
});
test('tea break is beside the tea table with continuous travel and unchanged phase boundaries',()=>{
 const pose={},previous={};for(let frame=899;frame<=2401;frame++){Life.sample(frame,true,pose);a(pose.workerY===.35);a(pose.workerX>=1.8&&pose.workerX<=6.5);if(frame>899)a(Math.abs(pose.workerX-previous.workerX)<.02);Object.assign(previous,pose);}
 for(const frame of [1320,1500,1739,1740,1979]){Life.sample(frame,true,pose);a.equal(pose.workerX,1.8);a(['tea-rest','tea-sip','watch'].includes(pose.workerPose));}
});
test('couplings support every joined passage and never span an open shunting gap',()=>{
 const A=require('../src/fidelity/mailtrain-paper/architecture'),boxes=[],p={box(...v){boxes.push(v);},line(){}},form=A.formation(true);
 for(const offset of [-6,-1,0]){boxes.length=0;Life.couplings(p,{chapterMode:'station',stationStage:2,chapterPose:{headOffset:offset,joint:3}},form);const decks=boxes.filter(v=>v[2]===3.07);a.equal(decks.length,offset<0?2:3);
  const engine=decks.find(v=>v[0]<1);a(Math.abs(engine[0]-(form.joints[0].a+offset))<1e-8);for(const v of decks){a(Math.abs(v[3]-.35)<1e-8);a.equal(v[1],1.65);a.equal(v[4],1.1);a(Math.abs(v[2]+v[5]-3.1)<1e-8);}if(offset<0)a(!decks.some(v=>v[0]===16));
 }
});
