'use strict';
const {test}=require('node:test'),a=require('node:assert/strict');
const A=require('../src/fidelity/mailtrain-paper/architecture');
test('carriage end closes the seat-side opening but retains the aligned cab doorway',()=>{
 a.equal(typeof A.bulkhead,'function');
 const solids=[];A.bulkhead({box(x,y,z,w,d,h){solids.push({x,y,z,w,d,h});},quad(){},line(){}});
 const filled=(y,z)=>solids.some(b=>b.x<=.04&&b.x+b.w>=.04&&y>b.y&&y<b.y+b.d&&z>b.z&&z<b.z+b.h);
 for(const y of [-1,-.5,0,.7,3.6,4.5,5.2])for(const z of [3.3,4.4,5.7,6.4])a(filled(y,z),`exposed end wall at ${y},${z}`);
 for(const y of [1.2,2.2,3.15])for(const z of [3.4,4.4,5.5])a(!filled(y,z),`cab passage blocked at ${y},${z}`);
 a(filled(2.2,6.2),'door has a structural header');
});
