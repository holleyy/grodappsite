'use strict';const{test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const file=path.join(__dirname,'../src/fidelity/mailtrain-paper/engine.js'),E=fs.existsSync(file)?require(file):{};
test('locomotive has a longitudinal boiler, transverse front beam and a separate rear cab',()=>{a.equal(typeof E.build,'function');const m=E.build();a(m.bounds.b-m.bounds.a>m.bounds.width*1.8);a(m.boiler.end<m.cab.start+.2);a(m.boiler.length>m.boiler.radius*3);a(m.beam.x<m.boiler.start);a(m.beam.width>3);a(m.beam.depth<.3);a(m.chimney.x>m.boiler.start&&m.chimney.x<m.boiler.end);a(m.cab.opening>1);});
test('opaque locomotive faces are sorted on the common camera depth and the far smokebox cap is culled',()=>{a.equal(typeof E.build,'function');const m=E.build();a(m.faces.length>200);for(let i=1;i<m.faces.length;i++)a(m.faces[i].depth>=m.faces[i-1].depth);a(!m.faces.some(f=>f.tag==='smokebox-front'));a(m.faces.some(f=>f.tag==='boiler'));a(m.faces.some(f=>f.tag==='cab-rear-post'));});
test('near geometry wins per pixel even when a large floor face has a nearer centroid',()=>{
 a.equal(typeof E.raster,'function');const floor={v:[[0,0,0],[5,0,0],[5,5,0],[0,5,0]],mat:'#0000ff',shade:0},raised={v:[[1,1,.5],[2,1,.5],[2,2,.5],[1,2,.5]],mat:'#ff0000',shade:0};
 const assets={stockPixels:{},worker:{sprites:{watch:{rect:[0,0,1,1],anchor:[.5,1]}},image:{width:1}},workerPixels:new Uint8ClampedArray(4)};
 const r=E.raster({faces:[raised,floor]},40,assets),x=Math.round(-r.left),y=Math.round(40-r.top),k=(y*r.width+x)*4;a.deepEqual(Array.from(r.pixels.slice(k,k+4)),[255,0,0,255]);
 const reversed=E.raster({faces:[floor,raised]},40,assets);a.deepEqual(r.pixels,reversed.pixels);
});
