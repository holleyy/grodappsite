'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const p=path.join(__dirname,'../src/fidelity/mailtrain-paper/geometry.js'),G=fs.existsSync(p)?require(p):{};
const levels=require('../src/data/levels.json').levels.filter(l=>/^5-/.test(l.id));
test('equal projected floor axes and height share the same inverse',()=>{
 assert.equal(typeof G.createCamera,'function');const c=G.createCamera();c.scale=40;c.x=200;c.y=100;
 const p={};G.project(c,2,1,3,p);assert.deepEqual(p,{x:240,y:40});
 G.inverse(c,240,40,3,p);assert.equal(p.x,2);assert.equal(p.y,1);
});
test('all 460 canonical cell centres pick their cells at three viewport sizes',()=>{
 assert.equal(typeof G.fit,'function');let n=0;
 for(const l of levels)for(const [w,h] of [[1440,1000],[390,844],[720,400]]){
 const c=G.createCamera(),p={},hit={};G.fit(c,l,w,h,{top:64,bottom:150,left:0,right:0},'board');
 for(let y=0;y<l.board.h;y++)for(let x=0;x<l.board.w;x++){
 G.cell(c,l,x+.5,y+.5,p);G.pick(c,l,p.x,p.y,hit);assert.deepEqual(hit,{valid:true,x,y});n++;
 }
 }assert.equal(n,1380);
});
test('one-tile edge snapping and out-of-range rejection preserve canonical input',()=>{
 assert.equal(typeof G.pick,'function');const l=levels[0],c=G.createCamera(),p={},h={};
 G.cell(c,l,-.5,1.5,p);G.pick(c,l,p.x,p.y,h);assert.deepEqual(h,{valid:true,x:0,y:1});
 G.cell(c,l,-1.1,1.5,p);G.pick(c,l,p.x,p.y,h);assert.deepEqual(h,{valid:false,x:-1,y:-1});
});
