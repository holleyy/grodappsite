'use strict';
const test=require('node:test'),a=require('node:assert/strict'),Life=require('../src/fidelity/mailtrain-paper/life');
// Artwork inspection: the original walking pair shows the back of the coat;
// the new pair shows its buttons/face. Mirroring cannot change front to back.
function check(sample,start,end){const from={},to={},pose={};let count=0;for(let frame=start;frame<end;frame+=.5){sample(frame,from);sample(frame+.001,to);if(!from.workerPose.startsWith('walk-'))continue;const dx=to.workerX-from.workerX,dy=to.workerY-from.workerY;if(Math.hypot(dx,dy)<1e-8)continue;const sx=dx-dy,sy=(dx+dy)*.5;let actual;Life.people({shadow(){},sprite(sheet,name,x,y,z,height,mirror){actual={sheet,name,mirror};}},sample===ambient?{worldFrame:frame,chapterMode:''}:{worldFrame:300,chapterMode:'exit',chapterFrame:frame});a.equal(actual.sheet,sy>0?'worker-front':'worker','wrong front/back view at '+frame);a.equal(actual.mirror,sx<0,'looks against screen travel at '+frame);count++;}return count;}
function ambient(t,o){return Life.sample(t,true,o);}
test('outward and return tea walks face along both projected floor axes',()=>{a(check(ambient,900,1320)>800);a(check(ambient,1980,2400)>800);});
test('departure selects the correct front/back and mirror at every turn',()=>{a(check(Life.departure,24,204)>350);});
