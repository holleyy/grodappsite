'use strict';
const test=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),Life=require('../src/fidelity/mailtrain-paper/life');
const bridge='../src/fidelity/mailtrain-paper/bridge.js';
if(fs.existsSync(require('node:path').join(__dirname,bridge)))global.MailtrainBridge=require(bridge);
function faces(frame){
 const out=[],noop=()=>{},p={c:{beginPath:noop,closePath:noop,fill:noop,save:noop,restore:noop,clip:noop,stroke:noop,globalAlpha:1},cam:{scale:1},patterns:{},v:noop,line:noop,disk:noop,box:noop,
  quad(...v){out.push({v:[v.slice(0,3),v.slice(3,6),v.slice(6,9),v.slice(9,12)],mat:v[12]});},
  plane(x,y,z,w,d,mat){this.quad(x,y,z,x+w,y,z,x+w,y+d,z,x,y+d,z,mat);},
  solid(){},preparedSolid(model,x=0,y=0,z=0){for(const f of model.faces)if(f.v)out.push({...f,v:f.v.map(v=>[v[0]+x,v[1]+y,v[2]+z])});}};
 if(global.MailtrainBridge)global.MailtrainBridge.prepare(p);
 Life.world(p,{worldFrame:frame,chapterMode:'',motion:false},{joints:[],vehicles:[]});return out;
}
test('viaduct openings have a vaulted underside spanning the full track width',()=>{
 const arch=faces(0).filter(f=>f.mat==='stone');
 a(arch.some(f=>Math.max(...f.v.map(v=>v[1]))-Math.min(...f.v.map(v=>v[1]))>4&&Math.max(...f.v.map(v=>v[2]))<-.4&&Math.max(...f.v.map(v=>v[2]))-Math.min(...f.v.map(v=>v[2]))>.02),'the arch has no recessed curved underside');
});
test('arch facing stones have real projected thickness and piers have deeper footings',()=>{
 const arch=faces(0).filter(f=>f.mat==='stone');
 a(arch.some(f=>Math.min(...f.v.map(v=>v[1]))>=4.79&&Math.max(...f.v.map(v=>v[1]))>4.9&&Math.max(...f.v.map(v=>v[1]))-Math.min(...f.v.map(v=>v[1]))>.09&&Math.max(...f.v.map(v=>v[2]))<-.3),'arch ring is still painted on the wall plane');
 a(arch.some(f=>Math.min(...f.v.map(v=>v[2]))< -6.5),'piers stop above their supporting footings');
});
test('bridge sections join at twelve units while keeping original travel speed',()=>{
 a.deepEqual(faces(0),faces(360));
 const base=faces(0).filter(f=>f.mat==='stone'),moved=faces(30).filter(f=>f.mat==='stone');a.equal(moved.length,base.length);
 for(let i=0;i<base.length;i++)for(let k=0;k<4;k++){a(Math.abs(moved[i].v[k][0]-base[i].v[k][0]-1)<1e-9);a.equal(moved[i].v[k][1],base[i].v[k][1]);a.equal(moved[i].v[k][2],base[i].v[k][2]);}
});
test('facing wedges stay inside their arch bay without extending across the next opening',()=>{
 const model=global.MailtrainBridge.build();
 for(const f of model.faces)for(const v of f.v)a(v[0]>=0&&v[0]<=12,'face escapes its bay: '+v[0]);
});
test('masonry joints stop at the pier footing instead of floating over the river',()=>{
 const model=global.MailtrainBridge.build();
 for(const f of model.faces)for(const v of f.v)a(v[2]>=model.foot,'unsupported '+f.tag+' below footing: '+v[2]);
});
