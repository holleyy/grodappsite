'use strict';
const test=require('node:test'),a=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const BA=require('../src/sim/12_boardanim'),Act=require('../src/fidelity/mailtrain-paper/acting'),R=require('../src/sim/10_rules'),L=require('../src/data/levels.json').levels.find(l=>l.id==='5-1');
function rig(){const scope=vm.createContext({MailtrainActing:Act});vm.runInContext(fs.readFileSync(require.resolve('../src/fidelity/mailtrain-paper/pieces'),'utf8'),scope);const p={cam:{scale:63.33},px:(x,y)=>(x-y)*63.33,py:(x,y,z)=>((x+y)/2-z)*63.33,shadow(){},sprite(){},anchored(){}};return new scope.MailtrainPieces(p,BA);}
function trace(d){const tr=BA.runRules(R,L,L.solution,2,.3,.3,BA.makeTrace(256));tr.d0[tr.n-1]=d;tr.homeDX=tr.homeDY=0;tr.end=BA.END_HOME;return tr;}
test('a nearer carrier and supported cat cover the basket rim; a farther carrier is behind it',()=>{
 const piece=rig(),events=[];piece.basket=(b,front)=>events.push(front?'basket-rim':'basket');piece.carrier=(x,y,z,front)=>{if(front)events.push('carrier');};piece.loose=()=>events.push('cat');
 for(let d=0;d<4;d++){
  events.length=0;const tr=trace(d),j=tr.n-1,time=tr.rel+tr.n*tr.tick+.25;
  piece.draw({level:{board:{}},boardSource:{n:1,traces:[tr],times:[time],hatches:[],queues:[],baskets:[{x:tr.x1[j],y:tr.y1[j],coat:2}],gates:[],turntables:[],dogs:[],cursor:-1},time});
  if(d>=2){a(events.indexOf('basket-rim')<events.indexOf('carrier'),'near carrier must cover basket rim, direction '+d);a(events.indexOf('basket-rim')<events.indexOf('cat'));}
  else a(events.indexOf('carrier')<events.indexOf('basket'),'far carrier must be behind basket, direction '+d);
 }
});
test('flight lands exactly on canonical home and wrong-basket roots, including queued home offsets',()=>{
 const piece=rig(),out=piece.acting.makeOut();
 for(let d=0;d<4;d++)for(const end of [BA.END_HOME,BA.END_WRONG])for(const offset of [0,2,-3]){
  const tr=trace(d);tr.end=end;tr.homeDX=offset;tr.homeDY=-offset;
  const now=tr.rel+tr.n*tr.tick+.6;piece.acting.sample(tr,now,out);const f=piece.flight(out,tr,now);
  a(Math.abs(f.x-(piece.x+(out.x-tr.ox)/16))<1e-8);a(Math.abs(f.y-(piece.y+(out.y-tr.oy)/16))<1e-8);a(Math.abs(f.z-(out.z/16-.12))<1e-8);
 }
});
test('sorting and flight reuse fixed records across reverse seeks and retain every campaign object',()=>{
 const piece=rig(),refs=[piece.order,piece.depth,piece.kind,piece.item,piece.flightPose],levels=require('../src/data/levels.json').levels.filter(l=>/^5-/.test(l.id));
 for(const l of levels)a(32*2+l.baskets.length*2+l.dogs.length<=piece.order.length);
 const tr=trace(2),out=piece.acting.makeOut();for(const age of [.5,.25,.59,.4,.25]){const now=tr.rel+tr.n*tr.tick+age;piece.acting.sample(tr,now,out);a.equal(piece.flight(out,tr,now),refs[4]);}
 // Exercise the real display-list path at maximum trace capacity, including
 // its return from a later frame and a subsequent drop to one visible trace.
 piece.basket=piece.carrier=piece.loose=piece.boxed=()=>{};
 const traces=Array.from({length:32},(_,i)=>trace(i%4)),before=structuredClone(traces),times=new Float64Array(32),poses=piece.poses.slice();
 const s={n:32,traces,times,hatches:[],queues:[],baskets:Array.from({length:8},(_,i)=>({x:i,y:1,coat:1})),dogs:Array.from({length:8},(_,i)=>({x:i,y:3})),gates:[],turntables:[],cursor:-1};
 const frame={level:{board:{}},boardSource:s,time:0,worldFrame:300,motion:true};
 function seek(age){for(let i=0;i<32;i++)times[i]=traces[i].rel+traces[i].n*traces[i].tick+age;piece.draw(frame);return Array.from(piece.order.slice(0,piece.count),k=>[piece.kind[k],piece.item[k],piece.depth[k]]);}
 const first=seek(.25);a.equal(piece.count,88);a.equal(first.filter(r=>r[0]===2).length,32);seek(.55);a.deepEqual(seek(.25),first);a.deepEqual(traces,before);
 s.n=1;piece.poses[31].effects.bumpAge=.1;piece.poses[31].effects.bumpX=3;seek(.25);a.equal(piece.count,26);a.equal(piece.poses[31].effects.bumpAge,-1);a.equal(piece.poses[31].effects.bumpX,-1);a(piece.poses.every((p,i)=>p===poses[i]));
 a.deepEqual([piece.order,piece.depth,piece.kind,piece.item,piece.flightPose].map((r,i)=>r===refs[i]),[true,true,true,true,true]);
});
test('flight clears both rims and meets the supported and landing soles on the original .4–.6 second clock',()=>{
 const piece=rig();a.equal(typeof piece.flight,'function');const out=Act.create(BA).makeOut(),DX=[1,0,-1,0],DY=[0,1,0,-1];
 for(let d=0;d<4;d++)for(const coat of [1,2]){
  const tr=trace(d);tr.coat=coat;const t0=tr.rel+tr.n*tr.tick,j=tr.n-1,hx=piece.x+tr.x1[j]+.5,hy=piece.y+tr.y1[j]+.5,bx=hx-DX[d]*.875,by=hy-DY[d]*.875;
  for(let i=0;i<=200;i++){
   const age=.4+i*.001;piece.acting.sample(tr,t0+age,out);const f=piece.flight(out,tr,t0+age),distance=Math.hypot(f.x-bx,f.y-by);
   if(i===0){a(Math.abs(f.x-bx)<1e-8&&Math.abs(f.y-by)<1e-8);a(Math.abs(f.z-2/63.33)<1e-8);}
   // Entire lower sprite envelope, including the changing sole anchor, clears
   // a .34-high carton plus its outward flap and the receiving basket rim.
   const name=(coat===1?'ginger':'blue')+'-push-'+(f.rear?'rear':'front'),rect=require('../src/fidelity/mailtrain-paper/assets/acting.json').sprites[name].rect,below=(1-f.av)*67/63.33*rect[3]/rect[2];
   if(distance>=.26&&distance<=.67)a(f.z-below>.40,'feet cross a rim at direction '+d+' age '+age);
   if(i===200){a(Math.abs(f.x-hx)<1e-8&&Math.abs(f.y-hy)<1e-8);a(Math.abs(f.z-(3/16-.12))<1e-8);}
  }
 }
});
