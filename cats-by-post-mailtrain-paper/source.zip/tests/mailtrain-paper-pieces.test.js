'use strict';
const test=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const R=require('../src/sim/10_rules'),BA=require('../src/sim/12_boardanim'),Act=require('../src/fidelity/mailtrain-paper/acting').create(BA),levels=require('../src/data/levels.json').levels.filter(l=>/^5-/.test(l.id));
const oracle=vm.createContext({BOARDANIM:BA,BA:BA.A,TILE:16,paperEnabled:true,paperTakeoffSources:[true],clamp:(v,a,b)=>Math.max(a,Math.min(b,v)),lerp:(a,b,t)=>a+(b-a)*t,paperBoardFlapPose(){}});
vm.runInContext(fs.readFileSync(require.resolve('../src/render/27a_paper_arrival.js'),'utf8'),oracle);
const keys=Object.keys(BA.makeOut()).concat('takeoff','takeoffSupported').filter(k=>!['x','y','z','bob','boxX','boxY'].includes(k));
test('Train smooth poses retain all canonical action and arrival deadlines without changing traces',()=>{
 const out=Act.makeOut(),base=BA.makeOut(),defaults=BA.makeOut();let count=0;
 for(const L of levels)for(const hatch of L.hatches)for(const coat of new Set(hatch.cats)){
 const tr=BA.runRules(R,{...L,hatches:[hatch]},L.solution,coat,.3,.3,BA.makeTrace(256)),before=structuredClone(tr);
 for(let frame=-1;frame<=(tr.n+1)*18+108;frame++){const t=frame/60;Object.assign(base,defaults);BA.pose(tr,t+1e-9,base);oracle.paperBoardArrivalPose(base,tr,t+1e-9);Act.sample(tr,t,out);for(const k of keys)a.equal(out[k],base[k],L.id+' '+k+' '+t);a(Number.isFinite(out.x)&&Number.isFinite(out.y)&&Number.isFinite(out.z));count++;}a.deepEqual(tr,before);
 }a(count>1000);
});
test('repeated and reverse sampling reuses every private pose record',()=>{const d=require('../src/sim/19h_train_chapter').demo(48,16),o=Act.makeOut(),records=[o.root,o.cat,o.box,o.rim,o.effects,o.base];for(const t of [0,.3,1.1,4.3,8.1,.4,0]){Act.sample(d.traces[0],t,o);a.deepEqual([o.root,o.cat,o.box,o.rim,o.effects,o.base].map((x,i)=>x===records[i]),[true,true,true,true,true,true]);}});
test('arrival soles hold on the carrier until flight, including mirrored rear-facing cats',()=>{
 const G=require('../src/fidelity/mailtrain-paper/geometry'),scope=vm.createContext({MailtrainActing:require('../src/fidelity/mailtrain-paper/acting')});vm.runInContext(fs.readFileSync(require.resolve('../src/fidelity/mailtrain-paper/pieces'),'utf8'),scope);
 const cam={x:0,y:0,scale:63.33},p={cam,px:(x,y)=>(x-y)*cam.scale,py:(x,y,z)=>((x+y)/2-z)*cam.scale,shadow(){},sprite(){},anchored(...v){this.last=v;}},piece=new scope.MailtrainPieces(p,BA),L=levels[0],DX=[1,0,-1,0],DY=[0,1,0,-1];let rims=0;piece.carrier=(x,y,z,front)=>{if(front)rims++;};
 for(const coat of [1,2]){const tr=BA.runRules(R,L,L.solution,coat,.3,.3,BA.makeTrace(256)),o=Act.makeOut(),j=tr.n-1,d=tr.d0[j],x=1+tr.x1[j]+.5-DX[d]*14/16,y=.8+tr.y1[j]+.5-DY[d]*14/16;
  for(const age of [.25,.35,.4]){const now=tr.rel+tr.n*tr.tick+age;Act.sample(tr,now,o);p.last=null;piece.loose(o,tr,now);a(p.last,'takeoff must use a sole anchor');a(Math.abs(p.last[2]-p.px(x,y))<1e-6);a(Math.abs(p.last[3]-(p.py(x,y,3.125)-2))<1e-6);}
  const now=tr.rel+tr.n*tr.tick+.5;Act.sample(tr,now,o);piece.loose(o,tr,now);a(Math.abs(p.last[2]-p.px(x,y))+Math.abs(p.last[3]-(p.py(x,y,3.125)-2))>1,'flight has begun');
 }a(rims>=4,'supported takeoff restores the front rim');
});
