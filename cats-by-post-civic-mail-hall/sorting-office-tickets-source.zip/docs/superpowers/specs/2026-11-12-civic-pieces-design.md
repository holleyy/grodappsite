# Civic Mail Hall: pieces and acting

The user accepted the shared-perspective foundation on12 November2026 and asked to continue. Complete phase2 of the reconstruction roadmap in the isolated study, retaining the accepted floor and camera. Upload permission covers the study/source/screenshots in draft PR38 and successive previews on grodappsite. No canonical game merge is authorised.

## Required result

All15 original Office puzzles have usable, recognisable pieces and supported paper acting. Plain, ginger and blue turntables differ by colour and pattern; heading arrows and hint locks remain legible. Hatch lids open for their releasing cat, with ordered waiting-cat portraits. Dogs sleep and react to real bumps. Round ginger and square blue baskets retain their different silhouettes and show settled cats without a carrier inside. A cat leaves a separate carrier, clears its rim, lands in a basket, turns/curls/naps; the empty carrier folds and disappears. Wrong deliveries retain an open carrier and a puzzled cat. Trace-driven head lead, bounce/stuck reactions and scheduled wake/departure are covered by the renderer.

## Binding constraints

- Keep all15 original Office records, original rules and BOARDANIM source unchanged; production cadence remains300ms.
- Keep the accepted Lantern2:1 projection and inverse picking unchanged. Do not bring back the scenic-overlay camera.
- Preserve the accepted paper arrival clock: stop14 source world units before basket; crouch.2s, push.3s, clearance.4s, fold.45s, landing.6s, flat.75s and gone1.2s after terminal segment. Original turn/curl/nap/wake/leave schedules remain authoritative.
- Preserve ginger and charcoal-tuxedo identities across all new art. The blue game category is communicated by its blue destination/filter; it does not turn the tuxedo into a different cat on arrival.
- Use separate cat/carrier and basket-front layers. Physical contacts must be reviewed in rendered frames, beyond numeric timing checks.
- No new game rules, dependencies, external runtime requests, random simulation or persistence changes. Canonical game/native/Lantern files remain unchanged.
- Architecture remains the accepted schematic in this phase. Full hall, working postal routes and canal motion are phases3–5.

## Artwork and scope

Fresh generated component masters match Lantern's thick paper, cream cut edges and warm shading: cat busts, loose crouch/push/sleep/puzzled poses; empty carriers, fold stages, dog poses and destination baskets. Mirroring provides four approach headings. Travel uses separate torso/bust and carrier, permitting head lead independent of carrier direction. Paper geometry supplies hatches, patterned turntable discs and directional arrows. Native source art is inspected for behaviour and registration but not mixed into the new character identity.

The rig can reuse authored crouch/push/sitting/nap pictures with controlled transforms for transition frames; it must not claim individually authored pictures where they are interpolated. Explicit visual review covers seams, foot/rim support, popping, depth and silhouette at phone scale.

## Qualification

Pure adapter compares against the existing production paper-arrival code as an independent oracle, including boundaries, both coats, all directions, correct/wrong and bounced final approaches. Scene context reducers cover queues, hatches, spin and dog reactions. Browser captures cover each physical transition and both coats, original15 wins,300ms cadence, all four viewport sizes, grayscale and reduced decorative motion. Publish the checked phase2 preview and describe remaining architecture work plainly.
