# Civic Mail Hall: architecture stage

The user accepted the corrected flat board and centred arrows, then authorised the next architecture preview. The chosen Civic Mail Hall and Lantern Quay papercraft references remain authoritative. This implements milestone 3 of the accepted reconstruction, in the existing isolated study.

## Outcome

A complete, supported hall around the playable board: large arched windows, warm stone and terracotta walls, teal columns and braces, an upper sorting gallery, glazed roof bays, a connected staircase, honey-coloured counter, ginger/blue sorting cabinet and a canal loading entrance. The floor and architecture share `CivicProjection`; no painting supplies false structural geometry. The hall has one fixed footprint around the maximum 6×4 Office board so switching deliveries does not move the building.

The normal play camera keeps its accepted board framing. Whole-hall view fits the complete building and canal and gives it the viewport. A `view=hall` link opens this architecture review directly; Board returns to the normal controls. Construction guides become optional and off by default. The selected original painting remains a separate reference view.

## Construction

Root implementation choice: use projected geometric faces for volume, arches, stairs, railings, supports and joinery. Apply flat paper material samples to those faces, and use existing registered cutouts for stationary cats and postal details. Static architecture is baked once per material set, then drawn as a cached layer. This preserves exact perspective and avoids adding per-frame geometry work.

Hall floor spans x=[-3,7.2], y=[-2,5.2], top z=0. Gallery floor is z=180; rear wall reaches z=310 and glazed roof peaks z=365. The gallery and all tall furniture lie at negative x or y, clear of the board's projected silhouette. The western staircase connects gallery to floor. Canal is on the left, surface z=-38. Visible floors, supports and water banks explain their physical connection.

## Approaches

The earlier full-scene painting overlay was rejected because its floor and furniture perspective could not match the board. Repeating it would reproduce the same fault. A wholly geometric untextured room would register correctly but miss the requested paper finish. Projected surfaces with real material texture and separate details combine reliable geometry with the approved craftsmanship; this is the implementation choice for the already approved direction.

## Constraints

- Preserve `HW=380/6`, `HH=190/6`, origin (760,465), board axes, cell arrangement and inverse picking.
- Preserve all 15 Office levels, inventories, rules, 300 ms cadence and character/piece anchors.
- Work only in the isolated Civic study plus its notes and previews; do not change canonical source, native assets, existing room factories or Lantern Quay.
- Keep the self-contained page offline with no remote assets, fonts or dependencies.
- Deterministic scenery; no `Math.random`. Bake static details outside the animation loop.
- The board remains the clearest area at phone sizes and in grayscale.
- This stage establishes architecture and a static canal setting. Grounded work routines, moving water/boats and final physical-device budgets remain subsequent milestones.

## Review

Inspect complete hall, normal board, phone, small phone and short landscape; all three original board sizes; grayscale; support/stair/counter/cabinet contacts; guide toggle and view changes; all stored solutions and existing acting regressions. Confirm initial material loads finish before caching. Publish the verified preview under the already authorised grodappsite path and update draft PR38 and offline/source archives.
