# Sorting Office finish and integration

The user approved the next phase on 12 November: warmer paper and lighting inspired by Lantern Quay, restrained canal life, coherent finishing, device/layout qualification, and integration into the main game. Existing permission covers independent implementation agents, draft PR updates and the grodappsite preview. Do not merge.

## Result

Keep this a cosy working Sorting Office. Preserve the accepted projection, flat board, supported architecture and 52-second postal job. Improve material volume with fine grain, directional face shading, cut edges and contact shadows. Replace broad yellow saturation with warm ivory, muted honey timber, coral brick, deep teal recesses and local amber light. The board remains the clearest element, including in grayscale.

Water remains on z=-38, outside gameplay. Currents and broken reflections follow the banks and visible sources; boat contact and wake follow its actual movement. Motion-off and reduced-motion retain stable complete poses. No runtime dependencies, network, random state or per-frame allocation.

Move the entire gallery bench and throw +0.25 y, retaining support heights and the y>-1 passage. Compact controls must not obscure the working helper.

Integrate through an Office-only presentation adapter against current main. Preserve canonical rules, level records, saves, controls, camera picking and every other room/mode. Map the study projection to the canonical board transform; do not embed a parallel session or stale game source. Unsupported boards/modes use the existing renderer. Qualify all 15 Office layouts. Physical iPhone/Safari testing is explicitly outstanding unless those devices become available.

## Evidence

Baseline: local 257f2ba; 63 focused tests pass; fixed Hall, phone and representative detail captures are under work/civic-finish. Compare the representative finished crop with the actual Lantern Quay asset before broad qualification. Check whole hall, work phases, visible staff corner, grayscale, motion and reduced motion, all Office sizes, real input, and other-room fallback. Review the assembled change once with a fresh reviewer before publication.
