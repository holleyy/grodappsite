# Sorting Office · working postal life

The user approved completing the remaining step4 work, asked that the robot share the floor perspective, requested a slightly cosier Sorting Office identity and asked whether the board fits every level. Existing implementation, delegation and publication permission remains in force. “You’ll figure it out” and “Let’s go” delegate routine design choices; no new approval gate is required.

## Scope and intent

This is the Sorting Office skin/study, not City Hall. Its15 Office records (1-1…1-5,2-1…2-10) match current canonical main: six5×3, two5×4 and seven6×4. Preserve these records, the300ms rule cadence, current projection, all30 occupied cubbies, papercraft cats/pieces and supported architecture. The current100-level campaign reaches10×8 and needs other mechanics/room layouts; do not claim it fits this Office skin or import those levels.

Finish one physically connected, readable postal cycle in the west work aisle. Make the worker’s soles, limbs, palms, wheels, parcels and machines use the same world projection as the board. Add a restrained lived-in finish and Sorting Office branding. Preserve existing canal life; further water/lighting expansion is not this phase.

## Approaches and decisions

Translating the existing fleet sprite would retain its flatter cart perspective and lacks walking frames. Authoring dozens of complete directional pictures would make contact constraints harder to maintain. The implementation choice is a jointed projected paper mechanism, with the existing paper textures, ivory/teal/brass palette and friendly oversized head. It maps directly to the accepted scene geometry and future Swift/Metal meshes. This is an engineering choice under the user’s delegated judgement.

A room-spanning trolley trip through the doorway is not proven: the staircase and threshold obstruct that route. Use the clear west aisle and a counter-height cart, supported lateral dispatch bridge and return rollers. It is a complete receive→process→load→dispatch job, with a controlled reverse pull rather than an unsupported U-turn. The same parcel returns on the bench rollers, making the repeat physically continuous.

## Shared world layout

Projection remains HW=380/6, HH=190/6, origin760,465. Floor remains x[-3,7.2], y[-2,5.2]; largest board is x[0,6], y[0,4]. Every moving work vertex must satisfy x≤-.14 and z≥0; a raised point unprojects farther left, so this also protects the board’s screen silhouette.

- Bench x[-1.75,-.95], y[.35,3.60], top58; same west edge, narrower and lower than the old counter. Its body, fronts and tabletop use these shared dimensions.
- Receiving parcel centre(-1.18,.68,58), on a supported rotating receiving pad of radius.21. Scale parcel centre(-1.18,1.26,64). Parcel .26×.26×14. Stamp head meets its top at78. Receiver and scale must have enough footprint for the package at every orientation.
- Return belt centrex=-1.55, width.32, top58, y3.12→.68. Cross-transfer surfaces at y.68 and3.12 connect x[-1.71,-.95]. Keep the belt lane free of cats and decor.
- Cart .50×.60, centrex=-.53, deck58, handle68 at carty-.41; wheel radius5.5, with all wheel bottoms at0. Loading centrey2.30; dispatch centrey3.25. Parcel rides at carty-.13.
- Retractable bridge x[-.95,-.78], y[2.97,3.27], top58. It folds clear until the cart is locked at dispatch. Its deployed plane meets the bench and cart without a gap. Transfer parcel to the return belt only while deployed; retract before return travel.
- Worker centrex=-.53. Receivingy.70, scaley1.26, cart-loadingy1.65, push-starty1.51, push-endy2.46. Body/feet conservative turning radius.32. Arms may reach west over the bench but must clear its body and deck before crossing the edge.
- Desk cat remains a complete pose, centre(-1.17,2.25,58), width54; its supported footprint clears the return belt. Gallery cat stays at its accepted supported perch.

## Cycle and pose contract

Create one pure, deterministic, seekable52-second cycle with reusable state. The following beats define timing; hand trajectories and foot plants must be continuous at every boundary:

0–2 receive/inspect;2–4 reach and grip;4–5 lift;5–6 turn to carry;6–8 carry to scale;8–9 face workbench;9–11 place on scale;11–12 release;12–14 weigh;14–15 reach stamp control;15–16 press;16–17 release control;17–19 regrip;19–20 lift;20–21 face cart;21–23 carry to loading position;23–25 place on cart;25–26 release and step back;26–27 grip handle;27–31 push to dispatch;31–32 deploy bridge;32–35 side-transfer parcel;35–36 retract bridge;36–40 reverse-pull cart;40–41 release handle;41–42 turn for return;42–47 walk back while parcel travels the return belt;47–49 cross-transfer to receiving;49–51 rotate receiving pad/parcel back to its initial orientation;51–52 settle.

`CivicPostalCycle.createState()` allocates one state containing `robot`, `cart`, `parcel`, `machine` and scalar `phase/time` fields. `sample(time,out)` reuses every nested object/array. Robot has x,y,yaw,lean,bob,headYaw; two feet (x,y,z,yaw,planted); two palm targets (x,y,z,grip). Cart has x,y,yaw,wheelAngle. Parcel has x,y,z(bottom),yaw,owner. Machine has scaleLoad,stampZ,lever,bridge,beltTravel,receivingYaw. Names and exact exported constants live in the layout module and interfaces; later render code consumes them rather than recomputing the story.

Foot step events are precomputed once. A stance sole stays at a fixed world point; swing feet lift and settle with zero endpoint velocity, and one foot always supports the worker. Turns use successive foot placements, not sliding both feet. Palm targets coincide with parcel side grips, cart handle or stamp control while attached. Ownership transfers occur only at exact surface contact; parcel position/yaw are continuous and supported or held at all times. Wheel rotation is signed travelled distance divided by radius, including reverse pull. The repeat returns the same physical parcel and all poses to their initial state without a reset jump.

## Projected paper rig and scene integration

Robot target proportions: standing height≈94 including antenna, soles8, leg joints to hip≈32, torso≈26, neck≈4, head≈22, antenna≈8. Oversized chamfered ivory head, inset teal face with two amber eyes, teal joints, brass hinge discs and small envelope badge. All meshes and their contact shadows project from actual world coordinates; no whole-robot billboard. Arm and leg links use fixed lengths and constrained joint targets. Paper grain comes from existing materials. Reuse geometry/state buffers; no per-frame arrays, objects, canvases or gradients in new paths. Static station shells/details bake once; animated press, rollers, bridge and gauges draw live. Profile before publication; do not claim physical-device frame rate.

Draw bench surfaces before work parcels, return-belt parcel before desk cat, and robot hands/near machine or trolley rails in their correct foreground order. Preserve the existing gallery/cubby occlusion splits. Moving work stays outside the board; puzzle simulation and timing remain independent. Motion off/reduced motion freezes work at its current stable pose while gameplay continues.

## Cosy finish

Use Sorting Office for visible title, heading, gable and Explore label. Civic Mail Hall remains concept/history/internal filenames. Add a warm oak staff bench on the gallery x[2.70,4.10], y[-1.83,-1.28], floor182, seat≈205, back≈234; one muted terracotta folded throw with cream stitching. A small postal bundle may occupy x[.45,1.0], y[-1.78,-1.30], base182, height≤16. Keep gallery passage y>-1.0 open. Counter decor must fit the new bench and avoid belt/scale/dispatch lanes: a small ledger/mug cluster and a task lamp near the cat, with restrained static warmth. No extra floor clutter or large rug competing with the board. Remove/rehome the old counter plant if it obstructs the belt.

## Acceptance

Prove phase-boundary and repeat continuity, fixed stance feet, rigid links, real grips/releases, signed wheel rotation, full parcel support across bridge/rollers and complete worker/cart/body clearance. Validate all15 Office levels at phone, small-phone, landscape and desktop sizes: visible/pickable cells, controls, actual placements and original stored wins. Capture active work states and largest boards, whole office, grayscale and cosy details. Require one fresh independent whole-change review and a material-fix pass before packaging, updating draft PR38 and publishing to the existing Civic test path. Keep canonical/native/Lantern files unchanged; preserve concurrent public-repo updates. Physical iPhone/Safari and Swift/Metal qualification remains open.
