# Civic Mail Hall life phase

The user authorised the next phase and asked that the floating gallery cat and still cubby cats be fixed within it. Existing publication permission applies. The accepted paper architecture, flat board, 30 occupied cubbies and full desk cat remain the visual baseline.

## Outcome and approach

Make the hall feel inhabited while the board remains clear: individually timed breathing and occasional full-body pose changes for all 30 cubby cats, a grounded sleeping gallery cat behind the railing, a quietly attentive desk cat, a small postal worker routine and water/boat motion on the canal. Motion off and reduced-motion must freeze scenery without stopping deliveries.

Implementation choice: deterministic scalar clocks and preallocated actor states, with static architecture split at the actual occlusion boundaries. A single flattened image cannot place moving cats behind rails; repainting every wall per frame wastes work. Three cached layers retain the paper finish while live actors draw between them. Existing full-body cat pictures supply the poses; small anchored scaling supplies breathing, with short transitions for occasional yawns/turns. This is a declared reuse of the authored components, not a newly painted frame for every state.

Layer order: canal water/boat; static walls/floor/stairs/empty cabinet; live cubby cats; shelf lips/lower gallery/deck/counter; live desk and gallery cats; upper gallery supports/roof/rails/details; postal worker and original playable board pieces. The gallery cat's sole plane is the actual deck top z=182 (previously188), with a floor shadow. Its front railing draws afterwards. Cubby and desk feet stay on z=slot base+3 and z=74 respectively throughout breathing.

Canal: low-contrast paper-like reflected strips, an immediately visible parcel boat, a slow continuous route and a loading stop. Boat/hull/wake remain inside visible water, and banks/bridge occlude them. Postal routine: a parked trolley worker in the safe counter-end apron checks and returns a manifest, with feet/wheels and held paper physically anchored. No route through furniture or across the puzzle.

## Constraints

Exact projection remains HW=380/6, HH=190/6, origin760,465. All15 Office records, inventory, picking, simulation and300ms cadence are unchanged. No canonical/native/Lantern changes. Self-contained offline page, no new runtime dependencies or network requests. No random/time reads in scene modules; the existing ambient clock is frozen by Motion off/visibility handling. New draw paths reuse buffers; no per-frame arrays, object creation, gradients or canvas allocation. Static layers remain baked once across camera/level changes and use bounded crops to limit memory.

## Review and limits

Prove contact/occlusion, repeatable samples, staggered movement, frozen ambient pixels, unchanged game clock, board clearance, all-level picking, repeated view changes and no repeated static bakes. Capture short motion evidence plus phone/desktop/grayscale. Measure browser draw costs and layer bytes, without claiming physical iPhone/Metal qualification. Update current preview, draft PR38 and offline/source packages; do not merge.
