# Civic Mail Hall Architecture Implementation Plan

> **For agentic workers:** Use the executing-plans workflow, with independent material/exterior tasks delegated under the user's explicit subagent authorisation. Steps use checkbox syntax for tracking.

**Goal:** Build and publish the complete Civic Mail Hall architectural shell around the accepted board.

**Architecture:** One deterministic projected room, textured with flat material artwork and baked into a cached static layer. Existing rules, pieces and acting draw above the room; optional guides and a whole-hall camera support review.

**Tech Stack:** Existing plain JavaScript/Canvas, Python packaging, Node tests and Chromium capture.

**Spec:** `docs/superpowers/specs/2026-11-12-civic-architecture-design.md`

## Global Constraints

- Exact projection: HW=380/6, HH=190/6, origin (760,465); no board-axis or picking change.
- All 15 original Office records and 300 ms cadence remain unchanged.
- Hall fixed at x=[-3,7.2], y=[-2,5.2], gallery z=180, roof peaks z=365.
- Only the isolated Civic study and accompanying documentation/previews change.
- Offline assets, deterministic geometry, static details cached outside the frame loop.

## Review Focus

- Small phone Board view retains usable cells and primary controls; full-hall view restores them on return.
- Largest 6×4 layout has no scenery across its playable screen polygon.
- Static cache waits for the immutable startup material set; explicit `bake()` replaces it if a future caller changes materials or layout. Camera and level changes reuse it.
- Gallery supports and stair endpoints meet their floor/deck; decorative cargo rests on surfaces.
- Switching all views and level sizes preserves picking, zoom, motion preference and original traces.

### Task 1: Projected hall and materials

**Files:** Create `foundation/architecture.js`, `foundation/architecture.test.js`, `foundation/exterior.js`, `foundation/assets/architecture/*`. Modify `foundation/build.py`, `foundation/renderer.js`.

**Interfaces:** `CivicArchitecture.layout()` returns the fixed room/deck/stair/bounds record; `new CivicArchitecture(renderer).draw()` draws the cached architecture through the renderer context. `CivicExterior(rendererLike).draw()` paints scenery before the interior. Material metadata supplies flat sample rectangles, never floor geometry.

- [x] Capture the accepted baseline and run focused tests / starting canonical suite.
- [x] Write geometry checks for common projection, stair/deck contact, complete bounds and clear board footprint; verify missing implementation fails.
- [x] Build projected textured walls, arches, supported gallery/roof/stairs, counter, cabinet and canal setting.
- [x] Integrate assets and static caching; run focused tests and inspect a complete hall render.

### Task 2: Cameras and playable composition

**Files:** Modify `foundation/projection.js` (optional explore bounds only), `foundation/app.js`, `foundation/shell.html`, `foundation/style.css`. Create `foundation/check-architecture-browser.js`.

**Interfaces:** Camera accepts optional scene bounds only for explore mode. `view('structure')` gives the whole viewport to the hall; `view('play')` restores existing controls and normal board camera.

- [x] Write browser assertions for full-hall bounds, view-return picking/controls, all three board sizes and cache reuse.
- [x] Fit the full scene, make guides optional, update the study copy and add `view=hall` entry.
- [x] Inspect phone, desktop, landscape and grayscale; fix composition/contacts until coherent.
- [x] Rerun alignment, controls/rules and acting checks alongside architecture tests.

### Task 3: Review, package and publish

**Files:** Update README/verification/package script, architecture progress/review notes, selected review images, PLAN portability row, draft PR38 and existing public preview.

- [x] Obtain an independent whole-change review and resolve material findings.
- [x] Produce self-contained playable and source archives; verify a fresh source rebuild.
- [x] Commit scoped changes, update the draft PR and deploy using current branch-head leases.
- [x] Verify Pages deployment and the published HTML bytes; return the live architecture preview.
