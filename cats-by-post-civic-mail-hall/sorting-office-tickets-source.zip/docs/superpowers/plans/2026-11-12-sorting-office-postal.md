# Sorting Office Postal Work Implementation Plan

> **For agentic workers:** Use the preserved autonomous execution method and user-authorised parallel work. Steps use checkbox syntax. Routine choices are delegated; do not add another approval gate.

**Goal:** Complete a connected postal work cycle with correctly projected walking/pushing, a cosier Sorting Office identity and proven fit for all15 Office layouts.

**Architecture:** Shared immutable workstation layout and a pure52-second pose sampler drive a projected paper rig. Static architecture/details bake; dynamic work composes at explicit depth boundaries. Original board/rules remain independent.

**Tech Stack:** Existing JavaScript/Canvas, reusable numeric geometry buffers, Node tests, Chromium capture, Python self-contained packaging.

**Spec:** `docs/superpowers/specs/2026-11-12-sorting-office-postal-design.md`

## Global Constraints

- Projection HW=380/6, HH=190/6, origin760,465; floor x[-3,7.2],y[-2,5.2];15 Office records up to6×4 and300ms cadence unchanged.
- Work geometry x≤-.14,z≥0; shared bench top58, scale64, cart58 and bridge58 prevent invented transfers.
- No new runtime dependencies/network requests or per-frame objects/arrays/canvases/gradients. Preserve all30 occupied cubbies and paper character bodies.
- Sorting Office identity; restrained cosy details; preserve existing canal but do not extend step5.
- Isolated study, draft PR38 and existing public path only. No merge or canonical/native/Lantern changes.

## Review Focus

- Ownership boundaries and loop seam: parcel never pops, duplicates, falls through support or changes position when its owner changes.
- Turning/reversing: at least one planted foot, no stance sliding, fixed link lengths, hands stay on handle and wheels reverse.
- Workstation reach: limbs clear table edges and moving press; bridge only supports transfers when deployed and docked.
- Every Office size on narrow/landscape screens: all cells remain visible/pickable and controls reachable; work never obscures board.
- Layering/freeze: return belt passes behind desk cat, hands/rails overlap correctly, Motion off/reduced motion preserves work without stopping puzzle delivery.

### Task1: Layout and deterministic work cycle

Create `foundation/postal-work-layout.js`, `postal-work-cycle.js`, `postal-work-cycle.test.js`. Interfaces: `CivicPostalLayout` immutable constants/surfaces; `CivicPostalCycle.createState()` and `sample(seconds,out)` follow the spec state contract. The implementer may add named scalar fields, documenting them for the rig; do not change shared dimensions silently.

- [x] Write and observe failing tests for complete beat order, surface/owner contact, grip targets, fixed stance feet, loop/seek determinism, cart distance/wheels, bridge docking and full route envelopes.
- [x] Implement precomputed foot events and reusable state with the specified52-second timing and shared layout.
- [x] Run the complete cycle suite; inspect all phase boundaries and densely sampled support/clearance. Commit the isolated model.

### Task2: Projected robot, cart and working machinery

Create `foundation/postal-work-rig.js`, `postal-work-rig.test.js`; replace current `postal-life.js` façade and its tests as appropriate for the new public runtime. Consume Task1 state and shared dimensions. Produce `new CivicPostal(renderer)`, `bake()`, `drawUnderCats(time)`, `draw(time)`, static `sample/layout` accessors for inspection. Static station drawing is exposed to architecture as `CivicPostal.drawStations(painter)`.

- [x] Write failing projection/contact/rig tests: soles and wheel bottoms on plane, fixed links, actual palm/handle contact, rigid face projection, max-board separation and reusable mesh/state buffers.
- [x] Build chamfered paper head/body, jointed arms/legs, feet, independent cart wheels/rails, connected rollers/scale/stamp/bridge and parcel. Reuse existing paper materials; ensure near/far component order.
- [x] Integrate renderer/build and architecture counter dimensions/depth hooks. Move desk cat with its supporting table. Replace obsolete parked-manifest browser assertions with real work assertions.
- [x] Capture and inspect idle, four walking/working headings, grip/lift/scale/stamp, cart push/pull and dispatch contact. Profile caches/draw cost; run focused suite. Commit.

### Task3: Cosy Sorting Office finish

Create `foundation/office-details.js` (static `drawGallery(p)` and `drawCounter(p,layout)` plus immutable support metadata); modify architecture integration, shell/app copy and scene plaque. Counter additions follow shared workspace reservations, not assumed old dimensions.

- [x] Implement supported bench/throw and compact practical gallery/table details with existing materials, preserving work routes and board clearance.
- [x] Verify support footprints, no collisions with belt/cat or working stations, and relative visual priority in whole office/phone/grayscale captures.
- [x] Rename visible room identity to Sorting Office and record Office scope. Commit.

### Task4: Whole-cycle and all-level qualification, packaging and publication

Create `foundation/check-postal-work-browser.js` and board-fit evidence; update README, verification, portability mapping, progress/review and source packaging. New offline/source names clearly describe the postal Office checkpoint; preserve earlier archives.

- [x] Check all15 Office layouts across phone/small-phone/landscape/desktop, actual picking/actions and stored wins. Capture largest5×4/6×4 layouts while work is active.
- [x] Check real foot/grip/parcel/rail pixels, motion-off/reduced-motion, all phase boundaries, no frame allocations/rebakes and software draw cost. Run one canonical suite if no valid baseline run covers the phase; do not duplicate heavy runs.
- [x] Obtain one fresh whole-change review, address material findings with RED→GREEN checks and record limitations.
- [x] Extract source package, rebuild byte-identical HTML and run its tests. Commit scoped source/proofs/packages.
- [x] Publish to the existing Civic preview with fresh GitHub head leases, preserving other changes; verify Pages and published bytes. Update draft PR38 with truthful scope and remaining device qualification.
