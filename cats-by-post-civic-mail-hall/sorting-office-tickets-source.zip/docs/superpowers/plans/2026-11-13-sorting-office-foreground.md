# Sorting Office foreground restoration

The user rejected the neighbourhood implementation because it lost the approved canal foreground, warm reflections and substantial boat. They authorised implementation through a visual checkpoint: the actual playable scene beside the reference at matching framing, plus a short water-motion preview. The main-game adapter remains separate and unmerged.

Keep the established board projection, room structure, postal work and cardboard carriers. Restore the composition with native projected near scenery and independently rendered water. Do not substitute a generated whole-scene picture for working scenery.

1. Extend the canal through the foreground crop. Add a large moored cabin mailboat, connected ropes, restrained bob and broken reflections from actual nearby light sources. Preserve the small delivery skiff separately.
2. Restore substantial quay furniture, abundant flowering planters, warm lanterns and deep underfloor contact shadows. Preserve all supports at their existing elevations.
3. Reframe the actual scene around the office, boat and quay. Replace the flat green surround with continuous scenery. The user reviewed the first iteration and requested removal of the framing leaves; let the canal and boat carry the foreground. Replace the uniform right-hand lawn with planted soil beds and an open paved path. Keep the blue board clear.
4. Compare actual browser captures with the approved reference. At 4:3, the boat should occupy approximately 17% of image width and be fully visible, the water should exit the crop without a rectangular end, and the bench, flowers and lanterns should read at thumbnail size. Test reflection movement and stable motion-off poses.
5. Bring the same changes into the isolated adapter, check all 15 Office levels and review-save isolation, and publish only the existing review paths. Deliver a comparison page and a short clip captured from the live renderer. Main remains untouched.

Ownership: foreground_water_boat owns canal-life.js; foreground_quay owns exterior.js; root owns backdrop, framing, integration and evidence. A separate read-only composition reviewer checks actual captures against the reference. Functional checks do not substitute for visual review.

Swift/Metal: extended water masks and source-linked reflection paths are immutable vertex buffers; hero hull and fixtures are cached paper meshes; independent ambient clocks drive restrained offsets. Static garden and cropped foreground cottage roof are separate baked textures.
