# Civic pieces and acting implementation plan

> **For agentic workers:** Use superpowers:subagent-driven-development for bounded implementation and independent review.

**Goal:** Replace the foundation's placeholder pieces and whole-carrier arrivals with coherent paper pieces and separate acting.
**Architecture:** A pure CivicActing adapter samples original traces and accepted arrival positions. A Canvas piece painter consumes registered asset metadata and these poses; the existing renderer owns camera and scene ordering.
**Tech Stack:** Plain JavaScript, Canvas2D, Node tests, Python asset packing, Chromium.
**Spec:** ../specs/2026-11-12-civic-pieces-design.md

## Global Constraints
- Keep all15 original Office records, original rules and BOARDANIM source unchanged; production cadence remains300ms.
- Keep the accepted Lantern2:1 projection and inverse picking unchanged. Do not bring back the scenic-overlay camera.
- Preserve the accepted paper arrival clock: stop14 source world units before basket; crouch.2s, push.3s, clearance.4s, fold.45s, landing.6s, flat.75s and gone1.2s after terminal segment. Original turn/curl/nap/wake/leave schedules remain authoritative.
- No new game rules, dependencies, external runtime requests, random simulation or persistence changes. Canonical game/native/Lantern files remain unchanged.

## Review Focus
- Wrong deliveries must retain their carrier while later cats continue.
- Queue membership drops at pop start, not first movement; independent hatches use their own releases.
- Repeated/rewound sampling must clear stale box/support/effect fields.
- Raised cats and front rims must occlude by ground position, not elevated screen y alone.
- Phone framing and input must survive more elaborate piece artwork.

### Task1: authoritative presentation adapter
**Files:** create foundation/acting.js and acting.test.js; modify foundation/session.js and its tests only if adapter injection is required.
**Interfaces:** CivicActing.create(BOARDANIM) returns makeOut(), sample(trace,time,out), hatch(levelHatch,traces,time,out), dog(dog,index,poses,ambientTime,out). makeOut extends BOARDANIM output with takeoff, takeoffSupported and any documented presentation flags. All positions remain source16-unit coordinates. No renderer dependency.
- [x] Write independent-oracle tests loading the actual production paperBoardArrivalPose in a VM with only its documented globals stubbed.
- [x] Implement exact paper adapter on top of BOARDANIM.pose with one effective time epsilon, deterministic reuse, real trace effects and shared hatch/dog reducers. Document reducer output contracts in acting.js.
- [x] Test boundaries, all approaches/coats/correct/wrong, bounce/stuck/headlead, queue ordering/release, dog reaction and stale-field reset.
- [x] Run node --test foundation/acting.test.js and existing session/projection tests; commit only owned files; independent task review.

### Task2: complete piece painter and integration
**Files:** create foundation/pieces.js, assets/acting*.webp and metadata/provenance, tools/pack-acting.py; modify renderer.js, app.js, shell.html, style.css, build.py and check-browser.js. Add read-only art review mode/harness as needed.
**Interfaces:** renderer invokes CivicActing.sample for each recorded trace into reusable pose storage; CivicPieces instance accepts renderer drawing helpers and generated sprite metadata. Painter has floor pieces, empty carrier, boxed cat, loose cat, basket base/front and dog layers. Use ground depth and explicit support/front-rim passes.
- [x] Pack original generated masters into named sprite records without changing character identities; document widths, sole/bottom anchors, mirroring and front masks.
- [x] Implement patterned3type turntable discs/arrows/spin/locks,3state hatch and ordered portrait queues,4state dogs and sleep glyphs.
- [x] Implement separate carrier/bust travel/head lead; crouch/push/flight, basket settlement, wrong puzzled state, independent fold/flat/fade, breath/blink/reactive motion and wake/leave presentation.
- [x] Integrate pause/reduced decorative motion without altering puzzle cadence; replace checkpoint copy with phase2 scope and clear view controls.
- [x] Browser-test real original puzzle outcomes and gesture controls; capture both coats/four approaches, supported push/clearance/fold/nap/wrong/dog/queue states; inspect phone/wide/grayscale.
- [x] Fix material visual issues, run focused regression checks and independent whole-change review. Rebuild reproducible packages, update PR38 and authorised grodappsite preview with version=pieces-02.

## Ledger
Task progress and review evidence: work/civic-phase2/progress.md. Whole-room visual qualification remains open until phases3–6.
