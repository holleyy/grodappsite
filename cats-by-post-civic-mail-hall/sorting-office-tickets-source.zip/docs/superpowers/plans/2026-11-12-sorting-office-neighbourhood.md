# Sorting Office neighbourhood and cardboard carriers

The user approved the fourth composition: a cosy residential canal, close cottages, quieter distant roofs, warm paper sky, a supported quay and approach stair. Implement it in the two existing review previews. Keep the main game and canonical room factory branches unmerged. User also requested an ordinary nicely designed cardboard box consistently throughout the moving cat's animation.

## Constraints

Keep the accepted projection, flat board, cell positions, all 15 Office deliveries and interior architecture/contact anchors. Background changes use the same projection and must not occlude the playable board. House and quay surfaces must support their props. Canal/boat heights must agree with banks and dock. Keep deterministic scenery, stable motion-off poses and pre-baked art; no new live allocations in the main adapter. Full-colour work is confined to the existing isolated presentation factory. No canonical levels, rules, progress or other-room changes. The separate review prefix retains isolated saves.

## Work

1. Replace all shared carrier art paths with ordinary kraft cardboard, retaining occupied/empty/takeoff/folding state continuity. Capture before/after close-ups and all directional transitions; test shared anchors.
2. Build the accepted residential setting: grounded front quay, connected approach, lower water and consistent bank/boat heights, nearby terraces/gardens, warm windows and flowers, distant bridge. Preserve the interior, work cycle and board. Add paper sky/distant roof layers, keep near versus distant contrast and manage cache size independently of camera framing.
3. Integrate the source into the existing main-game adapter, preserving its allocation optimisations. Verify board picking, all deliveries, reduced motion, scene framing/grayscale and review save isolation. Compare normal and Explore on phone and desktop.
4. Independently review the combined code and actual captures, address material issues, rebuild reproducible packages and publish only the already authorised study and separate adapter preview paths. Record exact changes, checks and hashes. No merge.

## Review focus

Physical ground contacts, new lower canal versus dock, outside stair continuity, bank bounds and water clipping, background focus at mobile scale, board picking after Explore, changing box design across takeoff/fold, static-cache reuse and source/preview provenance.
