# Sorting Office finish implementation plan

**Goal:** Complete the approved warm paper, canal and presentation integration phase.
**Architecture:** Existing cached Canvas room layers and preallocated moving meshes; a scoped adapter uses canonical game state without replacing its session.
**Tech:** Plain JS/Canvas, Node tests, Python build/package, Chromium captures.
**Spec:** ../specs/2026-11-12-sorting-office-finish.md

## Constraints and ownership

Root owns architecture.js, exterior.js, generated HTML, docs, packaging and publication. Canal agent owns canal-life.js and its focused tests. Material agent owns postal-work-rig.js, office-details.js and their specific tests. UI agent owns style.css and compact-toolbar verification. Integration agent owns a separate current-main checkout/adapter, never canonical files in this older study worktree. No shared-file concurrent edits. Do not alter board projection, rules, cat positions or work-cycle contacts to obtain shading.

## Tasks

- [x] Capture accepted baseline and run focused tests; audit reference, water and current-main integration contracts.
- [x] Root: soften cached face lighting, neutralise grain tint, add paper edges and local surface light. Inspect fixed representative crop before finishing full room.
- [x] Material agent: cached orientation lighting on existing moving faces; correct height-sensitive contact shadows; move supported bench/throw together. Preserve allocation-free rendering and all cycle contacts.
- [x] Canal agent: attached shore contact, coherent quiet currents, source-linked reflections and speed-responsive wake, with deterministic prebuilt geometry and unchanged route API.
- [x] UI agent: reserve compact Board controls outside the scene; qualify smallest portrait/landscape and Explore without compromising input/camera fit.
- [x] Integration agent: build an Office-only adapter on current main; preserve data, storage, game controls and fallback; run meaningful adapter and chapter-transition/browser tests.
- [x] Assemble: rebuild study, focused tests, all Office layout/input matrix, architecture/life/alignment/postal browser checks, grayscale and fixed before/after crops. Run canonical suite appropriate to actual integration.
- [x] Fresh whole-change reviewer, single material fix pass. Record remaining physical-device qualification honestly.
- [ ] Reproducible source/offline packages, scoped local commits, draft PR update and authorized public preview; verify deployed bytes and Pages success.

## Review focus

Lantern warmth comes from shaded volumes and concentrated light, not a yellow overlay. Preserve layer-cache seams, board clarity, actor/rail occlusion, planted feet and receiving surfaces. Integration must preserve canonical saves and input and must not pull in stale rules, levels or study app/session. Verify fallback and resource lifetime on chapter changes.
