# Civic Mail Hall Life Implementation Plan

> **For agentic workers:** Use executing-plans with the user's authorised independent canal/postal delegation. Steps use checkbox syntax.

**Scope note:** This small life checkpoint is complete; the original working-postal-life step4 remains open. See `docs/rooms/progress/civic-step-4-next.md` for the remaining route, locomotion, handling and machinery work. Some step5 water work was brought forward.

**Goal:** Ground the upstairs cat and make the cats, postal work and canal gently active.

**Architecture:** Seekable reusable actor states draw between three cropped static architecture layers. Canal draws behind the banks; the original ambient clock controls all scenery independently of the puzzle clock.

**Tech Stack:** Existing JavaScript/Canvas, Node tests, Chromium capture and Python offline packaging.

**Spec:** `docs/superpowers/specs/2026-11-12-civic-life-design.md`

## Global Constraints

- Exact projection HW=380/6, HH=190/6, origin760,465; all15 Office records and300ms cadence unchanged.
- Static architecture, no per-frame JS allocation in new life paths; reuse original full-body artwork.
- Ground planes: gallery182, desk74, cubbies slot base+3, canal-38. Motion off freezes scenery only.
- Scope is isolated Civic study, docs, draft PR38 and authorised existing preview path.

## Review Focus

- Gallery cat feet sit on the deck and railing genuinely occludes its body; no painted cat remains behind live one.
- Cats retain bodies/paws in every alternate pose, and movement is visible but staggered.
- Paused motion/hidden tabs preserve the scenery state while deliveries keep the original cadence.
- Boats, reflections and postal worker remain inside their support surfaces and outside the max6x4 board.
- Multiple cached layers remain bounded, load once and preserve all mobile view/picking behaviour.

### Task 1: Interior life and correct depth

Files: create `foundation/room-life.js`, `room-life.test.js`; modify `architecture.js`, `renderer.js`, `build.py`, and `exterior.js` water inclusion.
Interfaces: `new CivicRoomLife(renderer)`, `draw(group,timeSeconds)` for groups0 cubbies and1 desk/gallery; `layout()` and `sample(actor,time,out)` expose immutable contacts and reusable state. Architecture draws base → cubby actors → middle → upper actors → front, with one bake count.

- [x] Capture baseline. Write contact/determinism/stagger/occlusion checks and observe missing behaviour fail.
- [x] Implement grounded reusable room actors; split and crop the static layers, removing baked cats.
- [x] Verify layer order, floor contacts, body retention and focused tests. Commit.

### Task 2: Canal and postal routines

Files: delegated new `canal-life.js`/`.test.js` and `postal-life.js`/`.test.js`; root integrates in renderer/build.
Interfaces: each exports a global/CommonJS class with `new Class(renderer)` and `draw(timeSeconds)`. Root passes one frozen ambient clock. Canal is below architecture; postal worker replaces static crew in the safe counter-end apron.

- [x] Each implementer writes route/contact/continuity/clearance tests first and observes RED.
- [x] Implement water/boat and grounded manifest-checking routine with reusable state.
- [x] Integrate and inspect several timestamps; run combined tests and commit.

### Task 3: Qualification and publication

Files: new `check-life-browser.js`, life progress/review notes and captures; update copy, portability mapping, verification and packaging.

- [x] Browser-check motion on/off, reduced motion, actual changing pixels, support/railing masks, all15 picking/solutions, phone/landscape/grayscale and cache reuse; measure draw/layer cost.
- [x] Obtain one independent full-change review, resolve material findings with regressions, record limits.
- [x] Rebuild offline/source packages; extract and verify identical output. Commit scoped changes.
- [x] Update draft PR38 and current grodappsite preview with fresh head leases; verify Pages and published bytes.
