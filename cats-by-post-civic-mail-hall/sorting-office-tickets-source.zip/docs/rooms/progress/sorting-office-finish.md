# Sorting Office finish ledger

## Authorisation

User approved the proposed finish and integration plan; standing permission covers implementation agents, draft PRs and grodappsite deployment. No renewed permission gate or merge.

During implementation the user explicitly reiterated: prepare the main-game adapter for review, but do not merge it into the main game. Keep its branch and preview separate; do not replace the live main game.

## Baseline and decisions

- Accepted local 257f2ba; baseline HTML SHA256 3bc7ed281c60ae2394c241144fe36de92daddc4afac0859b54d453924021be4e.
- 63 focused tests pass. Baseline Hall/phone/detail captures: work/civic-finish.
- Audits identify flat shading and broad yellow as the fidelity gap; use directional shading and local lamp pools while preserving geometry.
- Bench/throw translate together +0.25 y at unchanged support heights; keep passage y>-1.
- Main integration must target current canonical main f01ce351, not the older study source. Preserve 100 canonical levels and authoritative state/input.
- Linux Chromium is available; physical iPhone and Safari are not. Browser emulation cannot be reported as physical device qualification.

## Status

Study implementation and qualification complete. Separate current-main adapter implementation, tests and independent review are complete. Reproducible packaging and authorised review-only publication are being finalised.


## Implemented study

- Shaded paper faces and moving world-normal stocks, neutral fine grain, cut edges, local gallery/task light, soft floor/sole/wheel shadows. No geometry changes to board, contacts or work cycle.
- Bench and throw moved together +0.25 y at their exact support heights; postal bundle unchanged. Foreground rails still occlude correctly.
- Attached shoreline bands, coherent currents, window-source reflections and speed-linked wake; fixed route/berth and motion modes.
- Compact Board toolbar reserves a real row outside the measured canvas; Explore/Reference preserved.
- Fixed pre-existing window-light spill beyond the floor by clipping illumination to the supported apron.

## Qualification

70 focused tests pass. All 75 Office/device cases pass with 4590 centre round trips and 22950 target probes. The final assembled 18 browser cases pass (life 5, architecture 7, alignment 2, toolbar 4). Changed rig passes 4 additional postal cases; canal passes 3 independent close/motion cases. Proof and machine results: docs/review-images/sorting-office-finish/. Static room remains 31.28MiB with one bake. Physical iPhone/Safari remains unavailable.

Final study HTML: 3c6a873d33b8cacefd32a56c46d3c68b51256eaa61a67ed11b6db5cf85ff8bbc, 6962538 bytes. Fresh whole-change review found no unresolved material findings; see sorting-office-finish-review.md. Adapter qualification and package evidence follow below.


## Separate main-game adapter

Prepared in /workspace/civic-main-integration against exact canonical main f01ce351e3db573427d4149320ef7f8d4ee0d810, through its established room-presentation factory. Final build web-8e8b4e764f5f preserves all 100 canonical levels, app/render/sim/data/native sources, the canonical export and five other room factories byte-for-byte. The adapter does not include the study session, rules or level copy. It restores native presentation on unsupported modes and chapter departure. The user's persisted Gentler motion preference freezes scenery while canonical deliveries continue. Smooth sampling is restricted to active Office paper output.

791 relevant current-main web/interface/camera/session/progress/rules/golden/chapter tests pass. Browser qualification completes 45 Office wins across three viewport types, 894 native cell picks, saved progress round trip, five other-room chapter demos/returns, native night/custom fallback and motion checks. Independent review additionally passes 29 adapter/fidelity/camera tests and reproduces the complete web build. The adapter stays on its own review branch and public preview path, with no main merge or live-main replacement.

## Packages and review

The first clean source-package extraction rebuilt byte-identical HTML and passed all 70 focused tests. The final source package includes the completed independent review; its documentation-only refresh is checked by a second clean byte-identical build. Offline/source archives are named sorting-office-finish.zip and sorting-office-finish-source.zip. Earlier named checkpoints and the original art-master archive remain intact. Publication identifiers are recorded in work/civic-finish/published.json after deployment.
