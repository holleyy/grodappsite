# Civic life progress · 12 November 2026

Plan: `docs/superpowers/plans/2026-11-12-civic-life.md`. Baseline local `028c3f7`, public `946e205bab59ac4a1e6191d86949edd6ea4a5f9d`, PR38 head `8a1b1c9e59f4cb48b3f78547a546369bdd6e7b09`.

The user authorised the next phase while asking for grounded gallery contact and cubby movement. Existing deployment/subagent permission covers the isolated preview and draft PR38. Canonical, native and Lantern files are untouched.

## Implemented

- Removed all baked room cats. Thirty cubby cats plus the desk/gallery cats use full-body authored poses, fixed sole contacts, subtle breathing and staggered turns/wakes. Gallery contact changes from188 to the actual deck182; the front rail now draws over it. Desk contact74 and cubby shelf+3 are preserved.
- Static base plus small cubby/gallery occluder patches retain shelf lips and rail depth. One bake is reused for all cameras and levels. An initial three large layers cost53.56MiB; clipping static portions into the base reduces this to31.28MiB. Browser seam reconstruction and complete alternate-pose envelope checks pass.
- Canal water/reflections and a parcel boat use a seekable168s route with mooring and return;192 heading geometries are preprojected once. The hull stays inside the channel and behind the quay/bridge.
- A parked postal clerk checks a manifest on a14s cycle. Its head/forearm use existing paper components; feet, wheels, trolley and their five contact shadows stay fixed.
- All scenery uses the existing ambient clock. Motion off, reduced motion and hidden-tab suspension preserve it; delivery rules retain the independent300ms cadence. New life draw paths reuse states and create no canvases, gradients or projected points per frame.

## Verification

Room contacts/stagger and canal/postal support/loop tests began RED. All50 focused Node tests now pass. All1084 canonical tests also pass (689.10s); no canonical files changed.

Five life browser cases cover real changing cubby pixels, actual rail occlusion, postal mask integrity, frozen pixels, continuing deliveries, reduced-motion changes, reusable objects, cache bounds, draw cost, pose sequences and canal passage. Seven architecture cases cover whole-hall fit, phone/landscape views and all-level picking. Five controls/rules cases cover1192 cell centres, gestures and all15 stored wins at300ms.

Forced-readback Chromium at1440×1000 compares the accepted static baseline (median19.6ms, p9543.2ms) with life (25.8ms,42.8ms). Before the patch optimisation, life median was40.8ms. These are software-browser draw timings, not a device framerate claim. Physical iPhone/Safari, sustained GPU use and Swift/Metal remain unverified.

Both board regressions also pass (214 seams,8 arrow headings). One independent review found no Critical/Important issue; the Minor capture-timing gap was corrected and the final sequence visually inspected. Final Study04 life-browser cases pass again. Review: `docs/rooms/progress/civic-life-review.md`.

## Packaging and publication

Clean extraction of `civic-life-source.zip` rebuilt byte-identical HTML and passed all50 focused tests. Offline `civic-life-04.zip` includes the self-contained page; the optional art-master ZIP is unchanged. The final HTML is7,247,463bytes, SHA256`69aaf5499268d66190301762c538cb5634eb2d1a588df9185941878ee963bcdd`.

Public deployment commit: `8393daf4aad532324bcd5101c232ed0d642e6efb`, scoped to the existing Civic directory. The preview is https://holleyy.github.io/grodappsite/cats-by-post-civic-mail-hall/?v=life-04&view=hall. Published repository bytes match the local HTML exactly. Pages run: https://github.com/holleyy/grodappsite/actions/runs/43287833206. The final deployment result and draft PR38 head are recorded in the PR handoff. No merge is authorised or performed in this phase.

## Step4 status correction and pillar fix

Study04 covers ambient cats and a parked manifest routine, not the original complete working-postal-life step4. The user reopened that distinction; the remaining sequence is in `civic-step-4-next.md`. Preserve existing water/boat motion, but finish route clearance, walking/pushing, parcel ownership and working receiving/processing surfaces before extending step5.

The floating-pillar report reproduces as column/cabinet volume overlap despite z=0 contact. The lower support row moves from y=-0.81 to-0.31, with bases on exposed floor and contact shadows. Gallery front, upper supports, roof/rail and attached details move coherently to a shared front edge at y=-0.15; deck height182, all cat soles and board projection remain unchanged. A meaningful geometry regression failed on the original overlap before the fix.

The subsequent box-placement report reproduced as parcels painting over foreground posts/rail. Parcels now draw first, with local support shadows; the three-box stack moves to a clear gallery bay. The additional regression checks foreground order, deck footprint, complete upper-box support and post clearance. Both structural regressions failed before their fixes.

Contact correction verification:52 focused Node tests and12 fresh Chromium cases (5 life,7 architecture) pass. Close-up pillar and parcel captures show both corrected contacts. A focused read-only review found no blocker. Public contact-fix commit: `3c6575c47b32c19db716e1a9ebc29fea5ab618b4`; preview https://holleyy.github.io/grodappsite/cats-by-post-civic-mail-hall/?v=contacts-04&view=hall. Final deployment/source-package evidence is recorded in PR38.

The final whole-hall inspection also moved the gallery sleeper along its supported deck to keep its face visible behind the relocated front row. Its sole remains z=182; the small foreground patch follows the new pose envelope. Final life-browser checks include this perch.

Final contact/perch preview commit: 63ca5ccba749a441050fdd02840f6331308ce9cc. The final HTML SHA256 is d8836b8ec2f32dd2a40fb1f81a01e346e903074fbd4de041da11491ba0cb0977 (7,248,094 bytes). All52 focused tests and the final5 life-browser cases pass with this perch; the7 architecture cases passed the same support/roof geometry. Source extraction rebuilds the same page.
