# Sorting Office foreground checkpoint · 13 November 2026

The user requested restoration of the rich foreground shown in the approved concept, with an actual playable-scene comparison and a short motion preview. They subsequently requested no framing leaves and clarified that the turquoise area outside the bottom-right wall was the flat surface needing attention.

## Result

The canal extends through the foreground and around the right-hand wall as real textured water, with prepared current fragments, shoreline contact and broken wall reflections. The large cabin postal boat has a warm window, ordinary parcels, cream fenders and a slack bow mooring. Water reflections render below the quay; the boat body and rope render after the architecture so the landing cannot cut into its roof.

The furnished quay includes a larger bench, flowering planters, warm lanterns and grounded underfloor shadows. The right-hand border now has visible soil and varied planting beside a paved path. Framing leaves are absent. The existing board, room interior, postal routine and cardboard carriers retain their geometry and behaviour.

The comparison page includes the original concept, previous playable scene, the actual current main-game renderer at the same 4:3 capture format, host controls/phone captures and a 14-second motion preview. The preview samples the working renderer at 30 fps for encoding; it is not a real-time device performance benchmark. It shows the boat and then the corrected right-hand water.

## Verification

- 88 focused study tests pass, including actual water/boat projection, bank clearance, fixed rope endpoint, repeatable seeks and right-water coverage.
- 60 successful Office deliveries and1,192 cell picks across desktop,393px phone,320px phone and landscape layouts. Architecture, water and backdrop each bake once across all level/view changes.
- Motion-off holds the complete rendered frame exactly. The right-hand water sample contains174 distinct colours;415 of7,000 sampled pixels change between ambient times5 and12, while repeating the same time changes zero pixels.
- The study's counted architecture/exterior/backdrop/foreground/water/carrier canvas backing is99,360,624bytes (~94.8MiB), excluding decoded source images, live output and process peak. The new canal cache accounts for22,284,652bytes.
- The isolated main-game adapter has separate qualification in `sorting-office-foreground-adapter.md`: all original Office levels, board picking, other-room restoration, prepared-frame allocation checks and review-save isolation.

All browser evidence comes from Linux Chromium with CSS viewport/DPR emulation. Physical iPhone/Safari and sustained device performance remain unverified. Canonical game sources and other room factories are preserved; no main-game merge is authorised or performed.

## Visual judgement

The foreground, boat and furnished quay now carry the composition again. The board, quay and boat share coherent projected axes; pillars stand on clear paving. The flat turquoise area specifically identified by the user now contains the same paper wash and current detail as the foreground canal.

This is a composition checkpoint, not a claim of complete concept fidelity. The concept still has rounder paper forms, richer local lighting and more varied distant scenery. Those are refinement opportunities for review; they are not concealed by functional test results.

Study HTML SHA256: `faaefde01c3e848337154d62815e8062bc98e0457648b6771ad861ac2d14ca1b` (8,045,370bytes).

Evidence: `docs/review-images/sorting-office-foreground/`; working iteration and motion records: `work/civic-foreground/`. Previous neighbourhood archives are retained unchanged.

A final close-up exposed a further flat triangle behind the right-hand cottages. The right reach now continues back to y=-8, with48 additional current groups; the physical shoreline remains attached to the actual bank. The same close-up camera verifies continuous grain and current marks to the crop edge.
