# Sorting Office delivery and furniture corrections · 13 November 2026

The user identified a lamp merging into a planter, a thin-looking cardboard carrier, stuttering delivery movement, and disconnected/floating bench supports. This checkpoint corrects those items in the standalone room and its separate main-game review adapter. Neither canonical game sources nor the main-game branch are replaced.

## Movement and draw cost

The old paper sampler rounded travel to two source world units. At the enlarged Office scale those increments projected to about7.9 native scene pixels, with repeated positions and an early stop on each straight tile. The presentation sampler now interpolates straight travel across the complete300ms beat, continuously through successive straight tiles. Real turn, bounce, hatch and basket action deadlines retain their original timing. Hatch rise, bob and empty-box slide also use continuous coordinates. The canonical simulation, trace buffers, fifteen level records and supported takeoff contacts remain unchanged.

A separate render bottleneck repeatedly resampled large paper scenery layers. Seven visible static layers now retain their high-quality pixels at the current camera scale and copy those pixels one-to-one during subsequent frames. Dynamic water fragments, boat motion, cats and postal work remain live. Camera changes refresh the existing surfaces; explicit scenery rebakes clear obsolete sources. No stationary-frame canvases or gradients are allocated.

In controlled headless Linux Chromium, median study draw time changed from82.9ms to7.0ms at the desktop viewport, and48.1ms to5.6ms at the emulated phone viewport. Recorded frame intervals improved but are not a60fps or physical-device claim. Separate before/after cache rendering of the same full scene differs by a maximum3/255 per colour channel, with mean difference0.0463; no pixel exceeds a summed RGB delta15. The compared1448×1086 view adds20,448,160bytes of raster backing. This memory is counted separately from original material/scene caches and decoded image/process memory.

## Physical details

The right quay lantern moves from x2.35 to2.95. Its reflection source moves with it; the entire lamp base clears the planter rim by.5355 world units. The bench's four feet already ended at quay height, but a far leg incorrectly painted over the closer planter. The bench now faces the canal: its back boards are on the far side of the seat, so front uprights remain visible. Continuous posts connect the ground feet through the seat brackets to low armrests; those armrests join the rear supports below the top back rail. The near planter occludes the far foot correctly. Disconnected decorative curls are removed.

The carrier retains its single direction/fold shell and registered cat contacts. Narrower, slightly drooping flaps now have corrugated cut edges, internal shading, scored folds, contact shadows, deterministic kraft fibres and a layered postal ticket. All40 cached images retain their dimensions and7.5MiB backing. Occupied, empty and collapsing states use the same geometry.

## Verification

-101 focused study tests pass, including continuous motion, exact original supported contacts, real projected planter/bench clearance, cache reuse and explicit cache release.
- The final browser report records all15 Office levels across four viewport layouts, pointer picks, stable motion-off pixels and cache reuse.
- Independent bounded review ran63 focused tests before the final cache-release regression was added, and inspected the four-direction carrier sheet, bench close-up and whole scene. No blocker was found. Its cache-lifecycle maintenance concern is fixed.
- Exact-build adapter qualification and actual canonical/prior/final movement comparison are recorded separately in `sorting-office-refinements-adapter.md`.

Browser evidence uses Linux Chromium and CSS viewport/DPR emulation. Physical iPhone/Safari and sustained device performance remain unverified. The adapter stays on its draft review branch; there is no main-game merge.

Study HTML SHA256: `a5574a4facf1af9997b184cce1637c368887c5b8ac151f4d5a3e4d4c45688730` (8,052,030bytes).
