# Sorting Office neighbourhood

The user approved the refined residential canal composition and requested that the moving cat keep an ordinary cardboard box. This stage updates only the isolated Office study and the existing separate main-game review adapter. No merge or replacement of the live main game is authorised.

## Result

A wider canal, low mooring, residential terrace, garden gate, bicycle, postbox and planted quay place the existing Office in a neighbourhood. Seven exterior treads reach the original floor. All seven original footing footprints stand on the quay at z=-91; water and boat lie at z=-120. A separate rear stair reaches the original doorway landing. Interior stairs, columns, desk work, board coordinates and all 15 deliveries are unchanged.

The sky and distant town use newly generated papercraft artwork. A separate flat facade asset is projected onto the near cottage walls, keeping the real wall corners and roof geometry. World geometry supplies all nearby contacts. The generated composition was a design guide, not a substitute gameplay bitmap. The distant bridge exists behind the west wall and is concealed in the normal fixed view.

The occupied carrier, empty carrier, takeoff rim and folding shell now share one cached kraft-cardboard design: folded panels, open flaps, tape, a modest paper ticket and fine fibres. No futuristic teal trim or lamp remains in the runtime carrier. The ticket follows the wall and is omitted when the wall folds too short to support it.

## Iteration and framing

The first integrated view hid the canal behind the old high quay. The revised low quay, wider water and downriver berth expose it. The broad background initially shrank the Office; independent room framing now keeps the original structure large while scenery continues past the viewport. Near scenery and the interior use separate caches. Detailed cottage fronts and a softer paper town replace the first flat silhouettes.

## Checks

The final focused study suite passes79 tests. Geometry tests cover all seven footings, both stair connections, cottage support, exact facade corners, boat clearance/turning envelope, water containment, deterministic replay and correct stroke-only wheel rendering. Carrier evidence covers four headings, occupied/takeoff registration, all folds, and the existing35-case acting browser suite plus final seven transition captures.

The assembled four-viewport browser qualification covers60 Office wins and1192 cell-centre round trips, original-room framing, cached level/view changes, a nonblank rendered board, grayscale and complete motion-off pose stability. Proof is under docs/review-images/sorting-office-neighbourhood. The fixed scene/sky/carrier caches together occupy73,855,972 bytes (70.43 MiB); this excludes decoded assets, live output, the canonical host and process peak. Runtime caches are reused across levels. Physical iPhone/Safari and native Swift/Metal remain unverified.

The separate main-game adapter keeps its existing pooled geometry and board caches. Its report records actual host verification, all15 Office deliveries, other-room returns, allocation checks and the isolated review-prefix save check. Canonical gameplay/source and the five other room factories remain unchanged.

## Portability

| System | Web | Swift/Metal mapping |
|---|---|---|
| Neighbourhood backdrop and near scenery | Static generated image + projected cached faces; separate scene framing | Textured far quad plus world-space indexed meshes and camera bounds |
| Cardboard carrier | Forty pre-baked direction/fold/full-rim images | Texture array indexed by direction, fold and front pass; existing trace anchors |

Publication identifiers and final package hashes are recorded in work/civic-background/published.json after review-only deployment.
