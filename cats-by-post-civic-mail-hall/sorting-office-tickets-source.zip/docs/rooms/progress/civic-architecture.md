# Civic architecture progress · 12 November 2026

Plan: `docs/superpowers/plans/2026-11-12-civic-architecture.md`.
Baseline: local `5c46f91`, live alignment revision 03, draft PR38 head `e00731ce0d22a8267cd7e67a603f029952ccd122`.

The user explicitly authorised the architecture stage after accepting the floor/arrow correction. Existing upload/deployment permission remains active. Implementation follows the chosen Civic concept in the isolated study.

## Done

Fixed projected hall, arched windows, terracotta/stone walls, teal gallery supports, connected stairs, glazed roof bays, counter, cabinet, clock and signs. Three generated material/decor/front atlases include masters, prompts, crop data and provenance. Exterior scenery adds the static canal, bridge, supported town bank and a continuous quay/landing route to the rear hall door.

The static cache waits for all images. One bake serves all 15 deliveries; explicit `bake()` is the documented invalidation operation for any future material replacement. Normal board projection, camera, picking and rules remain unchanged. Explore fits actual scene bounds, uses the full viewport and returns to play with controls restored. Guides start off; `?view=hall` is the review entry.

Independent review raised a loading-access issue and unsupported town footing; both were reproduced and fixed in one pass with new regressions. A future dynamic-material cache API is unnecessary for the immutable current inputs. See `civic-architecture-review.md`.

## Checked

32 focused Node tests; 7 architecture browser cases; 5 controls/rules cases including all 15 wins and 1,192 cell centres; 2 floor/arrow regressions. All 35 acting cases passed before the final scenery-only fixes. The canonical 1,084-test suite passed this stage. Chromium captures cover desktop, phone, small phone, landscape and grayscale.

Offline and reproducible source archives: `civic-architecture-03.zip` and `civic-architecture-source.zip`. The six PNG source masters are supplied in `civic-architecture-art-masters.zip`, extracted into the same folder for optional atlas repacking. This split fits the upload service's 16 MiB request limit; the source ZIP alone includes every runtime asset and pinned production input needed to build. Old checkpoint archives are retained. A clean extraction reproduced HTML SHA-256 `c002d642b0d6fc683aed6e582b038ba20f59a58b7e18c100ab6600e1623f59c6` and passed all 32 focused tests.

Public deployment: commit `fa51319c98528b29db3febac3822063b35a982d1`, successful Pages run `43257018392`. The published repository HTML matches the tested local page byte for byte. Source and handoff are uploaded in draft PR38 at `310923088f511912ba0463aa68cc955e2e6e669c`, without changing its base or merging it. Public documentation update `cf2e5235624e408b61f6cba1458fa6cc3ef14588` preserves the exact same HTML. The published branch keeps the current remote PLAN.md and inserts only the Civic portability row, preserving newer unrelated project notes. These post-publication ledger updates are later than the reproducible source-package snapshot.

## Handoff

- Done: complete architecture checkpoint, cached material rendering and playable/explore composition.
- Checked: geometry, all 15 original rules/solutions, prior acting and alignment regressions, phone/desktop browser layout. Final publish evidence is in draft PR38.
- Not checked: physical iPhone/Safari, sustained GPU/device budgets or native port. Pages-domain browsing is blocked here; use Actions success and published byte comparison alongside local browser checks.
- Open: postal work routines, water/boat movement, richer ambient life and final device polish. This architecture checkpoint deliberately keeps the canal still.
- Review images: `docs/review-images/civic-architecture/hall.png`, `phone-play.png`, `grayscale.png`.

Publishing targets only the existing Civic path on grodappsite and draft PR38. No merge or canonical game/native/Lantern changes.

## Cat revision 04 · 12 November 2026

User feedback identified a sparse sorting wall and a desk cat that appeared to be only a head. The cabinet now has 30 occupied pigeonholes (15 per coat), using full sitting/crouching/sleeping artwork, and the desk uses a full sitting cat at countertop height with a contact shadow. This reuses existing art and changes only static architecture drawing.

32 focused tests and 7 architecture browser cases pass freshly. Close-up, whole-hall and phone/grayscale review verify bodies, paws, contact and density. No gameplay, projection, floor, arrow, animated character or asset changes. Current page SHA-256 is `81d2c4b08f58fd2f56c082f83186db6edebcf99f26d446dad2afc770a7e72a7f`; it supersedes the initial Study03 hash above. Packages are refreshed; the PNG master archive remains byte-identical. Deployment evidence is recorded in draft PR38.
