# Civic architecture independent review · 12 November 2026

One fresh independent reviewer inspected the full change, rebuilt it, passed all 30 then-current Node tests and checked all 15 levels on a small phone through Explore → Reference → Board. Picking, restored controls, the motion preference and one-time caching passed. The board remained clear in grayscale. Shading is simpler than the concept, a visual refinement rather than a functional finding.

## Findings and one fix pass

- **Important — loading access:** the timber loading deck met the solid west wall while the rear arch opened above water. The quay now continues beside that wall and turns onto a supported rear landing. A stone step reaches the actual door threshold. A route-sampling test failed before the change and passes afterwards, including supports extending below water level.
- **Minor — town grounding:** the houses extended beyond the far-bank geometry. The bank now extends beneath every house, with bases at the same elevation. A new containment/contact test failed before the fix and passes afterwards.
- **Minor — cache invalidation:** automatic material replacement is not implemented. Current assets and layout are immutable after startup; explicit `bake()` is the rebake operation. This contract is now documented in source, README and plan. No current user path replaces those inputs, so a dynamic asset API is deferred until such a feature exists.

The two geometry fixes pass all 32 focused tests. Seven architecture browser cases repeat full-scene bounds, view-return picking and cache reuse across phone, small phone, landscape and desktop. Existing alignment and controls/rules regressions are rerun after the fix. No second review round is required for this documented pass.
