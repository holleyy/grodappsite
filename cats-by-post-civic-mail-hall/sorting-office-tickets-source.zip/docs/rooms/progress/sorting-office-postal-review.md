# Sorting Office postal work — independent review

12 November 2026. Reviewed the assembled change against local baseline `a817714`, the postal design and implementation plan, and the applicable repository rules. This was the single fresh whole-change review. No product files were edited and no commit or deployment was made by the reviewer.

**Verdict: no Critical or Important findings.** The implementation is ready for the planned source-package qualification and publication steps. Those steps were still pending when this review completed; this report does not claim they have passed.

Reviewed HTML: `studies/civic-mail-hall/foundation/index.html`, 6,953,512 bytes, SHA-256 `3bc7ed281c60ae2394c241144fe36de92daddc4afac0859b54d453924021be4e`.

## Independent checks

Ran these commands in the working checkout:

```sh
node --test studies/civic-mail-hall/foundation/*.test.js
python3 studies/civic-mail-hall/foundation/build.py
git diff --name-only a817714 -- src native sorting_office.html
```

All 63 focused tests passed. The independent rebuild produced the exact hash above. The canonical/native path comparison was empty. The fresh canonical log supplied by the integrating agent records 1,084 passing tests; the heavy suite was deliberately not repeated. Independent test output is in `work/civic-postal/independent-focused-tests.log`.

Read the layout, cycle, rig, postal facade and stations, static office details, architecture/depth integration, changed room-life/renderer/shell/build/package files, new and changed tests, browser checkers and README. The build embeds the new modules in dependency order and removes the unused runtime fleet sheet. Source packaging includes the new modules, pinned vendor inputs and current review/specification documents. Actual archive extraction/rebuild remains the integrating agent's next verification step.

An additional independent numerical probe sampled 10,401 robot poses at 200 Hz. The maximum error across both rigid links of all arms and legs was `4.62e-14`; minimum rendered robot height was zero; maximum robot world x was `−0.2257894737`. Robot mesh edges did not enter the interiors of the scale casing, upright or overhead beam. This complements the committed 100 Hz bench/mesh-edge checks and dense hand/shoulder checks, rather than treating declared footprints alone as collision proof.

## Evidence and assessment

- **Connected postal job:** the shared 52-second state drives one parcel through receiving, lifting, scale/stamp, trolley, supported dispatch bridge, return rollers and receiving rotation. Surface heights, ownership boundaries, hand contacts, loop continuity, stationary stance feet, fixed links and signed wheel travel agree between model and rendered geometry. The reach/withdraw paths and torso-relative elbow pole avoid the earlier bench intersection and near-shoulder instability.
- **Rendering and depth:** inspected `work/civic-postal/work-sequence.png`, `hall.png`, `cosy-details.png` and `grayscale.png` from the reviewed build. Feet, wheels, deck, grips and bridge use the floor projection; the job reads coherently across the nine displayed beats. Returning post sits behind the desk cat. The four postal browser cases confirm one visible parcel through the cycle and visibly changing grips; five life cases retain gallery/cubby occlusion, motion-off/reduced-motion freeze and independent delivery progress. Seven architecture and two floor/arrow cases also passed.
- **Office capacity:** the final `work/civic-postal/office-fit-final/report.json` identifies the exact reviewed hash, an unchanged build during capture and successful completion. All 15 original Office records pass on five CSS viewports: 320×568, 393×852, 568×320, 844×390 and 1280×900. The 75 cases include real tray/canvas placement and rotation, Send/Stop/Reset, stored wins and Explore-return, with 4,590 centre round trips and 22,950 visible target probes. Inspected the small-phone, small-landscape and desktop viewport captures and the phone all-level sheet. Every board fits; later campaign rooms and their larger boards are correctly excluded from the claim.
- **Visual priority and identity:** the blue board remains distinct from its surroundings, with clear grid and piece silhouettes in grayscale. Sorting Office appears in the page title, heading, Explore control and gable. The supported gallery bench/throw and compact ledger, mug and lamp add restrained warmth without occupying the postal lanes or board.
- **Runtime cost:** new live paths reuse state, mesh, numeric scratch and ordering buffers; paper stocks and static detail geometry bake once. Code inspection found no new per-frame arrays, objects, canvases or gradients. The browser guards exercise the reused state/mesh and allocation-sensitive APIs. The isolated 1440×1000 software-Chromium forced-readback comparison in `performance-final.log` records baseline median 29.5 ms/p95 71.2 ms and current median 33.5 ms/p95 56.7 ms, over 50 measured frames after ten warmups. These measurements support the stated diagnostic claim only; they do not establish physical-device frame rate.
- **Boundary:** the work remains in the isolated Office study. No canonical game/native changes or Lantern Quay mutation were found. The README accurately describes Office-only capacity and unverified physical iPhone/Safari and Swift/Metal qualification.

## Minor observation

At the fixed 6.4-second pose in the smallest Board views, the existing scene-control strip covers part of the helper's upper head. The board, pieces and dispatch controls remain clear, and Explore shows the complete routine. This is optional scenery/UI polish, not a blocker or a reason to expand this phase.

Evidence logs: `work/civic-postal/{postal-run,life-run,architecture-run,alignment-run,performance-final,canonical-tests}.log`; complete board evidence: `work/civic-postal/office-fit-final/`. Historical verification sections describe their own checkpoints and were not interpreted as current completion claims. Packaging, publication and physical-device checks were not performed by this reviewer.
