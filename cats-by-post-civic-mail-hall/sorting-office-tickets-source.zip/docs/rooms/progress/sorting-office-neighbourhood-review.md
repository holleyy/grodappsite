# Sorting Office neighbourhood independent review

Reviewed 12 November 2026. Review only; no runtime edits, merge or publication.

## Verdict

The combined study source and desktop composition pass the geometry and carrier quality review, with no material runtime finding. The accepted fourth concept is the art-direction reference, not a geometrically identical target: the actual native Office projection, interior and board are deliberately preserved. Phone Explore and desktop grayscale also pass visual inspection. Refreshed phone and small-phone Board captures pass: the complete board, carrier, baskets and controls are clear. Final release archive qualification remains with the integration worker.

## Evidence and constraints

Read the approved neighbourhood plan, scene-review.diff, current exterior/canal/architecture/backdrop/renderer/build/package and carrier source, geometry and carrier reports, and prior carrier review. Visually inspected the approved concept, composition-5.png, desktop-board.png corrected carrier-sheet.png, phone-neighbourhood.png and grayscale.png.

Independently ran `node --test studies/civic-mail-hall/foundation/*.test.js`: 79 passed, zero failed. An isolated copy rebuilt with build.py exactly matches the assembled study: SHA256 `866225945959eb19c94469bfdf29d91ed43dc8aea9c27e7ea62711e3fd5133d3`. The isolated build avoids writing the implementation worker's output. The repository-wide npm test was also started and remains active in unrelated suites; no final pass claim is made. Its log is /tmp/neighbourhood-root-tests.log.

All seven original Office feet have supporting quay at z=-91. The seven entrance treads meet the unchanged floor at z=0; the seven rear treads meet the existing doorway landing at z=-6. Both banks sit above water at z=-120. The translated boat route now berths beside the low loading deck, with full turning-envelope and bridge-clearance tests. The rendered dock contact is plausible, with no floating Office feet or disconnected approach observed.

The live frame bounds [-60,-150,1670,1070] contain the original Office bounds [-26.5,-122.5,1606.67,1016.83]. Far banks extend outside the camera deliberately. Exterior cache bounds and framing are now independent; the exterior is approximately 4.15 million pixels at 1.25x. The illustrated distant town has a separate cached backdrop; nearby cottages are projected geometry with registered facade artwork. Exterior replay preserves open bicycle wheels and explicit frame strokes. No new recurring canvas bake occurs in the reviewed replay paths. Existing board projection, session, acting and vendored rules/levels have no diff.

In desktop Explore the warm sky, cottages and low water read as a residential canal around the existing Office. The room remains dominant and its feet fit. In Board mode the complete board, kraft carrier, baskets and controls are clear. The corrected carrier uses the same full/front cache selection through occupied and supported takeoff states; folds keep the floor root. Its label remains on folds 0–2 and is omitted in folds 3/4, resolving the earlier review's protruding-ticket note. Forty carrier canvases cost about 7.5 MiB, allocated at construction.

## Material findings

None in the reviewed source or desktop evidence. Browser board-picking, all-15 delivery runs, reduced-motion interaction, final mobile captures and adapter allocation qualification belong to the integration evidence and are not inferred from this source review.

Release packaging follow-up: package.py recursively includes the new backdrop module, facade/backdrop WebPs and tests, but its explicit documentation list at review time omitted the neighbourhood plan/progress/review. Add those to the final source archive and prove an extracted rebuild before publishing. Existing archives have not been treated as final evidence.

## Small suggestions

- The distant bridge is hidden in the fixed view. The garden's native rounded foliage and quiet houses are simpler than the concept's dense flowers. More visible bridge silhouette or restrained garden detail would improve fidelity, but should not move the accepted interior or compete with the board.
- Add a focused cached-backdrop bake/replay check and assert the live frame contains the original Office bounds. The existing whole-hall test checks layout().bounds, not the new live frame assignment. Current numeric containment is correct.
- Carrier cache direction pairs share most artwork and could be deduplicated later if device memory warrants it. No device performance claim is made.

## Browser evidence supplement

The integration worker's browser-report.json records 298 board-centre picks and all 15 delivery wins at each of desktop, phone, small-phone and landscape viewports, one architecture/backdrop bake each, stable motion-off poses and no browser errors. These are supplied Chromium-emulation results, not a separate reviewer browser run. Phone Explore keeps the complete original Office and its approach in frame; substantial empty sky is a minor tall-screen composition trade-off. Desktop grayscale retains legible tile edges, cats and baskets. The first phone Board capture was blank: the integration worker traced this to its test-only frozen RAF plus ResizeObserver canvas clear and refreshed it after an explicit repaint. The refreshed phone and small-phone Board images were inspected and pass; the superseded blank captures are not product evidence.

## Final capture and packaging update

Inspected the refreshed landscape-board.png: the complete board and all primary controls are visible and readable. All four final viewport captures now pass visual inspection. The final supplied study report records 60 wins and 1,192 cell-centre picks. The integration worker confirms neighbourhood documents are now included in the final source archive; archive extraction/rebuild provenance remains in its release ledger.
