# Sorting Office postal work progress · 12 November 2026

Plan: `docs/superpowers/plans/2026-11-12-sorting-office-postal.md`. Baseline local `a817714`; current public contact/perch build `63ca5ccba749a441050fdd02840f6331308ce9cc`; draft PR38 head `d280889796f18703437874b70b8cc5c412f208e7` (refresh before publication).

The user explicitly authorised the remaining step4 work, delegated robot perspective decisions, requested a cosier Sorting Office and asked about all-level capacity. No renewed permission is needed for implementation/delegation/existing preview deployment. The first companion-page snapshot contains no page/document; use the working repository and existing preview.

Baseline:52 focused Node tests pass. Baseline HTML retained in `work/civic-postal/baseline.html`; prior accepted screenshots are in `docs/review-images/civic-life/`. Read-only route, level and visual audits informed the written spec.

Scope evidence: all15 Office records are identical to current canonical main. Six5×3, two5×4, seven6×4. Current campaign100 levels has boards up to10×8 and unsupported later mechanisms; this phase does not claim those fit. Audit: `work/civic-postal/level-audit.md`.

Implementation choices under delegated judgement: a narrower/lower west bench and counter-height trolley permit a complete supported loop on the existing floor. Reverse pull replaces an unproven U-turn. A world-projected paper mechanism replaces the flat fleet sprite to resolve the floor-perspective mismatch. Shared data drives all stations, actors and tests. The same parcel returns through visible supported rollers.

Pre-flight: layout→cycle→rig share scalar state and exact world planes; architecture consumes the same counter dimensions; room cats update their desk contact from that layout. Static details have separate methods and cannot occupy route/belt reservations. Root owns integration/rig/publication; isolated model and static-detail work may be delegated under the user’s standing permission. One final independent review covers the assembled result.

Task1: ready. Task2: planned. Task3: planned. Task4: planned.

Implementation in progress: root added a preallocated projected mesh/IK rig with passing initial rigid-link/projection tests (observed RED before module existed). Architecture now consumes shared bench extents, draws work surfaces beneath desk cats, and includes isolated static cosy details. The old parked manifest is being replaced, including its obsolete tests. Route/cycle and all-level browser proof are delegated to separate files. No deployment yet.

Qualification so far:61 focused Node tests pass; unchanged canonical suite1084/1084 passes freshly (486.09s). Initial integrated browser proof passes75 Office level/device cases, all75 original wins,4590 centre roundtrips and22950 visibility probes.241 work poses per viewport keep275676 active vertices outside the board (maxworldx−.2103). Four postal browser cases verify521 frames draw exactly one parcel,260 guarded frames reuse state/mesh without new canvases/gradients/projected point objects, visible grips and parcel layers. This early build is SHAca6e7582…; it is not yet the publication build.

Root found a further real fault through a dense physical probe: the original unconstrained elbow clips below the bench edge during reach/return/turn. A first fixed-plane solution clears the bench but exposes a fast elbow rotation when the retracting hand passes near its shoulder. The route implementer is correcting the return trajectory/IK and adding dense motion/contact regression coverage. This is required before final review/publication.

Performance work: grain initially composited separately on every dynamic face. It is now baked into reusable coloured paper patterns, giving one fill per face. An isolated software-Chromium forced-readback comparison at1440×1000: prior contact checkpoint median28.5ms/p9537ms; new rig/material build median34.8ms/p9562.8ms. This is diagnostic software rendering, not physical-device FPS; final verification must record the final build and device qualification remains open.


Final implementation: the hand paths approach and withdraw through a clear aisle point before crossing the bench; a torso-relative bend pole keeps continuous22+22 links. Dense1ms sampling gives minimum shoulder–palm distance14.5378px and maximum elbow movement0.30635px/ms. The old failure window is now≤0.25903px/ms. A100Hz mesh-edge/bench-box regression passes through the complete cycle. All63 focused tests pass.

Final HTML:3bc7ed281c60ae2394c241144fe36de92daddc4afac0859b54d453924021be4e,6,953,512bytes. The75-case matrix was rerun on this exact build: all75 original route wins/control checks,4590 centre round trips,22950 visibility probes. Work vertices maxx−.225789,allz≥0. All18 further browser cases pass (4postal,5life,7architecture,2alignment). Final isolated software-readback comparison: baseline29.5ms median/71.2ms p95; current33.5ms/56.7ms. No physical-device claim.

Review images are committed under docs/review-images/sorting-office-postal/: hall, work-sequence, cosy-details, grayscale, phone and landscape. office-fit-report.json records the complete level/device matrix. The board toolbar may cover background helper scenery in small Play views; it never covers puzzle cells or Send. Explore office is the full-scene view.

Portability: immutable layout/station records map to Codable support surfaces; the seekable pose sampler maps to an independent scenery-time value state; reusable paper meshes and material stocks map to Metal instances/textures; fixed foot and palm targets, signed wheels and depth boundaries carry across unchanged. Physical iPhone/Safari and Swift/Metal qualification remain open. The canonical game and later chapter layouts are outside this isolated study.

Independent whole-change review: no Critical or Important findings. The reviewer independently reproduced the63 tests/build hash and checked10,401 robot poses against scale/press solids, with max rigid-link error4.62e-14 and floor/mesh clearance. The compact-Board helper occlusion is an optional Minor, documented above; no material fix pass is needed. Review file: sorting-office-postal-review.md.

Packaging qualification: a clean extraction of sorting-office-postal-source.zip rebuilds the exact3bc7ed28 HTML and passes all63 focused tests. sorting-office-postal.zip contains that self-contained HTML and the current README. Optional art masters remain SHA7bec68b97143ec4c13ceafd6b6522609aea6833720c1bf29e05ea484c3785661. Existing earlier archives are retained.

Publication: the existing Civic preview is updated at public commit fc8d11473be06cc1626e46b85e07baf8c71c3e9c. Pages run43305048609 completed successfully. Raw published HTML bytes exactly match the tested3bc7ed28 build. Draft PR38 title/body now describe the complete Sorting Office work and remaining device qualification; no merge was made. Source/offline archives and review proofs are uploaded to that draft branch. Public changes are limited to cats-by-post-civic-mail-hall/index.html and README.md, preserving other chats’ site files.

Preview: https://holleyy.github.io/grodappsite/cats-by-post-civic-mail-hall/?v=postal-work&view=hall
PR: https://github.com/holleyy/cosysortie/pull/38
