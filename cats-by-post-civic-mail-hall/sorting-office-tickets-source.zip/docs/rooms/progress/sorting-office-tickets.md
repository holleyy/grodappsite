# Sorting Office · postal tickets ·13 November2026

The approved queue refinement replaces loose cat busts behind the hatch with cream postal tickets held in a small wooden rack. The full edit-mode box represents the first cat; only later cats get tickets. The lower/front ticket is next, with the later one stepped behind it. At runtime the acting reducer removes each ticket at the cat's pop start. No rule, level, trace or cadence changes.

The holder occupies the screen-left corner of its own hatch tile, outside the opening and both centre crossing lanes. Ten Office solutions revisit a hatch, and2-10 has adjacent hatches, so neighbouring tiles are deliberately not occupied. The cards insert beneath their slot lips. Single-cat hatches have no empty rack; multi-cat holders stay in place after their cards leave. Seven small prepared canvases cover the empty holder and all one-/two-ticket coat combinations, using344,064bytes. Drawing reuses those surfaces.

The game-review adapter preserves its pooled renderer and adds the same rack. Its accessible hatch button moves to the opposite floor corner (.96,.04) through an asserted assembly-only bridge transform. The canonical bridge remains unchanged; inactive Office and other rooms keep the existing centre anchor. The actual44px button and its focus/activation behaviour are retained.

Study checks:104passing Node tests;60successful deliveries and1,192cell picks across four Chromium viewport/DPR configurations. The new queue probe checks1-5at edit,0s,.6s and1.2s: blue/ginger,blue/ginger,ginger,empty. It verifies180prepared rack draws with stable canvases and no canvas/gradient creation. The link `?level=1-5` opens that review delivery directly. Reduced-motion complete poses remain stable. Browser evidence is Linux Chromium, not physical Safari.

Independent read-only review found no functional blocker in queue order, support geometry, resource accounting, draw allocations or scoped marker fallback. Study/adapter rack sources match. Separate adapter browser and preservation evidence is recorded on its review branch. Main remains unmerged.

Review: docs/review-images/sorting-office-tickets/index.html. Source checks: ticket-rack.test.js, check-tickets-browser.cjs and check-ticket-queue-browser.cjs. The previous movement/furniture review is retained.
