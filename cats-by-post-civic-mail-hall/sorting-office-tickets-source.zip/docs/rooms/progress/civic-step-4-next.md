# Civic Mail Hall · step 4 plan at the contact-fix checkpoint

The following records the earlier parked-helper checkpoint. The active implementation and qualification record is [Sorting Office postal work](sorting-office-postal.md).

The original step 4 is **working postal life**: routes, planted feet, grips/releases, rolling wheels and connected receiving machinery. Study 04 is a partial checkpoint, not completion of that step. Its current postal helper only checks a manifest beside a parked trolley. Cat breathing/poses are complete for this checkpoint; water and boat work from step 5 was brought forward. Preserve it, but concentrate the next work on the postal cycle.

## Next implementation sequence

1. **Prove one receive → weigh/stamp → load → dispatch cycle.** Start with a parcel arriving at a real receiving tray, process it at the counter and finish at a supported dispatch position. Include a return/rest beat. Keep the same parcel throughout. The first implementation task is a measured route and station blockout, before new animation or machinery art.
2. **Make the route physically fit.** Validate worker bodies, carried parcels and trolley turns against the maximum 6×4 board, furniture and the board's screen silhouette. The stairs/counter passage is effectively closed, and the shallow strip in front of the cubbies contains support posts. Front/right aprons are 1.2 units wide and do not yet constitute a proven route. Quay-to-hall work needs a supported crossing and a credible treatment of the raised doorway threshold. Reposition fixtures or use a deliberate hand-carry transfer where a trolley cannot pass; do not shrink or slide the worker through a gap.
3. **Build proper locomotion components.** Existing fleet artwork has no walking frames; legs, trolley and wheels are currently baked together. Add directional walking/pushing poses, alternating planted feet, body weight transfer, hands fixed to the push handle and independent wheel rotation driven by travelled distance. Include starts, stops and turns.
4. **Add parcel ownership and work.** Animate approach, grip, lift, carry, lower, surface contact and release. A parcel must be supported by exactly one surface or held by the worker during each transfer, with no duplicated or disappearing copy. Make the scale/stamp work. Any belt, chute or rollers must end at a real receiving tray or tabletop, with no unsupported handoff across a gap.
5. **Qualify the whole job.** Route workers behind/in front of scene objects correctly; the existing parked helper's final drawing pass cannot handle a room-spanning route. Check body/parcel/handle contacts, wheels, support surfaces and repeat seams across the entire cycle, including Motion off and reduced motion. Keep all 30 occupied cat cubbies and the 15 puzzle deliveries intact. Only then extend atmosphere/lighting in step 5.

## Route model work required

Current architecture bounds support picking/board clearance, not full navigation. The route model must include columns, counter overhangs and loose props, while representing the actual doorway opening and threshold instead of treating the entire rear wall as solid. Check projected occlusion as well as floor contact. No complete delivery route or walking art is claimed by the present build.

## Pillar and parcel corrections

The lower columns previously stood at y=-0.81 inside the cubby cabinet volume. Because they painted after the cabinet, their floor-level bases appeared suspended across its front. The support row now stands at y=-0.31, with bases on visible floor and a contact shadow. The gallery front extends to y=-0.15, and its upper posts, roof edge, rail and attached details follow that edge. The deck remains at z=182. Regression checks require all 5 columns to clear the cabinet, stair/counter footprints and board while retaining floor/deck contact.

The upper parcels also previously painted over the posts and rail despite standing behind them. They now draw before the foreground structure; the three-box stack is placed in an unobstructed gallery bay. Contact shadows and a regression check prove the upper parcel fits entirely on its supporting box and each base parcel sits on the deck.

Publication and verification for these corrections are recorded in the Civic study README, verification record and draft PR38. This note is the remaining-work plan; it does not claim those postal systems have been implemented.
