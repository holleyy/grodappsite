# Sorting Office finish: independent whole-change review

12 November 2026. One fresh reviewer; no implementation edits, commits, publication or further reviewers.

## Scope and status

Study finish against accepted `257f2ba`, plus the separate current-main Office presentation adapter against `f01ce351`. The user requires the adapter to remain separate for review: no merge or replacement of the live main game.

**Final result: no unresolved material findings in the study finish or separate main-game adapter. The adapter remains a review candidate on its separate branch; this review does not authorise merging or replacing the live main game.**

Read `AGENTS.md`, the finish spec and implementation plan, the finish ledger and the actual source diff. Review focuses on geometry, contacts, live-layer occlusion, allocation changes, deterministic scenery/accessibility, board clarity and presentation isolation rather than decorative preferences.

## Independently verified study evidence

- Ran `node --test studies/civic-mail-hall/foundation/*.test.js`: **70/70 pass**.
- Ran `python3 studies/civic-mail-hall/foundation/build.py`: **6,962,538 bytes**, SHA256 `3c6a873d33b8cacefd32a56c46d3c68b51256eaa61a67ed11b6db5cf85ff8bbc`, reproducing the assembled build.
- Ran the five-case life browser suite in Linux Chromium using the existing Chromium wrapper: **5/5 pass**. The initial invocation used the tool's unavailable macOS default; rerunning with `CHROME=/tmp/civic-exterior-chrome` succeeded.
- Browser checks cover actual foreground-rail occlusion, stable supported cats, unchanged frozen pixels, reduced-motion preference changes with deliveries continuing, unchanged scenery time across view changes, static patch seams and reuse of live geometry/state. Live loops reject new canvases, gradients and projected-point calls in the instrumented paths. Architecture bakes once.
- Read the final Office matrix report: **75 level/device cases**, 4,590 centre samples and 22,950 visibility samples, placement/win/reset and Explore return across all 15 Office layouts. This matrix was run by the implementation team, not repeated by this reviewer.
- Inspected baseline and final representative detail, final hall, final phone, and assembled grayscale captures, alongside the actual Lantern Quay reference `foundation/assets/port.webp`. Final gallery: `docs/review-images/sorting-office-finish/`.

## Study assessment

The finish reduces the earlier broad yellow tint, retaining warm ivory and timber with coral brick and deep teal recesses. Cached gradients, neutral grain, bevels and concentrated surface lighting improve material volume. It remains a restrained interpretation of the reference, with a clear flat blue game board in colour and clear board seams and pieces in grayscale.

Projection and board geometry are unchanged. Gallery bench and throw move together by exactly +0.25 y, keep their support heights, and remain behind the y > -1 passage. Moving mesh normals choose precomputed colour stocks; the new grain and shadow tiles are baked outside live drawing. New canal command geometry is prebuilt, remains on z=-38 and outside the board, and reuses caller state. Fixed shore contacts and window-linked reflections remain attached; the speed-dependent wake clears the channel and disappears at stationary stops/turns.

The existing static/live layer order is preserved and the independent browser occlusion/seam checks pass. Compact Board controls occupy a row outside the canvas; current phone evidence shows the working helper and board without toolbar overlap. The native/Swift mapping is recorded in `PLAN.md`.

## Separate main-game adapter

Reviewed the settled adapter in `/workspace/civic-main-integration`, based on exact current main `f01ce351e3db573427d4149320ef7f8d4ee0d810`, on `codex/sorting-office-paper-finish`.

- Independently ran `python3 tools/build-web.py --check`: reproducible **web-8e8b4e764f5f**, 100 levels, six rooms, 17,394,375 engine bytes, canonical export unchanged.
- Independently ran the final adapter, web-fidelity and web-camera tests: **29/29 pass**. These include restore/cancellation/error paths, provenance, exact trace ownership, all 100 boards' inverse picking at fractional scales, camera/session restoration and chapter ownership.
- Independently rebuilt all six factories into a temporary directory and compared them with the generated outputs. All reproduce exactly; Office bundle SHA256 `6c1bc1cb6ad0a2df57bc53e84a5c0c8dfb6a73695b37a87e7cc716fb81b7ae00`. The other five generated factories are byte-identical to current main.
- Independently exercised the actual web host: Office 2-10 facts survive refresh unchanged; persisted Gentler motion freezes scenery through a real canonical win; Office → Depot removes the Office alias; Office return remounts successfully; disposal restores native paper output and reports no owned resources. No page errors. This smoke used the preceding `web-c40c9997ca55` build; the settled build subsequently adds scoped output smoothing and passes the final checks above.
- Read the final implementation-team evidence: **791/791 relevant current-main tests**, and **56 browser records** including **45 Office wins** across desktop, phone and small landscape, **894 cell picks**, retained version-5 saves for all 15 Office wins, night/custom fallback, and five other-room chapter demo/return transitions. Browser report has no errors. Evidence is in the integration checkout's `work/office-paper/`.
- Inspected final desktop Board/Room, phone and small-landscape captures. The board remains clear. Smoothing is guarded by active Office presentation in both native and continuous-camera presenters; unsupported modes retain the prior output path.

The factory compiles only presentation modules inside its private namespace. It introduces no study session, rules, level table, application shell, storage key or input controller. Its reused state refers to canonical level/chute objects; trace facades inherit current canonical arrays/scalars and override only the presentation origin. The shared projection maps exactly to the native 16-unit board plane. Unsupported chapters, night, custom/generated/service/editor modes and unsupported boards use native output.

The existing room manager captures/restores the four overridden functions and the Office alias. Generation checks precede hook publication; disposal removes the preference listener and releases renderer/output references. Chapter transitions retain their native controllers. No changes exist in canonical `src/app`, `src/render`, `src/sim`, `src/data`, native code or `sorting_office.html`. The separate interface camera change only selects smoothing for the active adapter.

The reviewer raised the persisted Gentler motion path during assembly: OS media preference alone did not cover the host setting. The final adapter observes the host's applied reduced state, and the independent browser win confirms that scenery freezes while deliveries continue. A temporary smoothing-patch match-count failure and a source/build provenance race were corrected before the final green checks; neither remains an open finding. No decorative follow-up is required by this review.

## Limits

Physical iPhone/Safari, sustained mobile performance, native Swift/Metal and device peak memory remain unverified. Linux Chromium and emulated viewport results do not qualify those devices. Existing baseline allocations elsewhere in the study renderer are not claimed to have been removed; the review found no new per-frame allocation path in this finish's added material/canal/rig drawing.
