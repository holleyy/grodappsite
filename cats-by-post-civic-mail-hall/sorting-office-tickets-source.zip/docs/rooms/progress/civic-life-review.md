# Civic life whole-change review — 2026-11-12

Independent read-only runtime review of `codex/civic-mail-hall` against `028c3f7`, including the untracked room, canal, postal modules and their tests/browser harness. This report is the reviewer's only file change. No canonical tests were rerun and no publication or merge was performed.

## Findings

- **Critical:** none found.
- **Important:** none found.
- **Minor — motion evidence initially missed the postal action:** `studies/civic-mail-hall/foundation/check-life-browser.js:56` originally sampled the clerk at 0, 1.3, 26.9 and 29.6 seconds, all within its resting interval. Consequently all four clerk pictures in the initial `work/civic-life/motion-sequence.png` were identical. The author has corrected the capture source to independent, labeled postal times 1, 4.5, 6.6 and 8.8 seconds. Regeneration of that artifact remains part of the author's final verification. This was an evidence issue, not a demonstrated runtime failure.

## Review evidence

Inspected the runtime changes, build and package integration, app clock and motion handling, and the three new test suites. Independently executed all 18 new Node tests: 18 passed, 0 failed. Inspected the existing life-browser log: five cases completed, including 7,582 changed cubby pixels, 384 gallery rail-overlap pixels, 740 visible gallery-cat pixels, frozen motion-off/reduced-motion scenery with continuing delivery, reusable state and single bakes, and 7,225 changed canal pixels. Did not launch duplicate Chrome while the author's broader browser checks were running.

Visually inspected `hall.png`, `phone.png`, `motion-sequence.png` and `canal-passage.png`. The gallery cat rests behind the railing, occupied cubbies remain legible, and the clerk/boat stay outside the board. The phone capture retains the board and delivery controls. These initial captures precede the copy-only Study 04 header update.

The cubby/gallery patch bounds contain both authored silhouettes at maximum breathing scale and the supporting shadows. Static foreground scenery is excluded from the base only inside those patches, then restored after the relevant actors. The existing browser harness compares patch seams against an unsplit render and checks foreground rail pixels. No concrete patch clipping or contact defect was found. All 32 actor soles are fixed; periodic breathing and pose transitions are staggered. Short full-body crossfades are the documented reuse approach, rather than additional authored in-between frames.

Canal position, orientation and bobbing are continuous at route joins and the repeat seam. The hull and contact ring fit the turning channel; the checked projected paths clear the maximum board. Postal feet/wheels remain fixed, the paper corner follows the articulated hand, and the checking stroke follows the paper during marking. Runtime draw paths reuse actor/boat/postal state and precomputed boat geometry; no new explicit per-frame arrays, canvases, gradients or projected-point objects were found in the life modules. Motion handling advances scenery independently from the unchanged delivery clock.

## Limits and disposition

No blocking runtime finding. The author is completing refreshed captures, broader controls/alignment verification and final package/docs preparation. Packaging includes the new modules and this report. Browser software-rendering measurements and 31.28 MiB of architecture caches support bounded implementation costs, but do not qualify physical iPhone/Safari or Swift/Metal performance. No aesthetic preference is treated as a defect. One whole-change review was performed; this report does not claim an additional recursive review or device qualification.

## Author disposition

The motion sheet was regenerated with independent postal times1,4.5,6.6,8.8 and visually checked. It now shows the lift, check and return. All5 life cases pass on the final Study04 page, alongside7 architecture,5 controls/rules and2 floor/arrow cases. No runtime review fixes or additional review pass were needed.
