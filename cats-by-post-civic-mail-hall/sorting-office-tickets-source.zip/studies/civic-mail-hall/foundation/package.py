"""Reproducible offline preview and source archives; run after build.py."""
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import hashlib
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def write(name,files):
    with ZipFile(HERE/name,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
        for arc,path in sorted(files):
            info=ZipInfo(arc,(2026,11,13,0,0,0));info.compress_type=ZIP_DEFLATED;info.external_attr=0o100644<<16
            z.writestr(info,path.read_bytes())
    path=HERE/name;print(name,path.stat().st_size,hashlib.sha256(path.read_bytes()).hexdigest())
write('sorting-office-foreground.zip',[('Sorting Office.html',HERE/'index.html'),('README.md',HERE/'README.md')])
files=[]
masters=[]
for p in HERE.rglob('*'):
    if p.is_file() and p.suffix!='.zip' and '__pycache__' not in p.parts and p.name!='index.html':
        (masters if p.suffix=='.png' else files).append((str(p.relative_to(ROOT)),p))
for relative in ['docs/superpowers/plans/2026-11-12-sorting-office-neighbourhood.md','docs/rooms/progress/sorting-office-neighbourhood.md','docs/rooms/progress/sorting-office-neighbourhood-review.md','docs/superpowers/specs/2026-11-12-sorting-office-finish.md','docs/superpowers/plans/2026-11-12-sorting-office-finish.md','docs/rooms/progress/sorting-office-finish.md','docs/rooms/progress/sorting-office-finish-review.md','docs/superpowers/specs/2026-11-12-sorting-office-postal-design.md','docs/superpowers/plans/2026-11-12-sorting-office-postal.md','docs/rooms/progress/sorting-office-postal.md','docs/rooms/progress/sorting-office-postal-review.md','tools/snap.js','docs/rooms/progress/civic-step-4-next.md','docs/superpowers/specs/2026-11-12-civic-life-design.md','docs/superpowers/plans/2026-11-12-civic-life.md','docs/rooms/progress/civic-life.md','docs/rooms/progress/civic-life-review.md','studies/civic-mail-hall/assets/scenery.webp','docs/superpowers/specs/2026-11-12-civic-pieces-design.md','docs/superpowers/plans/2026-11-12-civic-pieces.md','docs/rooms/progress/civic-piece-inventory.md','docs/superpowers/specs/2026-11-12-civic-architecture-design.md','docs/superpowers/plans/2026-11-12-civic-architecture.md','docs/rooms/progress/civic-architecture.md','docs/rooms/progress/civic-architecture-review.md']:
    p=ROOT/relative;files.append((relative,p))
for relative in ['docs/superpowers/plans/2026-11-13-sorting-office-foreground.md','docs/rooms/progress/sorting-office-foreground.md']:
    files.append((relative,ROOT/relative))
write('sorting-office-foreground-source.zip',files)
# Earlier architecture masters are an immutable checkpoint, generated separately.
