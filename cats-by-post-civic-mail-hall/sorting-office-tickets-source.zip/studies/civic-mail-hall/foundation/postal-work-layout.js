/* Shared physical dimensions for the west workbench and its one postal job.
 * x/y are floor tiles; z and joint lengths are projected height units. */
(function(root,factory){
 const P=typeof module==='object'&&module.exports?require('./projection.js'):root.CivicProjection;
 const L=factory(P);if(typeof module==='object'&&module.exports)module.exports=L;root.CivicPostalLayout=L;
})(globalThis,function(P){
'use strict';
const beats=[
 ['receive',0,2],['reach-received',2,4],['lift-received',4,5],['turn-to-scale',5,6],
 ['carry-to-scale',6,8],['face-scale',8,9],['place-scale',9,11],['release-scale',11,12],
 ['weigh',12,14],['reach-control',14,15],['stamp',15,16],['release-control',16,17],
 ['grip-processed',17,19],['lift-processed',19,20],['face-cart',20,21],['carry-to-cart',21,23],
 ['place-cart',23,25],['release-cart',25,26],['grip-handle',26,27],['push',27,31],
 ['deploy-bridge',31,32],['side-transfer',32,35],['retract-bridge',35,36],['pull',36,40],
 ['release-handle',40,41],['turn-return',41,42],['walk-return',42,47],['cross-receive',47,49],
 ['rotate-receiving',49,51],['settle',51,52]
];
const layout={
 period:52,floorUnit:P.HW,clearanceX:-.14,
 floor:{x0:-3,x1:7.2,y0:-2,y1:5.2},board:{x0:0,x1:6,y0:0,y1:4},
 bench:{x0:-1.75,x1:-.95,y0:.35,y1:3.60,top:58},
 receiving:{x:-1.18,y:.68,z:58,top:58,radius:.21,initialYaw:-Math.PI/2},
 scale:{x:-1.18,y:1.26,z:64,top:64,radius:.21,stampRestZ:90,stampContactZ:78,
  control:{x:-.95,y:1.40,z:69,travel:4}},
 returnBelt:{x:-1.55,x0:-1.71,x1:-1.39,width:.32,y0:.68,y1:3.12,z:58,top:58},
 crossTransfer:{x0:-1.71,x1:-.95,width:.32,receivingY:.68,dispatchY:3.12,top:58},
 cart:{x:-.53,width:.50,depth:.60,deck:58,top:58,handleZ:68,handleOffset:-.41,handleHalfWidth:.18,
  wheelRadius:5.5,wheelHalfWidth:.225,wheelHalfDepth:.22,loadY:2.30,dispatchY:3.25,parcelOffset:-.13},
 bridge:{x0:-.95,x1:-.78,y0:2.97,y1:3.27,top:58},
 worker:{x:-.53,receivingY:.70,scaleY:1.26,loadY:1.65,pushStartY:1.51,pushEndY:2.46,
  radius:.32,footOffset:.105,footLift:10,hipZ:32,shoulderZ:56,shoulderOffset:.18,armLength:44},
 parcel:{id:'office-parcel',width:.26,depth:.26,height:14,gripZ:7,carryZ:68,carryReach:.36,workReach:.57},
 deskCat:{x:-1.17,y:2.25,z:58,width:54},
 phases:beats.map(b=>({name:b[0],start:b[1],end:b[2]})),
 owners:{receiving:'receiving',held:'held',scale:'scale',cart:'cart',dispatch:'dispatch-transfer',belt:'return-belt',cross:'cross-transfer'},
 surfaces:[
  {name:'bench',x0:-1.75,x1:-.95,y0:.35,y1:3.60,z:58},
  {name:'receiving',x:-1.18,y:.68,radius:.21,z:58},
  {name:'scale',x:-1.18,y:1.26,radius:.21,z:64},
  {name:'return-belt',x0:-1.71,x1:-1.39,y0:.52,y1:3.28,z:58},
  {name:'bridge',x0:-.95,x1:-.78,y0:2.97,y1:3.27,z:58}
 ]
};
function freeze(o){for(const key of Object.keys(o))if(o[key]&&typeof o[key]==='object')freeze(o[key]);return Object.freeze(o);}
return freeze(layout);
});
