'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const P=require('./projection.js');
let Canal;
try{Canal=require('./canal-life.js');}catch(error){if(error.code!=='MODULE_NOT_FOUND')throw error;}
function available(){assert.equal(typeof Canal,'function','the deterministic canal renderer must be exported');}
function close(a,b,message){assert.ok(Math.abs(a-b)<1e-9,message||`${a} differs from ${b}`);}
function cross(a,b,p){return(b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x);}
function intersectionArea(points,clip){
 let out=points;
 for(let i=0;i<clip.length&&out.length;i++){
  const a=clip[i],b=clip[(i+1)%clip.length],input=out;out=[];
  let p=input[input.length-1],dp=cross(a,b,p);
  for(const q of input){
   const dq=cross(a,b,q);
   if((dq>=0)!==(dp>=0)){const t=dp/(dp-dq);out.push({x:p.x+(q.x-p.x)*t,y:p.y+(q.y-p.y)*t});}
   if(dq>=0)out.push(q);p=q;dp=dq;
  }
 }
 let area=0;
 for(let i=0;i<out.length;i++){const p=out[i],q=out[(i+1)%out.length];area+=p.x*q.y-q.x*p.y;}
 return Math.abs(area)/2;
}
// Record the real renderer's canvas output, including its transforms. This is
// the platform boundary, so the route and geometry remain production code.
function recordingContext(){
 const paths=[],stack=[];let x=0,y=0,points=[];
 return{paths,globalAlpha:1,fillStyle:null,strokeStyle:null,lineWidth:1,
  save(){stack.push([x,y,this.globalAlpha]);},restore(){[x,y,this.globalAlpha]=stack.pop();},
  translate(dx,dy){x+=dx;y+=dy;},beginPath(){points=[];},closePath(){},
  moveTo(px,py){points.push({x:px+x,y:py+y});},lineTo(px,py){points.push({x:px+x,y:py+y});},
  fill(){paths.push({points:points.slice(),fill:this.fillStyle,alpha:this.globalAlpha});},
  stroke(){paths.push({points:points.slice(),stroke:this.strokeStyle,width:this.lineWidth,alpha:this.globalAlpha});}
 };
}
test('canal has a browser export independent of a clock or DOM',()=>{
 available();const browser=vm.createContext({});
 vm.runInContext(fs.readFileSync(__dirname+'/canal-life.js','utf8'),browser);
 assert.equal(typeof browser.CivicCanal,'function');
 const pose={};assert.equal(browser.CivicCanal.sampleBoat(0,pose),pose);
 assert.ok(Number.isFinite(pose.x)&&Number.isFinite(pose.y));
});
test('the postal boat stops alongside the loading deck for a useful dwell',()=>{
 available();const a=Canal.sampleBoat(2,{}),b=Canal.sampleBoat(15,{});
 assert.equal(a.moored,true);assert.equal(b.moored,true);
 close(a.x,b.x);close(a.y,b.y);close(a.speed,0);close(b.speed,0);
 assert.ok(a.y>=5.3+.55&&a.y<=6.7-.55,'the cargo hold is beside the landing');
 assert.ok(a.x<-4.03-.23&&a.x>-7+.23);
 assert.equal(Canal.sampleBoat(60,{}).moored,false);
});
test('the complete boat turning envelope clears the actual banks and channel ends',()=>{
 available();const pose={},hull=Canal.layout().hull;
 assert.ok(Object.isFrozen(hull)&&hull.length>=6);
 for(let t=0;t<=168;t+=.125){
  Canal.sampleBoat(t,pose);const c=Math.cos(pose.heading),s=Math.sin(pose.heading);
  for(const p of hull){
   const x=pose.x+p[0]*c-p[1]*s,y=pose.y+p[0]*s+p[1]*c;
   assert.ok(x>-7+.04&&x<-4.03-.04,`bank collision at ${t}: ${x}`);
   assert.ok(y>-3.5+.04&&y<9-.04,`channel end collision at ${t}: ${y}`);
  }
 }
});
test('the route is continuous across stops, turns and its repeat seam',()=>{
 available();const before={},after={};
 for(const t of[-56,0,18,30,42,100,112,168]){
  Canal.sampleBoat(t-1e-5,before);Canal.sampleBoat(t+1e-5,after);
  assert.ok(Math.hypot(before.x-after.x,before.y-after.y)<1e-4,`position jump at ${t}`);
  assert.ok(Math.abs(Math.sin(before.heading)-Math.sin(after.heading))<1e-4,`heading jump at ${t}`);
  assert.ok(Math.abs(before.bob-after.bob)<1e-4,`water contact jump at ${t}`);
 }
 let previous=Canal.sampleBoat(0,{});
 for(let t=.25;t<168;t+=.25){
  const next=Canal.sampleBoat(t,{});
  assert.ok(Math.hypot(next.x-previous.x,next.y-previous.y)/.25<.25,'the postal boat races through the scene');
  previous=next;
 }
});
test('fractional, negative and distant seeks are repeatable and reuse caller storage',()=>{
 available();const out={};
 for(const t of[-169.25,-.25,0,12.875,56.5,91.125,167.999]){
  assert.equal(Canal.sampleBoat(t,out),out);
  const first={...out};Canal.sampleBoat(112,out);Canal.sampleBoat(t,out);
  assert.deepEqual(out,first);
  const repeat=Canal.sampleBoat(t+168*1000,{});
  for(const key of['x','y','bob','speed'])close(repeat[key],first[key],key+' drifts across loops');
 }
});
test('the waterline remains inside the hull through every bob and turn',()=>{
 available();const l=Canal.layout(),pose={};
 for(let t=0;t<168;t+=.1){
  Canal.sampleBoat(t,pose);
  assert.equal(pose.z,-120);
  assert.ok(pose.bob+l.keel<0,'keel lifts clear of the water');
  assert.ok(pose.bob+l.gunwale>0,'gunwale submerges');
  assert.ok(Math.abs(pose.bob)<.5,'bobbing is too large for paper water');
 }
});
test('actual water, wakes and boat drawings never cover the largest board diamond',()=>{
 available();const ctx=recordingContext(),canal=new Canal({ctx}),board=P.corners(6,4);
 for(let t=0;t<168;t+=2){
  ctx.paths.length=0;canal.draw(t);canal.drawMailBoat(t);
  assert.ok(ctx.paths.length>60,'water and a parcel boat must be visible');
  for(const path of ctx.paths){
   assert.ok(path.points.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)));
   assert.ok(intersectionArea(path.points,board)<1e-7,`canal covers board at ${t}`);
   for(const p of path.points)assert.ok(p.x>=-1000&&p.x<=2550&&p.y>=-200&&p.y<=1880,'water exceeds its deliberate foreground reach');
  }
 }
});
test('repeated draw calls emit identical paper geometry after unrelated time seeks',()=>{
 available();const ctx=recordingContext(),canal=new Canal({ctx});
 canal.draw(63.75);canal.drawMailBoat(63.75);const first=structuredClone(ctx.paths);
 ctx.paths.length=0;canal.draw(109);canal.drawMailBoat(109);ctx.paths.length=0;canal.draw(63.75);canal.drawMailBoat(63.75);
 assert.deepEqual(ctx.paths,first);
 assert.equal(ctx.globalAlpha,1,'canal must restore the caller canvas state');
});
function waterPoint(p){
 const a=(p.x-760)/(380/6),b=(p.y-585)/(190/6);
 return{x:(a+b)/2,y:(b-a)/2};
}
function extent(points){
 return{x0:Math.min(...points.map(p=>p.x)),x1:Math.max(...points.map(p=>p.x)),y0:Math.min(...points.map(p=>p.y)),y1:Math.max(...points.map(p=>p.y))};
}
test('narrow shoreline contact stays attached to each real bank while the water moves',()=>{
 available();const ctx=recordingContext(),canal=new Canal({ctx}),banks=[
  b=>Math.abs(b.x0+7)<1e-8&&b.x1-b.x0<.12&&b.y1-b.y0>12,
  b=>Math.abs(b.x1+4.03)<1e-8&&b.x1-b.x0<.12&&b.y1-b.y0>7,
  b=>Math.abs(b.y0+4)<1e-8&&b.y1-b.y0<.12&&b.x1-b.x0>11,
  b=>Math.abs(b.x0-9.4)<1e-8&&b.x1-b.x0<.12&&b.y1-b.y0>9
 ];
 const contacts=[];
 for(const t of[0,9.75]){
  ctx.paths.length=0;canal.draw(t);canal.drawMailBoat(t);
  const found=banks.map(bank=>ctx.paths.find(path=>bank(extent(path.points.map(waterPoint)))));
  assert.ok(found.every(Boolean),'each actual bank needs a thin attached water contact');contacts.push(found);
 }
 assert.deepEqual(contacts[0],contacts[1],'shore contact must not drift away from masonry');
});
test('the moving wake extends with travel speed and disappears at mooring and stationary turns',()=>{
 available();const ctx=recordingContext(),canal=new Canal({ctx});
 const wakeAt=t=>{ctx.paths.length=0;canal.draw(t);canal.drawMailBoat(t);return ctx.paths.filter(path=>path.fill==='#d0e0c9'&&path.alpha>0);};
 const slow=wakeAt(20),fast=wakeAt(24),slowPose=Canal.sampleBoat(20,{}),fastPose=Canal.sampleBoat(24,{});
 assert.ok(slow.length>0&&fast.length>0,'both moving samples need a quiet wake');
 const slowReach=slowPose.y-extent(slow.flatMap(path=>path.points.map(waterPoint))).y0;
 const fastReach=fastPose.y-extent(fast.flatMap(path=>path.points.map(waterPoint))).y0;
 assert.ok(fastReach>slowReach+.12,'wake reach must follow travel rather than only changing opacity');
 for(const t of[0,15,35,105])assert.equal(wakeAt(t).length,0,'mooring and stationary turns must not leave a translating wake');
});
test('currents, reflections and wakes stay on the continuous canal through every passage and turn',()=>{
 available();const ctx=recordingContext(),canal=new Canal({ctx});
 const wet=p=>(p.x>=-7-1e-8&&p.x<=6.1+1e-8&&p.y>=-4-1e-8&&p.y<=-2.2+1e-8)||
  (p.x>=-7-1e-8&&p.x<=-3.05+1e-8&&p.y>=-4-1e-8&&p.y<=20+1e-8)||
  (p.x>=-7-1e-8&&p.x<=20+1e-8&&p.y>=7.2-1e-8&&p.y<=20+1e-8)||
  (p.x>=9.4-1e-8&&p.x<=20+1e-8&&p.y>=-8-1e-8&&p.y<=20+1e-8);
 for(let t=0;t<168;t+=.5){
  ctx.paths.length=0;canal.drawSurface(t);
  // The continuous water has no vertical tray end. Every surface vertex
  // must remain in the actual connected water footprint around the quay.
  for(const path of ctx.paths)for(const p of path.points)assert.ok(wet(waterPoint(p)),`water escaped its banks at ${t}: ${JSON.stringify(waterPoint(p))} fill ${path.fill}`);
  ctx.paths.length=0;canal.draw(t);canal.drawMailBoat(t);
  const boatWater=ctx.paths.filter(path=>['#d0e0c9','#427e7d','#b7b79b','#689b91'].includes(path.fill));
  assert.ok(boatWater.length>=5,'moving skiff needs contact and a broken water-plane reflection');
  for(const path of boatWater)for(const p of path.points)assert.ok(wet(waterPoint(p)),`boat water escaped at ${t}`);
 }
});
test('all water geometry reuses its built storage and the whole drawing repeats at the route seam',()=>{
 available();const ctx=recordingContext(),canal=new Canal({ctx});
 function hold(value){
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))hold(value[key]);Object.freeze(value);
 }
 const geometry=[canal.water,canal.currents,canal.reflections,canal.shoreline,canal.frames,canal.mailBoat],pose=canal.pose;
 for(const value of geometry)hold(value);
 for(const t of[-.25,0,12.875,24.5,63.75,167.5]){
  ctx.paths.length=0;canal.draw(t);canal.drawMailBoat(t);const first=structuredClone(ctx.paths);
  ctx.paths.length=0;canal.draw(103);canal.drawMailBoat(103);ctx.paths.length=0;canal.draw(t+168*1000);canal.drawMailBoat(t+168*1000);
  assert.deepEqual(ctx.paths,first,'a seek or loop seam changed the frozen scene');
 }
 assert.equal(canal.pose,pose);
 for(const [i,key]of['water','currents','reflections','shoreline','frames','mailBoat'].entries())assert.equal(canal[key],geometry[i],'draw replaced its prebuilt geometry');
});
test('broken window reflections stay beneath the actual paired far-bank windows',()=>{
 available();const ctx=recordingContext(),canal=new Canal({ctx});
 // Window centres from the eight existing house facades, independently of
 // the canal's reflection descriptors and their animated drawing commands.
 const windows=[-5.284,-4.87,-4.072,-3.635,-2.7292,-2.306,-1.4528,-.979,-.074,.358,1.3096,1.788,2.708,3.145,4.162,4.645];
 const colors=new Set(canal.reflections.filter(group=>group.kind==='distant').flatMap(group=>group.commands.map(path=>path.fill)));
 for(const t of[0,9.75,63.75]){
  ctx.paths.length=0;canal.draw(t);canal.drawMailBoat(t);const reflected=ctx.paths.filter(path=>colors.has(path.fill)),hits=windows.map(()=>0);
  for(const path of reflected){
   const points=path.points.map(waterPoint),b=extent(points),x=(b.x0+b.x1)/2;
   const nearest=windows.reduce((best,v,i)=>Math.abs(v-x)<Math.abs(windows[best]-x)?i:best,0);
   assert.ok(Math.abs(windows[nearest]-x)<.04,'a reflection detached from its source window');
   assert.ok(b.y0>=-3.98&&b.y1<=-3.4,'window reflection wandered from its bank');hits[nearest]++;
  }
  assert.ok(hits.every(count=>count>=2),'visible window groups need broken, source-attached reflections');
 }
});

test('near warm reflections share the screen column of their real cottage and quay lights',()=>{
 available();const canal=new Canal({ctx:recordingContext()}),near=canal.reflections.filter(group=>['quay','window','cottage'].includes(group.kind));
 const sources=[];
 for(let i=0;i<5;i++){
  sources.push({x:-7.79,y:-.9+i*1.75,z:-54},{x:-7.925,y:-1.265+i*1.75,z:2});
 }
 sources.push({x:-3.59,y:6.72,z:-15},{x:2.95,y:6.8,z:-21});
 assert.equal(near.length,sources.length);
 for(let i=0;i<near.length;i++){
  const group=near[i],source=sources[i],p=P.project(source.x,source.y,source.z);
  assert.deepEqual(group.source,source);
  assert.ok(group.commands.length>=7,'a visible near lamp needs a broken reflection ribbon');
  for(const path of group.commands){
   const x=(Math.min(...path.points.map(p=>p.x))+Math.max(...path.points.map(p=>p.x)))/2;
   assert.ok(Math.abs(x-p.x)<4,'reflection detaches sideways from its lamp');
   assert.ok(path.points.every(q=>q.y>p.y+20),'reflected light must lie below its source');
  }
 }
});
test('the large moored postal hull clears the quay and the entire moving skiff route',()=>{
 available();const a=Canal.layout().mailBoat,ca=Math.cos(a.heading),sa=Math.sin(a.heading);
 const hull=a.hull.map(p=>({x:a.x+p[0]*ca-p[1]*sa,y:a.y+p[0]*sa+p[1]*ca}));
 const b=extent(hull);
 assert.ok(b.x1-b.x0>3.4&&b.y1-b.y0>1.3,'mailboat must remain substantial in the foreground');
 assert.ok(b.y0>7.2+.1,'hull intersects quay masonry');
 const pose={};
 for(let t=0;t<168;t+=.125){
  Canal.sampleBoat(t,pose);const c=Math.cos(pose.heading),s=Math.sin(pose.heading);
  for(const p of Canal.layout().hull){
   const y=pose.y+p[0]*s+p[1]*c;
   assert.ok(y<b.y0-.15,'moving skiff reaches the moored postal boat');
  }
  const bob=Math.sin(t*Math.PI*2/7)*.3+Math.sin(t*Math.PI*2/12)*.08;
  assert.ok(a.keel+bob<0&&a.gunwale+bob>0,'moored hull lifts clear of or sinks beneath the water');
 }
});
test('mooring line has a fixed real bollard endpoint and a softly moving boat endpoint',()=>{
 available();const ctx=recordingContext(),canal=new Canal({ctx}),a=Canal.layout().mailBoat,anchor=a.moorings[a.activeMooring];
 const expected=P.project(anchor.x,anchor.y,anchor.z),ends=[];
 for(const t of[0,1.75,5.25]){
  ctx.paths.length=0;canal.drawMailBoat(t);
  const rope=ctx.paths.find(path=>path.stroke==='#e5bd79');assert.ok(rope);
  const end=rope.points[rope.points.length-1];close(end.x,expected.x);close(end.y,expected.y);ends.push(rope.points[0]);
 }
 assert.equal(ends[0].x,ends[1].x);assert.ok(Math.abs(ends[0].y-ends[1].y)>.2&&Math.abs(ends[0].y-ends[1].y)<.5);
});
test('mailboat casts a broken reflection made from its actual warm cabin and coral roof faces',()=>{
 available();const canal=new Canal({ctx:recordingContext()}),boat=canal.mailBoat;
 const bodyColours=new Set(boat.body.filter(path=>path.fill).map(path=>path.fill));
 assert.ok(boat.reflection.length>40);
 for(const path of boat.reflection){assert.ok(bodyColours.has(path.sourceFill));assert.ok(path.points.length>=3);}
 for(const color of['#ffe9a2','#df825d','#406e5f'])assert.ok(boat.reflection.some(path=>path.sourceFill===color),'boat reflection lost a defining material');
});
test('the formerly flat area outside the garden is covered by real water and moving crests',()=>{
 available();const ctx=recordingContext(),canal=new Canal({ctx}),outline=canal.water[0].points.map(waterPoint);
 const inside=(x,y)=>{
  let result=false;
  for(let i=0,j=outline.length-1;i<outline.length;j=i++){
   const a=outline[i],b=outline[j];
   if((a.y>y)!==(b.y>y)&&x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x)result=!result;
  }
  return result;
 };
 for(const [x,y]of[[10.5,-4.5],[12,-6],[10,-1.5],[13,0],[15,3],[11,8],[17,11]])assert.ok(inside(x,y),'outside water still stops at the garden wall');
 assert.ok(canal.currents.filter(group=>group.commands.some(path=>path.points.every(p=>{const q=waterPoint(p);return q.x>9.4&&q.y< -2.8;}))).length>30,'open water behind the garden has no continuing current detail');
 const marks=t=>{
  ctx.paths.length=0;canal.drawSurface(t);
  return ctx.paths.filter(path=>path.points.length>2&&path.points.every(p=>{const q=waterPoint(p);return q.x>10&&q.x<18&&q.y>-2&&q.y<8;}));
 };
 const first=structuredClone(marks(0)),later=marks(7);
 assert.ok(first.length>30,'right reach needs visible current detail, not only a coloured polygon');
 assert.equal(first.length,later.length,'right reach invents or drops geometry while moving');
 assert.ok(later.some((path,i)=>Math.abs(path.alpha-first[i].alpha)>.02),'right water has no light movement');
 assert.ok(later.some((path,i)=>Math.abs(path.points[0].x-first[i].points[0].x)>.15),'right water crests never move');
});
test('right-wall reflections are attached to masonry and leave the gate opening clear',()=>{
 available();const canal=new Canal({ctx:recordingContext()}),groups=canal.reflections.filter(group=>group.kind==='wall');
 assert.ok(groups.length>=10,'right canal lacks reflected wall colour');
 for(const group of groups){
  assert.equal(group.source.x,9.055);assert.equal(group.source.z,-37);
  assert.ok(group.source.y<=.45||group.source.y>=1.55,'open gate casts a solid-wall reflection');
  const source=P.project(group.source.x,group.source.y,group.source.z);
  assert.ok(group.commands.length>=3);
  for(const path of group.commands){
   const b=extent(path.points);
   assert.ok(Math.abs((b.x0+b.x1)/2-source.x)<1,'wall reflection drifts off its real source column');
   assert.ok(path.points.every(p=>waterPoint(p).x>9.4),'wall colour leaves the water side of the bank');
  }
 }
});
