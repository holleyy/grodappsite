/* A corner-mounted postal ticket holder. Printed portraits replace loose
 * miniature cats; its complete footprint clears both hatch crossing lanes. */
(function(root){
'use strict';
const HW=380/6,HH=190/6;
const LAYOUT=Object.freeze({x0:.002,x1:.138,y0:.862,y1:.998,cx:.07,cy:.93,slots:2});
class TicketRack{
 constructor(renderer){this.r=renderer;this.frames=[];this.bytes=0;this.counts=[];for(let i=0;i<100;i++)this.counts.push('+'+i);}
 static layout(){return LAYOUT;}
 static count(state,edit){return Math.min(2,Math.max(0,state.n-(edit?1:0)));}
 static frame(state,edit){const skip=edit?1:0,n=TicketRack.count(state,edit);let bits=0;for(let k=0;k<n;k++)if(state.queue[k+skip].coat===2)bits|=1<<k;return(1<<n)-1+bits;}
 bake(){
  const r=this.r;
  for(let n=0;n<=2;n++)for(let bits=0;bits<(1<<n);bits++){
   const canvas=document.createElement('canvas');canvas.width=96;canvas.height=128;const c=canvas.getContext('2d');c.scale(2,2);c.translate(24,52);
   const point=(x,y,z)=>({x:(x-y)*HW,y:(x+y)*HH-z});
   const polygon=(p,fill)=>{c.beginPath();c.moveTo(p[0].x,p[0].y);for(let i=1;i<p.length;i++)c.lineTo(p[i].x,p[i].y);c.closePath();c.fillStyle=fill;c.fill();};
   const box=(x0,y0,x1,y1,z0,z1)=>{
    polygon([point(x0,y1,z0),point(x1,y1,z0),point(x1,y1,z1),point(x0,y1,z1)],'#a97643');
    polygon([point(x1,y0,z0),point(x1,y1,z0),point(x1,y1,z1),point(x1,y0,z1)],'#8b613c');
    polygon([point(x0,y0,z1),point(x1,y0,z1),point(x1,y1,z1),point(x0,y1,z1)],'#d9b477');
   };
   // All geometry is relative to the same supported corner of the floor tile.
   c.fillStyle='#493e292b';c.beginPath();c.ellipse(0,1.3,9,4.3,0,0,Math.PI*2);c.fill();
   box(-.068,-.068,.068,.068,0,3);
   // A fixed two-step back and supporting ledges remain when tickets leave.
   const back=c.createLinearGradient(-7,-17,7,1);back.addColorStop(0,'#d2a76d');back.addColorStop(.6,'#b68650');back.addColorStop(1,'#8f6139');
   polygon([{x:-7.6,y:0},{x:-7.6,y:-17},{x:6.6,y:-17},{x:6.6,y:0}],back);
   c.strokeStyle='#efce99';c.lineWidth=.55;c.beginPath();c.moveTo(-7,-16.4);c.lineTo(6,-16.4);c.stroke();
   for(let k=1;k>=0;k--){
    if(k<n){const coat=(bits>>k)&1?'blue':'ginger',q=r.assets.acting.sprites[coat+'-bust-front'].rect;
    const left=-6.3-k*.45,top=-25-k*10.5,w=12.6,h=22.4;
    c.fillStyle='#513d2840';c.fillRect(left+.7,top+.8,w,h);
    const paper=c.createLinearGradient(left,top,left+w,top+h);paper.addColorStop(0,'#fff5df');paper.addColorStop(1,'#e9d7b5');c.fillStyle=paper;c.fillRect(left,top,w,h);
    c.strokeStyle='#c9ac7c';c.lineWidth=.5;c.strokeRect(left,top,w,h);
    c.fillStyle=coat==='ginger'?'#c47f3d':'#57798a';c.fillRect(left+.6,top+.7,w-1.2,1.5);
    // The face is ink within the paper border, with printed address rules and
    // a cancellation ring. It has no independent floor shadow or body.
    c.save();c.beginPath();c.rect(left+1,top+2.8,w-2,10);c.clip();c.globalAlpha=.88;
    const pw=9.2,ph=pw*q[3]/q[2];c.drawImage(r.images.acting,q[0],q[1],q[2],q[3],left+(w-pw)/2,top+3,pw,ph);c.restore();
    c.strokeStyle='#a3987b';c.lineWidth=.4;for(let j=0;j<2;j++){c.beginPath();c.moveTo(left+2,top+14+j*1.8);c.lineTo(left+w-2-j,top+14+j*1.8);c.stroke();}
    c.strokeStyle='#9d7f59';c.lineWidth=.35;c.beginPath();c.arc(left+w-2.7,top+11.3,1.5,0,Math.PI*2);c.stroke();
    if(!k){c.fillStyle='#3e7470';c.fillRect(left+2,top+17.4,w-4,2);}
    }
    // Paint each slot with its card, rear first, so its lip cannot cross the next portrait.
    const y=-3-k*10.5;
    polygon([{x:-8,y:y},{x:7.5,y:y},{x:7.5,y:y+3.1},{x:-8,y:y+3.1}],'#b98750');
    c.strokeStyle='#f2d29c';c.lineWidth=.7;c.beginPath();c.moveTo(-8,y);c.lineTo(7.5,y);c.stroke();
    c.strokeStyle='#8b603d';c.lineWidth=.45;c.beginPath();c.moveTo(-7,y+2.7);c.lineTo(6.5,y+2.7);c.stroke();
   }
   c.fillStyle='#e9c784';c.fillRect(-3.4,-.2,6.8,1.5);c.fillStyle='#786849';c.fillRect(-2,-.05,4,.35);
   this.frames.push(canvas);this.bytes+=canvas.width*canvas.height*4;
  }
 }
 draw(h,state,edit){
  if(h.cats.length<2)return;
  const r=this.r,c=r.ctx,x=760+(h.x+LAYOUT.cx-h.y-LAYOUT.cy)*HW,y=465+(h.x+LAYOUT.cx+h.y+LAYOUT.cy)*HH;
  c.drawImage(this.frames[TicketRack.frame(state,edit)],x-24,y-52,48,64);
  const extra=Math.max(0,state.waiting-(edit?1:0)-TicketRack.count(state,edit));
  if(extra){c.font='7px Trebuchet MS,sans-serif';c.textAlign='center';c.fillStyle='#345f5c';c.fillText(this.counts[Math.min(extra,99)],x,y-40);}
 }
}
root.CivicTicketRack=TicketRack;
if(typeof module==='object'&&module.exports)module.exports=TicketRack;
})(typeof globalThis!=='undefined'?globalThis:this);
