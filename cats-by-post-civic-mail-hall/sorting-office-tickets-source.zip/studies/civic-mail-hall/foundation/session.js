/* Pure adapter: original rule ticks and BOARDANIM traces, with no drawing dependencies. */
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else root.CivicSession=factory();
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  function create(R,BA,levels){
    const beat=R.GR_TICK_MS/1000, cw=['U','R','D','L'], types=R.GR_TYPES;
    const s={level:null,index:0,chutes:[],tray:{},selected:'plain',mode:'edit',elapsed:0,sim:null,traces:[],poses:[],events:[],gateTrace:null};
    let slots=Object.create(null);
    const same=(p,q)=>p.x===q.x&&p.y===q.y&&p.type===q.type&&p.dir===q.dir;
    function choose(){if(!(s.tray[s.selected]>0))s.selected=types.find(t=>s.tray[t]>0)||s.selected;}
    function pose(){for(let i=0;i<s.traces.length;i++)BA.pose(s.traces[i],s.elapsed,s.poses[i]);}
    s.reset=function(){s.mode='edit';s.sim=null;s.elapsed=0;s.events=[];s.traces=[];s.poses=[];s.gateTrace=null;return s;};
    s.load=function(index){if(!Number.isInteger(index)||index<0||index>=levels.length)throw new RangeError('Invalid Office index');s.level=levels[index];s.index=index;s.chutes=[];s.tray={plain:s.level.tray.plain|0,ginger:s.level.tray.ginger|0,blue:s.level.tray.blue|0};s.selected='plain';choose();return s.reset();};
    s.select=function(type){if(types.includes(type))s.selected=type;return s;};
    s.tap=function(x,y){
      if(s.mode==='running'||!Number.isInteger(x)||!Number.isInteger(y)||x<0||y<0||x>=s.level.board.w||y>=s.level.board.h)return false;
      if(['hatches','dogs','baskets','gates'].some(k=>(s.level[k]||[]).some(p=>p.x===x&&p.y===y)))return false;
      if(s.mode!=='edit')s.reset();
      const k=s.chutes.findIndex(p=>p.x===x&&p.y===y);
      if(k>=0){const p=s.chutes[k];if(p.locked)return false;const d=cw.indexOf(p.dir);if(d===3){s.chutes.splice(k,1);s.tray[p.type]++;}else p.dir=cw[d+1];}
      else{choose();if(!(s.tray[s.selected]>0))return false;const type=s.selected;s.tray[type]--;s.chutes.push({x,y,type,dir:'U'});choose();}return true;
    };
    s.clear=function(){if(s.mode==='running')return false;if(s.mode!=='edit')s.reset();for(const p of s.chutes)if(!p.locked)s.tray[p.type]++;s.chutes=s.chutes.filter(p=>p.locked);choose();return true;};
    s.hint=function(){
      if(s.mode==='running')return null;
      const h=s.level.solution.find(q=>!s.chutes.some(p=>same(p,q)));if(!h)return null;
      const P=s.chutes.filter(p=>p.x!==h.x||p.y!==h.y),T={...s.tray};
      for(const p of s.chutes)if(p.x===h.x&&p.y===h.y)T[p.type]++;
      if(T[h.type]>0)T[h.type]--;else{const k=P.findIndex(p=>p.type===h.type&&!p.locked&&!s.level.solution.some(q=>same(p,q)));if(k<0)return null;P.splice(k,1);}
      if(s.mode!=='edit')s.reset();P.push({x:h.x,y:h.y,type:h.type,dir:h.dir,locked:true});s.chutes=P;s.tray=T;choose();return h;
    };
    function tick(){
      const sim=s.sim,t=sim.tick;R.grTick(sim);
      if(s.gateTrace)BA.recordGates(s.gateTrace,sim,(t+1)*beat);
      for(let i=0;i<sim.n;i++){
        const tr=s.traces[i],ev=sim.ev[i];
        if(ev===R.GE_RELEASED){tr.big=!!sim.big[i];tr.rel=(t+1)*beat;tr.tick=tr.pop=beat;tr.hx=sim.x[i];tr.hy=sim.y[i];tr.hatchDir=sim.dir[i];tr.ox=tr.oy=0;tr.bw=sim.W;tr.bh=sim.H;tr.coat=sim.coat[i];tr.look=i&3;tr.blinkPhase=(i*13)%40;}
        else if(ev>=R.GE_MOVED&&ev<=R.GE_WAIT){
          BA.record(tr,sim.px[i],sim.py[i],sim.pdir[i],sim.x[i],sim.y[i],sim.dir[i],ev,sim.bounced[i]);BA.recordDestination(tr,sim,i);
          if(ev===R.GE_DELIVERED){if(tr.homeKind!=='flap'){const key=sim.x[i]+','+sim.y[i],k=slots[key]|0;slots[key]=k+1;if(k>0){tr.homeDX=3;tr.homeDY=-3;}}
            s.events.push({t:(t+1)*beat+BA.T_NAP,x:sim.x[i]*16+8+tr.homeDX,y:sim.y[i]*16+8+tr.homeDY,coat:sim.coat[i],done:false});}
        }
      }
      if(sim.outcome!==R.GO_RUNNING)for(const tr of s.traces)if(tr.end===BA.END_RUNNING&&tr.rel!==Infinity)tr.end=BA.END_STOPPED;
    }
    s.send=function(){
      if(s.mode==='running')return s.reset();
      s.sim=R.grCreate(s.level,s.chutes);s.elapsed=0;s.mode='running';s.events=[];slots=Object.create(null);
      s.traces.length=s.poses.length=s.sim.n;
      for(let i=0;i<s.sim.n;i++){let tr=s.traces[i];if(!tr||tr.max<s.sim.timeLimit+2)tr=s.traces[i]=BA.makeTrace(s.sim.timeLimit+2);BA.reset(tr);tr.rel=Infinity;tr.pop=beat;if(!s.poses[i])s.poses[i]=BA.makeOut();}
      s.gateTrace=s.sim.gates.length?BA.makeGateTrace(s.sim.n*s.sim.timeLimit):null;tick();pose();return s;
    };
    s.step=function(dt){
      if(!Number.isFinite(dt)||dt<0)throw new RangeError('Step must be finite nonnegative seconds');
      if(s.mode==='edit'||!s.sim)return s;
      s.elapsed+=dt;
      if(s.mode==='running'){
        while(s.sim.outcome===R.GO_RUNNING&&s.elapsed+1e-10>=s.sim.tick*beat)tick();
        if(s.sim.outcome!==R.GO_RUNNING&&s.elapsed+1e-10>=s.sim.tick*beat)s.mode=s.sim.outcome===R.GO_WON?'won':'lost';
      }
      for(const e of s.events)if(!e.done&&s.elapsed+1e-10>=e.t)e.done=true;
      pose();return s;
    };
    return s.load(0);
  }
  return {create};
});
