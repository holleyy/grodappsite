'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Details=require('./office-details.js'),P=require('./projection.js');

function recordingPainter(){
 const vertices=[],boxes=[];
 return{vertices,boxes,
  box(x,y,w,h,z,height){boxes.push({x,y,w,h,z,height});for(const xx of [x,x+w])for(const yy of [y,y+h])for(const zz of [z,z+height])vertices.push([xx,yy,zz]);},
  poly(points){vertices.push(...points);},line3(a,b){vertices.push(a,b);}
 };
}
test('counter details stand on the worktop and keep postal lanes and board clear',()=>{
 for(const top of [58,70]){
  const p=recordingPainter();Details.drawCounter(p,{bench:{top}});
  for(const [x,y,z] of p.vertices){
   assert.ok(x>-1.39&&x<-.95,'detail enters return rollers or leaves the counter');
   assert.ok(y>1.60&&y<2.97,'detail enters scale or dispatch work area');
   assert.ok(z>=top,'detail sinks below the supporting worktop');
   const point=P.project(x,y,z);assert.ok(P.unproject(point.x,point.y).x<0,'detail hides the playable board');
  }
  assert.ok(p.boxes.some(b=>b.z===top),'ledger has no worktop contact');
  assert.ok(p.vertices.some(v=>v[0]===-1.11+.066&&v[2]===top),'mug has no worktop contact');
  assert.ok(p.vertices.some(v=>v[0]===-1.15+.095&&v[2]===top),'lamp has no worktop contact');
 }
});
test('gallery details retain supported footprints and leave the front passage open',()=>{
 const p=recordingPainter();Details.drawGallery(p);
 for(const [x,y,z] of p.vertices){
  assert.ok(y<=-1.0&&y>=-1.83&&z>=182,'detail leaves gallery support or passage reservation');
  const point=P.project(x,y,z);assert.ok(P.unproject(point.x,point.y).y<0,'gallery detail hides the playable board');
 }
 const bench=Details.supports.find(s=>s.name==='gallery bench');
 const cloth=Details.supports.find(s=>s.name==='folded throw');
 assert.equal(bench.y0,-1.58);assert.equal(bench.y1,-1.03);
 for(const [x,y,z] of p.vertices)if(x>=bench.x0&&x<=bench.x1){
  assert.ok(y>=bench.y0&&y<=bench.y1+1e-9&&z>=bench.z0&&z<=bench.z1,'rendered bench or textile diverges from its supported footprint');
 }
 assert.equal(cloth.supportZ,bench.seat);
 assert.ok(cloth.x0>=bench.x0&&cloth.x1<=bench.x1&&cloth.y0>=bench.y0&&cloth.y1<=bench.y1);
 const feet=p.boxes.filter(b=>b.z===182&&b.height===19);assert.equal(feet.length,4);
 for(const foot of feet)assert.equal(foot.z+foot.height+4,bench.seat);
 assert.ok(p.boxes.some(b=>b.x===cloth.x0&&b.y===cloth.y0&&b.z===cloth.supportZ&&Math.abs(b.y+b.h-cloth.y1)<1e-9),'textile did not move with the supporting seat');
 const bundle=Details.supports.find(s=>s.name==='postal bundle');
 assert.ok(bundle.z1-bundle.supportZ<=16);
 assert.ok(p.boxes.some(b=>b.x>=bundle.x0&&b.x+b.w<=bundle.x1&&b.y>=bundle.y0&&b.y+b.h<=bundle.y1&&b.z===bundle.supportZ));
});
