/* Civic architecture study: cached paper hall, registered live pieces and
 * unchanged Office trace clocks on the shared floor plane. */
(function(root){
'use strict';
const P=CivicProjection;
const depthOrder=(a,b)=>a.depth-b.depth||a.order-b.order;
class Renderer{
 constructor(canvas,assets){this.canvas=canvas;this.ctx=canvas.getContext('2d');this.assets=assets;this.images={};this.ready=false;this.config={width:1,height:1,w:5,h:3,mode:'play',zoom:1,panX:0,panY:0};this.scenery=new CivicSceneryCache(this);this.guides=false;this.selected=null;this.gray=false;this.motion=true;this.ambient=0;this.acting=CivicActing.create(BOARDANIM);this.pieces=new CivicPieces(this);this.tickets=new CivicTicketRack(this);this.poses=[];this.items=[];this.pool=[];this.sceneLevel=null;this.backdrop=new CivicBackdrop(this);this.roomLife=new CivicRoomLife(this);this.canal=new CivicCanal(this);this.postal=new CivicPostal(this);this.architecture=new CivicArchitecture(this);this.observer=new ResizeObserver(()=>this.resize());this.observer.observe(canvas);this.resize();}
 async load(){await Promise.all(['cats','pieces','acting','materials','decor','fronts','backdrop','houseFront'].map(name=>new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>{this.images[name]=im;resolve();};im.onerror=()=>reject(Error('Artwork did not load: '+name));im.src=this.assets[name].src;})));this.backdrop.bake();this.architecture.bake();this.canal.bake();this.postal.bake();this.tickets.bake();this.config.sceneBounds=this.architecture.bounds;this.ready=true;}
 resize(){const r=this.canvas.getBoundingClientRect();this.config.width=r.width;this.config.height=r.height;this.dpr=Math.min(devicePixelRatio||1,2);this.canvas.width=Math.round(r.width*this.dpr);this.canvas.height=Math.round(r.height*this.dpr);this.cam=P.camera(this.config);}
 fit(mode){this.config.mode=mode;this.config.zoom=1;this.config.panX=this.config.panY=0;this.cam=P.camera(this.config);}
 zoom(delta,x,y){const next=Math.max(.7,Math.min(2.5,this.config.zoom+delta)),pan=P.zoomAt(this.config,{x,y},next);Object.assign(this.config,pan,{zoom:next});this.cam=P.camera(this.config);}
 drag(dx,dy){this.config.panX+=dx;this.config.panY+=dy;this.cam=P.camera(this.config);}
 cellAt(x,y){const r=this.canvas.getBoundingClientRect(),p=P.fromScreen({x:x-r.left,y:y-r.top},this.cam);return P.pick(p.x,p.y,this.config.w,this.config.h);}
 screenCell(x,y){const r=this.canvas.getBoundingClientRect(),p=P.toScreen(P.centre(x,y),this.cam);return{x:p.x+r.left,y:p.y+r.top};}
 sprite(sheet,index,x,bottom,width){const r=this.assets[sheet].rects[index];this.ctx.drawImage(this.images[sheet],r[0],r[1],r[2],r[3],x-width/2,bottom-width*r[3]/r[2],width,width*r[3]/r[2]);}
 path(points,fill,stroke,width=1){const c=this.ctx;c.beginPath();for(let i=0;i<points.length;i++){const p=points[i];if(i)c.lineTo(p.x,p.y);else c.moveTo(p.x,p.y);}c.closePath();if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=width;c.stroke();}}
 shadow(x,y,rx,ry,alpha=.13){const c=this.ctx;c.fillStyle='rgba(65,51,35,'+alpha+')';c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fill();}
 line(a,b,color='#71918e',width=1.3){const c=this.ctx;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);c.strokeStyle=color;c.lineWidth=width;c.stroke();}
 label(text,p,colour='#5e7774',size=12){const c=this.ctx;c.font=size+'px Trebuchet MS, sans-serif';c.textAlign='center';c.fillStyle=colour;c.fillText(text,p.x,p.y);}
 board(w,h){
  const c=this.ctx,[a,b,e,d]=P.corners(w,h);
  // One sheet of card: thickness belongs only to its two outside front edges.
  this.path([d,e,{x:e.x,y:e.y+3},{x:d.x,y:d.y+3}],'#bba079');
  this.path([b,e,{x:e.x,y:e.y+3},{x:b.x,y:b.y+3}],'#a88d68');
  if(!this.paper){
   const paper=document.createElement('canvas');paper.width=paper.height=64;
   // Only blue paper grain, well inside the source tile. None of its painted
   // edges, perspective or bevels can enter the floor geometry.
   paper.getContext('2d').drawImage(this.images.pieces,128,161,64,32,0,0,64,64);
   this.paper=c.createPattern(paper,'repeat');
  }
  c.save();this.path([a,b,e,d],'#7c8da7');c.clip();
  c.transform(P.HW/96,P.HH/96,-P.HW/96,P.HH/96,a.x,a.y);
  c.fillStyle=this.paper;c.fillRect(0,0,w*96,h*96);c.restore();
  // Small stock variations stay coplanar; they add no raised tile faces.
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
   const tint=((x*17+y*31)%7-3)*.008;
   this.path([P.project(x,y),P.project(x+1,y),P.project(x+1,y+1),P.project(x,y+1)],tint<0?'rgba(35,53,78,'+(-tint)+')':'rgba(255,248,226,'+tint+')');
  }
  // Each seam is a single continuous line through the shared grid vertices.
  c.beginPath();
  for(let x=1;x<w;x++){const p=P.project(x,0),q=P.project(x,h);c.moveTo(p.x,p.y);c.lineTo(q.x,q.y);}
  for(let y=1;y<h;y++){const p=P.project(0,y),q=P.project(w,y);c.moveTo(p.x,p.y);c.lineTo(q.x,q.y);}
  c.strokeStyle='#ead8b5';c.lineWidth=2.1;c.stroke();
  this.path([a,b,e,d],null,'#eddbb8',2.6);
 }
 structure(w,h){
  this.backdrop.draw();this.canal.draw(this.ambient);this.architecture.draw();this.canal.drawMailBoat(this.ambient);
  if(!this.guides)return;
  const f=CivicArchitecture.layout().floor;
  for(let x=-3;x<=7;x++)this.line(P.project(x,f.y0),P.project(x,f.y1),'#3b8d8866',.8);
  for(let y=-2;y<=5;y++)this.line(P.project(f.x0,y),P.project(f.x1,y),'#3b8d8866',.8);
  this.path(P.corners(w,h),null,'#287b75',1.5);
 }

 crew(){this.postal.draw(this.ambient);}

 prepare(s){
  if(this.sceneLevel!==s.level){this.sceneLevel=s.level;let first=0;this.hatches=s.level.hatches.map(h=>{const v={...h,first};first+=h.cats.length;return v;});this.hatchStates=this.hatches.map(()=>this.acting.makeHatchOut());this.dogStates=(s.level.dogs||[]).map(()=>this.acting.makeDogOut());this.preview=this.hatches.map(h=>{const o=this.acting.makeOut();o.anim=BOARDANIM.A.IDLE;o.x=h.x*16+8;o.y=h.y*16+8;o.dir=o.head=OfficeRules.GR_DIR[h.dir];return o;});this.previewTraces=this.hatches.map(h=>({coat:(typeof h.cats[0]==='string'?h.cats[0]:h.cats[0].coat)==='blue'?2:1}));}
  while(this.poses.length<s.traces.length)this.poses.push(this.acting.makeOut());this.poses.length=s.traces.length;
  for(let i=0;i<s.traces.length;i++)this.acting.sample(s.traces[i],s.elapsed,this.poses[i]);
  for(let i=0;i<this.hatches.length;i++)this.acting.hatch(this.hatches[i],s.traces,s.elapsed,this.hatchStates[i]);
  for(let i=0;i<this.preview.length;i++)this.preview[i].eyes=this.motion&&(Math.floor(this.ambient*10)+i*13)%40===0?1:0;
  for(let i=0;i<this.dogStates.length;i++)this.acting.dog(s.level.dogs[i],i,this.poses,this.motion?this.ambient:0,this.dogStates[i]);
  this.pieces.motion=this.motion;
 }
 item(kind,index,depth,order=0){const k=this.items.length;let item=this.pool[k];if(!item)item=this.pool[k]={kind:0,index:0,depth:0,order:0};item.kind=kind;item.index=index;item.depth=depth;item.order=order;this.items.push(item);}
 draw(s){
  if(!this.ready)return;const c=this.ctx,L=s.level,B=L.board;
  this.config.w=B.w;this.config.h=B.h;this.cam=P.camera(this.config);
  c.setTransform(this.dpr,0,0,this.dpr,0,0);c.clearRect(0,0,this.config.width,this.config.height);c.fillStyle='#ddd3b7';c.fillRect(0,0,this.config.width,this.config.height);
  c.save();if(this.gray)c.filter='grayscale(1)';c.translate(this.cam.tx,this.cam.ty);c.scale(this.cam.scale,this.cam.scale);c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';
  this.prepare(s);this.structure(B.w,B.h);
  this.board(B.w,B.h);
  if(this.selected){const{x,y}=this.selected;this.path([P.project(x,y),P.project(x+1,y),P.project(x+1,y+1),P.project(x,y+1)],'#fff7d22b','#fff3c8',2);}
  for(const t of s.chutes){let spin=0;for(const o of this.poses)if(o.spinX===t.x&&o.spinY===t.y)spin=Math.max(spin,o.spin);this.pieces.table(t,spin);}
  for(let i=0;i<this.hatches.length;i++)this.pieces.hatch(this.hatches[i],this.hatchStates[i]);
  this.items.length=0;
  for(let i=0;i<L.baskets.length;i++){const b=L.baskets[i],p=P.centre(b.x,b.y);this.item('basket',i,p.y-2);this.item('basket-front',i,p.y+24,5);}
  for(let i=0;i<(L.dogs||[]).length;i++){const d=L.dogs[i];this.item('dog',i,P.centre(d.x,d.y).y+5);}
  if(s.mode==='edit')for(let i=0;i<this.hatches.length;i++){const h=this.hatches[i];this.item('preview',i,P.centre(h.x,h.y).y+2);}
  else for(let i=0;i<this.poses.length;i++){const o=this.poses[i];if(!o.cat.visible)continue;
   if(o.box.visible&&!o.box.occupied)this.item('box',i,P.project(o.boxX/16,o.boxY/16).y+1);
   this.item(o.cat.boxed?'boxed':'cat',i,P.project(o.x/16,o.y/16).y+2,o.anim===BOARDANIM.A.PUZZLED?8:1);
  }
  for(let i=0;i<this.hatches.length;i++){const h=this.hatches[i];this.item('tickets',i,465+(h.x+h.y+1)*P.HH+5,4);}
  this.items.sort(depthOrder);
  for(const item of this.items){const i=item.index,o=this.poses[i],tr=s.traces[i];switch(item.kind){
   case 'tickets':this.tickets.draw(this.hatches[i],this.hatchStates[i],s.mode==='edit');break;
   case 'basket':this.pieces.basket(L.baskets[i]);break;
   case 'basket-front':this.pieces.basket(L.baskets[i],true);break;
   case 'dog':this.pieces.dog(L.dogs[i],i,this.dogStates[i]);break;
   case 'preview':this.pieces.boxed(this.preview[i],this.previewTraces[i],this.ambient);break;
   case 'box':this.pieces.carrier(o.boxX,o.boxY,tr.d0[tr.n-1],o.boxFold,o.boxFade);break;
   case 'boxed':this.pieces.boxed(o,tr,s.elapsed);break;
   case 'cat':this.pieces.loose(o,tr,s.elapsed);break;
  }}
  for(let i=0;i<this.hatches.length;i++)if(this.hatchStates[i].open)this.pieces.hatchFront(this.hatches[i]);
  this.crew(B.h);this.backdrop.drawForeground();
  if(this.guides){for(let x=0;x<B.w;x++)this.label(String.fromCharCode(65+x),P.project(x+.5,B.h+.28));for(let y=0;y<B.h;y++)this.label(String(y+1),P.project(B.w+.28,y+.5));}
  c.restore();
 }
}
root.CivicRenderer=Renderer;
})(globalThis);
