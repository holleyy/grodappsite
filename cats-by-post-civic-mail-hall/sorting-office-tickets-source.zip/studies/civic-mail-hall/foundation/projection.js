(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.CivicProjection = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const HW = 380 / 6;
  const HH = 190 / 6;

  function project(x, y, z = 0) {
    return { x: 760 + (x - y) * HW, y: 465 + (x + y) * HH - z };
  }
  function centre(x, y) { return project(x + 0.5, y + 0.5); }
  function unproject(px, py, z = 0) {
    const difference = (px - 760) / HW;
    const sum = (py - 465 + z) / HH;
    return { x: (sum + difference) / 2, y: (sum - difference) / 2 };
  }
  function corners(w, h) {
    return [project(0, 0), project(w, 0), project(w, h), project(0, h)];
  }
  function pick(px, py, w, h) {
    const point = unproject(px, py);
    if (point.x < 0 || point.y < 0 || point.x >= w || point.y >= h) return null;
    return { x: Math.floor(point.x), y: Math.floor(point.y) };
  }
  function camera({ width, height, w, h, mode = 'play', zoom = 1, panX = 0, panY = 0, sceneBounds = null }) {
    // The canvas occupies its own DOM region: HUD space is already excluded.
    let left = -200, right = 1700, top = 0, bottom = 1100;
    if(mode==='explore'&&sceneBounds)({left,right,top,bottom}=sceneBounds);
    if (mode !== 'explore') {
      const c = corners(w, h);
      left = Math.min(...c.map(p => p.x)) - 80;
      right = Math.max(...c.map(p => p.x)) + 80;
      top = Math.min(...c.map(p => p.y)) - 120;
      bottom = Math.max(...c.map(p => p.y)) + 50;
    }
    const viewportWidth = Math.max(1, width), viewportHeight = Math.max(1, height);
    const scale = Math.min(viewportWidth / (right - left), viewportHeight / (bottom - top)) * Math.max(0.01, zoom);
    return { scale, tx: viewportWidth / 2 - (left + right) * scale / 2 + panX,
      ty: viewportHeight / 2 - (top + bottom) * scale / 2 + panY };
  }
  function toScreen(point, camera) {
    return { x: point.x * camera.scale + camera.tx, y: point.y * camera.scale + camera.ty };
  }
  function fromScreen(point, camera) {
    return { x: (point.x - camera.tx) / camera.scale, y: (point.y - camera.ty) / camera.scale };
  }
  function zoomAt(config, point, newZoom) {
    const anchor = fromScreen(point, camera(config));
    const next = toScreen(anchor, camera({ ...config, zoom: newZoom, panX: 0, panY: 0 }));
    return { panX: point.x - next.x, panY: point.y - next.y };
  }
  return { HW, HH, project, centre, unproject, corners, pick, camera, toScreen, fromScreen, zoomAt };
});
