'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Postal=require('./postal-life.js'),Rig=require('./postal-work-rig.js'),P=require('./projection.js'),A=require('./architecture.js');
const L=Postal.layout();
test('workbench and desk cat use the same shared supporting surface',()=>{
 const desk=require('./room-life.js').layout().find(a=>a.id==='desk');
 const counter=A.layout().solids.find(a=>a.name==='counter');
 assert.equal(counter.x1,L.bench.x1);assert.equal(counter.z1,L.bench.top);assert.equal(desk.z,L.bench.top);
 const boxes=[];Postal.drawStations({box(x,y,w,d,z,h){boxes.push({x,y,w,d,z,h});},face(){},line3(){}});
 assert.ok(boxes.some(b=>b.z+b.h===L.scale.top&&L.scale.x>b.x&&L.scale.x<b.x+b.w&&L.scale.y>b.y&&L.scale.y<b.y+b.d),'scale pan is not under the declared station');
 assert.ok(boxes.some(b=>b.z+b.h===L.bench.top&&3.12>b.y&&3.12<b.y+b.d&&-1.55>b.x&&-1.55<b.x+b.w),'dispatch rollers have no supporting top');
});
test('every rendered worker, wheel and parcel vertex clears the playable floor for the full cycle',()=>{
 const rig=new Rig({}),state=Postal.createState();let count=0;
 for(let i=0;i<=520;i++){
  Postal.sample(i/10,state);rig.mesh.reset();rig.robot(state);rig.cart(state);rig.parcel(state);
  for(let j=0;j<rig.mesh.count;j++){const f=rig.mesh.faces[j];for(let k=0;k<f.count;k++){
   const x=f.vertices[k*3],y=f.vertices[k*3+1],z=f.vertices[k*3+2];
   assert.ok(x<=-.14,'moving mesh enters board at '+i/10+' x='+x);assert.ok(z>=-1e-8,'moving mesh falls through floor at '+i/10);
   const screen=P.project(x,y,z),floor=P.unproject(screen.x,screen.y);assert.ok(floor.x<0,'raised actor covers puzzle floor');count++;
  }}
 }
 assert.ok(count>100000,'complete articulated rig was not sampled');
});
test('rendered rigid limbs reach the exact sole and palm targets throughout the cycle',()=>{
 const rig=new Rig({}),state=Postal.createState(),u=P.HW;
 const distance=(a,b,c,x,y,z)=>Math.hypot((a-x)*u,(b-y)*u,c-z);
 for(let i=0;i<=1040;i++){
  Postal.sample(i/20,state);rig.mesh.reset();rig.robot(state);
  for(let side=0;side<2;side++){
   const o=side*12,v=rig.links,f=state.robot.feet[side],h=state.robot.hands[side];
   assert.ok(Math.abs(distance(v[o],v[o+1],v[o+2],v[o+3],v[o+4],v[o+5])-17)<1e-6,'thigh changes length');
   assert.ok(Math.abs(distance(v[o+3],v[o+4],v[o+5],f.x,f.y,f.z+6)-17)<1e-6,'unreachable foot at '+i/20);
   assert.ok(Math.abs(distance(v[o+6],v[o+7],v[o+8],v[o+9],v[o+10],v[o+11])-22)<1e-6,'upper arm changes length at '+i/20);
   assert.ok(Math.abs(distance(v[o+9],v[o+10],v[o+11],h.x,h.y,h.z)-22)<1e-6,'unreachable palm at '+i/20);
  }
 }
});
