'use strict';
const test=require('node:test'), assert=require('node:assert/strict');
const R=require('./vendor/sim/10_rules.js'), BA=require('./vendor/sim/12_boardanim.js');
const levels=require('./vendor/data/levels.json').levels.filter(l=>!l.room).slice(0,15);
const Session=require('./session.js');
const create=()=>Session.create(R,BA,levels);
test('all 15 original Office records win with their stored routes',()=>{
 const s=create(); assert.equal(levels.length,15);
 levels.forEach((l,i)=>{s.load(i); assert.equal(s.level,l); while(s.hint()){} assert.deepEqual(s.chutes.map(({locked,...p})=>p),l.solution); s.send(); for(let t=0;t<1000&&s.mode==='running';t++)s.step(1/60); assert.equal(s.mode,'won',l.id);});
});
test('release tick zero, exact 300ms steps, and original multi-hatch rule queues',()=>{
 const s=create(); s.load(3);s.send();const direct=R.grCreate(s.level,[]);R.grTick(direct);
 assert.equal(s.sim.tick,1);s.step(17/60);assert.equal(s.sim.tick,1);s.step(1/60);assert.equal(s.sim.tick,2);R.grTick(direct);
 for(let j=0;j<15;j++){assert.deepEqual(s.sim.x,direct.x);assert.deepEqual(s.sim.st,direct.st);s.step(.3);R.grTick(direct);}
 const multi=levels.find(l=>l.hatches.length>1); assert.ok(multi);s.load(levels.indexOf(multi));s.send(); const d=R.grCreate(multi,[]);R.grTick(d);
 for(let j=0;j<15;j++){assert.deepEqual(s.sim.x,d.x);assert.deepEqual(s.sim.ev,d.ev);s.step(.3);R.grTick(d);}
});
test('placement rotates clockwise then returns inventory; immutable tiles reject placement',()=>{
 const s=create(),before={...s.tray};s.tap(1,0);assert.equal(s.chutes[0].dir,'U');for(const dir of ['R','D','L']){s.tap(1,0);assert.equal(s.chutes[0].dir,dir);}s.tap(1,0);assert.equal(s.chutes.length,0);assert.deepEqual(s.tray,before);
 for(const p of [...s.level.hatches,...s.level.baskets,...s.level.dogs])s.tap(p.x,p.y);assert.equal(s.chutes.length,0);
 s.tap(1,0);s.send();s.reset();assert.equal(s.mode,'edit');assert.equal(s.chutes.length,1);s.clear();assert.deepEqual(s.tray,before);
});
test('hint matches original SCORE including replacing and reclaiming pieces',()=>{
 const SCORE=require('./vendor/sim/16_score.js');const s=create();s.tap(1,0);
 const expected=SCORE.applyHint(s.level,s.chutes,s.tray);s.hint();assert.deepEqual(s.chutes,expected.placements);assert.deepEqual(s.tray,expected.tray);s.clear();assert.equal(s.chutes.length,1);
});
test('records and poses equal BOARDANIM and settle after outcome with reused outputs',()=>{
 const s=create();s.hint();s.send();const tr=s.traces[0],p=s.poses[0];assert.equal(tr.rel,.3);assert.equal(p.anim,BA.A.POP);
 s.step(.3);assert.equal(tr.n,1);assert.equal(tr.ev[0],s.sim.ev[0]);assert.deepEqual(p,BA.pose(tr,s.elapsed,BA.makeOut()));
 while(s.mode==='running')s.step(.3);const tick=s.sim.tick;s.step(3);assert.equal(s.sim.tick,tick);assert.equal(s.poses[0],p);assert.equal(p.anim,BA.A.NAP);assert.deepEqual(p,BA.pose(tr,s.elapsed,BA.makeOut()));
});
