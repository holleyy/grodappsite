'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const R=require('./vendor/sim/10_rules.js'),BA=require('./vendor/sim/12_boardanim.js'),Session=require('./session.js');
let Acting;try{Acting=require('./acting.js').create(BA);}catch(e){if(e.code!=='MODULE_NOT_FOUND')throw e;}
// Independent oracle: execute the shipped production function, with its documented
// drawing/asset gates enabled. No Civic formula or copied paper timing is used.
const context=vm.createContext({BOARDANIM:BA,BA:BA.A,TILE:16,paperEnabled:true,paperTakeoffSources:[true],
 clamp:(x,a,b)=>Math.max(a,Math.min(b,x)),lerp:(a,b,t)=>a+(b-a)*t,paperBoardFlapPose:()=>{}});
vm.runInContext(fs.readFileSync(path.resolve(__dirname,'./vendor/render/27a_paper_arrival.js'),'utf8'),context);
const oracle=(tr,t)=>{const p=BA.makeOut();BA.pose(tr,t+1e-9,p);context.paperBoardArrivalPose(p,tr,t+1e-9);return p;};
const flatKeys=[...Object.keys(BA.makeOut()),'takeoff','takeoffSupported'];
// The old renderer is still the oracle for actions and timing. Positions are
// intentionally continuous in this enlarged study; separate trajectory tests
// below verify those floor paths and their unchanged contacts/deadlines.
const presentationKeys=new Set(['x','y','z','bob','boxX','boxY']);
const flat=o=>Object.fromEntries(flatKeys.filter(k=>!presentationKeys.has(k)).map(k=>[k,o[k]]));
const dir=['R','D','L','U'];
function fixture(kind='arrival',coat='ginger',rotation=0,wrong=false,type='plain'){
 let h={x:1,y:3,dir:'R',cats:[coat]},b={x:5,y:3,coat:wrong?(coat==='ginger'?'blue':'ginger'):coat},dogs=[],tables=[];
 if(kind==='turn'){tables=[{x:3,y:3,dir:'U',type}];b={x:3,y:0,coat};}
 if(kind==='straight'){tables=[{x:3,y:3,dir:'R',type}];b={x:6,y:3,coat};}
 if(kind==='mismatch'){tables=[{x:3,y:3,dir:'U',type:coat==='ginger'?'blue':'ginger'}];b={x:6,y:3,coat};}
 if(kind==='dogbounce'){dogs=[{x:5,y:3}];b={x:0,y:3,coat};}
 if(kind==='wallbounce'){h.dir='L';}
 if(kind==='stuck'){dogs=[{x:0,y:3},{x:2,y:3}];b={x:5,y:5,coat};}
 if(kind==='bounce-return-table'){dogs=[{x:5,y:3}];tables=[{x:3,y:3,dir:'R',type:'plain'}];b={x:0,y:0,coat};}
 if(kind==='bounced-terminal'){h.x=2;dogs=[{x:3,y:3}];b={x:1,y:3,coat};}
 if(wrong)b.coat=coat==='ginger'?'blue':'ginger';
 const rotate=p=>{const q={...p};for(let r=0;r<rotation;r++){const x=q.x;q.x=6-q.y;q.y=x;if(q.dir)q.dir=dir[(dir.indexOf(q.dir)+1)&3];}return q;};
 return {id:kind,board:{w:7,h:7},hatches:[rotate(h)],dogs:dogs.map(rotate),baskets:[rotate(b)],tray:{plain:0,ginger:0,blue:0},solution:tables.map(rotate),timeLimit:16};
}
function trace(level,coat='ginger',tick=.3){return BA.runRules(R,level,level.solution,coat,tick,tick,BA.makeTrace(64));}
function compare(tr,t,out){Acting.sample(tr,t,out);assert.deepEqual(flat(out),flat(oracle(tr,t)),`t=${t}, coat=${tr.coat}, d=${tr.hatchDir}, end=${tr.end}`);}
const arrivalTimes=[-.3,-.001,0,.199,.2,.299,.3,.35,.399,.4,.449,.45,.55,.599,.6,.65,.749,.75,.9,1.199,1.2,1.8,3];

test('exports the pure acting factory and returns reused caller outputs',()=>{
 assert.ok(Acting,'CivicActing.create(BOARDANIM) must exist');const out=Acting.makeOut();assert.equal(Acting.sample(trace(fixture()),0,out),out);
 const h=Acting.makeHatchOut();assert.equal(Acting.hatch(fixture().hatches[0],[],0,h),h);const d=Acting.makeDogOut();assert.equal(Acting.dog({x:0,y:0},0,[],0,d),d);
 const browser=vm.createContext({});vm.runInContext(fs.readFileSync(path.resolve(__dirname,'./acting.js'),'utf8'),browser);assert.equal(typeof browser.CivicActing.create,'function');
});
test('production action oracle: both coats, four headings, correct/wrong, boundaries and offset homes',()=>{
 const out=Acting.makeOut();
 for(const coat of ['ginger','blue'])for(let rotation=0;rotation<4;rotation++)for(const wrong of [false,true])for(const tick of [.3,.5])for(const kind of ['arrival','bounced-terminal']){
  const tr=trace(fixture(kind,coat,rotation,wrong),coat,tick);tr.ox=32;tr.oy=-16;tr.homeDX=3;tr.homeDY=-3;
  const a=tr.rel+tr.n*tick;
  for(const t of arrivalTimes)compare(tr,a+t,out);
  for(const b of [0,.2,.3,.4,.45,.55,.6,.65,.75,.9,1.2])for(const delta of [-1e-7,0,1e-7])compare(tr,a+b+delta,out);
  for(const f of [0,.12,.8,.9,1])for(const delta of [-1e-7,0,1e-7])compare(tr,tr.rel-tr.pop+f*tr.pop+delta,out);
 }
});
test('real movement traces retain head lead, spin, bounce, stuck, wall filtering and bounced-terminal exception',()=>{
 const out=Acting.makeOut();let bounce=0,stuck=0,headLead=0,spin=0;
 for(const coat of ['ginger','blue'])for(let rotation=0;rotation<4;rotation++)for(const tick of [.3,.5]){
  for(const kind of ['dogbounce','wallbounce','stuck','bounce-return-table','bounced-terminal','mismatch','turn','straight']){
   for(const type of kind==='turn'||kind==='straight'?['plain','ginger','blue']:['plain']){
    const tr=trace(fixture(kind,coat,rotation,false,type),coat,tick);
    for(let k=0;k<tr.n;k++){
     for(let f=0;f<Math.round(tick*10);f++){
      compare(tr,tr.rel+k*tick+(f+.5)/10,out);
      bounce+=out.anim===BA.A.BOUNCE;stuck+=out.anim===BA.A.STUCK;headLead+=out.dir!==out.head;spin+=out.spin>0;
      if(kind==='wallbounce')assert.equal(out.bumpX,-1);
      if(kind==='mismatch'||kind==='straight')assert.equal(out.spin,0);
     }
     compare(tr,tr.rel+(k+1)*tick-1e-7,out);
    }
    if(kind==='bounced-terminal'){assert.equal(tr.bn[tr.n-1],1);for(const dt of [-tick,-.001,0,.2,.4,.6])compare(tr,tr.rel+tr.n*tick+dt,out);}
   }
  }
 }
 assert.ok(bounce&&stuck&&headLead&&spin,'fixtures must exercise actual animation branches');
});
test('wake and leave retain absolute schedule, original headings and flap pulse',()=>{
 const out=Acting.makeOut();
 for(let heading=0;heading<4;heading++){
  const tr=trace(fixture());tr.napUntil=tr.rel+tr.n*tr.tick+5;tr.leaveDir=heading;
  for(const dt of [-1e-7,0,.3,.6,.9,1.11,1.23,1.33,1.45,1.5-1e-7,1.5,1.5+1e-7])compare(tr,tr.napUntil+dt,out);
 }
});
test('records express separate carrier, fixed paw support, roots and real effect targets',()=>{
 const tr=trace(fixture()),a=tr.rel+tr.n*tr.tick,out=Acting.makeOut();
 Acting.sample(tr,a+.199,out);assert.ok(out.cat.boxed&&out.box.occupied);assert.equal(out.box.x,out.x);
 Acting.sample(tr,a+.3,out);const support=[out.x,out.y,out.z];assert.equal(out.cat.boxed,false);assert.equal(out.box.occupied,false);assert.ok(out.rim.visible&&out.cat.supported);assert.equal(out.cat.x,out.x);assert.equal(out.rim.x,out.boxX+4);
 Acting.sample(tr,a+.35,out);assert.deepEqual([out.x,out.y,out.z],support);
 Acting.sample(tr,a+.4,out);assert.equal(out.rim.visible,false);assert.equal(out.box.fold,0);assert.equal(out.root.phase,'flight');
 Acting.sample(tr,a+.45,out);assert.equal(out.box.fold,1);
 Acting.sample(tr,a+.9,out);assert.ok(out.effects.cushionOccupied);assert.equal(out.root.phase,'settling');
 Acting.sample(tr,a+1.2,out);assert.equal(out.box.visible,false);assert.equal(out.root.phase,'nap');
 const wrong=trace(fixture('arrival','blue',0,true),'blue');for(const dt of [.6,2,20,600]){Acting.sample(wrong,wrong.rel+wrong.n*wrong.tick+dt,out);assert.equal(out.box.visible,true);assert.equal(out.box.fold,0);assert.equal(out.effects.puzzled,true);assert.equal(out.cat.coat,2);}
});
test('reused outputs and nested records are deterministic under poisoned, rewound and hidden sampling; one epsilon only',()=>{
 const tr=trace(fixture()),before=structuredClone(tr),out=Acting.makeOut(),identities={root:out.root,cat:out.cat,box:out.box,rim:out.rim,effects:out.effects,base:out.base};
 const a=tr.rel+tr.n*tr.tick;
 for(const t of [a+.35,a+5,-1,a+.45,0,a+.2,a+1.3,-1]){
  for(const key of flatKeys)out[key]=999;for(const key of ['root','cat','box','rim','effects','base'])for(const k of Object.keys(out[key]))out[key][k]=999;
  Acting.sample(tr,t,out);const fresh=Acting.sample(tr,t,Acting.makeOut());assert.deepEqual(out,fresh);
  for(const key of Object.keys(identities))assert.equal(out[key],identities[key]);
 }
 assert.deepEqual(tr,before);assert.equal(out.box.visible,false);assert.equal(out.rim.visible,false);assert.equal(out.effects.spin,0);assert.equal(out.effects.bumpAge,-1);
 compare(tr,a+.2-1.5e-9,out);assert.equal(out.takeoff,-1);compare(tr,a+.2-.5e-9,out);assert.equal(out.takeoff,0);
 for(const bad of [NaN,Infinity,-Infinity])assert.throws(()=>Acting.sample(tr,bad,out),RangeError);
});
function recorded(level){const s=Session.create(R,BA,[level]);s.send();while(s.mode==='running')s.step(.3);return s;}
function multi(){const level=fixture();level.hatches=[{x:0,y:2,dir:'R',cats:['ginger','blue','ginger','blue','ginger']},{x:6,y:4,dir:'L',cats:['blue','ginger']}];level.baskets=[{x:6,y:2,coat:'ginger'},{x:0,y:4,coat:'blue'}];return level;}
test('hatch reducer uses real per-hatch release clocks, four portrait cap and pop-start queue removal',()=>{
 const level=multi(),s=recorded(level),out=Acting.makeHatchOut(),entries=out.queue.slice();
 Acting.hatch(level.hatches[0],[],0,out);assert.equal(out.waiting,5);assert.equal(out.n,4);assert.deepEqual(out.queue.slice(0,4).map(p=>p.coat),[1,2,1,2]);
 for(const t of [-1e-7,0,.3-1e-7,.3,.6-1e-7,.6,.9,1.2])for(const [index,h] of level.hatches.entries()){
  Acting.hatch(h,s.traces,t,out);const first=index===0?0:5;
  const ids=h.cats.map((_,j)=>first+j).filter(id=>t+1e-9<s.traces[id].rel-s.traces[id].pop);
  assert.equal(out.waiting,ids.length);assert.equal(out.n,Math.min(4,ids.length));assert.deepEqual(out.queue.slice(0,out.n).map(p=>p.id),ids.slice(0,4));
  const open=Math.max(0,...s.traces.slice(first,first+h.cats.length).map(tr=>oracle(tr,t)).filter(p=>p.anim===BA.A.POP).map(p=>p.hatchOpen));assert.equal(out.open,open);
  for(let j=0;j<4;j++){assert.equal(out.queue[j],entries[j]);if(j>=out.n){assert.equal(out.queue[j].visible,false);assert.equal(out.queue[j].id,-1);assert.equal(out.queue[j].x,0);assert.equal(out.queue[j].y,0);}}
  if(out.n){assert.equal(out.queue[0].x,h.x*16+8+(h.dir==='R'?3:-3));assert.equal(out.queue[0].z,.5);}
 }
 // Artificially move only the second hatch's absolute release clocks: independent reducer.
 for(const tr of s.traces.slice(5))tr.rel+=.15;
 Acting.hatch(level.hatches[0],s.traces,0,out);assert.equal(out.waiting,4);Acting.hatch(level.hatches[1],s.traces,0,out);assert.equal(out.waiting,2);assert.equal(out.open,0);
 Acting.hatch(level.hatches[1],s.traces,.15,out);assert.equal(out.waiting,1);assert.equal(out.open,1);
});
// Execute actual production dog drawing with a recorder in place of raster calls.
const dogContext=vm.createContext({fract:v=>v-Math.floor(v),buildDog:f=>{dogContext.frame=f;},blitSprite:(...args)=>{dogContext.anchor=args;},drawZ:(...args)=>{dogContext.glyph=args;}});
const dogSource=fs.readFileSync(path.resolve(__dirname,'./vendor/render/28_pieces.js'),'utf8');
vm.runInContext(dogSource.slice(dogSource.indexOf('function dogFrame('),dogSource.indexOf('const Z_SMALL')),dogContext);
test('dog reducer matches original ambient frames, mirror, glyph and real dog/stuck bumps',()=>{
 const out=Acting.makeDogOut(),glyph=out.glyph;let reactedDog=false,reactedStuck=false;
 for(const kind of ['dogbounce','stuck','wallbounce']){
  const level=fixture(kind),tr=trace(level),pose=Acting.makeOut();
  const j=Array.from(tr.bn).findIndex(Boolean),bump=tr.rel+j*tr.tick+.2*tr.tick,dx=[1,0,-1,0],dy=[0,1,0,-1];
  const dog=level.dogs.find(d=>d.x===tr.x0[j]+dx[tr.d0[j]]&&d.y===tr.y0[j]+dy[tr.d0[j]])||{x:0,y:3};
  for(const dt of [-1e-7,0,.599,.6]){
   Acting.sample(tr,bump+dt,pose);const lift=pose.bumpX===dog.x&&pose.bumpY===dog.y&&pose.bumpAge>=0&&pose.bumpAge<.6?1:0;
   if(lift&&kind==='dogbounce')reactedDog=true;if(lift&&kind==='stuck')reactedStuck=true;
   for(let index=0;index<2;index++)for(const t of [0,.51,1,1.5,6,6.2,6.3,2.7]){
    const ambient=t-index*1.7;dogContext.glyph=null;dogContext.drawDog(dog.x*16+8,dog.y*16+8,ambient,lift,!!(index&1),index*1.7);
    Acting.dog(dog,index,[pose],ambient,out);assert.equal(out.frame,dogContext.frame);assert.equal(out.earLift,lift);assert.equal(out.mirror,!!(index&1));assert.equal(out.glyph,glyph);assert.equal(out.glyph.visible,dogContext.glyph!==null);
    if(dogContext.glyph)assert.deepEqual([out.glyph.x,out.glyph.y,out.glyph.z,out.glyph.big,out.glyph.fade],Array.from(dogContext.glyph));
   }
  }
 }
 assert.ok(reactedDog&&reactedStuck,'both real bounce and STUCK must lift the matching dog ear');
 Acting.dog({x:5,y:3},0,[],0,out);assert.equal(out.earLift,0);
});
test('wrong delivery retains open carrier while later real-rule cat delivers; stacked baskets keep unoffset boxes',()=>{
 for(const cats of [['blue','ginger'],['ginger','ginger']]){
  const level=fixture();level.hatches[0].cats=cats;const s=recorded(level),poses=s.traces.map(()=>Acting.makeOut());
  assert.equal(s.traces[1].end,BA.END_HOME);assert.equal(s.traces[0].end,cats[0]==='blue'?BA.END_WRONG:BA.END_HOME);
  const time=s.traces[1].rel+s.traces[1].n*.3+.35;s.traces.forEach((tr,i)=>Acting.sample(tr,time,poses[i]));
  if(cats[0]==='blue'){assert.ok(poses[0].box.visible);assert.equal(poses[0].box.fold,0);assert.equal(poses[0].anim,BA.A.PUZZLED);}else{assert.equal(s.traces[1].homeDX,3);assert.equal(s.traces[1].homeDY,-3);assert.equal(poses[1].boxX,5*16+8-14);}
 }
});

test('cat record anchors, mirror and boxed stretch match original drawBoardCat registration',()=>{
 const c=vm.createContext({BOARDANIM:BA,paperEnabled:false,COAT_GINGER:1,buildCatBox:(...args)=>{c.stretch=args[6];},buildLoose:()=>{},blitSprite:(...args)=>{c.blit=args;},drawQMark:()=>{},loopT:0});
 const source=fs.readFileSync(path.resolve(__dirname,'./vendor/render/27_catbox.js'),'utf8');
 vm.runInContext(source.slice(source.indexOf('const BA = BOARDANIM.A;'),source.indexOf('function drawBoardBox(')),c);
 for(let d=0;d<4;d++){
  const tr=trace(fixture('arrival','ginger',d)),out=Acting.makeOut(),a=tr.rel+tr.n*tr.tick;
  for(const time of [0,.35,a+.05,a+.6,a+.7,a+.8,a+.95,a+1.3]){
   Acting.sample(tr,time,out);c.stretch=0;c.drawBoardCat(out,tr);assert.deepEqual([out.cat.x,out.cat.y,out.cat.z],Array.from(c.blit).slice(0,3));assert.equal(out.cat.mirror,!!c.blit[3]);assert.equal(out.cat.stretch,c.stretch);
  }
 }
});

test('hatch scratch is deterministic across cat poses, rewind and empty traces',()=>{
 const level=fixture();level.hatches[0].cats=['ginger','ginger'];level.baskets[0].x=2;
 const s=recorded(level),h=level.hatches[0],out=Acting.makeHatchOut(),base=out.base;
 Acting.hatch(h,s.traces,.95,out);
 assert.deepEqual(out.base,BA.pose(s.traces[1],.95+1e-9,BA.makeOut()),'each cat must start with clean scratch');
 for(const t of [0,-1,3,0]){
  Acting.hatch(h,s.traces,t,out);assert.deepEqual(out,Acting.hatch(h,s.traces,t,Acting.makeHatchOut()));assert.equal(out.base,base);
 }
 Acting.hatch(h,s.traces,3,out);Acting.hatch(h,[],0,out);
 assert.deepEqual(out,Acting.hatch(h,[],0,Acting.makeHatchOut()));assert.equal(out.base,base);
});

// The larger paper scene must not magnify the original two-world-unit pixel
// steps. Keep the rule beat and action clocks, but sample the floor continuously.
test('straight delivery glides through tile boundaries at the original 300ms beat',()=>{
 for(let d=0;d<4;d++){
  const dx=[1,0,-1,0][d],dy=[0,1,0,-1][d],tr=BA.makeTrace(3),out=Acting.makeOut();
  tr.rel=tr.tick=tr.pop=.3;tr.hx=tr.hy=2;tr.hatchDir=d;
  for(let k=0;k<3;k++)BA.record(tr,2+dx*k,2+dy*k,d,2+dx*(k+1),2+dy*(k+1),d,BA.EV_MOVED,0);
  let previous=null,distinct=new Set();
  for(let frame=0;frame<=54;frame++){
   const elapsed=frame/60;Acting.sample(tr,tr.rel+elapsed,out);
   const distance=Math.min(48,(elapsed+1e-9)*16/.3),x=40+dx*distance,y=40+dy*distance;
   assert.ok(Math.abs(out.x-x)<1e-7&&Math.abs(out.y-y)<1e-7,`heading${d}, frame${frame}: continuous position`);
   distinct.add(out.x+','+out.y);
   if(previous)assert.ok(Math.hypot(out.x-previous.x,out.y-previous.y)<.89,'no quantised spatial jump');
   previous={x:out.x,y:out.y};
  }
  assert.equal(distinct.size,55,'each render sample advances, including across tile boundaries');
  for(const k of [1,2]){
   Acting.sample(tr,tr.rel+k*tr.tick-1e-6,out);const x=out.x,y=out.y;
   Acting.sample(tr,tr.rel+k*tr.tick+1e-6,out);
   assert.ok(Math.hypot(out.x-x,out.y-y)<.0002,'adjacent segments meet continuously');
  }
 }
});
test('turning, bouncing and arrival keep their action clocks with subpixel positions',()=>{
 const out=Acting.makeOut();
 for(const kind of ['turn','dogbounce','wallbounce','arrival'])for(let d=0;d<4;d++){
  const tr=trace(fixture(kind,'ginger',d));
  for(let k=0;k<tr.n;k++)for(let frame=0;frame<18;frame++){
   const t=tr.rel+(k+frame/18)*tr.tick;Acting.sample(tr,t,out);const old=oracle(tr,t);
   for(const key of ['anim','frame','dir','head','ears','eyes','spinX','spinY','spin','bumpX','bumpY','bumpAge','hatchOpen','takeoff','takeoffSupported'])assert.equal(out[key],old[key],`${kind} ${key}`);
   if(tr.bn[k]){
    const px=tr.ox+tr.x0[k]*16+8,py=tr.oy+tr.y0[k]*16+8,qx=tr.ox+tr.x1[k]*16+8,qy=tr.oy+tr.y1[k]*16+8;
    assert.ok(out.x>=Math.min(px,qx)-3&&out.x<=Math.max(px,qx)+3);
    assert.ok(out.y>=Math.min(py,qy)-3&&out.y<=Math.max(py,qy)+3);
   }
   if(tr.d1[k]!==tr.d0[k]&&!tr.bn[k]&&tr.ev[k]===BA.EV_MOVED&&frame>=11){
    assert.equal(out.x,tr.ox+tr.x1[k]*16+8);assert.equal(out.y,tr.oy+tr.y1[k]*16+8);
   }
  }
  const arrival=tr.rel+tr.n*tr.tick;
  if(tr.end===BA.END_HOME&&!tr.bn[tr.n-1]){
   Acting.sample(tr,arrival-1e-6,out);const x=out.x,y=out.y;Acting.sample(tr,arrival,out);
   assert.ok(Math.hypot(out.x-x,out.y-y)<1e-6,'approach meets the supported carrier');
  }
 }
});
test('hatch rise and discarded-box slide advance without pixel-grid holds',()=>{
 const tr=trace(fixture()),out=Acting.makeOut(),start=tr.rel-tr.pop;
 let previous=-Infinity;
 for(let frame=0;frame<24;frame++){
  Acting.sample(tr,start+tr.pop*(.16+frame*.024),out);
  assert.ok(out.z>previous,'subpixel hatch rise advances each sample');previous=out.z;
 }
 const arrival=tr.rel+tr.n*tr.tick;previous=Infinity;
 for(let frame=0;frame<24;frame++){
  Acting.sample(tr,arrival+.755+frame/60,out);
  assert.ok(out.boxX<previous,'subpixel discarded carrier slide advances each sample');previous=out.boxX;
 }
});

test('parked carrier, supported takeoff and settled cat roots keep their original contacts',()=>{
 const out=Acting.makeOut();
 for(const coat of ['ginger','blue'])for(let d=0;d<4;d++)for(const wrong of [false,true]){
  const tr=trace(fixture('arrival',coat,d,wrong),coat);tr.homeDX=3;tr.homeDY=-3;
  const arrival=tr.rel+tr.n*tr.tick;
  for(const age of [0,.1,.2,.3,.35,.4,.45,.6,.75,1.2,3]){
   Acting.sample(tr,arrival+age,out);const old=oracle(tr,arrival+age);
   assert.deepEqual([out.x,out.y,out.z],[old.x,old.y,old.z],`contact ${coat}/${d}/${wrong} at${age}`);
  }
 }
});
