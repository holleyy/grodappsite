/* High-quality scenery is resampled only when the view changes. The prepared
 * visible pixels are then copied one-to-one, without filtering giant layers
 * on every delivery frame. Moving water fragments, actors and pieces stay live. */
(function(root){
'use strict';
class SceneryCache{
 constructor(renderer){this.r=renderer;this.entries=new Map();this.bytes=0;this.bakes=0;}
 clear(){for(const e of this.entries.values())e.canvas.width=e.canvas.height=1;this.entries.clear();this.bytes=0;}
 draw(image,x,y,w,h){
  const r=this.r,c=r.ctx,cam=r.cam,d=r.dpr,s=cam.scale*d,tx=cam.tx*d,ty=cam.ty*d;
  const cw=c.canvas.width,ch=c.canvas.height;let e=this.entries.get(image);
  if(!e){e={canvas:document.createElement('canvas'),valid:false,bytes:0};e.canvas.width=e.canvas.height=1;this.entries.set(image,e);}
  if(!e.valid||e.s!==s||e.tx!==tx||e.ty!==ty||e.cw!==cw||e.ch!==ch||e.x!==x||e.y!==y||e.w!==w||e.h!==h){
   e.s=s;e.tx=tx;e.ty=ty;e.cw=cw;e.ch=ch;e.x=x;e.y=y;e.w=w;e.h=h;e.valid=true;
   const l=Math.max(0,Math.floor(x*s+tx)),t=Math.max(0,Math.floor(y*s+ty)),right=Math.min(cw,Math.ceil((x+w)*s+tx)),bottom=Math.min(ch,Math.ceil((y+h)*s+ty));
   e.visible=right>l&&bottom>t;e.left=l;e.top=t;this.bytes-=e.bytes;
   e.canvas.width=e.visible?right-l:1;e.canvas.height=e.visible?bottom-t:1;e.bytes=e.canvas.width*e.canvas.height*4;this.bytes+=e.bytes;
   if(e.visible){const cache=e.canvas.getContext('2d');cache.imageSmoothingEnabled=true;cache.imageSmoothingQuality='high';cache.setTransform(s,0,0,s,tx-l,ty-t);cache.drawImage(image,x,y,w,h);}
   this.bakes++;
  }
  if(e.visible){c.save();c.setTransform(1,0,0,1,0,0);c.drawImage(e.canvas,e.left,e.top);c.restore();}
 }
}
root.CivicSceneryCache=SceneryCache;
if(typeof module==='object'&&module.exports)module.exports=SceneryCache;
})(typeof globalThis!=='undefined'?globalThis:this);
