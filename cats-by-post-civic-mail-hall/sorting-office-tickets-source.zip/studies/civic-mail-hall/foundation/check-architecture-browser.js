const fs=require('node:fs'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process');
const H=`for(let i=0;i<150&&!window.__foundation?.ready;i++)await new Promise(r=>setTimeout(r,30));const check=(v,m)=>{if(!v)throw Error(m);};check(__foundation.ready,'assets ready');__foundation.pause(true);const F=__foundation,R=F.renderer,S=F.session,P=CivicProjection;`;
const jobs=[];
for(const [name,device]of [['desktop','1600x1200@1'],['phone','786x1300@2'],['small-phone','640x1136@2'],['landscape','1136x640@2']]){
 jobs.push({url:'http://127.0.0.1:8765/studies/civic-mail-hall/foundation/index.html?view=hall',device,wait:800,js:`(async()=>{${H}
 check(R.config.mode==='explore','hall deep link');check(getComputedStyle(document.querySelector('aside')).display==='none','hall viewport');
 check(!R.guides&&!document.getElementById('guides').checked,'guides default off');
 const b=R.architecture.bounds,rect=R.canvas.getBoundingClientRect();for(const p of [{x:b.left,y:b.top},{x:b.right,y:b.bottom}]){const q=P.toScreen(p,R.cam);check(q.x>=-.01&&q.y>=-.01&&q.x<=rect.width+.01&&q.y<=rect.height+.01,'hall cropped');}
 const count=R.architecture.bakes;for(let i=0;i<15;i++){S.load(i);R.draw(S);}check(R.architecture.bakes===count,'cache rebuilt for board changes');
 F.view('play');R.draw(S);check(getComputedStyle(document.querySelector('aside')).display!=='none','controls restored');for(let i=0;i<15;i++){S.load(i);R.draw(S);for(let y=0;y<S.level.board.h;y++)for(let x=0;x<S.level.board.w;x++){const p=F.cell(x,y),q=R.cellAt(p.x,p.y);check(q?.x===x&&q?.y===y,'picking after explore');}}
 F.view('structure');R.draw(S);return{case:'${name}',bakes:count,hallFits:true,viewReturn:true};})()`,out:'work/civic-architecture/'+name+'-hall.png'});
}
for(const [name,device,gray]of [['desktop-play','1440x1000@1',false],['phone-play','786x1300@2',false],['gray','1440x1000@1',true]])jobs.push({url:'http://127.0.0.1:8765/studies/civic-mail-hall/foundation/index.html',device,wait:800,js:`(async()=>{${H}S.load(3);F.refresh();F.view('play');R.gray=${gray};R.draw(S);return{case:'${name}',board:S.level.board};})()`,out:'work/civic-architecture/'+name+'.png'});
fs.mkdirSync('work/civic-architecture',{recursive:true});fs.writeFileSync('work/civic-architecture/browser-jobs.json',JSON.stringify(jobs));
const r=spawnSync(process.execPath,['tools/snap.js','--batch','work/civic-architecture/browser-jobs.json'],{encoding:'utf8',maxBuffer:2e6,timeout:180000});const log=(r.stdout||'')+(r.stderr||'');fs.writeFileSync('work/civic-architecture/browser.log',log);console.log(log);assert.equal(r.status,0);assert.ok(!/setup error|page exception|page console\.(error|warning|assert)/.test(log));console.log(jobs.length,'architecture browser cases passed');
