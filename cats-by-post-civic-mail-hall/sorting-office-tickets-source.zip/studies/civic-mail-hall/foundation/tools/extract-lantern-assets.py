#!/usr/bin/env python3
"""Decode original PortAssets bytes without resizing, cropping or recompression."""
import argparse, base64, hashlib, json, pathlib, re
ROOT = pathlib.Path(__file__).resolve().parents[4]
p = argparse.ArgumentParser()
p.add_argument('--source', type=pathlib.Path, default=ROOT/'work/civic-v2/lantern-quay.html')
p.add_argument('--public-url', default='https://holleyy.github.io/grodappsite/cats-by-post-lantern-quay/?v=playtest-06')
p.add_argument('--source-url', default='https://raw.githubusercontent.com/holleyy/grodappsite/main/cats-by-post-lantern-quay/index.html')
a=p.parse_args()
raw=a.source.read_bytes()
match=re.search(r'window.PortAssets=(\{.*?\});</script>', raw.decode(), re.S)
assets=json.loads(match[1])
out=pathlib.Path(__file__).resolve().parents[1]/'assets'
out.mkdir(parents=True, exist_ok=True)
manifest={'sourceGitBlob':'6442e8933b802eab5582bfb34eca8941ac20de31','publicUrl':a.public_url,'sourceUrl':a.source_url,'sourceFile':str(a.source.relative_to(ROOT)),'sourceFileSha256':hashlib.sha256(raw).hexdigest(),'method':'Base64 decode only; original WebP bytes, dimensions and rects preserved. No art edited.','assets':{}}
for name, data in assets.items():
    header, encoded=data['src'].split(',',1)
    mime=header.removeprefix('data:').split(';')[0]
    ext={'image/webp':'webp','image/png':'png'}[mime]
    content=base64.b64decode(encoded)
    filename=f'{name}.{ext}'
    (out/filename).write_bytes(content)
    manifest['assets'][name]={k:v for k,v in data.items() if k!='src'}|{'file':filename,'mimeType':mime,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
(out/'rects.json').write_text(json.dumps({name:{k:v for k,v in item.items() if k!='src'} for name,item in assets.items()},indent=2)+'\n')
(out/'provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Extracted',len(assets),'unaltered sheets to',out)
