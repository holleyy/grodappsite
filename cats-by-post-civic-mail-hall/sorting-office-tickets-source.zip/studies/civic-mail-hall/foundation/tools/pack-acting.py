"""Pack generated component masters; preserve original pixels and alpha.

Cell bounds and the largest alpha>16 silhouette identify sprite rectangles.
This excludes fragments of neighbouring sprites at generated row boundaries.
No recolouring, masking,
resampling, background removal or character edits are performed.
"""
from pathlib import Path
from PIL import Image
import json, hashlib

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'assets'
MASTERS=ASSETS/'acting-masters'
COATS=['ginger','blue']
cat_names=['bust-front','bust-rear','crouch-front','crouch-rear','push-front','push-rear','nap','puzzled']
extra_names=['blink','bump-front','bump-rear','wake','walk-front-0','walk-front-1','walk-rear-0','walk-rear-1']
sources=[('cats.png',4,4,[coat+'-'+n for coat in COATS for n in cat_names]),
         ('expressions.png',4,4,[coat+'-'+n for coat in COATS for n in extra_names]),
         ('props.png',4,3,['carrier-D','carrier-R','carrier-L','carrier-U','dog-0','dog-1','dog-2','dog-3','basket-ginger','basket-blue','fold-half','fold-flat'])]
atlas=Image.new('RGBA',(384*8,320*6))
records={}; provenance=[]
def silhouette_bounds(part):
    width,height=part.size
    mask=bytearray(1 if a>16 else 0 for a in part.getchannel('A').getdata())
    best=0;bounds=None
    for start in range(len(mask)):
        if not mask[start]:continue
        stack=[start];mask[start]=0;count=0;x0=width;y0=height;x1=y1=0
        while stack:
            k=stack.pop();x=k%width;y=k//width;count+=1
            x0=min(x0,x);y0=min(y0,y);x1=max(x1,x+1);y1=max(y1,y+1)
            for n in (k-1 if x else -1,k+1 if x+1<width else -1,k-width if y else -1,k+width if y+1<height else -1):
                if n>=0 and mask[n]:mask[n]=0;stack.append(n)
        if count>best:best=count;bounds=(x0,y0,x1,y1)
    return bounds
for filename,cols,rows,names in sources:
    path=MASTERS/filename
    im=Image.open(path).convert('RGBA')
    provenance.append({'file':'acting-masters/'+filename,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':list(im.size)})
    for index,name in enumerate(names):
        col,row=index%cols,index//cols
        cell=(round(col*im.width/cols),round(row*im.height/rows),round((col+1)*im.width/cols),round((row+1)*im.height/rows))
        part=im.crop(cell)
        box=silhouette_bounds(part)
        if box is None: raise ValueError(name+' is empty')
        box=(max(0,box[0]-1),max(0,box[1]-1),min(part.width,box[2]+1),min(part.height,box[3]+1))
        sprite=part.crop(box)
        assert sprite.width<=380 and sprite.height<=316,(name,sprite.size)
        k=len(records); x=(k%8)*384+2;y=(k//8)*320+2
        atlas.paste(sprite,(x,y))
        records[name]={'rect':[x,y,sprite.width,sprite.height],'anchor':[.5,1],
                       'source':filename,'crop':[cell[0]+box[0],cell[1]+box[1],sprite.width,sprite.height]}
atlas.save(ASSETS/'acting.webp','WEBP',quality=94,method=6,alpha_quality=100)
(ASSETS/'acting.json').write_text(json.dumps({'width':atlas.width,'height':atlas.height,'sprites':records},indent=2)+'\n')
(ASSETS/'acting-provenance.json').write_text(json.dumps({'generated':'2026-11-12','direction':'Lantern Quay paper characters and props; new component artwork','masters':provenance,'processing':'Equal-cell extraction, largest connected silhouette bounds exclude adjacent sprite fragments, unscaled packing, WebP encoding. No character edits.','sha256':hashlib.sha256((ASSETS/'acting.webp').read_bytes()).hexdigest()},indent=2)+'\n')
print(len(records),'sprites', (ASSETS/'acting.webp').stat().st_size,'bytes')
