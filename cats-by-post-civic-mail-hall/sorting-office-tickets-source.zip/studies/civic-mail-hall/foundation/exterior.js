/* Static canal-side paper scenery. Every contact, fold and face uses the same
 * world projection as the hall; draw() only replays geometry prepared here. */
(function(root){
'use strict';
const P=root.CivicProjection||(typeof require==='function'?require('./projection.js'):null);
const LAYOUT=Object.freeze({
 canal:Object.freeze({x0:-7,x1:-3.05,y0:-3.5,y1:20,z:-120}),
 frontCanal:Object.freeze({x0:-7,x1:9.4,y0:7.2,y1:20,z:-120}),
 rearCanal:Object.freeze({x0:-7,x1:6.1,y0:-4,y1:-2.2,z:-120}),
 landing:Object.freeze({x0:-4.03,x1:-3,y0:5.3,y1:6.7,z:-91}),
 quay:Object.freeze({x0:-4.03,x1:9.4,y0:-2.8,y1:7.2,z:-91}),
 stairs:Object.freeze({x0:-2.78,x1:-1.58,y0:5.2,y1:6.9,z0:-91,z1:0,steps:7}),
 hall:Object.freeze({x0:-3,x1:7.2,y0:-2,y1:5.2,z:0})
});
const PALETTE={
 water:'#528f83',waterDeep:'#39796f',waterDark:'#2b625d',waterLight:'#8eb8a3',
 stone:'#e3c4a1',stoneLight:'#fae3bb',stoneShade:'#b99a80',stoneDeep:'#867e6c',
 roof:'#99a3a2',roofShade:'#7e9190',roofLight:'#b8bfba',
 timber:'#bda47b',timberLight:'#ddc394',timberShade:'#998369'
};
function emptyBounds(){return{left:Infinity,top:Infinity,right:-Infinity,bottom:-Infinity};}
function grow(bounds,x,y,pad=0){
 bounds.left=Math.min(bounds.left,x-pad);bounds.right=Math.max(bounds.right,x+pad);
 bounds.top=Math.min(bounds.top,y-pad);bounds.bottom=Math.max(bounds.bottom,y+pad);
}
class Exterior{
 constructor(renderer){
  this.r=renderer;this.commands=[];this.props=[];this.bounds=emptyBounds();
  this.build();
 }
 static layout(){return LAYOUT;}
 prop(name,build){
  const prop={name,first:this.commands.length,count:0,bounds:emptyBounds()};
  this.current=prop;build();prop.count=this.commands.length-prop.first;
  this.props.push(prop);this.current=null;
 }
 path(world,fill,stroke=null,width=1){
  if(this.bridgeWide)world=world.map(p=>[p[0]<-4.4?p[0]-(Math.min(1,(-4.4-p[0])/1.1))*1.5:p[0],p[1],p[2]]);
  if(this.offsetZ)world=world.map(p=>[p[0],p[1],p[2]+this.offsetZ]);
  const points=world.map(p=>P.project(p[0],p[1],p[2]));
  const translucent=fill&&(/^rgba/.test(fill)||/^#[0-9a-f]{8}$/i.test(fill));
  this.commands.push({kind:0,points,world,fill,stroke,width,material:this.current.name.includes('water')||translucent?'none':'stone'});
  for(const p of points){grow(this.bounds,p.x,p.y,stroke?width/2:0);grow(this.current.bounds,p.x,p.y,stroke?width/2:0);}
 }
 line(a,b,color,width=1){
  if(this.bridgeWide){a=[a[0]<-4.4?a[0]-Math.min(1,(-4.4-a[0])/1.1)*1.5:a[0],a[1],a[2]];b=[b[0]<-4.4?b[0]-Math.min(1,(-4.4-b[0])/1.1)*1.5:b[0],b[1],b[2]];}
  if(this.offsetZ){a=[a[0],a[1],a[2]+this.offsetZ];b=[b[0],b[1],b[2]+this.offsetZ];}
  const p=P.project(a[0],a[1],a[2]),q=P.project(b[0],b[1],b[2]);
  this.commands.push({kind:1,a:p,b:q,world:[a,b],color,width});
  grow(this.bounds,p.x,p.y,width/2);grow(this.bounds,q.x,q.y,width/2);
  grow(this.current.bounds,p.x,p.y,width/2);grow(this.current.bounds,q.x,q.y,width/2);
 }
 glow(x,y,z,radius,aspect,colour){
  const world=[],points=[],origin=P.project(x,y,z);
  for(let i=0;i<32;i++){
   const a=i*Math.PI/16,u=Math.cos(a)*radius,v=Math.sin(a)*radius*aspect;
   const p=aspect<1?[x+(u/P.HW+v/P.HH)/2,y+(v/P.HH-u/P.HW)/2,z]:[x+u/(P.HW*2),y-u/(P.HW*2),z-v];world.push(p);points.push(P.project(...p));
  }
  this.commands.push({kind:3,world,points,origin,radius,aspect,colour});
  for(const p of points){grow(this.bounds,p.x,p.y);grow(this.current.bounds,p.x,p.y);}
 }
 quad(x0,y0,x1,y1,z,fill,stroke=null,width=1){
  this.path([[x0,y0,z],[x1,y0,z],[x1,y1,z],[x0,y1,z]],fill,stroke,width);
 }
 box(x0,y0,x1,y1,z0,z1,top,front,side){
  this.path([[x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0]],front);
  this.path([[x1,y0,z1],[x1,y1,z1],[x1,y1,z0],[x1,y0,z0]],side);
  this.quad(x0,y0,x1,y1,z1,top);
 }
 build(){
  this.prop('canal water',()=>this.water());
  this.prop('far bank',()=>this.farBank());
  this.prop('left towpath',()=>this.towpath());
  this.prop('front quay',()=>this.frontQuay());
  // Distant trees are silhouettes behind the roof line, not a full backdrop.
  for(const [x,y,h,w]of[[-5.2,-6.25,77,.34],[-2.35,-6.85,83,.38],[.1,-6.45,67,.34],[2.7,-6.35,78,.34],[4.65,-5.9,64,.3]]){
   this.prop('town tree '+x,()=>this.tree(x,y,-91,h,w,true));
  }
  const homes=[
   {x:-5.5,y:-5.85,w:.9,d:.74,h:70,wall:'#d8b5a2',side:'#bd9e91',trim:'#eee1c8',roof:'#a2aaa5'},
   {x:-4.3,y:-6.3,w:.95,d:.8,h:91,wall:'#e8d9b8',side:'#c7bea8',trim:'#f3e8ce',roof:'#9aa4a3'},
   {x:-2.95,y:-5.83,w:.92,d:.78,h:80,wall:'#a7bdb0',side:'#8ea69b',trim:'#e5ddc4',roof:'#a3aaa5'},
   {x:-1.7,y:-6.24,w:1.03,d:.87,h:93,wall:'#d6afa0',side:'#ba958a',trim:'#eddbc1',roof:'#9ca6a4'},
   {x:-.3,y:-5.72,w:.94,d:.79,h:74,wall:'#e9daba',side:'#c5bda6',trim:'#f4e9d2',roof:'#9fa9a4'},
   {x:1.06,y:-6.14,w:1.04,d:.84,h:88,wall:'#b1c1b0',side:'#95a895',trim:'#eee3c7',roof:'#98a4a1'},
   {x:2.48,y:-5.69,w:.95,d:.82,h:79,wall:'#d9b5a2',side:'#bd9f91',trim:'#f0e1c6',roof:'#9aa3a1'},
   {x:3.91,y:-5.96,w:1.05,d:.84,h:91,wall:'#e7d6b7',side:'#c7bba2',trim:'#f2e5ca',roof:'#9ba5a0'}
  ];
  for(let i=0;i<homes.length;i++)this.prop('town house '+(i+1),()=>this.house(homes[i]));
  for(let i=0;i<5;i++)this.prop('west cottage '+i,()=>this.cottage(-9.45,-1.65+i*1.75,i));
  this.prop('garden cottage 1',()=>this.house({x:7.05,y:-6.3,w:1.04,d:1.15,h:108,wall:'#d8c0ad',side:'#baa89a',trim:'#eee0c6',roof:'#95a49a'}));
  this.prop('garden cottage 2',()=>this.house({x:8.3,y:-6.1,w:1.04,d:1.15,h:119,wall:'#d9cbb0',side:'#b9b59e',trim:'#eee2ca',roof:'#ac9288'}));
  this.prop('garden',()=>this.garden());
  this.prop('canal bridge',()=>this.bridge());
  this.prop('hall quay',()=>this.quay());
  this.prop('rear door landing',()=>this.rearLanding());
  this.prop('loading landing',()=>this.landing());
  this.prop('entry stair',()=>this.entryStair());
  this.prop('quayside furniture',()=>this.furniture());
  this.prop('quayside garden',()=>this.quayGarden());
  for(const y of [-.85,1.05,4.99])this.prop('hall mooring '+y,()=>this.bollard(-3.91,y,-91));
  for(const y of [-1.9,.55,3.05,5.25])this.prop('towpath mooring '+y,()=>this.bollard(-7.12,y,-91,true));
  this.prop('towpath tree',()=>this.tree(-7.38,7.2,-91,60,.26,false));
  this.prop('towpath shrubs',()=>{
   this.tree(-7.37,-.15,-91,31,.22,false);
   this.tree(-7.4,-.62,-91,39,.24,false);
  });
 }
 water(){
  const z=-120;
  // The canal continues beyond the foreground framing. Runtime water comes
  // from CanalLife; these same shore contacts serve the static replay.
  this.path([[-7,-4,z],[6.1,-4,z],[6.1,-2.2,z],[-3.05,-2.2,z],[-3.05,7.2,z],[9.4,7.2,z],[9.4,20,z],[-7,20,z]],PALETTE.water);
  this.quad(-7,-3.5,-6.69,20,z,'#3c7d73');
  this.quad(-4.32,-2.2,-4.03,7.2,z,'#326f66');
  this.quad(-6.68,-3.5,-6.33,20,z,'#62998a');
  this.quad(-7,-4,6.1,-3.72,z,'#3d7c71');
  this.quad(-3.05,-2.48,6.1,-2.2,z,'#3c7b6f');
  this.quad(-4.03,7.2,9.4,7.42,z,'#2f695f');
  // Broken paper strips keep the reflections still and less busy than tiles.
  for(let i=0;i<70;i++){
   const x=-6.62+(i*11%17)*.101,y=-3.22+i*.245;
   const length=.14+(i*7%9)*.032;
   this.quad(x,y,Math.min(-3.43,x+length),y+.034,z+.1,i%4===0?'#d9e0c1':i%3===0?'#b8d3c2':'#95c3b7');
  }
  for(let i=0;i<21;i++){
   const x=-2.7+i*.41,y=-3.61+(i*7%9)*.105;
   this.quad(x,y,x+.13+(i%3)*.08,y+.037,z+.1,i%4===0?'#d3dcc0':'#a7cab9');
  }
  for(const [x,y,w]of[[-4.8,-1.4,.55],[-4.28,.2,.37],[-4.9,2.9,.58],[-4.32,4.94,.4],[-.3,-3.2,.6],[3.3,-2.8,.5]]){
   this.quad(x,y,x+w,y+.046,z+.2,'#c7dbc8');
  }
 }
 farBank(){
  this.offsetZ=-83;
  this.box(-10,-8,9.4,-4,-48,-8,'#dcd7bf','#b3b49f','#9fa997');
  this.quad(-7.6,-4.28,6.3,-4,-6,'#ede2c9');
  for(let x=-6.05;x<6.3;x+=.49)this.line([x,-4.28,-5.9],[x,-4,-5.9],'#c6c0a8',.75);
  for(let x=-9.1;x<6.2;x+=.72){
   this.line([x,-4,-8],[x,-4,-24],'#9da795',.8);
   this.line([x+.35,-4,-25],[x+.35,-4,-42],'#9da795',.8);
  }
  this.line([-7.6,-4,-25],[6.3,-4,-25],'#a3ac98',.8);
  this.offsetZ=0;
 }
 towpath(){
  this.offsetZ=-83;
  this.box(-10,-4.2,-7,9.1,-48,-8,'#dfd8be','#bbb69c','#b1b29c');
  this.quad(-7.22,-4.2,-7,9.1,-6,'#eee4ca');
  this.line([-7,-4.2,-6],[-7,9.1,-6],'#f5ebd5',1.3);
  for(let y=-4.15;y<9.1;y+=.42){
   this.line([-7.6,y,-7.9],[-7,y,-7.9],'#c9c3aa',.7);
   this.line([-7,y,-8],[-7,y,-27],'#969f8c',.8);
   this.line([-7,y+.21,-28],[-7,y+.21,-47],'#969f8c',.8);
  }
  this.line([-7,-4.2,-28],[-7,9.1,-28],'#a1a790',.9);
  this.line([-7,-4.2,-40],[-7,9.1,-40],'#89a28f',2.1);
  this.offsetZ=0;
 }
 house(h){
  const{x,y,w,d}=h,z=-91,top=z+h.h,x1=x+w,y1=y+d,xm=x+w/2,ridge=top+29;
  this.quad(x-.06,y-.03,x1+.07,y1+.09,z-1,'#c1c5ad');
  this.box(x,y,x1,y1,z,top,h.trim,h.wall,h.side);
  this.path([[x,y1,top],[xm,y1,ridge],[x1,y1,top]],h.wall);
  this.path([[x-.06,y-.07,top],[xm,y-.07,ridge],[xm,y1+.08,ridge],[x-.06,y1+.08,top]],h.roof);
  this.path([[xm,y-.07,ridge],[x1+.06,y-.07,top],[x1+.06,y1+.08,top],[xm,y1+.08,ridge]],PALETTE.roofShade);
  this.line([x-.06,y1+.08,top],[xm,y1+.08,ridge],h.trim,2.7);
  this.line([xm,y1+.08,ridge],[x1+.06,y1+.08,top],h.trim,2.7);
  this.line([xm,y-.07,ridge],[xm,y1+.08,ridge],PALETTE.roofLight,1.1);
  // Quiet roof folds, window recesses and pale lintels read at hall-view scale.
  for(const t of [.32,.66]){
   const xx=xm+(w/2+.06)*t,zz=ridge-29*t;
   this.line([xx,y-.07,zz],[xx,y1+.08,zz],'#a5afaa',.6);
  }
  for(const u of [.24,.7])for(const zz of [z+24,top-19]){
   const wx=x+w*u,ww=w*.15,wh=15;
   this.path([[wx,y1+.012,zz],[wx+ww,y1+.012,zz],[wx+ww,y1+.012,zz+wh],[wx,y1+.012,zz+wh]],'#829f9d',h.trim,1.6);
   this.line([wx+ww/2,y1+.018,zz],[wx+ww/2,y1+.018,zz+wh],h.trim,.8);
   this.line([wx,y1+.02,zz+wh*.55],[wx+ww,y1+.02,zz+wh*.55],h.trim,.8);
   this.line([wx-.025,y1+.026,zz-1],[wx+ww+.025,y1+.026,zz-1],h.trim,1.7);
  }
  const dy=y+d*.34;
  this.path([[x1+.012,dy,z+32],[x1+.012,dy+d*.2,z+32],[x1+.012,dy+d*.2,z+48],[x1+.012,dy,z+48]],'#7e9995',h.trim,1.4);
  this.box(x+w*.68,y+d*.17,x+w*.82,y+d*.33,top+7,top+38,'#d6b1a0','#bd988a','#a98e82');
  this.box(x+w*.66,y+d*.15,x+w*.84,y+d*.35,top+37,top+41,'#e7c7b0','#c4a28f','#b09888');
 }
 tree(x,y,z,h,w,distant){
  const dark=distant?'#9fac8b':'#8d9e75',mid=distant?'#b8bf97':'#adbb83',light=distant?'#ced1aa':'#c8cd95';
  this.box(x-.035,y-.035,x+.035,y+.035,z,z+h*.57,'#b7aa87','#a99a7b','#988c72');
  const p=(u,v)=>[x+u*w,y-u*w,z+v*h];
  this.path([p(-.85,.34),p(-1,.55),p(-.67,.63),p(-.75,.78),p(-.36,.82),p(-.25,.97),p(.05,1),p(.34,.9),p(.67,.88),p(.75,.7),p(.97,.61),p(.83,.39),p(.47,.3),p(0,.27)],mid);
  this.path([p(0,.27),p(.47,.3),p(.83,.39),p(.97,.61),p(.75,.7),p(.67,.88),p(.34,.9),p(.02,.64)],dark);
  this.path([p(-.85,.34),p(-1,.55),p(-.67,.63),p(-.75,.78),p(-.36,.82),p(-.25,.97),p(.05,1),p(-.12,.62)],light);
  this.path([p(-.12,.62),p(.05,1),p(.34,.9),p(.02,.64),p(0,.27)],mid);
  this.line([x,y,z+h*.28],[x,y,z+h*.68],distant?'#9da886':'#94a078',.8);
 }
 bridge(){
  this.offsetZ=-83;this.bridgeWide=true;
  const y0=-2.08,y1=-1.55;
  const crest=[[-5.83,-8],[-5.4,12],[-4.9,23],[-4.4,27],[-3.9,23],[-3.4,12],[-2.96,-8]];
  const outer=crest.map(p=>[p[0],y1,p[1]]);
  const arch=[[-2.96,y1,-38],[-3.3,y1,-38],[-3.39,y1,-18],[-3.58,y1,-3],[-3.9,y1,8],[-4.2,y1,13],[-4.57,y1,13],[-4.9,y1,8],[-5.18,y1,-3],[-5.37,y1,-18],[-5.46,y1,-38],[-5.83,y1,-38]];
  this.path(outer.concat(arch),'#ccc9af');
  for(let i=0;i<crest.length-1;i++){
   const a=crest[i],b=crest[i+1];
   this.path([[a[0],y0,a[1]],[b[0],y0,b[1]],[b[0],y1,b[1]],[a[0],y1,a[1]]],'#e5dcc1');
   this.line([a[0],y0,a[1]+1],[a[0],y1,a[1]+1],'#c4bfa8',.7);
  }
  // The narrow back edge stands above the arched masonry without a heavy rail.
  for(let i=0;i<crest.length-1;i++){
   const a=crest[i],b=crest[i+1];
   this.path([[a[0],y0,a[1]],[b[0],y0,b[1]],[b[0],y0,b[1]+9],[a[0],y0,a[1]+9]],'#b7bfaa');
   this.line([a[0],y0,a[1]+9],[b[0],y0,b[1]+9],'#eee4cc',2);
  }
  for(let i=1;i<crest.length-1;i++){
   const a=crest[i];this.line([a[0],y1,a[1]],[a[0],y1,a[1]-9],'#b3b9a2',.8);
  }
  for(let i=2;i<arch.length-2;i++)this.line(arch[i],arch[i+1],'#e3dcc2',2.2);
  this.offsetZ=0;this.bridgeWide=false;
 }
 quay(){
  this.box(-4.03,-2.8,-3,7.2,-131,-91,'#e7dbc0','#c3bca2','#b0b49c');
  this.line([-4.03,-2.8,-91],[-4.03,7.2,-91],'#f3e6ca',1.4);
  for(let y=-2.76;y<7.2;y+=.42)this.line([-4.03,y,-90.8],[-3,y,-90.8],'#c7bea4',.8);
  this.path([[-4.03,-2.8,-91],[-4.03,7.2,-91],[-4.03,7.2,-131],[-4.03,-2.8,-131]],'#c0bea4');
  this.line([-4.03,-2.8,-120],[-4.03,7.2,-120],'#94a893',1.7);
  for(let y=-2.7;y<7.2;y+=.5)this.line([-4.03,y,-91],[-4.03,y,-130],'#a8ae96',.8);
 }
 rearLanding(){
  for(let i=0;i<7;i++)this.box(-3.95,-.04-(i+1)*.28,-3.08,-.04-i*.28,-91,-91+(i+1)*85/7,'#ead9bd','#c6b397','#ad9e87');
  // The loading quay turns behind the west wall and reaches the open rear arch.
  for(const x of [-3.8,-1.25])for(const y of [-2.65,-2.15]){
   this.box(x-.1,y-.1,x+.1,y+.1,-131,-12,'#d9c9a8','#b6ad91','#9eaa94');
  }
  this.box(-4.03,-2.8,-1.02,-2,-14,-6,'#e7dbc0','#c3bca2','#b0b49c');
  for(let x=-3.9;x<-1.02;x+=.42)this.line([x,-2.8,-5.8],[x,-2,-5.8],'#c7bea4',.8);
  this.line([-4.03,-2.8,-6],[-1.02,-2.8,-6],'#f3e6ca',1.4);
 }
 landing(){
  const l=LAYOUT.landing;
  this.box(l.x0,l.y0,l.x1,l.y1,-100,l.z,PALETTE.timberLight,PALETTE.timber,PALETTE.timberShade);
  for(let y=l.y0+.17;y<l.y1;y+=.17)this.line([l.x0,y,l.z+.1],[l.x1,y,l.z+.1],'#b39a72',.85);
  this.bollard(-3.87,5.42,l.z,true);this.bollard(-3.87,6.54,l.z,true);
 }
 frontQuay(){
  const q=LAYOUT.quay;
  this.box(q.x0,q.y0,q.x1,q.y1,-131,q.z,'#dfb995','#b48a6d','#9c785f');
  // Broad paving is deliberately quieter than the board above it.
  for(let y=-2.8,row=0;y<7.2;y+=.48,row++)for(let x=-4.03+(row%2)*.36;x<9.4;x+=.72){
   const x1=Math.min(x+.7,9.4),y1=Math.min(y+.46,7.2);
   this.quad(x+.02,y+.02,x1,y1,-90.9,['#e7c5a3','#dcb594','#e0bd9a','#efd0ac'][(row+Math.round(x*10)+100)%4]);
  }
  // Deep shelter beneath the raised floor is a projected shadow on paving,
  // leaving the sunny outer walk and every original footing visible.
  this.quad(-2.98,-1.94,7.15,4.9,-90.67,'rgba(76,57,45,.24)');
  for(let i=0;i<7;i++)this.quad(-2.98+i*.04,-1.94+i*.04,7.15-i*.035,5.72-i*.105,-90.65+i*.005,'rgba(76,57,45,.073)');
  for(const x of[-2.8,.25,3.3,6.8])this.path([[x-.12,4.77,-90.6],[x+.38,4.77,-90.6],[x+1.07,5.58,-90.6],[x+.57,5.58,-90.6]],'#65574620');
  this.quad(-4.03,5.25,-3.74,7.2,-90.5,'#f4d7ad');
  this.quad(-4.03,6.94,9.4,7.2,-90.5,'#f4d7ad');
  for(let y=5.3;y<7.2;y+=.43)this.line([-4.02,y,-90.3],[-3.74,y,-90.3],'#b58b67',.8);
  // Each foreground coping stone has a visible cream top, mortar joint and
  // moss-darkened waterline, rather than a single floating brown strip.
  for(let x=-4.03,row=0;x<9.4;x+=.55,row++){
   const right=Math.min(x+.55,9.4);
   this.line([x,6.94,-90.3],[x,7.2,-90.3],'#ba916c',.85);
   this.line([x,7.2,-91],[x,7.2,-108],'#8c6b54',.85);
   this.line([Math.min(x+.275,9.4),7.2,-108],[Math.min(x+.275,9.4),7.2,-130],'#8c6b54',.85);
   this.path([[x+.02,7.201,-109],[right-.02,7.201,-109],[right-.02,7.201,-128],[x+.02,7.201,-128]],row%3===0?'#8c8870':'#a18c6d');
  }
  this.line([-4.03,7.205,-108],[9.4,7.205,-108],'#977657',.8);
  this.line([-4.03,7.21,-120],[9.4,7.21,-120],'#547b66',3.2);
  this.line([-4.03,7.2,-90.4],[9.4,7.2,-90.4],'#ffe7bd',1.5);
 }
 flowerBox(x,y,z,w=.6){
  this.box(x,y,x+w,y+.23,z,z+12,'#d6b28a','#bd946c','#997653');
  for(let i=0;i<7;i++){
   const xx=x+.05+i*w/7,yy=y+.1+(i%2)*.07,h=z+18+(i%3)*4;
   this.line([xx,yy,z+10],[xx,yy,h+7],'#6e8755',1.4);
   this.path([[xx-.07,yy,h-2],[xx-.09,yy,h+7],[xx,yy,h+3],[xx+.08,yy,h+9],[xx+.06,yy,h-3]],i%2?'#99aa66':'#758d54');
   for(let j=0;j<5;j++){
    const a=j*Math.PI*2/5,u=Math.cos(a)*.043,v=Math.sin(a)*3.3;
    this.path([[xx+u-.035,yy,h+6+v],[xx+u,yy,h+9+v],[xx+u+.035,yy,h+6+v],[xx+u,yy,h+3+v]],['#e9a3a2','#efc7ba','#f0ddad'][i%3]);
   }
  }
 }
 cottage(x,y,index){
  const w=1.5,d=1.54,z=-91,h=123+(index%2)*16,x1=x+w,y1=y+d,roof=z+h;
  const walls=['#e0b69e','#e5c7a3','#d6c3ab','#ddad98','#c3c9af'],roofs=['#bb8273','#7f9991','#be887c','#91a296','#ad7b71'];
  this.box(x,y,x1,y1,z,roof,'#f0d8ba',walls[index],index%2?'#b9ad94':'#c09d88');
  this.path([[x,y,roof],[x+.75,y,roof+43],[x1,y,roof],[x1,y1,roof],[x+.75,y1,roof+43],[x,y1,roof]],roofs[index]);
  this.path([[x+.75,y,roof+43],[x1+.09,y-.06,roof],[x1+.09,y1+.09,roof],[x+.75,y1+.09,roof+43]],roofs[index]);
  this.path([[x,y1,roof],[x+.75,y1,roof+43],[x1,y1,roof]],walls[index]);
  this.line([x-.06,y1+.03,roof],[x+.75,y1+.03,roof+43],'#ead2b4',3);
  this.line([x+.75,y1+.03,roof+43],[x1+.09,y1+.03,roof],'#ead2b4',3);
  for(let k=1;k<5;k++)this.line([x+.75+k*.17,y-.06,roof+43-k*9],[x+.75+k*.17,y1+.09,roof+43-k*9],'#d5b8a366',1);
  this.box(x+.26,y+.18,x+.48,y+.42,roof+15,roof+67,'#ead0b5','#b88872','#9b7366');
  this.box(x+.22,y+.14,x+.52,y+.46,roof+64,roof+70,'#efd9bd','#c69d80','#b08b75');
  // Front gables have their own joinery; the terrace reads from either view.
  for(const xx of[x+.22,x+.99])for(const low of[z+23,z+77]){
   const yy=y1+.018;
   this.path([[xx,yy,low],[xx+.27,yy,low],[xx+.27,yy,low+28],[xx,yy,low+28]],'#e7c27e','#f1ddbe',2);
   this.line([xx+.135,yy+.006,low],[xx+.135,yy+.006,low+28],'#fff0cc',1.2);
   this.line([xx,yy+.006,low+14],[xx+.27,yy+.006,low+14],'#fff0cc',1.2);
   this.line([xx-.03,yy+.015,low-2],[xx+.3,yy+.015,low-2],'#f1dcc0',2.5);
  }
  this.path([[x+.62,y1+.02,z+2],[x+.88,y1+.02,z+2],[x+.88,y1+.02,z+45],[x+.62,y1+.02,z+45]],'#6b897b','#ead2af',2);
  this.path([[x+.67,y1+.025,roof+10],[x+.83,y1+.025,roof+10],[x+.83,y1+.025,roof+25],[x+.67,y1+.025,roof+25]],'#efcf89','#e9d4b5',1.5);
  this.line([x+.84,y1+.03,z+20],[x+.84,y1+.03,z+23],'#e7bd73',2);
  for(let row=0;row<6;row++)this.line([x+.04,y1+.01,z+8+row*19],[x1-.04,y1+.01,z+8+row*19],'#bc987d30',.6);
  // Canal-facing doors and tall warm windows sit on the east wall.
  const face=(a,b,lo,hi,fill)=>this.path([[x1+.018,a,lo],[x1+.018,b,lo],[x1+.018,b,hi],[x1+.018,a,hi]],fill,'#f0dbc1',2);
  face(y+.19,y+.55,z+3,z+52,['#638a7d','#9b7165','#778d82'][index%3]);
  this.box(x1,y+.13,x1+.18,y+.62,z,z+3,'#ead7ba','#baa286','#a18d78');
  for(const yy of[y+.23,y+.99]){
   face(yy,yy+.31,z+76,z+110,'#efc875');
   this.line([x1+.025,yy+.155,z+77],[x1+.025,yy+.155,z+110],'#fff0cc',1.6);
   this.line([x1+.025,yy,z+93],[x1+.025,yy+.31,z+93],'#fff0cc',1.4);
  }
  face(y+.99,y+1.3,z+19,z+51,'#edc47a');
  this.houseFront(x1+.025,y,y1,z,roof);
  this.flowerBox(x1+.035,y+.9,z+9,.24);
  this.line([x1+.03,y1-.07,z+5],[x1+.03,y1-.07,roof],'#628175',2);
  this.lantern(x1+.16,y+.75,z,43);
  this.flowerBox(x+.28,y1+.035,z,.7);
 }
 houseFront(x,y0,y1,z0,z1){
  const world=[[x,y1,z1],[x,y0,z1],[x,y0,z0],[x,y1,z0]],points=world.map(p=>P.project(...p));
  this.commands.push({kind:2,world,points,origin:points[0],imageWidth:(y1-y0)*P.HW,imageHeight:z1-z0});
  for(const p of points){grow(this.bounds,p.x,p.y);grow(this.current.bounds,p.x,p.y);}
 }
 lantern(x,y,z,h=62){
  const hero=h>70,w=hero?.115:.065;
  // Lantern glow is baked with the lantern, then reflected by CanalLife at
  // the same world position. Its upright remains visibly planted in stone.
  if(hero){
   this.glow(x,y,z+h-6,38,1,'#ffc653');
   this.glow(x,y,z+.1,42,.42,'#ffca69');
  }
  this.box(x-w*1.3,y-w*1.3,x+w*1.3,y+w*1.3,z,z+5,'#b89d70','#8f7e57','#655f45');
  this.box(x-w*.56,y-w*.56,x+w*.56,y+w*.56,z+5,z+h-16,'#bd9657','#8e7650','#5f6650');
  this.line([x-w*.45,y+w*.57,z+7],[x-w*.45,y+w*.57,z+h-17],'#e9bc79',1.1);
  this.box(x-w,y-w,x+w,y+w,z+h-16,z+h+4,'#ffe7a5','#ffd36b','#efad46');
  this.path([[x-w+.012,y+w+.006,z+h-13],[x+w-.012,y+w+.006,z+h-13],[x+w-.012,y+w+.006,z+h+1],[x-w+.012,y+w+.006,z+h+1]],'#fff9c9');
  this.path([[x+w+.006,y-w+.012,z+h-13],[x+w+.006,y+w-.012,z+h-13],[x+w+.006,y+w-.012,z+h+1],[x+w+.006,y-w+.012,z+h+1]],'#ffe991');
  this.line([x-w+.035,y+w+.012,z+h-11],[x-w+.035,y+w+.012,z+h-1],'#fffde7',2.1);
  for(const xx of[x-w,x+w])for(const yy of[y-w,y+w])this.line([xx,yy,z+h-16],[xx,yy,z+h+4],'#9c713a',hero?2.2:1.3);
  this.box(x-w*1.2,y-w*1.2,x+w*1.2,y+w*1.2,z+h-18,z+h-15,'#c7a15d','#9e743a','#796039');
  this.path([[x-w*1.45,y-w*1.45,z+h+4],[x+w*1.45,y-w*1.45,z+h+4],[x+w*1.45,y+w*1.45,z+h+4],[x-w*1.45,y+w*1.45,z+h+4]],'#9a7c42');
  this.path([[x-w*1.45,y+w*1.45,z+h+4],[x+w*1.45,y+w*1.45,z+h+4],[x,y,z+h+17]],'#8b6c3f');
  this.path([[x+w*1.45,y-w*1.45,z+h+4],[x+w*1.45,y+w*1.45,z+h+4],[x,y,z+h+17]],'#b8914d');
  this.line([x,y,z+h+15],[x,y,z+h+20],'#d0a058',2);
 }
 paperLeaf(x,y,z,dx,dz,width,colour,shade='#768b39',vein='#d1c76c80'){
  const length=Math.hypot(dx,dz),nx=-dz/length*width,ny=dx/length*width;
  const p=(u,v)=>[x+u/(P.HW*2),y-u/(P.HW*2),z+v];
  const base=p(0,0),tip=p(dx,dz),left=[base],right=[base];
  for(let i=1;i<8;i++){const t=i/8,curve=Math.pow(Math.sin(t*Math.PI),.72);left.push(p(dx*t+nx*curve,dz*t+ny*curve));right.push(p(dx*t-nx*curve,dz*t-ny*curve));}
  left.push(tip);right.push(tip);
  this.path(left,colour);this.path(right,shade);
  this.line(base,tip,vein,.7);
 }
 blossom(x,y,z,r,colour){
  const point=(u,v)=>[x+u/(P.HW*2),y-u/(P.HW*2),z+v];
  for(let k=0;k<5;k++){
   const a=k*Math.PI*2/5+.28,ox=Math.cos(a)*r*.6,oy=Math.sin(a)*r*.6,pts=[];
   for(let j=0;j<8;j++){const b=j*Math.PI/4;pts.push(point(ox+Math.cos(b)*r*.58,oy+Math.sin(b)*r*.58));}
   this.path(pts,colour);
  }
  const centre=[];for(let j=0;j<7;j++){const a=j*Math.PI*2/7;centre.push(point(Math.cos(a)*r*.27,Math.sin(a)*r*.27));}
  this.path(centre,'#e9b957');
 }
 planter(x,y,z,w=.94,d=.47,theme=0){
  const bottom=z+2,top=z+20;
  this.quad(x-.04,y-.03,x+w+.1,y+d+.12,z+.1,'#6e63402b');
  this.box(x+.035,y+.025,x+w-.035,y+d-.025,z,bottom,'#b88e51','#906831','#78542f');
  this.path([[x+.035,y+d-.025,bottom],[x+w-.035,y+d-.025,bottom],[x+w,y+d,top],[x,y+d,top]],'#bc8f51');
  this.path([[x+w-.035,y+.025,bottom],[x+w-.035,y+d-.025,bottom],[x+w,y+d,top],[x+w,y,top]],'#a87d41');
  this.quad(x,y,x+w,y+d,top,'#755633');
  this.box(x-.025,y+d-.025,x+w+.025,y+d+.035,top-3,top+2,'#e9c281','#c99a58','#ac7f45');
  this.box(x+w-.025,y-.025,x+w+.035,y+d+.035,top-3,top+2,'#e9c281','#c99a58','#ac7f45');
  for(let i=1;i<5;i++)this.line([x+w*i/5,y+d-.018,bottom+2],[x+w*i/5,y+d+.004,top-4],'#91693180',.8);
  // Broad folded leaves form a real canopy, with stems terminating in soil.
  for(let i=0;i<11;i++){
   const xx=x+.08+(i*7%11)/11*(w-.12),yy=y+.07+(i%3)*d*.25,b=z+17+(i%2)*4;
   const dx=((i*11%13)-6)*3.2,dz=13+(i*7%5)*4;
   this.paperLeaf(xx,yy,b,dx,dz,5+(i%3),['#a7ac45','#9eac4c','#c1bf57','#879a3e'][i%4]);
  }
  for(let i=0;i<5;i++){
   const xx=x+.08+(i*3%5)/5*(w-.1),yy=y+.11+(i%2)*d*.4,head=z+37+(i*3%5)*2.2;
   this.line([xx,yy,z+18],[xx,yy,head],'#6c873c',1.1);
   const crown=[];
   for(let j=0;j<24;j++){const a=j*Math.PI/12,r=10+(j%2)*1.3,u=Math.cos(a)*r; crown.push([xx+u/(P.HW*2),yy-u/(P.HW*2),head+Math.sin(a)*r*.82]);}
   this.path(crown,theme?'#dfc491':'#d67e86');
   for(let j=0;j<12;j++){
    const a=j*2.4,r=2.1+Math.sqrt(j)*2.1,u=Math.cos(a)*r,v=Math.sin(a)*r;
    this.blossom(xx+u/(P.HW*2),yy-u/(P.HW*2),head+v,3.1+(j%3)*.35,theme?['#fff3cb','#fff8e0','#f4deb0'][(i+j)%3]:['#e994a0','#f8b7bd','#ffd1c5'][(i+j)%3]);
   }
  }
 }
 shrub(x,y,z,h,seed){
  this.line([x,y,z],[x,y,z+h*.7],'#89916a',2);
  for(let i=0;i<9;i++){
   const u=((i*7%9)-4)*.075,base=z+h*(.35+(i%3)*.2),pts=[];
   for(let j=0;j<14;j++){const a=j*Math.PI/7,r=.16+(i%3)*.018;pts.push([x+u+Math.cos(a)*r,y-u-Math.cos(a)*r,base+Math.sin(a)*h*.23]);}
   this.path(pts,['#8f9f6b','#a9b578','#b5ba80','#98a872'][(i+seed)%4]);
  }
 }
 gardenPlant(x,y,z,h,seed,flower=0){
  const footprint=[];
  for(let j=0;j<18;j++){const a=j*Math.PI/9;footprint.push([x+Math.cos(a)*h*.0072,y+Math.sin(a)*h*.0072,z+.04]);}
  this.path(footprint,'#373d3025');
  // Branches carry broad rounded leaves at three heights, avoiding the
  // repeated bubble silhouettes and bare flat turf of the previous garden.
  const colours=['#739052','#8a9e59','#a2ad67','#657f4b','#94a85f'];
  const shades=['#5a7446','#708647','#7e924d','#567047','#728a4a'];
  for(let i=0;i<13;i++){
   const angle=((i*137+seed*47)%360)*Math.PI/180;
   const u=Math.cos(angle)*h*.17,base=z+h*(.16+(i%3)*.12),xx=x+u/(P.HW*2),yy=y-u/(P.HW*2);
   const dx=Math.cos(angle)*h*.48,dz=h*(.22+(i*3%7)*.035),tone=(i+seed)%5;
   this.line([x,y,z+1],[xx,yy,base],'#5e7044',.9);
   this.paperLeaf(xx,yy,base,dx,dz,h*.13,colours[tone],shades[tone],'#bfca8e35');
  }
  if(flower){
   for(let i=0;i<3;i++){
    const u=(i-1)*h*.19,xx=x+u/(P.HW*2),yy=y-u/(P.HW*2),head=z+h*(.83+(i%2)*.13);
    this.line([x,y,z+h*.3],[xx,yy,head],'#69804a',1.1);
    const radius=h*.19,crown=[];
    for(let j=0;j<24;j++){const a=j*Math.PI/12,r=radius*(1+(j%2)*.08),v=Math.cos(a)*r;crown.push([xx+v/(P.HW*2),yy-v/(P.HW*2),head+Math.sin(a)*r*.84]);}
    this.path(crown,flower===1?'#c98189':flower===2?'#cfbb8c':'#9280a2');
    for(let j=0;j<12;j++){
     const a=j*2.4+seed,r=radius*.21+Math.sqrt(j)*radius*.19,u=Math.cos(a)*r,v=Math.sin(a)*r;
     this.blossom(xx+u/(P.HW*2),yy-u/(P.HW*2),head+v,Math.max(2,radius*.3),flower===1?['#e8a3a9','#f1bec0','#fbd3c7'][(i+j)%3]:flower===2?['#fff2c9','#f6dfad','#fff7de'][(i+j)%3]:['#b7a5c5','#c8bad4','#ddd0e2'][(i+j)%3]);
    }
   }
  }
 }
 gardenBed(x0,y0,x1,y1,z){
  // Soil is recessed behind individually cut terracotta edging. A few small
  // stones and mulch flecks leave believable gaps between plant clusters.
  this.box(x0,y0,x1,y1,z,z+6,'#906c4c','#b68761','#9e714f');
  this.quad(x0+.055,y0+.055,x1-.055,y1-.055,z+5.2,'#765941');
  this.box(x0-.025,y0-.025,x0+.075,y1+.025,z,z+9,'#d7ae7c','#ad7c54','#926643');
  this.box(x0-.025,y1-.075,x1+.025,y1+.025,z,z+9,'#dbb481','#b28058','#996a46');
  for(let y=y0+.28;y<y1;y+=.34)this.line([x0-.026,y,z+1],[x0-.026,y,z+8],'#80583f80',.7);
  for(let i=0;i<24;i++){
   const x=x0+.13+((i*17)%23)/23*(x1-x0-.24),y=y0+.13+((i*11)%23)/23*(y1-y0-.24);
   this.quad(x,y,x+.025+(i%3)*.009,y+.017,z+5.3,i%3?'#987958':'#b99a71');
  }
 }
 garden(){
  // The narrow office garden is a paved path and two planted borders, not a
  // single green foundation. The side supports retain clear stone footings.
  this.box(7.2,-4,9.4,4.9,-131,-91,'#dfc09c','#b59474','#a18368');
  for(let y=-4,row=0;y<4.9;y+=.43,row++)for(let x=7.2;x<9.4;x+=.44){
   this.quad(x+.012,y+.012,Math.min(x+.428,9.4),Math.min(y+.418,4.9),-90.9,['#e6cba7','#dbc09e','#edd2ad'][(row+Math.round(x*10))%3]);
  }
  this.gardenBed(7.6,-3.8,8.79,.2,-91);
  this.gardenBed(7.58,1.78,8.79,4.64,-91);
  const plants=[
   [8.47,-3.22,58,1],[7.94,-3.43,26,0],[8.28,-2.39,43,3],[7.86,-1.99,27,0],[8.51,-1.29,55,2],[7.94,-.77,35,0],[8.35,-.22,42,1],
   [8.43,2.13,49,2],[7.9,2.32,24,0],[8.48,3.01,56,1],[7.92,3.4,33,3],[8.35,3.97,45,0],[7.88,4.25,26,2]
  ];
  for(let i=0;i<plants.length;i++){const[x,y,h,flower]=plants[i];this.gardenPlant(x,y,-85.8,h,i,flower);}
  for(const [a,b]of[[-4,.45],[1.55,4.9]]){
   this.box(8.85,a,9.05,b,-91,-37,'#e5cfb2','#c2a28d','#a78b7c');
   for(let y=a+.1;y<b;y+=.44)this.line([9.055,y,-90],[9.055,y,-38],'#b3937f',.7);
   this.line([9.055,a,-63],[9.055,b,-63],'#aa8f7b',.8);
  }
  for(const y of[.4,1.56])this.box(8.79,y,9.12,y+.23,-91,-22,'#edd9bb','#c5a78e','#ae927e');
  for(let y=.68;y<1.55;y+=.13)this.line([8.98,y,-90],[8.98,y,-35-Math.abs(y-1.05)*26],'#7a947d',3.5);
  this.line([8.98,.65,-71],[8.98,1.54,-71],'#b0b58b',2);
  this.flowerBox(9.1,2.05,-91,.28);this.flowerBox(9.1,3.1,-91,.28);
  this.bicycle(9.18,2.75,-91);
  this.box(9.12,.1,9.36,.38,-91,-49,'#bb7b66','#a76153','#87564c');
  this.path([[9.365,.15,-59],[9.365,.32,-59],[9.365,.32,-56],[9.365,.15,-56]],'#ead5b3');
 }
 bicycle(x,y,z){
  const wheel=(cy)=>{const pts=[];for(let i=0;i<20;i++){const a=i*Math.PI/10;pts.push([x,cy+Math.cos(a)*.22,z+15+Math.sin(a)*14]);}this.path(pts,null,'#657e70',2.5);};
  wheel(y-.37);wheel(y+.37);
  const a=[x,y-.37,z+15],b=[x,y+.37,z+15],c=[x,y-.12,z+36],d=[x,y+.16,z+36],e=[x,y+.03,z+15];
  for(const pair of[[a,c],[c,e],[e,a],[e,d],[d,b],[c,d]])this.line(pair[0],pair[1],'#cda15e',2.3);
  this.line([x,y-.12,z+36],[x,y-.12,z+43],'#64786a',2);
  this.line([x,y-.23,z+44],[x,y+.01,z+44],'#8d7055',3);
  this.line([x,y+.16,z+36],[x,y+.1,z+48],'#64786a',2);
  this.line([x,y+.1,z+48],[x,y+.27,z+49],'#64786a',2.3);
 }
 entryStair(){
  const s=LAYOUT.stairs,run=(s.y1-s.y0)/s.steps,rise=91/s.steps;
  // Each solid riser starts on the quay; the last tread meets the office edge.
  for(let i=0;i<s.steps;i++){
   const y1=s.y1-i*run,y0=y1-run,top=s.z0+(i+1)*rise;
   this.box(s.x0,y0,s.x1,y1,s.z0,top,'#f0dbc0','#ceb296','#b39a80');
   this.line([s.x0,y1,top],[s.x1,y1,top],'#fff0d1',1.5);
  }
  for(const x of[s.x0+.06,s.x1-.06]){
   for(let i=0;i<=s.steps;i+=2){const y=s.y1-i*run,z=s.z0+Math.min(s.steps,i+1)*rise;this.line([x,y,z],[x,y,z+34],'#bc955b',3);}
   this.line([x,s.y1,s.z0+rise+34],[x,s.y0,34],'#d9b472',4);
   this.line([x,s.y1,s.z0+rise+35],[x,s.y0,35],'#f5d89a',1.2);
  }
 }
 furniture(){
  this.lantern(-3.59,6.72,-91,82);
  // Leave clear paving between the planter rim and the complete lamp foot.
  // The additional gap also separates their silhouettes in the fixed view.
  this.lantern(2.95,6.8,-91,76);
  this.planter(-3.47,6.67,-91,.47,.43,0);
  this.planter(-1.49,6.62,-91,.6,.43,0);
  this.bench(-.82,6.28,-91,2.08);
  // This planter is nearer than the bench: paint it last so it correctly
  // occludes the far foot instead of receiving a green leg on its soil.
  this.planter(1.45,6.6,-91,.78,.46,1);
  for(const y of[5.7,6.8])this.bollard(-3.9,y,-91,true);
  this.bollard(-2.8,7.05,-91);this.bollard(-.85,7.07,-91);
 }
 bench(x,y,z,w){
  this.quad(x-.04,y-.02,x+w+.08,y+.7,z+.1,'#625d4938');
  // The bench faces the canal (+y). Its back is on the far side of the seat,
  // so the two front uprights and the low armrests remain plainly visible.
  const back=y+.10,front=y+.61,seatBottom=z+24,seatTop=z+29,backTop=z+56;
  const supports=[x+.08,x+w-.08],woodLeft=x+.10,woodRight=x+w-.10;
  const backY=height=>back-.07*(height-(z+3))/(backTop-(z+3));
  const strut=(xx,y0,z0,y1,z1)=>{
   const a=.04,b=.03;
   this.path([[xx-a,y0+b,z0],[xx+a,y0+b,z0],[xx+a,y1+b,z1],[xx-a,y1+b,z1]],'#2d6659');
   this.path([[xx+a,y0-b,z0],[xx+a,y0+b,z0],[xx+a,y1+b,z1],[xx+a,y1-b,z1]],'#214e47');
   this.quad(xx-a,y1-b,xx+a,y1+b,z1,'#6f9680');
   this.line([xx-a+.01,y0+b+.002,z0+1],[xx-a+.01,y1+b+.002,z1-1],'#83ab8a',.85);
  };
  const foot=(xx,yy)=>{
   this.quad(xx-.07,yy-.105,xx+.075,yy+.11,z+.12,'#40574928');
   this.box(xx-.045,yy-.085,xx+.045,yy+.085,z,z+3,'#5b8775','#315d53','#214b47');
  };
  // Rear uprights grow directly from their feet. Both back rails and the arm
  // attachment use this same leaning line; no support projects above the top.
  for(const xx of supports){
   foot(xx,back);strut(xx,back,z+3,backY(backTop),backTop);
   this.box(xx-.06,back-.045,xx+.06,front+.035,seatBottom-3,seatBottom,'#5a8973','#315f52','#224c43');
  }
  for(let i=0;i<3;i++){
   const low=z+33+i*9,high=low+(i===2?9:7),lo=backY(low),hi=backY(high);
   this.path([[woodLeft,lo+.04,low],[woodRight,lo+.04,low],[woodRight,hi+.04,high],[woodLeft,hi+.04,high]],'#ca894f');
   this.path([[woodRight,lo-.03,low],[woodRight,lo+.04,low],[woodRight,hi+.04,high],[woodRight,hi-.03,high]],'#a66d3f');
   this.quad(woodLeft,hi-.03,woodRight,hi+.04,high,'#e7ae6d');
   this.line([woodLeft+.02,hi+.041,high],[woodRight-.02,hi+.041,high],'#ffdfa0',.9);
   for(const xx of[woodLeft+.04,woodRight-.04]){const middle=low+3,yy=backY(middle)+.041;this.line([xx,yy,middle],[xx+.015,yy,middle],'#80613d',1.4);}
  }
  for(let i=0;i<5;i++){
   const yy=y+.08+i*.112;
   this.box(woodLeft,yy,woodRight,yy+.09,seatBottom,seatTop,'#dda15c','#bc7846','#a8683e');
   this.line([woodLeft+.02,yy+.089,seatTop],[woodRight-.02,yy+.089,seatTop],'#ffe1a1',.9);
   for(const xx of[woodLeft+.04,woodRight-.04])this.line([xx,yy+.04,seatTop+.2],[xx+.015,yy+.04,seatTop+.2],'#6a634a',1.5);
  }
  // The nearer posts are continuous from foot to arm. Draw them after the
  // timber seat, then join each arm directly to its corresponding back post.
  for(const xx of supports){
   const armLow=z+42,armHigh=z+46,armBack=backY(armHigh),curve=[];
   foot(xx,front);strut(xx,front,z+3,front,armLow);
   for(let i=0;i<=14;i++){const t=i/14;curve.push([xx,front+(armBack-front)*t,armLow+(armHigh-armLow)*t+1.8*Math.sin(t*Math.PI)]);}
   for(let i=0;i<curve.length-1;i++){
    this.line(curve[i],curve[i+1],'#2e6c5b',6.2);
    this.line([curve[i][0]-.018,curve[i][1],curve[i][2]+1.3],[curve[i+1][0]-.018,curve[i+1][1],curve[i+1][2]+1.3],'#8aae80',1.3);
   }
  }
 }
 quayGarden(){
  // A planted corner softens the outer garden wall without obstructing the
  // front walk or the largest playable board. Each leaf grows from its bed.
  this.box(7.35,5.55,8.95,6.68,-91,-75,'#e6c697','#b58b61','#947149');
  this.quad(7.43,5.63,8.87,6.6,-74.9,'#795b40');
  for(const [x,y,h,seed,flower]of[[7.72,5.96,38,2,1],[8.29,5.93,47,4,2],[8.62,6.24,26,8,0],[7.94,6.34,25,9,3]])this.gardenPlant(x,y,-74.8,h,seed,flower);
  this.planter(8.95,4.75,-91,.35,.4,1);
 }
 bollard(x,y,z,small=false){
  const w=small?.055:.068,h=small?15:20;
  this.box(x-w*1.5,y-w*1.5,x+w*1.5,y+w*1.5,z,z+2,'#bbb29a','#969a89','#828f81');
  this.box(x-w,y-w,x+w,y+w,z+2,z+h,'#87988b','#788e81','#617c73');
  this.box(x-w*1.5,y-w*1.5,x+w*1.5,y+w*1.5,z+h-2,z+h+1,'#d5c8a6','#a69f80','#90977e');
 }
 draw(includeWater=true){
  const r=this.r;
  const start=includeWater?0:this.props[0].count;
  for(let i=start;i<this.commands.length;i++){
   const c=this.commands[i];
   if(c.kind===3){
    if(r.ctx?.createRadialGradient){const ctx=r.ctx;ctx.save();ctx.translate(c.origin.x,c.origin.y);ctx.scale(1,c.aspect);const g=ctx.createRadialGradient(0,0,0,0,0,c.radius);g.addColorStop(0,c.colour+'70');g.addColorStop(.26,c.colour+'30');g.addColorStop(.68,c.colour+'0c');g.addColorStop(1,c.colour+'00');ctx.fillStyle=g;ctx.fillRect(-c.radius,-c.radius,c.radius*2,c.radius*2);ctx.restore();}
    else r.path(c.points,null,null,0);
   }else if(c.kind===2){
    if(r.images?.houseFront&&r.ctx){const ctx=r.ctx;ctx.save();ctx.transform(1,-.5,0,1,c.origin.x,c.origin.y);ctx.drawImage(r.images.houseFront,0,0,c.imageWidth,c.imageHeight);ctx.restore();}
   }else if(c.kind===0){
    if(r.poly&&c.fill){r.poly(c.world,c.fill,c.material);if(c.stroke)r.path(c.points,null,c.stroke,c.width);}
    else r.path(c.points,c.fill,c.stroke,c.width);
   }
   else r.line(c.a,c.b,c.color,c.width);
  }
 }
}
root.CivicExterior=Exterior;
if(typeof module==='object'&&module.exports)module.exports=Exterior;
})(typeof globalThis!=='undefined'?globalThis:this);
