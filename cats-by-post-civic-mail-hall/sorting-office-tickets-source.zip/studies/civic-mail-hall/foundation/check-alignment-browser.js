/* Regression checks read the rendered pixels and actual Canvas path vertices. */
const fs=require('node:fs'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process');
const setup=`
for(let i=0;i<100&&!window.__foundation?.ready;i++)await new Promise(r=>setTimeout(r,30));
const check=(v,m)=>{if(!v)throw Error(m);};check(__foundation.ready,'assets ready');
__foundation.pause(true);const R=__foundation.renderer,S=__foundation.session,P=CivicProjection;
`;
const floor=`(async()=>{${setup}
R.structure=()=>{};R.crew=()=>{};R.guides=false;
S.level={board:{w:5,h:3},hatches:[],baskets:[],dogs:[]};S.chutes=[];S.traces=[];S.mode='edit';
R.fit('play');R.draw(S);const c=R.ctx;
const cream=(x,y)=>{const p=P.toScreen(P.project(x,y),R.cam),v=c.getImageData(Math.round(p.x*R.dpr),Math.round(p.y*R.dpr),1,1).data;return v[0]>180&&v[1]>160&&v[2]<v[0];};
let samples=0;for(let x=1;x<5;x++)for(let k=1;k<30;k++){check(cream(x,k/10),'broken x seam at '+x+','+k/10);samples++;}
for(let y=1;y<3;y++)for(let k=1;k<50;k++){check(cream(k/10,y),'broken y seam at '+k/10+','+y);samples++;}
return{case:'continuous floor seams',samples};})()`;
const arrows=`(async()=>{${setup}
const c=R.ctx,paths=[],saved={};let vertices=[];
for(const name of ['beginPath','moveTo','lineTo','fill'])saved[name]=c[name].bind(c);
c.setTransform(1,0,0,1,0,0);
c.beginPath=()=>{vertices=[];saved.beginPath();};
for(const name of ['moveTo','lineTo'])c[name]=(x,y)=>{vertices.push(new DOMPoint(x,y).matrixTransform(c.getTransform()));saved[name](x,y);};
c.fill=(...args)=>{if(vertices.length>=3)paths.push({points:vertices.slice(),fill:c.fillStyle});saved.fill(...args);};
const centre=pts=>{let a=0,x=0,y=0;for(let i=0;i<pts.length;i++){const p=pts[i],q=pts[(i+1)%pts.length],v=p.x*q.y-q.x*p.y;a+=v;x+=(p.x+q.x)*v;y+=(p.y+q.y)*v;}return{x:x/(3*a),y:y/(3*a)};};
for(const dir of ['R','D','L','U'])for(const kind of ['table','hatch']){
 paths.length=0;const p=P.centre(2,1);R.pieces[kind]({x:2,y:1,dir,type:'plain'},kind==='table'?0:{open:0,n:0,waiting:0});
 const arrow=paths.find(v=>v.fill===(kind==='table'?'#fff0cf':'#456e6d'));check(arrow,'arrow path '+kind);
 const pts=arrow.points,actual=centre(pts),face=kind==='table'?P.project(2.5,1.5,3):p;
 check(Math.hypot(actual.x-face.x,actual.y-face.y)<.05,kind+' '+dir+' arrow mass off-centre: '+JSON.stringify(actual)+' / '+JSON.stringify(face));
 const bounds={x:(Math.min(...pts.map(p=>p.x))+Math.max(...pts.map(p=>p.x)))/2,y:(Math.min(...pts.map(p=>p.y))+Math.max(...pts.map(p=>p.y)))/2};
 check(Math.hypot(bounds.x-face.x,bounds.y-face.y)<.05,kind+' '+dir+' silhouette off-centre');
 const tip=pts[0],axis=P.project(2.5+OfficeRules.GR_DX[OfficeRules.GR_DIR[dir]],1.5+OfficeRules.GR_DY[OfficeRules.GR_DIR[dir]],kind==='table'?3:0);
 check(Math.abs((tip.x-face.x)*(axis.y-face.y)-(tip.y-face.y)*(axis.x-face.x))<.001,kind+' '+dir+' heading off-axis');
}
for(const [name,fn] of Object.entries(saved))c[name]=fn;R.draw(S);return{case:'centred projected arrows',headings:8};})()`;
const url=process.env.CIVIC_URL||'http://127.0.0.1:8765/studies/civic-mail-hall/foundation/index.html';
const jobs=[{url,device:'1440x1000@1',wait:500,js:floor,out:'work/civic-alignment/seams.png'},{url,device:'1440x1000@1',wait:500,js:arrows,out:'work/civic-alignment/arrows-check.png'}];
fs.mkdirSync('work/civic-alignment',{recursive:true});fs.writeFileSync('work/civic-alignment/check-jobs.json',JSON.stringify(jobs));
const run=spawnSync(process.execPath,['tools/snap.js','--batch','work/civic-alignment/check-jobs.json'],{encoding:'utf8',maxBuffer:2e6,timeout:120000});
const log=(run.stdout||'')+(run.stderr||'');console.log(log);assert.equal(run.status,0);assert.ok(!/setup error|page exception|page console\.(error|warning|assert)/.test(log));
console.log('2 floor/arrow browser regression cases passed');
