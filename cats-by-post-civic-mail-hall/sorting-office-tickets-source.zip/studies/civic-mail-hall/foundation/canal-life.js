/* Quiet paper water beneath the hall; the moored mailboat composites in
 * front of the quay. Route time is supplied, and geometry is prepared once. */
(function(root){
'use strict';
const HW=380/6,HH=190/6,TAU=Math.PI*2,DURATION=168,FRAMES=192;
const HULL=Object.freeze([[-.18,-.49],[-.1,-.62],[.1,-.62],[.18,-.49],[.22,.4],[.13,.56],[0,.65],[-.13,.56],[-.22,.4]].map(Object.freeze));
const MAIL_HULL=Object.freeze([[-.48,-1.75],[.48,-1.75],[.64,-1.43],[.675,.92],[.57,1.32],[.3,1.63],[0,1.78],[-.3,1.63],[-.57,1.32],[-.675,.92],[-.64,-1.43]].map(Object.freeze));
const LAYOUT=Object.freeze({
 duration:DURATION,phaseOffset:56,keel:-2,gunwale:8,hull:HULL,
 canal:Object.freeze({x0:-7,x1:-4.03,y0:-3.5,y1:20,z:-120}),
 frontCanal:Object.freeze({x0:-7,x1:9.4,y0:7.2,y1:20,z:-120}),
 rightCanal:Object.freeze({x0:9.4,x1:20,y0:-8,y1:20,z:-120}),
 rearCanal:Object.freeze({x0:-7,x1:6.1,y0:-4,y1:-2.8,z:-120}),
 berth:Object.freeze({x:-4.765,y:5.93,z:-120}),
 mailBoat:Object.freeze({x:-3,y:8.5,z:-120,heading:-Math.PI/2,keel:-4,gunwale:18,hull:MAIL_HULL,activeMooring:1,
  moorings:Object.freeze([Object.freeze({x:-2.8,y:7.05,z:-73}),Object.freeze({x:-.85,y:7.07,z:-73})])})
});
function wrap(t){return((Number.isFinite(t)?t:0)%DURATION+DURATION)%DURATION;}
function ease(t){return t*t*t*(t*(t*6-15)+10);}
function velocity(t){return 30*t*t*(t-1)*(t-1);}
function sampleBoat(time,out={}){
 const t=wrap(wrap(time)+56);let y=3.93,heading=0,speed=0,u=0;
 if(t<56){u=t/56;y=-2.6+6.53*ease(u);speed=6.53/56*velocity(u);}
 else if(t<74){}
 else if(t<86){u=(t-74)/12;y=3.93+.89*ease(u);speed=.89/12*velocity(u);}
 else if(t<98){y=4.82;heading=Math.PI*ease((t-86)/12);}
 else if(t<156){u=(t-98)/58;y=4.82-7.42*ease(u);heading=Math.PI;speed=7.42/58*velocity(u);}
 else{y=-2.6;heading=Math.PI+Math.PI*ease((t-156)/12);}
 out.x=-4.765;out.y=y+2;out.z=-120;out.heading=heading;out.speed=speed;
 out.bob=Math.sin(t*TAU/7)*.28+Math.sin(t*TAU/12)*.08;
 out.moored=t>=56&&t<74;out.phase=t;return out;
}
function command(world,fill,stroke=null,width=1,angle=0,relative=false){
 const c=Math.cos(angle),s=Math.sin(angle),points=[];
 for(let i=0;i<world.length;i++){
  const p=world[i],x=p[0]*c-p[1]*s,y=p[0]*s+p[1]*c;
  points.push({x:(relative?0:760)+(x-y)*HW,y:(relative?0:465)+(x+y)*HH-p[2]});
 }
 return{points,fill,stroke,width};
}
function replayPath(c,path){
 const points=path.points;c.beginPath();
 for(let i=0;i<points.length;i++){const p=points[i];if(i)c.lineTo(p.x,p.y);else c.moveTo(p.x,p.y);}
 c.closePath();
 if(path.fill){c.fillStyle=path.fill;c.fill();}
 if(path.stroke){c.strokeStyle=path.stroke;c.lineWidth=path.width;c.stroke();}
}
function replay(c,commands){for(let i=0;i<commands.length;i++)replayPath(c,commands[i]);}
class Canal{
 constructor(renderer){
  this.r=renderer;this.pose=sampleBoat(0,{});this.water=[];this.currents=[];this.reflections=[];this.shoreline=[];this.frames=[];
  this.buildWater();
  for(let i=0;i<FRAMES;i++)this.frames.push(this.buildBoat(i*TAU/FRAMES));
  this.mailBoat=this.buildMailBoat();
 }
 static layout(){return LAYOUT;}
 static sampleBoat(time,out){return sampleBoat(time,out);}
 bake(){
  if(this.r.scenery)this.r.scenery.clear();
  // Static paper colour and grain are prepared once. Motion only composites
  // these canvases and replays the small prebuilt water/rope fragments.
  if(typeof document==='undefined'||!root.CivicArchitecture)return;
  const make=(b,scale)=>{
   const canvas=document.createElement('canvas');canvas.width=Math.ceil((b.right-b.left)*scale);canvas.height=Math.ceil((b.bottom-b.top)*scale);
   const c=canvas.getContext('2d');c.setTransform(scale,0,0,scale,-b.left*scale,-b.top*scale);return{canvas,c};
  };
  const b=this.waterBounds={left:-970,top:215,right:2220,bottom:1870},water=make(b,1),c=water.c;
  replay(c,this.water);c.save();
  const outline=this.water[0].points;c.beginPath();for(let i=0;i<outline.length;i++)i?c.lineTo(outline[i].x,outline[i].y):c.moveTo(outline[i].x,outline[i].y);c.closePath();c.clip();
  const wash=c.createLinearGradient(0,270,320,1330);wash.addColorStop(0,'#286f6a');wash.addColorStop(.36,'#3d8a7e');wash.addColorStop(.7,'#579e89');wash.addColorStop(1,'#428c85');
  c.globalAlpha=.52;c.fillStyle=wash;c.fillRect(b.left,b.top,b.right-b.left,b.bottom-b.top);
  for(const [x,y,r,color]of[[10,650,420,'#75ac8b'],[260,1040,590,'#73aa8b'],[650,1270,440,'#397c77'],[1420,1110,710,'#72aa8b'],[1960,1040,470,'#367c76']]){
   const g=c.createRadialGradient(x,y,10,x,y,r);g.addColorStop(0,color);g.addColorStop(1,color+'00');c.globalAlpha=.13;c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);
  }
  const painter=new root.CivicArchitecture.Painter(c,this.r.images,this.r.assets),paper=painter.material('teal');
  if(paper){c.globalCompositeOperation='soft-light';c.globalAlpha=.37;c.fillStyle=paper;c.fillRect(b.left,b.top,b.right-b.left,b.bottom-b.top);}
  // The last two metres dissolve into the backdrop's same teal stock, so a
  // tall phone composition cannot expose a rectangular end to the canal.
  c.globalCompositeOperation='source-over';c.globalAlpha=1;
  const fade=c.createLinearGradient(760-17.8*HW,585+17.8*HH,760+(1.32-20)*HW,585+(1.32+20)*HH);fade.addColorStop(0,'#428c8500');fade.addColorStop(1,'#428c85');c.fillStyle=fade;c.fillRect(b.left,b.top,b.right-b.left,b.bottom-b.top);
  // Only the distant outer reach fades. The visible water outside the
  // garden wall keeps the same paper wash and currents as the front canal.
  const edge=c.createLinearGradient(760+(18.2-10)*HW,585+(18.2+10)*HH,760+(20-11.08)*HW,585+(20+11.08)*HH);edge.addColorStop(0,'#428c8500');edge.addColorStop(1,'#428c85');c.fillStyle=edge;c.fillRect(b.left,b.top,b.right-b.left,b.bottom-b.top);c.restore();
  this.waterCanvas=water.canvas;
  let left=Infinity,top=Infinity,right=-Infinity,bottom=-Infinity;
  for(const path of this.mailBoat.body)for(const p of path.points){left=Math.min(left,p.x);right=Math.max(right,p.x);top=Math.min(top,p.y);bottom=Math.max(bottom,p.y);}
  const bb=this.mailBoatBounds={left:left-4,top:top-4,right:right+4,bottom:bottom+4},boat=make(bb,2),bc=boat.c;
  const tint=(hex,amount,target)=>{const a=parseInt(hex.slice(1),16),b=parseInt(target.slice(1),16);return '#'+[16,8,0].map(s=>Math.round(((a>>s)&255)*(1-amount)+((b>>s)&255)*amount).toString(16).padStart(2,'0')).join('');};
  for(const path of this.mailBoat.body){
   const points=path.points;bc.beginPath();for(let i=0;i<points.length;i++)i?bc.lineTo(points[i].x,points[i].y):bc.moveTo(points[i].x,points[i].y);bc.closePath();
   if(path.fill){
    let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;for(const p of points){x0=Math.min(x0,p.x);y0=Math.min(y0,p.y);x1=Math.max(x1,p.x);y1=Math.max(y1,p.y);}
    const g=bc.createLinearGradient(x0,y0,x0+(x1-x0)*.4,y1+.1);g.addColorStop(0,tint(path.fill,.08,'#fff1d1'));g.addColorStop(.35,path.fill);g.addColorStop(1,tint(path.fill,.16,'#244d4a'));bc.fillStyle=g;bc.fill();
    if(paper){bc.save();bc.clip();bc.globalCompositeOperation='soft-light';bc.globalAlpha=.55;bc.fillStyle=paper;bc.fillRect(x0-1,y0-1,x1-x0+2,y1-y0+2);bc.restore();}
   }
   if(path.stroke){bc.strokeStyle=path.stroke;bc.lineWidth=path.width;bc.stroke();}
  }
  this.mailBoatCanvas=boat.canvas;this.cacheBytes=(water.canvas.width*water.canvas.height+boat.canvas.width*boat.canvas.height+256*256)*4;this.bakes=(this.bakes||0)+1;
 }
 buildWater(){
  const base=this.water,z=-120;
  const face=(points,fill)=>base.push(command(points,fill));
  const quad=(x0,y0,x1,y1,h,fill,target=base)=>{
   target.push(command([[x0,y0,h],[x1,y0,h],[x1,y1,h],[x0,y1,h]],fill));
  };
  // This surface continues out of the composition. There is no visible tray
  // edge in the foreground; the native stone banks define the water instead.
  face([[-7,-4,z],[6.1,-4,z],[6.1,-2.2,z],[-3.05,-2.2,z],[-3.05,7.2,z],[9.4,7.2,z],[9.4,-8,z],[20,-8,z],[20,20,z],[-7,20,z]],'#428c85');
  quad(-7,-4,-6.65,20,z,'#367e79');quad(-6.65,-3.7,-6.1,20,z,'#3c847c');
  quad(-6.1,-2.8,-4.32,20,z,'#4c968a');
  quad(-4.32,-2.8,-4.03,7.2,z,'#347c76');quad(-4.14,-2.8,-4.03,7.2,z,'#2d6e6c');
  quad(-7,-4,6.1,-3.72,z,'#367c75');quad(-3.05,-2.48,6.1,-2.2,z,'#377d75');
  // A darker reflected quay starts at the masonry. The broad forewater holds
  // larger soft paper patches, never a tight repeating checker or glitter.
  quad(-4.03,7.2,9.4,7.37,z,'#2e6f6d');
  quad(-4.03,7.37,9.4,7.61,z,'#367d75');
  quad(-4.03,7.61,9.4,8.15,z,'#40877c');
  // The outside wall meets the same continuous canal. Its darker reflected
  // base is fixed to the masonry; moving broken colour sits farther out.
  quad(9.4,-2.8,9.56,7.2,z,'#2e716d');
  quad(9.56,-2.8,9.84,7.2,z,'#367f75');
  quad(9.84,-2.8,10.18,7.2,z,'#408a7c');
  const wet=(x,y)=>(x>=-6.975&&x<=6.075&&y>=-3.975&&y<=-2.225)||(x>=-6.975&&x<=-4.055&&y>=-3.975&&y<=19.975)||(x>=-6.975&&x<=19.975&&y>=7.225&&y<=19.975)||(x>=9.425&&x<=19.975&&y>=-7.975&&y<=19.975);
  // Water crests use one oblique plane and a shared travelling phase. Their
  // paper cut edges are irregular but their direction is coherent.
  const ripple=(x,y,w,d,fill,target)=>{
   const points=[[x-w,y+w,z],[x-w*.7+d,y+w*.7+d,z],[x+w*.72+d,y-w*.72+d,z],[x+w,y-w,z],[x+w*.67-d,y-w*.67-d,z],[x-w*.65-d,y+w*.65-d,z]];
   if(points.every(p=>wet(p[0],p[1])))target.push(command(points,fill));
  };
  for(let i=0;i<115;i++){
   const x=-6.66+(i*7%17)*.141,y=-3.25+i*.196,commands=[];
   ripple(x,y,.09+(i*5%7)*.027,.009+(i%3)*.003,i%7===0?'#9bbbab':'#72a799',commands);
   if(commands.length)this.currents.push({commands,phase:y*.83,axis:0});
  }
  for(let i=0;i<84;i++){
   const x=-3.65+(i*11%31)*.398,y=7.8+Math.floor(i/8)*.9+(i%4)*.21,commands=[];
   ripple(x,y,.14+(i%5)*.055,.012+(i%3)*.003,i%9===0?'#a1c0a9':'#73a99a',commands);
   if(commands.length)this.currents.push({commands,phase:y*.83,axis:0});
  }
  for(let i=0;i<180;i++){
   const x=9.77+(i*37%173)/173*9.8,y=-2.37+(i*61%179)/179*21.8,commands=[];
   ripple(x,y,.15+(i*7%9)*.034,.012+(i%4)*.003,i%11===0?'#a4c1ac':i%4===0?'#85b4a2':'#72a79a',commands);
   if(commands.length)this.currents.push({commands,phase:y*.83,axis:0});
  }
  // Continue the reach behind the garden rather than exposing a diagonal
  // flat triangle when the foreground is viewed close. The physical bank
  // contact still ends at the real quay; only open water continues here.
  for(let i=0;i<48;i++){
   const x=9.77+(i*19%47)/47*9.8,y=-7.58+(i*29%43)/43*5.02,commands=[];
   ripple(x,y,.15+(i*7%9)*.034,.012+(i%4)*.003,i%11===0?'#a4c1ac':i%4===0?'#85b4a2':'#72a79a',commands);
   if(commands.length)this.currents.push({commands,phase:y*.83,axis:0});
  }
  for(let i=0;i<19;i++){
   const x=-2.75+i*.45,y=-3.6+(i*5%7)*.11,commands=[];
   quad(x,y,x+.13+(i%3)*.07,y+.023,z,i%4===0?'#a7be9d':'#6b9e8d',commands);
   this.currents.push({commands,phase:x*.83,axis:1});
  }
  // Warm reflected light is mapped from real fixture heights. Reflecting a
  // vertical source across z=-120 shifts its image equally in world x/y,
  // hence straight down in this camera. Wavelets then break that image up.
  const light=(source,kind,index)=>{
   const commands=[],distance=(source.z-z)/(2*HH),baseDistance=Math.max(.93,distance*.8);
   for(let j=0;j<10;j++){
    if((j+index*3)%7===4)continue;
    const travel=baseDistance+j*.14+(j%3)*.022,width=.07+j*.009+((j*5+index*3)%5)*.027;
    const x=source.x+travel+(j%2?.012:-.012),y=source.y+travel;
    ripple(x,y,width,.018+(j%4)*.01,['#f5d98d','#efd18a','#ffe5a6','#e7c784'][(j+index)%4],commands);
   }
   this.reflections.push({source,kind,commands,phase:(source.x+source.y)*.83,alpha:kind==='quay'?.66:kind==='window'?.37:.54});
  };
  for(let i=0;i<5;i++){
   light({x:-7.79,y:-.9+i*1.75,z:-54},'cottage',i);
   light({x:-7.925,y:-1.265+i*1.75,z:2},'window',i+5);
  }
  light({x:-3.59,y:6.72,z:-15},'quay',10);
  light({x:2.95,y:6.8,z:-21},'quay',11);
  // The distant paired windows remain secondary to the closer golden lamps.
  for(const house of[[-5.5,-5.85,.9,.74],[-4.3,-6.3,.95,.8],[-2.95,-5.83,.92,.78],[-1.7,-6.24,1.03,.87],[-.3,-5.72,.94,.79],[1.06,-6.14,1.04,.84],[2.48,-5.69,.95,.82],[3.91,-5.96,1.05,.84]]){
   for(const offset of[.24,.7]){
    const source={x:house[0]+house[2]*offset,y:house[1]+house[3]+.012,z:-67},commands=[];
    for(let j=0;j<4;j++){
     const width=.135+j*.024,x=source.x-width/2+(j%2?.018:-.012),y=-3.94+j*.118;
     quad(x,y,x+width,y+.026+(3-j)*.005,z,j%2?'#99b69e':'#adc3a5',commands);
    }
    this.reflections.push({source,kind:'distant',commands,phase:source.x*.83,alpha:.31});
   }
  }
  // The garden's actual warm wall reflects across z=-120, giving the newly
  // visible right reach a source of colour without inventing extra lamps.
  for(let i=0;i<13;i++){
   const source={x:9.055,y:-2.56+i*.56,z:-37},commands=[],travel=(source.z-z)/(2*HH);
   if(source.y>.45&&source.y<1.55)continue; // Open gate has no wall face.
   for(let j=0;j<5;j++){
    const distance=travel-.3+j*.14;
    ripple(source.x+distance,source.y+distance,.12+(j%3)*.06,.019+(j%2)*.007,['#577e70','#6d8b77','#879a80','#b5aa80','#72947e'][(i+j)%5],commands);
   }
   this.reflections.push({source,kind:'wall',commands,phase:(source.x+source.y)*.83,alpha:.46});
  }
  // Narrow fixed contacts meet the actual banks. They never drift with the
  // reflection, which keeps the water anchored when scenery motion is off.
  quad(-7,-4,-6.93,20,z,'#2b6866',this.shoreline);
  quad(-4.1,-2.8,-4.03,7.2,z,'#2b6866',this.shoreline);
  quad(-7,-4,6.1,-3.93,z,'#336f66',this.shoreline);
  quad(-4.03,7.2,9.4,7.255,z,'#285f60',this.shoreline);
  quad(9.4,-2.8,9.455,7.2,z,'#285f60',this.shoreline);
  for(let i=0;i<43;i++){
   const y=-3.67+i*.54;
   quad(-6.925,y,-6.905,y+.18+(i%3)*.052,z,'#8ab2a0',this.shoreline);
   if(y> -2.7&&y<7)quad(-4.125,y+.12,-4.109,y+.32,z,'#7fa695',this.shoreline);
  }
  for(let i=0;i<24;i++){
   const x=-3.94+i*.54;quad(x,7.28,x+.24+(i%3)*.045,7.295,z,'#7da693',this.shoreline);
  }
  for(let i=0;i<20;i++){
   const y=-2.63+i*.48;quad(9.48,y,9.495,y+.19+(i%3)*.038,z,'#7fa897',this.shoreline);
  }
 }
 buildBoat(angle){
  const body=[],contact=[],reflection=[],wake=[],wakeLong=[],ca=Math.cos(angle),sa=Math.sin(angle);
  const face=(points,fill,stroke=null,width=1)=>body.push(command(points,fill,stroke,width,angle,true));
  const top=(x0,y0,x1,y1,z,fill)=>face([[x0,y0,z],[x1,y0,z],[x1,y1,z],[x0,y1,z]],fill);
  const visible=(dx,dy)=>(dx*ca-dy*sa)+(dx*sa+dy*ca)>0;
  const box=(x0,y0,x1,y1,z0,z1,light,front,side)=>{
   if(visible(0,-1))face([[x1,y0,z0],[x0,y0,z0],[x0,y0,z1],[x1,y0,z1]],side);
   if(visible(-1,0))face([[x0,y0,z0],[x0,y1,z0],[x0,y1,z1],[x0,y0,z1]],side);
   if(visible(0,1))face([[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]],front);
   if(visible(1,0))face([[x1,y1,z0],[x1,y0,z0],[x1,y0,z1],[x1,y1,z1]],front);
   top(x0,y0,x1,y1,z1,light);
  };
  contact.push(command(HULL.map(p=>[p[0]*1.055,p[1]*1.055,0]),'#427e7d',null,1,angle,true));
  // Broken hull/cabin colour remains on the water plane, independent of bob.
  // It extends only just beyond the hull, so the complete turning circle fits.
  for(let i=0;i<4;i++){
   const y=-.38+i*.18,x=.22+(i%2)*.015;
   reflection.push(command([[x,y,0],[x+.045,y+.012,0],[x+.035,y+.11,0],[x-.012,y+.095,0]],i===0?'#b7b79b':'#689b91',null,1,angle,true));
  }
  // Small broken wake strips are only shown during translation. During turns
  // the contact ring stays within the complete narrow-channel turning circle.
  for(let i=0;i<3;i++)for(const sign of[-1,1]){
   const x=sign*(.16+i*.052),y=-.62-i*.076;
   wake.push(command([[x,y,0],[x+sign*.034,y-.08,0],[x+sign*.044,y-.076,0],[x+sign*.015,y+.01,0]],'#d0e0c9',null,1,angle,true));
  }
  for(let i=0;i<3;i++)for(const sign of[-1,1]){
   const x=sign*(.25+i*.044),y=-.88-i*.08;
   wakeLong.push(command([[x,y,0],[x+sign*.03,y-.07,0],[x+sign*.043,y-.065,0],[x+sign*.014,y+.012,0]],'#d0e0c9',null,1,angle,true));
  }
  for(let i=0;i<HULL.length;i++){
   const a=HULL[i],b=HULL[(i+1)%HULL.length];
   if(!visible(b[1]-a[1],a[0]-b[0]))continue;
   face([[a[0],a[1],LAYOUT.keel],[b[0],b[1],LAYOUT.keel],[b[0],b[1],6],[a[0],a[1],6]],i%2?'#397f7d':'#4a9790');
   face([[a[0],a[1],6],[b[0],b[1],6],[b[0],b[1],LAYOUT.gunwale],[a[0],a[1],LAYOUT.gunwale]],'#ded0ac');
   face([[a[0],a[1],1],[b[0],b[1],1]],null,'#a9bba0',.65);
  }
  face(HULL.map(p=>[p[0],p[1],LAYOUT.gunwale]),'#eee2c2');
  face(HULL.map(p=>[p[0]*.84,p[1]*.88,8.1]),'#7caaa0');
  top(-.16,-.42,.16,-.36,8.3,'#c8b18b');
  top(-.16,.37,.16,.42,8.3,'#c8b18b');
  face([[-.125,.48,8.3],[0,.61,8.3],[.125,.48,8.3]],'#c58568');
  // Sort complete little deck objects so each rigid assembly keeps its faces.
  const objects=[
   {x:0,y:-.26,kind:0},{x:-.075,y:.16,kind:1},{x:.075,y:.18,kind:2}
  ];
  objects.sort((a,b)=>((a.x*ca-a.y*sa)+(a.x*sa+a.y*ca))-((b.x*ca-b.y*sa)+(b.x*sa+b.y*ca)));
  for(const object of objects){
   if(object.kind===0){
    box(-.145,-.43,.145,-.1,8.2,20,'#e7d8b8','#d9c5a1','#bfae8c');
    if(visible(0,1)){
     face([[-.115,-.099,12],[.115,-.099,12],[.115,-.099,18],[-.115,-.099,18]],'#688e88');
     face([[0,-.098,12],[0,-.098,18]],null,'#e9dabb',1);
    }
    if(visible(1,0))face([[.146,-.38,12],[.146,-.15,12],[.146,-.15,18],[.146,-.38,18]],'#7b9d91');
    if(visible(-1,0))face([[-.146,-.15,12],[-.146,-.38,12],[-.146,-.38,18],[-.146,-.15,18]],'#668b82');
    if(visible(0,-1))face([[-.11,-.431,12],[.11,-.431,12],[.11,-.431,17],[-.11,-.431,17]],'#77988b');
    box(-.16,-.445,.16,-.085,20,22,'#dba17c','#bd8164','#aa745d');
    top(-.16,-.287,.16,-.262,22.1,'#e5b891');
   }else{
    const left=object.kind===1,x0=left?-.16:.015,x1=left?-.005:.16,y0=left?.005:.105,y1=left?.28:.33,z1=left?17:20;
    box(x0,y0,x1,y1,8.3,z1,left?'#e5c89a':'#d4ac87',left?'#cba877':'#b98c6c',left?'#b79770':'#a67e63');
    const xm=(x0+x1)/2,ym=(y0+y1)/2;
    top(xm-.013,y0,xm+.013,y1,z1+.1,'#f0ddba');
    top(x0,ym-.015,x1,ym+.015,z1+.11,'#f0ddba');
    top(x0+.02,y0+.035,x0+.068,y0+.095,z1+.2,'#fff0d3');
    if(visible(0,1))face([[xm-.013,y1+.001,8.3],[xm+.013,y1+.001,8.3],[xm+.013,y1+.001,z1],[xm-.013,y1+.001,z1]],'#ead3ac');
    if(visible(0,-1))face([[xm-.013,y0-.001,8.3],[xm+.013,y0-.001,8.3],[xm+.013,y0-.001,z1],[xm-.013,y0-.001,z1]],'#d9c19b');
   }
  }
  return{body,contact,reflection,wake,wakeLong};
 }
 buildMailBoat(){
  const angle=LAYOUT.mailBoat.heading,body=[],mirror=[],contact=[],reflection=[],ripples=[],ropes=[],a=LAYOUT.mailBoat;
  const ca=Math.cos(angle),sa=Math.sin(angle),visible=(dx,dy)=>(dx*ca-dy*sa)+(dx*sa+dy*ca)>0;
  const face=(points,fill,stroke=null,width=1)=>{
   points=points.map(p=>[p[0],p[1],p[2]+Math.max(0,Math.min(16,(p[2]-34)*.64))]);
   body.push(command(points,fill,stroke,width,angle,true));
   if(fill)mirror.push(command(points.map(p=>[p[0],p[1],-p[2]]),fill,null,1,angle,true));
  };
  const top=(x0,y0,x1,y1,z,fill)=>face([[x0,y0,z],[x1,y0,z],[x1,y1,z],[x0,y1,z]],fill);
  const line=(points,color,width=1)=>face(points,null,color,width);
  const box=(x0,y0,x1,y1,z0,z1,light,front,side)=>{
   if(visible(0,-1))face([[x1,y0,z0],[x0,y0,z0],[x0,y0,z1],[x1,y0,z1]],side);
   if(visible(-1,0))face([[x0,y0,z0],[x0,y1,z0],[x0,y1,z1],[x0,y0,z1]],side);
   if(visible(0,1))face([[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]],front);
   if(visible(1,0))face([[x1,y1,z0],[x1,y0,z0],[x1,y0,z1],[x1,y1,z1]],front);
   top(x0,y0,x1,y1,z1,light);
  };
  // Water displacement is one soft dark rim, with a wider broken ring. The
  // hull stays below that waterline throughout the tiny moored breathing.
  for(const [scale,color]of[[1.12,'#34766e'],[1.045,'#245e5d']])contact.push(command(MAIL_HULL.map(p=>[p[0]*scale,p[1]*scale,0]),color,null,1,angle,true));
  for(let i=0;i<MAIL_HULL.length;i++){
   const p=MAIL_HULL[i],q=MAIL_HULL[(i+1)%MAIL_HULL.length];
   if(!visible(q[1]-p[1],p[0]-q[0]))continue;
   const edge=[[p[0],p[1],-4],[q[0],q[1],-4],[q[0]*1.015,q[1]*1.005,12],[p[0]*1.015,p[1]*1.005,12]];
   face(edge,i%2?'#205f59':'#2a766b');
   face([[p[0]*1.015,p[1]*1.005,10],[q[0]*1.015,q[1]*1.005,10],[q[0]*1.025,q[1]*1.007,15.5],[p[0]*1.025,p[1]*1.007,15.5]],'#c8845c');
   face([[p[0]*1.025,p[1]*1.007,15.5],[q[0]*1.025,q[1]*1.007,15.5],[q[0]*1.025,q[1]*1.007,18],[p[0]*1.025,p[1]*1.007,18]],'#f3d8a3');
   line([[p[0],p[1],1.8],[q[0],q[1],1.8]],'#458f7d',1.1);
   line([[p[0]*1.025,p[1]*1.007,15.6],[q[0]*1.025,q[1]*1.007,15.6]],'#d9a16d',.8);
  }
  face(MAIL_HULL.map(p=>[p[0]*1.025,p[1]*1.007,18]),'#f2dbad');
  face(MAIL_HULL.map(p=>[p[0]*.9,p[1]*.94,18.15]),'#799e83');
  face(MAIL_HULL.map(p=>[p[0]*.77,p[1]*.89,18.25]),'#b89563');
  for(let j=0;j<12;j++){
   const y=-1.5+j*.25,w=y>1.25?.23:y>1?.4:.49;
   top(-w,y,w,y+.02,18.4,'#8c7854');
   line([[-w+.015,y+.037,18.45],[w-.015,y+.037,18.45]],'#d8b779',.55);
  }
  const parcel=(x,y,w,d,z,h)=>{
   box(x,y,x+w,y+d,z,z+h,'#e5b97b','#bb8b52','#ca9b5b');
   const xm=x+w*.5,ym=y+d*.52;
   top(xm-.027,y,xm+.027,y+d,z+h+.1,'#f5dda9');
   top(x,ym-.024,x+w,ym+.024,z+h+.15,'#ead09a');
   if(visible(-1,0))face([[x-.002,ym-.024,z],[x-.002,ym+.024,z],[x-.002,ym+.024,z+h],[x-.002,ym-.024,z+h]],'#e6c78e');
   if(visible(0,1))face([[xm-.027,y+d+.002,z],[xm+.027,y+d+.002,z],[xm+.027,y+d+.002,z+h],[xm-.027,y+d+.002,z+h]],'#e6c78e');
   top(x+.035,y+.04,x+.15,y+.14,z+h+.2,'#f5e5c0');
   line([[x+.055,y+.065,z+h+.25],[x+.128,y+.065,z+h+.25]],'#aa9367',.55);
   line([[x+.055,y+.095,z+h+.25],[x+.11,y+.095,z+h+.25]],'#aa9367',.45);
   line([[x+.01,y+d+.004,z+1],[x+.01,y+d+.004,z+h-1],[x+w-.01,y+d+.004,z+h-1]],'#e8c58c',.5);
  };
  // A small stern luggage rack and parcels precede the cabin in native depth.
  box(-.49,-1.55,.49,-1.1,18.3,21,'#d5b37c','#ae8958','#bd9664');
  parcel(.06,-1.52,.35,.35,21,16);parcel(-.4,-1.46,.33,.31,21,11);
  parcel(.09,-1.5,.27,.26,37,11);
  // Four turned wooden rail posts and a cream rim make the boat a crafted
  // object rather than the old futuristic carrier enlarged into a vessel.
  for(const x of[-.51,.51])box(x-.027,-1.47,x+.027,-1.42,18,30,'#f2d6a1','#c19863','#d2aa73');
  box(-.55,-1.51,.55,-1.44,28,31,'#f0d6a6','#ba8f5d','#c7a06d');
  // A teal-and-cream wheelhouse with real inset glass, a postal door and a
  // shallow faceted coral roof. Each face shares the floor's two-to-one axes.
  box(-.51,-.94,.51,.57,18.4,63,'#ecd7b3','#d9bd8d','#e4c99a');
  face([[-.515,-.94,20],[-.515,.57,20],[-.515,.57,35],[-.515,-.94,35]],'#7d9b82');
  for(let j=0;j<8;j++){
   const y=-.88+j*.19;line([[-.518,y,21],[-.518,y,34]],'#5e826e',.55);
  }
  face([[-.52,-.8,37],[-.52,-.11,37],[-.52,-.11,58],[-.52,-.8,58]],'#9b825a');
  face([[-.525,-.76,39],[-.525,-.15,39],[-.525,-.15,56],[-.525,-.76,56]],'#f6bf55');
  face([[-.529,-.725,40],[-.529,-.475,40],[-.529,-.475,54],[-.529,-.725,54]],'#ffe9a2');
  face([[-.529,-.445,40],[-.529,-.18,40],[-.529,-.18,54],[-.529,-.445,54]],'#ffe293');
  line([[-.532,-.8,37],[-.532,-.8,58],[-.532,-.11,58],[-.532,-.11,37],[-.532,-.8,37]],'#f6e0b5',2.1);
  line([[-.535,-.46,38],[-.535,-.46,57]],'#d49b51',1.6);
  line([[-.537,-.77,47],[-.537,-.14,47]],'#e3ac61',1);
  line([[-.54,-.84,36],[-.54,-.07,36]],'#c7965f',2.1);
  // A narrow second glazed panel catches cool water behind the warm window.
  face([[-.525,.09,38],[-.525,.4,38],[-.525,.4,57],[-.525,.09,57]],'#668d79','#f1d7a9',1.4);
  face([[-.53,.12,40],[-.53,.23,40],[-.53,.36,55],[-.53,.25,55]],'#a6bda0');
  line([[-.535,.08,47],[-.535,.41,47]],'#f1d7a9',1.2);
  face([[-.36,.576,20],[.36,.576,20],[.36,.576,61],[-.36,.576,61]],'#406e5f','#f0d7a7',2);
  for(const x of[-.28,-.14,0,.14,.28])line([[x,.58,21],[x,.58,60]],'#355e53',.55);
  // Envelope plate is part of the cabin door, in that door's actual plane.
  face([[-.23,.59,37],[.23,.59,37],[.23,.59,52],[-.23,.59,52]],'#efd19a','#bd945d',.8);
  line([[-.23,.592,52],[0,.592,43.2],[.23,.592,52]],'#a87445',1.1);
  line([[-.23,.592,37],[-.055,.592,44],[.055,.592,44],[.23,.592,37]],'#bd8b50',.85);
  face([[.27,.595,29],[.3,.595,29],[.3,.595,33],[.27,.595,33]],'#e9bd6b');
  box(-.56,-.985,.56,.615,61.8,64,'#f5ddb2','#d6b78b','#dfc39a');
  const roof=[[-.6,64],[-.46,68.2],[-.25,71.2],[0,72.3],[.25,71.2],[.46,68.2],[.6,64]];
  for(let j=0;j<roof.length-1;j++){
   const p=roof[j],q=roof[j+1];
   face([[p[0],-1.015,p[1]],[q[0],-1.015,q[1]],[q[0],.665,q[1]],[p[0],.665,p[1]]],['#ef9c71','#e99165','#df825d','#d47754','#c5694c','#b55d45'][j]);
   line([[p[0],-1.015,p[1]+.15],[p[0],.665,p[1]+.15]],'#f0b48b',.65);
  }
  face(roof.map(p=>[p[0],.67,p[1]]).concat([[.6,.67,61.8],[-.6,.67,61.8]]),'#bd7157');
  line(roof.map(p=>[p[0],.675,p[1]+.2]),'#f1b084',1.4);
  for(const y of[-.86,-.24,.38])line(roof.map(p=>[p[0],y,p[1]+.3]),'#f4ba92',.65);
  // Tiny paper fibres follow each large material, rather than a screen noise
  // overlay that would float independently of this rigid boat.
  for(let i=0;i<48;i++){
   const x=-.47+(i*13%43)*.021,y=-.96+(i*11%47)*.033,z=72.3-Math.abs(x)*6.9;
   line([[x,y,z+.4],[x+.018,y+.032,z+.25]],i%3?'#efb28b':'#b86c52',.3);
  }
  // Cargo in the open bow, with ordinary tape and readable folded box rims.
  parcel(.06,.82,.38,.38,18.5,17);parcel(-.39,.86,.34,.36,18.5,13);
  parcel(.08,.84,.29,.27,35.5,13);parcel(-.17,1.28,.32,.26,18.5,11);
  // Fore and side rails are drawn last so contents sit inside their rim.
  for(let i=0;i<MAIL_HULL.length;i++){
   const p=MAIL_HULL[i],q=MAIL_HULL[(i+1)%MAIL_HULL.length];
   if(!visible(q[1]-p[1],p[0]-q[0]))continue;
   face([[p[0]*1.025,p[1]*1.007,15.5],[q[0]*1.025,q[1]*1.007,15.5],[q[0]*1.025,q[1]*1.007,18.1],[p[0]*1.025,p[1]*1.007,18.1]],'#ecd1a0');
   line([[p[0]*1.025,p[1]*1.007,18.2],[q[0]*1.025,q[1]*1.007,18.2]],'#fff0c7',1.2);
  }
  const fender=(x,y)=>{
   const ring=[];for(let j=0;j<10;j++){const p=j*TAU/10;ring.push([x+Math.cos(p)*.065,y+Math.sin(p)*.065]);}
   for(let j=0;j<ring.length;j++){
    const p=ring[j],q=ring[(j+1)%ring.length];if(!visible(q[1]-p[1],p[0]-q[0]))continue;
    face([[p[0]*1,p[1],4],[q[0],q[1],4],[q[0],q[1],17],[p[0],p[1],17]],j%2?'#eadcc0':'#d9c9aa');
   }
   face(ring.map(p=>[p[0],p[1],17]),'#f5e8cb');
   line([[x,y,17],[x+.06,y,22],[x+.12,y,18]],'#b4a184',1);
   line([[x-.04,y,5],[x-.04,y,15]],'#fbf0d8',.8);
  };
  fender(-.72,-.87);fender(-.72,.84);fender(-.4,1.56);
  box(.45,1.39,.51,1.45,18.4,23,'#c5aa77','#62766a','#49665d');
  box(.42,1.4,.54,1.44,22,24,'#d0b680','#6f7f6b','#526a5c');
  // One genuine slack mooring line meets the exposed quay bollard. Its boat
  // endpoint follows bobbing while the stone endpoint remains fixed.
  const moor=LAYOUT.mailBoat.moorings[LAYOUT.mailBoat.activeMooring],start={x:.48,y:1.42,z:22.5},points=[];
  const sx=start.x*ca-start.y*sa,sy=start.x*sa+start.y*ca;
  for(let i=0;i<=28;i++){
   const u=i/28,x=sx+(moor.x-a.x-sx)*u,y=sy+(moor.y-a.y-sy)*u;
   const z=start.z+(moor.z-a.z-start.z)*u-Math.sin(u*Math.PI)*13;
   points.push({x:(x-y)*HW,y:(x+y)*HH-z,boatWeight:1-u});
  }
  ropes.push({points,stroke:'#775c40',width:3.4},{points,stroke:'#e5bd79',width:2.15});
  // Make the hull/cabin reflection from those very faces, reflected below
  // the water plane and sliced into uneven horizontal paper wavelets once.
  const clipBand=(points,y0,y1)=>{
   let out=points;
   for(const [edge,side]of[[y0,1],[y1,-1]]){
    const input=out;out=[];if(!input.length)break;
    let p=input[input.length-1],dp=(p.y-edge)*side;
    for(const q of input){
     const dq=(q.y-edge)*side;
     if((dq>=0)!==(dp>=0)){const u=dp/(dp-dq);out.push({x:p.x+(q.x-p.x)*u,y:edge});}
     if(dq>=0)out.push(q);p=q;dp=dq;
    }
   }
   return out;
  };
  for(let band=0;band<14;band++){
   const y0=-37+band*10.6+(band%3)*1.3,y1=y0+3.4+(band%4)*1.1,dx=(band%3-1)*3.1;
   for(const path of mirror){
    const points=clipBand(path.points,y0,y1);if(points.length<3)continue;
    const tint=(hex,amount)=>{const c=parseInt(hex.slice(1),16),w=0x428c85;return '#'+[16,8,0].map(s=>Math.round(((c>>s)&255)*(1-amount)+((w>>s)&255)*amount).toString(16).padStart(2,'0')).join('');};
    reflection.push({points:points.map(p=>({x:p.x+dx,y:p.y})),fill:tint(path.fill,path.fill==='#ffe9a2'||path.fill==='#ffe293'?.12:.48),sourceFill:path.fill,stroke:null,width:1});
   }
  }
  for(let j=0;j<4;j++){
   const scale=1.09+j*.072;
   for(let i=1;i<MAIL_HULL.length;i+=2){
    const p=MAIL_HULL[i],q=MAIL_HULL[(i+1)%MAIL_HULL.length];
    ripples.push(command([[p[0]*scale,p[1]*scale,0],[q[0]*scale,q[1]*scale,0]],null,j%2?'#86b3a0':'#b1c8a7',.6,angle,true));
   }
  }
  return{body,contact,reflection,ripples,ropes};
 }
 drawMailWater(time){
  const c=this.r.ctx,t=wrap(time),a=LAYOUT.mailBoat,boat=this.mailBoat;
  c.save();c.translate(760+(a.x-a.y)*HW,465+(a.x+a.y)*HH-a.z);
  c.save();c.globalAlpha*=.24+Math.sin(t*TAU/28)*.025;c.translate(Math.sin(t*TAU/14)*.8,Math.sin(t*TAU/28)*.4);replay(c,boat.reflection);c.restore();
  c.save();c.globalAlpha*=.52;replay(c,boat.contact);c.restore();
  c.save();c.globalAlpha*=.29+Math.sin(t*TAU/7)*.06;replay(c,boat.ripples);c.restore();c.restore();
 }
 drawMailBoat(time){
  const c=this.r.ctx,t=wrap(time),a=LAYOUT.mailBoat,boat=this.mailBoat,bob=Math.sin(t*TAU/7)*.3+Math.sin(t*TAU/12)*.08;
  c.save();c.translate(760+(a.x-a.y)*HW,465+(a.x+a.y)*HH-a.z);
  for(let j=0;j<boat.ropes.length;j++){
   const rope=boat.ropes[j];c.beginPath();
   for(let i=0;i<rope.points.length;i++){
    const p=rope.points[i],y=p.y-p.boatWeight*bob;if(i)c.lineTo(p.x,y);else c.moveTo(p.x,y);
   }
   c.strokeStyle=rope.stroke;c.lineWidth=rope.width;c.stroke();
  }
  c.translate(0,-bob);
  if(this.mailBoatCanvas){const b=this.mailBoatBounds;c.drawImage(this.mailBoatCanvas,b.left,b.top,b.right-b.left,b.bottom-b.top);}else replay(c,boat.body);c.restore();
 }
 drawSurface(time){
  const c=this.r.ctx,t=wrap(time);c.save();
  if(this.waterCanvas){const b=this.waterBounds;this.r.scenery.draw(this.waterCanvas,b.left,b.top,b.right-b.left,b.bottom-b.top);}else replay(c,this.water);
  for(let i=0;i<this.currents.length;i++){
   const current=this.currents[i],flow=Math.sin(t*TAU/56-current.phase)*.019,cross=Math.sin(t*TAU/28-current.phase)*.005;
   const x=current.axis?flow:cross,y=current.axis?cross:flow;
   c.save();c.globalAlpha*=.66+Math.sin(t*TAU/28-current.phase)*.1;c.translate((x-y)*HW,(x+y)*HH);replay(c,current.commands);c.restore();
  }
  for(let i=0;i<this.reflections.length;i++){
   const reflection=this.reflections[i],spread=Math.sin(t*TAU/28-reflection.phase)*.006;
   c.save();const alpha=c.globalAlpha;
   c.translate(spread*HW,spread*HH);
   for(let j=0;j<reflection.commands.length;j++){
    c.globalAlpha=alpha*(reflection.alpha+Math.sin(t*TAU/14-reflection.phase+j*.91)*(reflection.kind==='distant'?.035:.09));
    replayPath(c,reflection.commands[j]);
   }c.restore();
  }
  replay(c,this.shoreline);c.restore();
 }
 draw(time){
  const c=this.r.ctx,pose=sampleBoat(time,this.pose),t=wrap(time),frame=this.frames[Math.round(pose.heading/TAU*FRAMES)%FRAMES];
  this.drawSurface(time);c.save();
  c.translate(760+(pose.x-pose.y)*HW,465+(pose.x+pose.y)*HH-pose.z);
  c.save();c.globalAlpha*=.38;replay(c,frame.reflection);c.restore();
  c.save();c.globalAlpha*=.21;replay(c,frame.contact);c.restore();
  if(pose.speed>.001){
   c.save();c.globalAlpha*=Math.min(1,pose.speed/.16)*(.52+Math.sin(t*TAU/4)*.05);replay(c,frame.wake);c.restore();
   const clearance=pose.heading<Math.PI/2?pose.y+3.5:9-pose.y;
   const reach=Math.min(1,Math.max(0,(pose.speed-.06)/.1))*Math.min(1,Math.max(0,(clearance-1.12)/.18));
   if(reach>0){c.save();c.globalAlpha*=reach*.36;replay(c,frame.wakeLong);c.restore();}
  }
  c.translate(0,-pose.bob);replay(c,frame.body);c.restore();
  this.drawMailWater(time);
 }
}
root.CivicCanal=Canal;
if(typeof module==='object'&&module.exports)module.exports=Canal;
})(typeof globalThis!=='undefined'?globalThis:this);
