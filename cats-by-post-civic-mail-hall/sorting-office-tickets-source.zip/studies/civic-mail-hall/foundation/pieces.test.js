'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const Projection=require('./projection.js');
function setup(){
 let created=0,gradients=0,draws=[],shadows=[];
 const context=new Proxy({globalAlpha:1,createLinearGradient(){gradients++;return {addColorStop(){}};}},{get(o,k){return k in o?o[k]:(...args)=>{};}});
 const document={createElement(){created++;return {width:0,height:0,getContext(){return context;}};}};
 const c=vm.createContext({document,CivicProjection:Projection,BOARDANIM:require('./vendor/sim/12_boardanim.js')});vm.runInContext(fs.readFileSync(__dirname+'/pieces.js','utf8'),c);
 context.drawImage=(...args)=>draws.push(args);
 const pieces=new c.CivicPieces({ctx:context,shadow:(...v)=>shadows.push(v)});
 return {pieces,draws,shadows,created:()=>created,gradients:()=>gradients};
}
test('all headings and fold states share cached kraft shells, anchored full and front passes',()=>{
 const {pieces,draws,shadows,created,gradients}=setup();assert.equal(created(),40);const bakedGradients=gradients();assert.ok(bakedGradients>0);
 for(let d=0;d<4;d++)for(let fold=0;fold<5;fold++)for(const front of [false,true]){
  pieces.carrier(24,40,d,fold,.25,front);const args=draws.at(-1),p=pieces.point(24,40);
  assert.equal(args[0],pieces.carriers[(d*5+fold)*2+Number(front)]);
  assert.deepEqual(args.slice(1),[p.x-64,p.y-56,128,96]);
 }
 assert.equal(shadows.length,20);assert.equal(created(),40,'sampling must not bake frames');assert.equal(gradients(),bakedGradients,'material shading is baked, never rebuilt during delivery');
 const n=draws.length;pieces.carrier(0,0,0,-1);pieces.carrier(0,0,0,0,1);assert.equal(draws.length,n);
});
test('occupied and takeoff-supported cats reuse the same full/front geometry',()=>{
 const {pieces,draws}=setup(),BA=require('./vendor/sim/12_boardanim.js');pieces.asset=()=>{};
 for(let d=0;d<4;d++){
  draws.length=0;pieces.boxed({x:24,y:40,z:0,dir:d,head:d,anim:BA.A.IDLE},{coat:1},0);
  assert.equal(draws.length,2);assert.equal(draws[0][0],pieces.carriers[d*10]);assert.equal(draws[1][0],pieces.carriers[d*10+1]);
  const occupiedFront=draws[1].slice(1);draws.length=0;pieces.anchored=()=>{};
  const tr={coat:1,n:1,rel:0,tick:.3,d0:[d],ox:0,oy:0,x1:[2],y1:[2],end:BA.END_HOME,homeDX:0,homeDY:0};
  pieces.loose({x:24,y:40,boxX:24,boxY:40,dir:d,takeoff:0,takeoffSupported:1},tr,.5);
  assert.equal(draws.length,1);assert.equal(draws[0][0],pieces.carriers[d*10+1]);assert.deepEqual(draws[0].slice(1),occupiedFront,'rim must not jump when cat leaves');
  draws.length=0;pieces.loose({dir:d,takeoff:1,takeoffSupported:0},tr,.8);assert.equal(draws.length,0,'airborne cat must clear rim');
 }
});
