'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),P=require('./projection.js');
let A;try{A=require('./architecture.js');}catch{A={};}
test('fixed hall contains all accepted boards without moving its footprint',()=>{
 assert.equal(typeof A.layout,'function','hall layout is not implemented');
 const l=A.layout();assert.deepEqual(l.floor,{x0:-3,y0:-2,x1:7.2,y1:5.2});
 const levels=require('./vendor/data/levels.json').levels.filter(l=>!l.room||l.room==='office');
 for(const level of levels){assert.ok(level.board.w<l.floor.x1);assert.ok(level.board.h<l.floor.y1);}
});
test('stair treads connect the floor continuously to the gallery',()=>{
 assert.equal(typeof A.layout,'function','hall layout is not implemented');
 const l=A.layout(),s=l.stairs;assert.equal(s.length,12);assert.equal(s[0].bottom,0);assert.equal(s.at(-1).top,l.galleryZ);
 for(let i=1;i<s.length;i++){assert.equal(s[i].bottom,s[i-1].top);assert.ok(Math.abs(s[i].y1-s[i-1].y0)<1e-9);}
 assert.ok(Math.abs(s.at(-1).y0-l.landingY)<1e-9);
});
test('tall architectural solids remain outside the largest projected board',()=>{
 assert.equal(typeof A.layout,'function','hall layout is not implemented');
 const l=A.layout();assert.ok(l.solids.length>=5);
 for(const b of l.solids){const pts=[];for(const x of [b.x0,b.x1])for(const y of [b.y0,b.y1])for(const z of [b.z0,b.z1]){const p=P.project(x,y,z);pts.push(P.unproject(p.x,p.y));}
 assert.ok(pts.every(p=>p.x<0)||pts.every(p=>p.y<0),b.name+' projects onto the board');}
});
test('whole-hall bounds include roof, foundation and loading edge',()=>{
 assert.equal(typeof A.layout,'function','hall layout is not implemented');
 const l=A.layout(),b=l.bounds;for(const [x,y,z]of l.extents){const p=P.project(x,y,z);assert.ok(p.x>=b.left&&p.x<=b.right&&p.y>=b.top&&p.y<=b.bottom,JSON.stringify([x,y,z,p,b]));}
});
test('gallery columns stand on clear floor, avoid the cabinet and support the deck',()=>{
 const boxes=[],columns=[];
 const p={ctx:{save(){},clip(){},restore(){}},path(){},surfaceLight(){},box(x,y,w,h,z,height,mat){boxes.push({x0:x,x1:x+w,y0:y,y1:y+h,z0:z,z1:z+height,mat});},poly(){},face(){},line3(){},brace(){},column(x,y,height){const start=boxes.length;A.Painter.prototype.column.call(this,x,y,height);columns.push(boxes.slice(start));}};
 const a=new A({});a.cabinet(p);const cabinet=boxes.splice(0);a.galleryLower(p);
 const intersects=(a,b)=>a.x0<b.x1&&a.x1>b.x0&&a.y0<b.y1&&a.y1>b.y0&&a.z0<b.z1&&a.z1>b.z0;
 assert.equal(columns.length,5);
 const deck=boxes.find(b=>b.z0===166&&b.z1===180);
 for(const column of columns){
  const foot=column[0],cap=column.at(-1);assert.equal(foot.z0,0,'pillar has no floor contact');
  for(const solid of A.layout().solids.filter(b=>b.name==='stairs'||b.name==='counter'))assert.ok(!intersects(foot,solid),'pillar foot intersects '+solid.name);
  for(const part of column){for(const solid of cabinet)assert.ok(!intersects(part,solid),'pillar intersects the cubby cabinet');assert.ok(part.y1<0,'pillar enters playable board');}
  assert.ok(cap.y0<deck.y1&&cap.y1>deck.y0&&cap.x0<deck.x1&&cap.x1>deck.x0&&cap.z1>=deck.z0,'pillar cap misses gallery deck');
 }
});
test('gallery parcels are supported and draw behind posts and the front railing',()=>{
 const events=[],boxes=[];
 const p={box(x,y,w,h,z,height){boxes.push({x,y,w,h,z,height});events.push({kind:'post'});},parcel(x,y,z,w,h,height){events.push({kind:'parcel',x,y,z,w,h,height});},rail(){events.push({kind:'rail'});},poly(){},line3(){},brace(){},lamp(){},plant(){}};
 new A({}).galleryUpper(p);
 const parcels=events.filter(e=>e.kind==='parcel');assert.equal(parcels.length,5);
 assert.ok(events.findLastIndex(e=>e.kind==='parcel')<events.findIndex(e=>e.kind==='post'),'boxes paint over structural posts');
 assert.ok(events.findLastIndex(e=>e.kind==='parcel')<events.findIndex(e=>e.kind==='rail'),'boxes paint over foreground rail');
 const deck=A.layout().solids.find(b=>b.name==='gallery');
 for(const b of parcels){
  if(b.z===182)assert.ok(b.x>=deck.x0&&b.x+b.w<=deck.x1&&b.y>=deck.y0&&b.y+b.h<=deck.y1,'parcel footprint leaves gallery floor');
  else assert.ok(parcels.some(a=>a!==b&&a.z+a.height===b.z&&b.x>=a.x&&b.x+b.w<=a.x+a.w&&b.y>=a.y&&b.y+b.h<=a.y+a.h),'stacked parcel has no complete supporting top');
  for(const post of boxes.filter(p=>p.z===182))assert.ok(b.x+b.w<=post.x||b.x>=post.x+post.w||b.y+b.h<=post.y||b.y>=post.y+post.h,'parcel intersects gallery post');
 }
});
