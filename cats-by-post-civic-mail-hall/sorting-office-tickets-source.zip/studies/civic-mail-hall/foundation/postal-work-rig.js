/* Folded-card meshes in the board's world coordinates. Geometry buffers and
 * joint scratch space are allocated once; live frames only move vertices. */
(function(root,factory){
 const P=typeof module==='object'&&module.exports?require('./projection.js'):root.CivicProjection;
 const L=typeof module==='object'&&module.exports?require('./postal-work-layout.js'):root.CivicPostalLayout;
 const Rig=factory(P,L);if(typeof module==='object'&&module.exports)module.exports=Rig;root.CivicPostalRig=Rig;
})(globalThis,function(P,L){
'use strict';
const U=P.HW,TAU=Math.PI*2;
const colours={ivory:['#f8ead2','#dfc8ab','#bea48b'],teal:['#86aaa0','#467c75','#2b5756'],brass:['#efd09a','#bf965a','#8e6c49'],paper:['#faf0d8','#e2d1b3','#bbae96'],parcel:['#e5be93','#c29570','#a97e60'],ink:['#294d4b','#294d4b','#294d4b'],eye:['#ffda70','#ffda70','#ffda70'],rubber:['#60706a','#3d5750','#2b4140'],tape:['#f6e4c2','#e4cda7','#c5ab87']};
// All tonal stocks are prepared once. Existing face normals select a stock,
// so the light stays in the room when the robot turns; chamfers acquire
// their own intermediate tones without changing contact geometry.
const SHADE_STEPS=24,stocks={};
for(const palette of Object.values(colours)){
 const levels=[];
 for(let i=0;i<SHADE_STEPS;i++){
  const t=i/(SHADE_STEPS-1),mix=t<.68?t/.68:(t-.68)/.32;
  const a=parseInt(palette[t<.68?2:1].slice(1),16),b=parseInt(palette[t<.68?1:0].slice(1),16);
  let hex='#';for(const shift of [16,8,0])hex+=Math.round(((a>>shift)&255)*(1-mix)+((b>>shift)&255)*mix).toString(16).padStart(2,'0');
  levels.push(hex);
 }
 for(const colour of palette)stocks[colour]=levels;
}
const octX=[-.32,.32,.5,.5,.32,-.32,-.5,-.5],octY=[-.5,-.5,-.32,.32,.5,.5,.32,-.32];
function solveJoint(ax,ay,az,bx,by,bz,l1,l2,hx,hy,hz,out){
 let dx=bx-ax,dy=by-ay,dz=bz-az,d=Math.hypot(dx,dy,dz);d=Math.max(1e-8,d);
 dx/=d;dy/=d;dz/=d;const along=(l1*l1-l2*l2+d*d)/(2*d),height=Math.sqrt(Math.max(0,l1*l1-along*along));
 const dot=hx*dx+hy*dy+hz*dz;hx-=dot*dx;hy-=dot*dy;hz-=dot*dz;let h=Math.hypot(hx,hy,hz);
 if(h<1e-6){hx=dy;hy=-dx;hz=0;h=Math.hypot(hx,hy);if(h<1e-6){hx=1;hy=hz=0;h=1;}}
 out[0]=ax+dx*along+hx/h*height;out[1]=ay+dy*along+hy/h*height;out[2]=az+dz*along+hz/h*height;return out;
}
// The bend pole follows the torso with a small inward bias. It keeps the
// elbows in the aisle without intersecting the IK circle with an x-plane,
// whose tangencies could make the elbow jump between distant solutions.
function aisleJoint(ax,ay,az,bx,by,bz,side,yaw,out){
 const si=Math.sin(yaw),co=Math.cos(yaw);
 solveJoint(ax,ay,az,bx,by,bz,22,22,si*.1-side*co*.3,co*.1+side*si*.3,1,out);
}
class Mesh{
 constructor(){
  this.faces=Array.from({length:768},()=>({vertices:new Float64Array(24),screen:new Float64Array(16),count:0,depth:0,colour:'',grain:true}));
  this.order=new Uint16Array(768);this.scratch=new Float64Array(96);this.count=0;
 }
 reset(){this.count=0;}
 vertex(i,x,y,z){const s=this.scratch;i*=3;s[i]=x;s[i+1]=y;s[i+2]=z;}
 face(a,b,c,d,colour,grain=true){
  const s=this.scratch,ia=a*3,ib=b*3,ic=c*3;
  const ax=(s[ib]-s[ia])*U,ay=(s[ib+1]-s[ia+1])*U,az=s[ib+2]-s[ia+2],bx=(s[ic]-s[ia])*U,by=(s[ic+1]-s[ia+1])*U,bz=s[ic+2]-s[ia+2];
  const nx=ay*bz-az*by,ny=az*bx-ax*bz,nz=ax*by-ay*bx;
  if(nx+ny+nz<=1e-8)return;
  const light=Math.max(0,Math.min(1,((-.28*nx+.48*ny+.84*nz)/Math.hypot(nx,ny,nz)+.28)/1.12));
  const f=this.faces[this.count];if(!f)throw Error('postal mesh capacity');f.count=d<0?3:4;f.depth=0;f.colour=stocks[colour]?.[Math.round(light*(SHADE_STEPS-1))]||colour;f.grain=grain;
  for(let k=0;k<f.count;k++){const src=(k===0?a:k===1?b:k===2?c:d)*3,o=k*3,x=s[src],y=s[src+1],z=s[src+2];f.vertices[o]=x;f.vertices[o+1]=y;f.vertices[o+2]=z;f.screen[k*2]=760+(x-y)*P.HW;f.screen[k*2+1]=465+(x+y)*P.HH-z;f.depth+=(x+y)*U+z;}
  f.depth/=f.count;this.order[this.count]=this.count;this.count++;
 }
 box(x,y,z,w,d,h,yaw=0,mat='ivory'){
  const co=Math.cos(yaw),si=Math.sin(yaw),p=colours[mat];
  for(let i=0;i<8;i++){const a=((i===1||i===2||i===5||i===6)?1:-1)*w/2,b=((i===2||i===3||i===6||i===7)?1:-1)*d/2;this.vertex(i,x+a*co+b*si,y-a*si+b*co,z+(i>3?h:0));}
  this.face(0,3,2,1,p[2]);this.face(4,5,6,7,p[0]);this.face(0,1,5,4,p[2]);this.face(1,2,6,5,p[2]);this.face(2,3,7,6,p[1]);this.face(3,0,4,7,p[1]);
 }
 chamfer(x,y,z,w,d,h,yaw,mat){
  const co=Math.cos(yaw),si=Math.sin(yaw),p=colours[mat];
  for(let i=0;i<16;i++){const k=i%8,a=octX[k]*w,b=octY[k]*d;this.vertex(i,x+a*co+b*si,y-a*si+b*co,z+(i>7?h:0));}
  for(let i=0;i<8;i++)this.face(i,(i+1)%8,(i+1)%8+8,i+8,p[i<4?2:1]);
  this.face(8,9,10,15,p[0]);this.face(15,10,11,14,p[0]);this.face(14,11,12,13,p[0]);
 }
 strut(ax,ay,az,bx,by,bz,width,mat){
  const dx=(bx-ax)*U,dy=(by-ay)*U,dz=bz-az,len=Math.hypot(dx,dy,dz)||1;
  let ux=-dy,uy=dx,uz=0,n=Math.hypot(ux,uy);if(n<1e-6){ux=1;uy=0;n=1;}ux/=n;uy/=n;
  const vx=-dz*uy/len,vy=dz*ux/len,vz=(dx*uy-dy*ux)/len;
  for(let i=0;i<8;i++){const a=((i===1||i===2||i===5||i===6)?1:-1)*width/2,b=((i===2||i===3||i===6||i===7)?1:-1)*width/2;this.vertex(i,(i>3?bx:ax)+(ux*a+vx*b)/U,(i>3?by:ay)+(uy*a+vy*b)/U,(i>3?bz:az)+(uz*a+vz*b));}
  const p=colours[mat];this.face(0,3,2,1,p[2]);this.face(4,5,6,7,p[0]);this.face(0,1,5,4,p[2]);this.face(1,2,6,5,p[2]);this.face(2,3,7,6,p[1]);this.face(3,0,4,7,p[1]);
 }
 disk(x,y,z,radius,height,yaw,mat){
  const p=colours[mat];for(let k=0;k<16;k++){const a=(k%8)*TAU/8+yaw;this.vertex(k,x+Math.cos(a)*radius,y+Math.sin(a)*radius,z+(k>7?height:0));}
  this.vertex(16,x,y,z+height);for(let k=0;k<8;k++){this.face(k,(k+1)%8,(k+1)%8+8,k+8,p[1]);this.face(16,k+8,(k+1)%8+8,-1,p[0]);}
 }
 // Wheel axles run along x. Rim vertices stay fixed (including bottomz0);
 // the inset brass spoke rotates, so faceting never lifts the rolling tyre.
 wheel(x,y,z,radius,angle){
  for(let side=0;side<2;side++)for(let i=0;i<12;i++){const a=i*TAU/12;this.vertex(side*12+i,x+(side? .028:-.028),y+Math.sin(a)*radius/U,z+Math.cos(a)*radius);}
  for(let i=0;i<12;i++){const j=(i+1)%12;this.face(i,j,12+j,12+i,colours.rubber[1],false);}
  this.vertex(24,x+.029,y,z);for(let i=0;i<12;i++)this.face(24,12+(i+1)%12,12+i,-1,colours.teal[1]);
  const dy=Math.sin(angle)*radius*.7/U,dz=Math.cos(angle)*radius*.7;
  this.strut(x+.034,y-dy,z-dz,x+.034,y+dy,z+dz,1.4,'brass');
  this.box(x+.04,y,z-1.8,.035,.055,3.6,0,'brass');
 }
 draw(c,pattern){
  const n=this.count,order=this.order,faces=this.faces;
  // Insertion sorting a reusable index buffer avoids allocating face arrays.
  for(let i=1;i<n;i++){const k=order[i],depth=faces[k].depth;let j=i-1;while(j>=0&&faces[order[j]].depth>depth){order[j+1]=order[j];j--;}order[j+1]=k;}
  c.lineWidth=.38;c.lineJoin='round';
  for(let i=0;i<n;i++){const f=faces[order[i]],v=f.screen;c.beginPath();c.moveTo(v[0],v[1]);for(let k=1;k<f.count;k++)c.lineTo(v[k*2],v[k*2+1]);c.closePath();c.fillStyle=f.grain&&pattern?.[f.colour]||f.colour;c.fill();c.strokeStyle='#594e3928';c.stroke();

  }
 }
}
class Rig{
 constructor(renderer){this.r=renderer;this.mesh=new Mesh();this.joint=new Float64Array(3);this.pattern=null;this.shadowTile=null;this.bakes=0;this.links=new Float64Array(24);}
 bake(){
  const r=this.r,q=r.assets.materials?.materials?.ivory?.atlasRect;this.pattern={};
  // Neutral, centred grain preserves the palette instead of adding a second
  // yellow wash. Every face still needs only one cached pattern fill.
  if(q&&r.images.materials){
   const grain=document.createElement('canvas');grain.width=grain.height=64;const gc=grain.getContext('2d');gc.drawImage(r.images.materials,...q,0,0,64,64);
   const pixels=gc.getImageData(0,0,64,64),data=pixels.data;let mean=0;
   for(let i=0;i<data.length;i+=4)mean+=data[i]*.2126+data[i+1]*.7152+data[i+2]*.0722;mean/=4096;
   for(let i=0;i<data.length;i+=4){const v=Math.max(0,Math.min(255,128+(data[i]*.2126+data[i+1]*.7152+data[i+2]*.0722-mean)*2));data[i]=data[i+1]=data[i+2]=v;}
   gc.putImageData(pixels,0,0);
   for(const shades of Object.values(stocks))for(const colour of shades){
    if(this.pattern[colour])continue;const tile=document.createElement('canvas');tile.width=tile.height=64;const c=tile.getContext('2d');
    c.fillStyle=colour;c.fillRect(0,0,64,64);c.globalCompositeOperation='soft-light';c.globalAlpha=.55;c.drawImage(grain,0,0);this.pattern[colour]=r.ctx.createPattern(tile,'repeat');
   }
  }
  this.shadowTile=document.createElement('canvas');this.shadowTile.width=this.shadowTile.height=64;const sc=this.shadowTile.getContext('2d'),g=sc.createRadialGradient(32,32,1,32,32,31);
  g.addColorStop(0,'#514631');g.addColorStop(.36,'#514631c9');g.addColorStop(1,'#51463100');sc.fillStyle=g;sc.fillRect(0,0,64,64);
  this.bakes++;
 }

 robot(s){
  const m=this.mesh,b=s.robot,yaw=b.yaw,co=Math.cos(yaw),si=Math.sin(yaw),x=b.x+si*b.lean,y=b.y+co*b.lean,bob=b.bob;
  m.chamfer(x,y,34+bob,.28,.23,25,yaw,'ivory');m.box(x,y,59+bob,.11,.10,5,yaw,'brass');
  const hy=yaw+(b.headYaw||0),hs=Math.sin(hy),hc=Math.cos(hy);
  m.chamfer(x,y,64+bob,.43,.33,22,hy,'ivory');
  m.box(x+hs*.169,y+hc*.169,68+bob,.32,.016,14,hy,'ink');
  for(let side=-1;side<=1;side+=2)m.box(x+hs*.182+hc*side*.085,y+hc*.182-hs*side*.085,73+bob,.035,.018,5,hy,'eye');
  m.box(x,y,86+bob,.035,.035,5,hy,'brass');m.chamfer(x,y,91+bob,.08,.08,4,hy,'teal');
  // Envelope badge sits on the body plane and turns with the torso.
  m.box(x+si*.122,y+co*.122,43+bob,.12,.012,8,yaw,'paper');
  m.strut(x+si*.132-co*.055,y+co*.132+si*.055,50+bob,x+si*.132,y+co*.132,46+bob,1,'brass');
  m.strut(x+si*.132+co*.055,y+co*.132-si*.055,50+bob,x+si*.132,y+co*.132,46+bob,1,'brass');
  for(let i=0;i<2;i++){
   const side=i?1:-1,f=b.feet[i],hx=b.x+co*side*.10,hy0=b.y-si*side*.10,hz=32+bob,ax=f.x,ay=f.y,az=f.z+6;
   solveJoint(hx*U,hy0*U,hz,ax*U,ay*U,az,17,17,si,co,0,this.joint);
   const kx=this.joint[0]/U,ky=this.joint[1]/U,kz=this.joint[2];
   m.strut(hx,hy0,hz,kx,ky,kz,6,'ivory');m.chamfer(kx,ky,kz-3.2,.105,.105,6.4,yaw,'teal');m.strut(kx,ky,kz,ax,ay,az,5.5,'ivory');
   m.chamfer(f.x,f.y,f.z,.15,.26,6,f.yaw,'teal');m.box(f.x,f.y,f.z+.1,.145,.25,1.2,f.yaw,'rubber');
   const h=b.hands[i],sx=x+co*side*.18,sy=y-si*side*.18,sz=56+bob;
   aisleJoint(sx*U,sy*U,sz,h.x*U,h.y*U,h.z,side,yaw,this.joint);
   const ex=this.joint[0]/U,ey=this.joint[1]/U,ez=this.joint[2];
   const o=i*12;this.links[o]=hx;this.links[o+1]=hy0;this.links[o+2]=hz;this.links[o+3]=kx;this.links[o+4]=ky;this.links[o+5]=kz;this.links[o+6]=sx;this.links[o+7]=sy;this.links[o+8]=sz;this.links[o+9]=ex;this.links[o+10]=ey;this.links[o+11]=ez;
   m.chamfer(sx,sy,sz-4,.12,.12,8,yaw,'teal');m.strut(sx,sy,sz,ex,ey,ez,5.8,'ivory');m.chamfer(ex,ey,ez-3,.10,.10,6,yaw,'brass');m.strut(ex,ey,ez,h.x,h.y,h.z,5,'ivory');
   m.chamfer(h.x,h.y,h.z-2.5,.09,.07,5,yaw,'teal');
   const handYaw=h.attachment==='parcel'?s.parcel.yaw:yaw,hc=Math.cos(handYaw),hs=Math.sin(handYaw),gap=.025+.055*(1-h.grip);
   for(let finger=-1;finger<=1;finger+=2){
    m.strut(h.x+hc*gap* finger-hs*.025,h.y-hs*gap* finger-hc*.025,h.z,h.x+hc*gap* finger+hs*.055,h.y-hs*gap* finger+hc*.055,h.z,1.8,'brass');
    m.strut(h.x+hc*gap* finger+hs*.055,h.y-hs*gap* finger+hc*.055,h.z,h.x+hc*gap*.55* finger+hs*.06,h.y-hs*gap*.55* finger+hc*.06,h.z,1.8,'brass');
   }
  }
 }
 cart(s){
  const m=this.mesh,c=s.cart,x=c.x,y=c.y;
  for(let side=-1;side<=1;side+=2)for(let end=-1;end<=1;end+=2)m.wheel(x+side*L.cart.wheelHalfWidth,y+end*L.cart.wheelHalfDepth,L.cart.wheelRadius,L.cart.wheelRadius,c.wheelAngle);
  m.box(x,y,9,.44,.50,4,0,'teal');
  for(let side=-1;side<=1;side+=2)for(let end=-1;end<=1;end+=2)m.strut(x+side*.20,y+end*.23,12,x+side*.20,y+end*.23,55,3.2,'teal');
  m.strut(x-.20,y-.23,13,x+.20,y-.23,54,2.2,'brass');m.strut(x+.20,y+.23,13,x-.20,y+.23,54,2.2,'brass');
  m.box(x,y,54,.50,.60,4,0,'ivory');
  for(let side=-1;side<=1;side+=2)m.strut(x+side*.19,y-.27,54,x+side*.19,y-.41,68,3.5,'teal');
  m.strut(x-.19,y-.41,68,x+.19,y-.41,68,4,'brass');
  // Low end stops leave the west side unobstructed for the bridge transfer.
  m.box(x,y+.29,58,.50,.022,3,0,'teal');m.box(x+.24,y,58,.02,.56,3,0,'teal');
 }
 parcel(s){const p=s.parcel,m=this.mesh;m.box(p.x,p.y,p.z,.26,.26,14,p.yaw,'parcel');m.box(p.x,p.y,p.z+14.03,.042,.263,.08,p.yaw,'tape');m.box(p.x,p.y,p.z+14.13,.12,.10,.08,p.yaw,'paper');}
 shadow(c,x,y,z,rx,ry,alpha,yaw=0){
  if(!this.shadowTile)return;const co=Math.cos(yaw),si=Math.sin(yaw);c.save();c.globalAlpha*=alpha;
  c.transform((co+si)*P.HW*rx,(co-si)*P.HH*rx,(si-co)*P.HW*ry,(si+co)*P.HH*ry,760+(x-y)*P.HW,465+(x+y)*P.HH-z);
  c.drawImage(this.shadowTile,-1,-1,2,2);c.restore();
 }
 shadows(c,s){
  this.shadow(c,s.cart.x,s.cart.y,0,.40,.48,.065);
  for(let i=0;i<2;i++){const f=s.robot.feet[i],height=Math.max(0,f.z),spread=1+Math.min(1,height/12)*.65;this.shadow(c,f.x,f.y,0,.12*spread,.19*spread,.26/(1+height*.16),f.yaw);}
  for(let i=0;i<4;i++){const x=s.cart.x+(i%2?1:-1)*L.cart.wheelHalfWidth,y=s.cart.y+(i<2?-1:1)*L.cart.wheelHalfDepth;this.shadow(c,x,y,0,.075,.055,.24);}
 }
 draw(s){const c=this.r.ctx;this.shadows(c,s);this.mesh.reset();this.cart(s);this.robot(s);if(s.parcel.owner===L.owners.held||s.parcel.owner===L.owners.cart)this.parcel(s);this.mesh.draw(c,this.pattern);}
 drawParcel(s){this.mesh.reset();this.parcel(s);this.mesh.draw(this.r.ctx,this.pattern);}
}
Rig.Mesh=Mesh;Rig.solveJoint=solveJoint;return Rig;
});
