/* Seekable room-cat acting. Every pose scales around its fixed sole contact;
 * the architecture supplies the shelf lips and gallery rail in front. */
(function(root,factory){
 const P=typeof module==='object'&&module.exports?require('./projection.js'):root.CivicProjection;
 const L=typeof module==='object'&&module.exports?require('./postal-work-layout.js'):root.CivicPostalLayout;
 const Life=factory(P,L);root.CivicRoomLife=Life;if(typeof module==='object'&&module.exports)module.exports=Life;
})(globalThis,function(P,L){
'use strict';
const actors=[],kinds=['nap','crouch-front','puzzled','crouch-front','nap'],cw=6.28/10;
function actor(id,group,coat,kind,x,y,z,width,row=-1){
 const index=actors.length,alternate=kind==='crouch-front'?'crouch-rear':'wake',foot=P.project(x,y,z);
 actors.push(Object.freeze({id,group,coat,row,x,y,z,width,pose:coat+'-'+kind,alternate:coat+'-'+alternate,alternateWidth:group===0&&alternate==='wake'?25:width,
  px:foot.x,py:foot.y,period:32+(index*7)%13,phase:index*1.79,breathPhase:index*.91}));
}
for(let row=0;row<3;row++)for(let col=0;col<10;col++){
 const kind=kinds[(row*3+col)%5];actor('cubby-'+row+'-'+col,0,col<5?'ginger':'blue',kind,.41+col*cw+(cw-.07)*.5,-.61,27+row*34,kind==='nap'?29:kind==='puzzled'?24:28,row);
}
actor('desk',1,'ginger','puzzled',L.deskCat.x,L.deskCat.y,L.deskCat.z,L.deskCat.width);
actor('gallery',1,'ginger','nap',6.4,-.5,182,50);
Object.freeze(actors);
const smooth=t=>t*t*(3-2*t);
class RoomLife{
 static layout(){return actors;}
 static makeState(){return{x:0,y:0,z:0,scaleY:1,mix:0,pose:'',alternate:''};}
 static sample(a,time,out){
  const t=Number.isFinite(time)?time:0,phase=((t+a.phase)%a.period+a.period)%a.period;
  out.x=a.x;out.y=a.y;out.z=a.z;out.pose=a.pose;out.alternate=a.alternate;
  out.scaleY=1+.022*Math.sin(phase/a.period*Math.PI*16+a.breathPhase);
  out.mix=phase<.28?smooth(phase/.28):phase<2.12?1:phase<2.4?1-smooth((phase-2.12)/.28):0;
  return out;
 }
 constructor(renderer){
  this.r=renderer;this.states=actors.map(()=>RoomLife.makeState());
  this.rects=actors.map(a=>({base:renderer.assets.acting.sprites[a.pose].rect,alternate:renderer.assets.acting.sprites[a.alternate].rect}));
 }
 picture(rect,a,width,scaleY,alpha){
  if(alpha<=0)return;const c=this.r.ctx,h=width*rect[3]/rect[2]*scaleY;
  c.globalAlpha=alpha;c.drawImage(this.r.images.acting,rect[0],rect[1],rect[2],rect[3],a.px-width/2,a.py-h,width,h);
 }
 draw(group,time){
  const c=this.r.ctx;c.save();c.fillStyle='rgba(64,49,31,.17)';
  for(let i=0;i<actors.length;i++){
   const a=actors[i];if(a.group!==group)continue;const s=RoomLife.sample(a,time,this.states[i]),r=this.rects[i];
   c.globalAlpha=1;c.beginPath();c.ellipse(a.px,a.py,a.width*.34,a.width*.08,0,0,Math.PI*2);c.fill();
   this.picture(r.base,a,a.width,s.scaleY,1-s.mix);this.picture(r.alternate,a,a.alternateWidth,s.scaleY,s.mix);
  }
  c.restore();
 }
}
return RoomLife;
});
