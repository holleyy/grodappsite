'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const P = require('./projection.js');
const levels = require('./vendor/data/levels.json').levels.filter(l => !l.room).slice(0, 15);
const near = (a,b) => assert.ok(Math.abs(a-b)<1e-8, `${a} != ${b}`);
const pointNear = (a,b) => { near(a.x,b.x); near(a.y,b.y); };
test('Lantern origin, axes and 2:1 tile diamond', () => {
  assert.equal(P.HW,380/6); assert.equal(P.HH,190/6);
  assert.deepEqual(P.project(0,0),{x:760,y:465});
  const a=P.project(1,0), b=P.project(0,1);
  near(a.x-760,760-b.x); near(a.y-465,b.y-465);
  near((a.x-760)/(a.y-465),2);
  pointNear(P.unproject(a.x,a.y),{x:1,y:0});
  pointNear(P.unproject(b.x,b.y),{x:0,y:1});
});
test('corners close a parallelogram and elevated projection round trips', () => {
  const c=P.corners(6,5);
  near(c[0].x+c[2].x,c[1].x+c[3].x); near(c[0].y+c[2].y,c[1].y+c[3].y);
  for (const [x,y,z] of [[0,0,0],[6,5,0],[-3,-2,80],[2.5,4.5,120]]) {
    const p=P.project(x,y,z); pointNear(P.unproject(p.x,p.y,z),{x,y});
  }
});
test('all cells of the fifteen Office layouts pick their centres', () => {
  assert.equal(levels.length,15);
  for(const {board:{w,h}} of levels) for(let y=0;y<h;y++) for(let x=0;x<w;x++) {
    const p=P.centre(x,y); assert.deepEqual(P.pick(p.x,p.y,w,h),{x,y});
  }
});
test('picking rejects points beyond each edge without snapping', () => {
  for(const [x,y] of [[-.0001,2],[6.0001,2],[2,-.0001],[2,5.0001],[6,2],[2,5]]) {
    const p=P.project(x,y); assert.equal(P.pick(p.x,p.y,6,5),null);
  }
});
test('camera fits play bounds on phone, desktop and landscape viewports', () => {
  for(const [width,height] of [[320,400],[393,450],[900,600],[560,240]]) {
    const camera=P.camera({width,height,w:6,h:5});
    const c=P.corners(6,5), xs=c.map(p=>p.x),ys=c.map(p=>p.y);
    for(const p of [{x:Math.min(...xs)-80,y:Math.min(...ys)-120},{x:Math.max(...xs)+80,y:Math.max(...ys)+50}]) {
      const s=P.toScreen(p,camera); assert.ok(s.x>=-1e-8&&s.x<=width+1e-8); assert.ok(s.y>=-1e-8&&s.y<=height+1e-8);
      pointNear(P.fromScreen(s,camera),p);
    }
  }
});
test('zoom preserves the point under the pointer in both camera modes', () => {
  for(const mode of ['play','explore']) {
    const config={width:393,height:450,w:6,h:5,mode,zoom:1.3,panX:21,panY:-34};
    const pointer={x:115,y:271}, before=P.fromScreen(pointer,P.camera(config));
    const pan=P.zoomAt(config,pointer,2.4);
    pointNear(P.toScreen(before,P.camera({...config,...pan,zoom:2.4})),pointer);
  }
});
