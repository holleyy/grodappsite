# Civic component artwork · study02

44 new paper components match the approved Lantern characters: ginger tabby and charcoal tuxedo. The logical category `blue` still means the tuxedo with the blue destination/filter. No indexed cat is substituted during arrivals.

Three generated RGBA masters are retained in `acting-masters/`. `tools/pack-acting.py` extracts each named cell using the largest connected alpha silhouette, excluding neighbouring pose fragments crossing a generated row boundary. Source pixels and alpha are preserved in unscaled crops, then encoded to WebP at quality94. `acting-provenance.json` pins all masters and the packed sheet.

Each coat has8 primary components: front/rear bust, front/rear crouch, front/rear push, curled nap and puzzled sit. Eight extras supply front blink, front/rear flattened-ear reaction, waking yawn and two walking steps in front/rear views. Mirroring supplies four headings. Twelve props are four empty carriers, four dogs, round ginger/square blue baskets and half-folded/flat carriers.

Travel has separate bust and carrier. Head lead changes the bust direction first; the lower torso stays hidden by the front rim. These are busts, not independent head and torso pictures. Breathing/stretch use small transforms; curl/turn/flight reuse the documented poses. There are44 authored pictures, not a new picture at every sampled time.

Registration: carrier width88, vertical scale.72, floor bottom centre+20. Basket width91, scale.78, bottom centre+26. Bust width48, paws at centre+3. Front masks are Canvas clips over the same registered artwork. All floor centres use CivicProjection.

Take-off hind-sole anchors within crops: front crouch(.84,.88), front push(.94,.75), rear(.63,.90). Soles stay on the carrier interior during.2–.4s crouch/push, then move to the basket during.4–.6s with a22projected-unit arc. This is new art registration; the pure adapter separately retains the exact production numerical pose. Carrier folds follow.45/.55/.65/.75/1.2s. Half-fold art changes wall height for intermediate folds; flat art slides/fades independently.

Visual proof must show contact, occlusion and stable character identity. Source numeric parity alone is not that proof. Close captures cover both coats and four approaches. Full architecture and canal life remain subsequent stages.
