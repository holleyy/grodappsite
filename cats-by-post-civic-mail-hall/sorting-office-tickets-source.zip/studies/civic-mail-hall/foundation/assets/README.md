# Lantern Quay source artwork

These six WebP files are byte-for-byte base64 decodes of `PortAssets` in the actual public Lantern Quay HTML. No pixels were changed. `provenance.json` records URLs, the supplied Git blob ID, source HTML SHA-256, sheet SHA-256, dimensions and every exact crop rectangle. `rects.json` provides just the original sheet dimensions and crop rectangles for renderer consumption. Rectangles are `[left,top,width,height]`, zero-indexed. Transparent pixels can carry coloured RGB; preserve alpha when drawing.

## Reusable sprites

| Sheet/index | Use | Source rectangle | Recommended native width / bottom anchor |
|---|---|---|---|
| pieces/0 | Blue paper floor tile | 24,116,272,136 | 127.4666667 / cell.y+34.6666667 |
| cats/0 | Ginger N (upper right) | 38,127,306,292 | 88 / cell.y+20 |
| cats/1 | Ginger E (lower right) | 409,108,318,295 | 88 / cell.y+20 |
| cats/2 | Ginger S (lower left) | 807,110,316,293 | 88 / cell.y+20 |
| cats/3 | Ginger W (upper left) | 1192,126,306,293 | 88 / cell.y+20 |
| cats/4 | Dark cat, blue carrier, N | 38,623,306,291 | 88 / cell.y+20 |
| cats/5 | Dark cat, blue carrier, E | 410,604,319,295 | 88 / cell.y+20 |
| cats/6 | Dark cat, blue carrier, S | 807,604,317,295 | 88 / cell.y+20 |
| cats/7 | Dark cat, blue carrier, W | 1192,622,307,292 | 88 / cell.y+20 |
| pieces/8 | Gold-cushion destination basket | 41,703,233,171 | 91 / cell.y+26 |
| pieces/9 | Teal-cushion destination basket | 355,703,233,171 | 91 / cell.y+26 |
| fleet/3 | Standing marshal robot | 129,563,265,351 | 64 / apron foot |
| fleet/4 | Postal robot with parcel trolley | 530,547,452,379 | 112 / apron foot |
| fleet/5 | Seated robot cat | 1139,599,268,313 | 47 / apron foot |

All sprite anchors above are the crop's bottom centre: source `(width/2,height)`. Draw target is `(anchor.x-width/2,anchor.y-width*rect.height/rect.width,width,width*rect.height/rect.width)`. These crops include their own feet/carrier bases; do not stretch them to a diamond. Cats are eight complete cat-and-carrier poses, not separate cats that can be detached from carriers. Dark means grey cat with blue panels; ginger uses teal panels. Baskets are single fixed three-quarter poses, not directional sprites. Robot poses are individual standing/cargo/seated illustrations, with no walking frames.

## Sorting Office postal rig

The current working-post preview replaces the fleet cutout with projected, jointed paper geometry in `postal-work-rig.js`. Head, limbs, soles, trolley, wheels and parcel share the board coordinate system. Existing ivory paper grain is baked into coloured material patterns; no source image pixels were altered. `postal-work-cycle.js` provides continuous contact targets and fixed foot events. The retained fleet file is historical reference/provenance and is no longer embedded or loaded by this build.

## Civic floor correction

The source tile geometry below documents Lantern artwork, not the current Civic floor construction. Civic now samples only blue grain at source rectangle `[128,161,64,32]`, entirely inside the painted top face. A single projected paper sheet, continuous grid lines and perimeter-only thickness replace the repeated illustrated bevels. No source asset pixels or the accepted projection were changed.

## Floor and foot geometry

The native source projection uses half-width `HW=380/6`, half-height `HH=190/6`, origin `(760,465)`. For zero-based coordinates `(x,y)`, cell centre is `(760+(x-y)*HW,465+(x+y+1)*HH)`. A logical floor diamond has corners `(0,-HH),(HW,0),(0,HH),(-HW,0)`. Source floor rect is precisely 2:1. Its opaque upper tip is near local `(139,1)` and lower tip `(133,135)` (alpha >128); its side tips are near local `(1,67)` and `(270,65)`. Native width is `2*HW+.8`, so sprite height is `2*HH+.4`; bottom is `cell.y+HH+3`, leaving its visual centre `3-.2=2.8` below the logical diamond centre. The 3px offset represents the little paper base; preserve this relationship when adapting to another projection.

At native width88, cat heights range81.379–84.261px (by rect aspect); the exact height must be calculated per pose. Root/foot stays at `cell.y+20`, independent of direction. Source floor-plane shadow is `(cell.x,cell.y+11)` with radii34,13. Baskets at width91 are66.7854px tall, bottom `cell.y+26`. Do not infer root anchors from the tallest ear or the centre of the image. Scaling every anchor and width by a common factor retains the paper proportions.

Native crew contact points are deliberately more precise than a single bottom anchor. For actor bottom-centre `(x,y)`, width `w`, aspect `h/w`, each contact `(u,v)` is `(x+(u-.5)*w,y-(1-v)*w*aspect)`:

- Marshal fleet/3: aspect351/265; contacts(.32,.995),(.67,.96).
- Cargo fleet/4: aspect379/452; contacts(.084,.929),(.29,.905),(.542,.979),(.812,1),(.945,.918).
- Robot cat fleet/5: aspect313/268; contacts(.15,.97),(.4,.99),(.7,.96).

## Renderer reuse boundary

The initial Civic foundation reused the floor tile, two carrier families, two destination cushions and cargo robot. The current postal rig replaces that cargo cutout as described above. Derive all positions and facing from the original Office engine and trace sampler. Preserve Office starts, arrivals, exits, inventory and timings. The Lantern engine and its seal/beacon/paired-cradle mechanics are unnecessary for this skin.

The original Lantern renderer uses N,E,S,W sprite order; map Office direction vectors explicitly rather than copying enum numbers. It depth-sorts board objects by cell-centre y (goals y−1, cats y+2), draws tiles first, then floor pads, then sorted objects. A cat on a different source/destination cell interpolates its root position over150ms; turns run150–210ms with heading swap halfway, x squeeze18%, y stretch3.5%. The Lantern beat is300ms. These are visual observations, not instructions to overwrite Office movement: feed the unchanged Office trace's movement phase into the new skin. Lantern pad lifts and stamp press logic should not enter the Office simulation.

Keep Civic scenery separate; port.webp is the complete original Lantern environment and must not become the Civic background. The original scene places cargo robot `(1100,568)`, marshal `(1278,596)`, seated cat robot `(287,553)`; choose Civic apron positions from actual scenery floor contacts instead. The fleet source art does not supply a gait; walking/pushing requires the separate projected rig.
