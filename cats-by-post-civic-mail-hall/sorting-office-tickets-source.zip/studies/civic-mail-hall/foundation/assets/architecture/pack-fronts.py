#!/usr/bin/env python3
"""Pack two unmodified generated front elevations for Civic Mail Hall."""

import hashlib
import json
from pathlib import Path

from PIL import Image


HERE = Path(__file__).resolve().parent
MASTER = HERE / 'fronts-master.png'
OUTPUT = HERE / 'fronts.webp'
source = Image.open(MASTER).convert('RGBA')
assert source.size == (1254, 1254)
atlas = Image.new('RGBA', (1264, 1136), (0, 0, 0, 0))
sprites = {
    'archedWindow': {
        'sourceRect': [5, 66, 465, 1119],
        'atlasRect': [8, 8, 465, 1119],
        'visibleBounds': [8, 8, 449, 1103],
        'recommendedFaceAspect': 1 / 2.2,
        'description': 'Tall arched ivory paper-stone window with honey-gold mullions, quiet pale-teal glazing and a layered canal-town view.',
        'notes': 'Fully front-facing. Map onto the entire window plane, including sill and keystone; the glass/view is intentionally opaque inside the opening. Generated natural silhouette is about 1:2.46.',
    },
    'counterFront': {
        'sourceRect': [473, 540, 772, 304],
        'atlasRect': [481, 8, 772, 304],
        'visibleBounds': [8, 8, 756, 288],
        'recommendedFaceAspect': 3,
        'description': 'Honey oak card counter facade with three recessed framed panels, narrow joinery and three brass pulls.',
        'notes': 'Fully front-facing with no top or side face. Map onto the vertical counter front. Generated natural silhouette is about 2.63:1; modest horizontal scaling fits a 3:1 target.',
    },
}
for sprite in sprites.values():
    sx, sy, width, height = sprite['sourceRect']
    x, y, _, _ = sprite['atlasRect']
    atlas.paste(source.crop((sx, sy, sx + width, sy + height)), (x, y))
atlas.save(OUTPUT, 'WEBP', lossless=True, method=6, exact=True)
metadata = {
    'schemaVersion': 1,
    'image': OUTPUT.name,
    'imageSize': list(atlas.size),
    'rectFormat': '[x, y, width, height], pixels, top-left origin',
    'master': MASTER.name,
    'masterSize': list(source.size),
    'masterSha256': hashlib.sha256(MASTER.read_bytes()).hexdigest(),
    'imageSha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
    'provenance': {
        'tool': 'image_gen.imagegen',
        'date': '2026-11-12',
        'source': '/workspace/generated_images/exec-80de5ec7-9aa7-46ff-a793-7a8301d95a54.png',
        'prompt': 'fronts.prompt.txt',
        'processing': 'Rectangular sprite crops, transparent atlas packing and lossless WebP conversion only. No painted repair, colour edit or alpha retouch.',
        'scope': 'Original generated artwork for the authorised full-colour isolated Civic Mail Hall architecture study.',
    },
    'notes': [
        'Both assets are front elevations, ready to project through the existing board projection onto explicit wall/counter geometry.',
        'Crops preserve every corresponding pixel with alpha >= 16. Faint isolated generator specks outside the crops are omitted.',
        'visibleBounds is crop-local and measured at alpha >= 16. Tiny low-alpha fringe pixels remain unaltered inside each crop.',
        'Internal paper relief/shading supplies craft detail. Neither asset includes a floor, an external scene surround or a projected 3D side.',
    ],
    'sprites': sprites,
}
(HERE / 'fronts.json').write_text(json.dumps(metadata, indent=2) + '\n')
decoded = Image.open(OUTPUT).convert('RGBA')
assert decoded.size == atlas.size
for sprite in sprites.values():
    sx, sy, width, height = sprite['sourceRect']
    x, y, _, _ = sprite['atlasRect']
    original = source.crop((sx, sy, sx + width, sy + height))
    packed = decoded.crop((x, y, x + width, y + height))
    assert packed.tobytes() == original.tobytes()
print(f'{OUTPUT.name}: {atlas.width} x {atlas.height}, {OUTPUT.stat().st_size:,} bytes; both decoded crops pixel-exact')
