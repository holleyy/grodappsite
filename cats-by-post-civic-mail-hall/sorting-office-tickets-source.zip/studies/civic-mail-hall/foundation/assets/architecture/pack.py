#!/usr/bin/env python3
"""Crop and pack generated Civic Hall art. No painting or alpha retouching."""

import hashlib
import json
from pathlib import Path

from PIL import Image, ImageStat


HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def crop(image, rect):
    x, y, width, height = rect
    return image.crop((x, y, x + width, y + height))


def write_json(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


def material_atlas():
    master_path = HERE / 'materials-master.png'
    master = Image.open(master_path).convert('RGB')
    assert master.size == (1254, 1254)
    atlas = Image.new('RGB', (1024, 1024))
    entries = [
        ('ivory', 'Warm ivory stone/card', [57, 57, 512, 512], [0, 0, 512, 512]),
        ('teal', 'Deep desaturated teal painted card', [684, 57, 512, 512], [512, 0, 512, 512]),
        ('oak', 'Honey oak brown card', [57, 684, 512, 512], [0, 512, 512, 512]),
        ('terracotta', 'Terracotta brick-red card', [684, 684, 512, 512], [512, 512, 512, 512]),
    ]
    materials = {}
    for key, label, source_rect, atlas_rect in entries:
        patch = crop(master, source_rect)
        atlas.paste(patch, tuple(atlas_rect[:2]))
        mean = [round(channel) for channel in ImageStat.Stat(patch).mean]
        materials[key] = {
            'label': label,
            'sourceRect': source_rect,
            'atlasRect': atlas_rect,
            'meanRgb': mean,
            'meanHex': '#' + ''.join(f'{channel:02x}' for channel in mean),
            'usage': 'Map to an explicit flat face; add face lighting in the renderer.',
        }
    output = HERE / 'materials.webp'
    atlas.save(output, 'WEBP', quality=95, method=6)
    write_json('materials.json', {
        'schemaVersion': 1,
        'image': output.name,
        'imageSize': [1024, 1024],
        'rectFormat': '[x, y, width, height], pixels, top-left origin',
        'master': master_path.name,
        'masterSize': list(master.size),
        'masterSha256': digest(master_path),
        'imageSha256': digest(output),
        'provenance': {
            'tool': 'image_gen.imagegen',
            'date': '2026-11-12',
            'source': '/workspace/generated_images/exec-6a196323-3bef-45cc-bab9-566966eb0760.png',
            'prompt': 'materials.prompt.txt',
            'processing': 'Unaltered 512-pixel interior crops, atlas packing, WebP quality 95 conversion only.',
            'scope': 'Original generated artwork for the authorised full-colour isolated Civic Mail Hall study.',
        },
        'notes': [
            'Four exact 627-pixel quadrants in the master; each crop excludes 57 or 58 pixels around quadrant edges.',
            'All patches are front-flat albedo with fine paper grain and no architectural objects or baked directional lighting.',
            'Patches are seamless-ish rather than mathematically tileable. Avoid stretching a tiny patch across a whole wall.',
            'Use atlasRect as drawImage source crop. Keep sampling inside the crop to avoid colour bleed between atlas neighbours.',
        ],
        'materials': materials,
    })


def decor_atlas():
    master_path = HERE / 'decor-master.png'
    master = Image.open(master_path).convert('RGBA')
    assert master.size == (1254, 1254)
    atlas = Image.new('RGBA', (1216, 1144), (0, 0, 0, 0))
    entries = [
        ('clock', [16, 29, 513, 525], [8, 8, 513, 525]),
        ('plaque', [570, 67, 670, 415], [537, 8, 670, 415]),
        ('postEarly', [80, 637, 442, 587], [8, 549, 442, 587]),
        ('catsByPost', [721, 638, 452, 585], [466, 549, 452, 585]),
    ]
    sprites = {}
    for key, source_rect, atlas_rect in entries:
        patch = crop(master, source_rect)
        atlas.paste(patch, tuple(atlas_rect[:2]))
        sprites[key] = {'sourceRect': source_rect, 'atlasRect': atlas_rect}
    sprites['clock'].update({
        'description': 'Station clock dial with no hands. Fine minute marks and twelve hour marks.',
        'pivot': [258, 262],
        'pivotInAtlas': [266, 270],
        'visibleDialSize': [497, 509],
        'recommendedFaceAspect': 1,
        'notes': 'Map to a square face; the generated silhouette has about 2.4 percent vertical elongation. Draw hands from the documented pivot.',
    })
    sprites['plaque'].update({
        'description': 'Cream civic plaque with cat/envelope crest and a blank main title field.',
        'blankTextRect': [53, 213, 570, 150],
        'blankTextRectInAtlas': [590, 221, 570, 150],
        'notes': 'Local text rectangle fits a large Civic Mail Hall title with a smaller subtitle.',
    })
    sprites['postEarly']['description'] = 'Terracotta-bordered POST EARLY poster with a sun and teal envelope.'
    sprites['catsByPost']['description'] = 'Teal-bordered CATS BY POST poster with a charcoal cat in a parcel.'
    output = HERE / 'decor.webp'
    atlas.save(output, 'WEBP', lossless=True, method=6, exact=True)
    write_json('decor.json', {
        'schemaVersion': 1,
        'image': output.name,
        'imageSize': [1216, 1144],
        'rectFormat': '[x, y, width, height], pixels, top-left origin',
        'master': master_path.name,
        'masterSize': list(master.size),
        'masterSha256': digest(master_path),
        'imageSha256': digest(output),
        'provenance': {
            'tool': 'image_gen.imagegen',
            'date': '2026-11-12',
            'source': '/workspace/generated_images/exec-c766e116-3b8e-4cf8-ae63-ce45f3a2e318.png',
            'prompt': 'decor.prompt.txt',
            'processing': 'Rectangular sprite crops, transparent atlas packing, lossless WebP conversion only. No alpha recolouring or painted repair.',
            'scope': 'Original generated artwork for the authorised full-colour isolated Civic Mail Hall study.',
        },
        'notes': [
            'All four assets are front elevations. Project onto explicit wall faces using existing board projection.',
            'Source crops retain every pixel with alpha >= 16 for their corresponding object; faint isolated low-alpha generator specks outside these crops are omitted.',
            'Internal paper lamination includes slight relief shading; there is no surrounding scene or external drop shadow.',
            'Clock pivot and plaque text rectangles are in crop-local pixels unless suffixed InAtlas.',
        ],
        'sprites': sprites,
    })


if __name__ == '__main__':
    material_atlas()
    decor_atlas()
    for name in ('materials.webp', 'materials.json', 'decor.webp', 'decor.json'):
        path = HERE / name
        print(f'{name}: {path.stat().st_size:,} bytes')
