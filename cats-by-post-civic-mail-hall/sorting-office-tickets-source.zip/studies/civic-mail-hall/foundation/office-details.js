/* Static, supported paper details. Architecture calls these only while baking
 * its gallery and counter layers, before their foreground rails and actors. */
(function(root,factory){
 const Details=factory();if(typeof module==='object'&&module.exports)module.exports=Details;root.CivicOfficeDetails=Details;
})(globalThis,function(){
'use strict';
const paper={top:'#f8ead2',left:'#dfc8ab',right:'#bea48b'};
const cloth={top:'#c78e79',left:'#ac7562',right:'#91604f'};
const brass={top:'#efd09a',left:'#bf965a',right:'#8e6c49'};
const bench={x0:2.70,x1:4.10,y0:-1.58,y1:-1.03,z0:182,z1:234,seat:205};
// These are solid bounds, not decorative shadows. supportZ is the plane
// carrying the item; the throw is entirely on the seat, with no loose drape.
const supports=Object.freeze([
 Object.freeze({name:'gallery bench',support:'gallery',...bench,supportZ:182}),
 Object.freeze({name:'folded throw',support:'bench seat',x0:3.50,x1:3.98,y0:-1.53,y1:-1.05,z0:205,z1:210,supportZ:205}),
 Object.freeze({name:'postal bundle',support:'gallery',x0:.45,x1:1,y0:-1.78,y1:-1.30,z0:182,z1:196,supportZ:182}),
 Object.freeze({name:'ledger',support:'counter',x0:-1.33,x1:-1.02,y0:1.85,y1:2.02,z0:58,z1:61.2,supportZ:58}),
 Object.freeze({name:'mug',support:'counter',x0:-1.18,x1:-.985,y0:1.67,y1:1.81,z0:58,z1:65.8,supportZ:58}),
 Object.freeze({name:'task lamp',support:'counter',x0:-1.28,x1:-.98,y0:2.47,y1:2.76,z0:58,z1:88,supportZ:58})
]);

function ellipse(x,y,rx,ry,z,n=12){
 const points=[];for(let i=0;i<n;i++){const a=i*Math.PI*2/n;points.push([x+Math.cos(a)*rx,y+Math.sin(a)*ry,z]);}return points;
}
function cylinder(p,x,y,rx,ry,z,height,colours,material='stone'){
 const bottom=ellipse(x,y,rx,ry,z),top=ellipse(x,y,rx,ry,z+height);
 for(let i=0;i<bottom.length;i++){
  const next=(i+1)%bottom.length,a=(i+.5)*Math.PI*2/bottom.length;
  if(Math.cos(a)+Math.sin(a)>0)p.poly([bottom[i],bottom[next],top[next],top[i]],Math.cos(a)>Math.sin(a)?colours.right:colours.left,material);
 }
 p.poly(top,colours.top,material);
}

function drawGallery(p){
 // The entire bench sits 0.25 tile forward so its seat and textile show
 // beneath the roof beam; its feet still share the gallery deck plane.
 // The front edge remains behind the reserved y > -1 gallery passage.
 for(const x of [2.77,3.95])for(const y of [-1.53,-1.16]){
  p.poly([[x-.015,y-.015,182.02],[x+.095,y-.015,182.02],[x+.095,y+.095,182.02],[x-.015,y+.095,182.02]],'#61472d20','none');
  p.box(x,y,.08,.08,182,19,'teal');
 }
 for(const x of [2.77,3.95])p.box(x,-1.57,.08,.07,182,52,'teal');
 p.box(2.77,-1.14,1.26,.06,196,4,'oak');
 for(const z of [215,226])p.box(2.70,-1.56,1.40,.075,z,7,'oak');
 for(const y of [-1.53,-1.36,-1.19])p.box(2.70,y,1.40,.16,201,4,'oak');
 for(const x of [2.81,3.99])for(const z of [218.5,229.5]){
  p.poly([[x-.018,-1.482,z-1.1],[x+.018,-1.482,z-1.1],[x+.018,-1.482,z+1.1],[x-.018,-1.482,z+1.1]],'#c9a762','none');
 }
 // Two soft, thin folds keep this a textile rather than another parcel.
 p.box(3.50,-1.53,.48,.48,205,1.8,'brick',cloth);
 p.box(3.52,-1.505,.44,.435,206.8,2.6,'brick',cloth);
 p.poly([[3.52,-1.505,209.4],[3.96,-1.505,209.4],[3.945,-1.07,209.4],[3.53,-1.07,209.4]],'#cf9a83','brick');
 p.line3([3.53,-1.08,207],[3.945,-1.08,207],'#875d4e',.9);
 for(let i=0;i<7;i++){
  const x=3.55+i*.055;p.line3([x,-1.097,209.65],[x+.024,-1.097,209.65],'#f4e4cd',.85);
 }
 for(let i=0;i<6;i++){
  const y=-1.47+i*.059;p.line3([3.55,y,209.65],[3.55,y+.026,209.65],'#f4e4cd',.75);
 }
 // A tied paper bundle sits in its own bay, clear of the gallery passage.
 p.poly([[.45,-1.78,182.02],[1,-1.78,182.02],[1,-1.30,182.02],[.45,-1.30,182.02]],'#61472d20','none');
 p.box(.46,-1.77,.52,.44,182,7.6,'oak',{top:'#d5b583',left:'#b79768',right:'#a8895e'});
 p.box(.48,-1.75,.48,.40,189.6,4.6,'stone',paper);
 p.box(.495,-1.735,.44,.37,194.2,1.3,'stone',paper);
 p.line3([.71,-1.77,182.5],[.71,-1.77,195.7],'#9a825e',1);
 p.line3([.71,-1.77,195.7],[.71,-1.33,195.7],'#aa9168',1.1);
 p.line3([.71,-1.33,195.7],[.71,-1.33,182.5],'#8e7755',1);
 p.line3([.46,-1.55,195.7],[.98,-1.55,195.7],'#aa9168',1.1);
 p.poly([[.77,-1.69,195.65],[.90,-1.69,195.65],[.90,-1.60,195.65],[.77,-1.60,195.65]],'#f3e4c2','stone');
 p.line3([.79,-1.66,195.8],[.88,-1.66,195.8],'#8d8e79',.7);
 p.line3([.79,-1.63,195.8],[.85,-1.63,195.8],'#8d8e79',.7);
}

function drawCounter(p,layout){
 const work=layout?.bench||layout,z=Number.isFinite(work?.top)?work.top:58;
 // The return rollers occupy x<=-1.39. All solid details stay to their east,
 // between the scale work area and dispatch cross-transfer.
 p.box(-1.33,1.85,.31,.17,z,1.2,'teal');
 p.box(-1.32,1.86,.29,.15,z+1.2,1.25,'stone',paper);
 p.poly([[-1.32,1.86,z+2.7],[-1.175,1.86,z+2.15],[-1.175,2.01,z+2.15],[-1.32,2.01,z+2.7]],'#f7e8c6','stone');
 p.poly([[-1.175,1.86,z+2.15],[-1.03,1.86,z+2.7],[-1.03,2.01,z+2.7],[-1.175,2.01,z+2.15]],'#eddbb7','stone');
 p.line3([-1.175,1.865,z+2.4],[-1.175,2.01,z+2.4],'#a58c64',.8);
 for(let i=0;i<3;i++){
  const y=1.89+i*.032;
  p.line3([-1.30,y,z+2.85],[-1.20,y,z+2.5],'#a4a18a',.65);
  p.line3([-1.15,y,z+2.5],[-1.05,y,z+2.85],'#a4a18a',.65);
 }
 p.poly([[-1.16,1.99,z+2.8],[-1.145,1.99,z+2.8],[-1.145,2.02,z+2.8],[-1.16,2.02,z+2.8]],'#b87d61','brick');
 // The mug handle is an open paper loop attached to the same projected body.
 const handle=[[-1.06,1.74,z+6],[-1.015,1.74,z+6.4],[-.99,1.74,z+4.8],[-.997,1.74,z+2.7],[-1.052,1.74,z+2.3]];
 for(let i=1;i<handle.length;i++)p.line3(handle[i-1],handle[i],'#ddcba4',2.1);
 cylinder(p,-1.11,1.74,.066,.066,z,7.2,paper);
 p.poly(ellipse(-1.11,1.74,.051,.051,z+7.3),'#a38b64','none');
 p.poly(ellipse(-1.11,1.74,.039,.039,z+7.35),'#8d7150','none');
 p.line3([-1.155,1.784,z+2.3],[-1.071,1.784,z+2.3],'#738d7d',1.15);
 // Restrained warmth is painted onto the worktop, not over the board or cat.
 if(p.surfaceLight)p.surfaceLight(-1.17,2.64,z+.02,.19,.27,'#ffe3a6',.28);
 else{p.poly(ellipse(-1.17,2.64,.16,.20,z+.02),'#edc97a18','none');p.poly(ellipse(-1.17,2.64,.11,.14,z+.03),'#f1d48c20','none');}
 cylinder(p,-1.15,2.65,.095,.08,z,2.4,{top:'#63857b',left:'#4a6d62',right:'#385b52'},'teal');
 p.line3([-1.15,2.65,z+2.4],[-1.15,2.65,z+21],'#9c7a43',2.4);
 p.line3([-1.15,2.65,z+21],[-1.13,2.59,z+25],'#c7a45f',2.5);
 cylinder(p,-1.15,2.65,.035,.035,z+19.8,2.2,brass,'oak');
 const lower=ellipse(-1.13,2.59,.145,.115,z+22),upper=ellipse(-1.13,2.59,.062,.05,z+30);
 p.poly(lower,'#f4d68e','stone');
 for(let i=0;i<lower.length;i++){
  const next=(i+1)%lower.length,a=(i+.5)*Math.PI*2/lower.length;
  if(Math.cos(a)+Math.sin(a)>0)p.poly([lower[i],lower[next],upper[next],upper[i]],Math.cos(a)>Math.sin(a)?'#3c675f':'#63867a','teal');
 }
 p.poly(upper,'#749487','teal');
 for(let i=0;i<lower.length;i++)p.line3(lower[i],lower[(i+1)%lower.length],'#c9ad6b',.8);
}

return Object.freeze({drawGallery,drawCounter,supports});
});
