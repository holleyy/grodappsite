'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const P=require('./projection.js');
const Exterior=require('./exterior.js');
const cross=(a,b,p)=>(b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x);
function clipPolygon(points,clip){
 let out=points;
 for(let i=0;i<clip.length&&out.length;i++){
  const a=clip[i],b=clip[(i+1)%clip.length],input=out;out=[];
  let p=input[input.length-1],dp=cross(a,b,p);
  for(const q of input){
   const dq=cross(a,b,q);
   if((dq>=0)!==(dp>=0)){
    const t=dp/(dp-dq);out.push({x:p.x+(q.x-p.x)*t,y:p.y+(q.y-p.y)*t});
   }
   if(dq>=0)out.push(q);p=q;dp=dq;
  }
 }
 return out;
}
function area(points){
 let sum=0;
 for(let i=0;i<points.length;i++){const p=points[i],q=points[(i+1)%points.length];sum+=p.x*q.y-q.x*p.y;}
 return Math.abs(sum)/2;
}
class RecordedExterior extends Exterior{
 box(x0,y0,x1,y1,z0,z1,...colors){
  (this.boxes||(this.boxes=[])).push({name:this.current.name,x0,y0,x1,y1,z0:z0+(this.offsetZ||0),z1:z1+(this.offsetZ||0)});
  super.box(x0,y0,x1,y1,z0,z1,...colors);
 }
}
test('the low loading deck meets the quay and a solid rear stair reaches the doorway',()=>{
 const e=new RecordedExterior({}),deck=e.boxes.find(b=>b.name==='loading landing'&&b.z1===-91);
 assert.ok(deck&&deck.y0===5.3&&deck.y1===6.7);
 const steps=e.boxes.filter(b=>b.name==='rear door landing'&&b.z0===-91);
 assert.equal(steps.length,7);assert.equal(steps.at(-1).z1,-6);
 const rear=e.boxes.find(b=>b.name==='rear door landing'&&b.z0===-14);
 assert.ok(Math.abs(steps.at(-1).y0-rear.y1)<1e-9);
 for(const t of steps)assert.equal(t.z0,-91);
});
test('every distant house rests entirely on the town bank',()=>{
 const e=new RecordedExterior({}),bank=e.boxes.find(b=>b.name==='far bank');
 const houses=e.boxes.filter(b=>b.name.startsWith('town house')&&b.z0===-91);
 assert.equal(houses.length,8);
 for(const h of houses){
  assert.ok(h.x0>=bank.x0&&h.x1<=bank.x1&&h.y0>=bank.y0&&h.y1<=bank.y1,`${h.name} extends beyond solid ground`);
  assert.equal(h.z0,bank.z1,`${h.name} floats above the bank`);
 }
});
test('exterior exports the browser class and fixed hall/canal/landing contacts',()=>{
 const browser=vm.createContext({CivicProjection:P});
 vm.runInContext(fs.readFileSync(__dirname+'/exterior.js','utf8'),browser);
 assert.equal(typeof browser.CivicExterior,'function');
 const layout=Exterior.layout();
 assert.deepEqual(layout.hall,{x0:-3,x1:7.2,y0:-2,y1:5.2,z:0});
 assert.deepEqual(layout.canal,{x0:-7,x1:-3.05,y0:-3.5,y1:20,z:-120});
 assert.deepEqual(layout.frontCanal,{x0:-7,x1:9.4,y0:7.2,y1:20,z:-120});
 assert.equal(layout.frontCanal.y0,layout.quay.y1);
 assert.equal(layout.frontCanal.z,layout.canal.z);
 assert.equal(layout.landing.x1,layout.hall.x0);
 assert.ok(layout.landing.z>layout.canal.z&&layout.landing.z<layout.hall.z);
 assert.ok(Object.isFrozen(layout)&&Object.isFrozen(layout.canal));
});
test('every exterior face and line stays outside the largest board screen diamond',()=>{
 const e=new Exterior({}),board=P.corners(6,4);
 for(const c of e.commands){
  // Ground beneath the office is occluded by its unchanged solid floor.
  if(c.world.every(p=>p[2]<=-90)||c.world.every(p=>p[2]<0&&p[1]<-2))continue;
  if(c.kind!==1){
   assert.ok(area(clipPolygon(c.points,board))<1e-7,'a scenery face covers the playable board: '+e.props.find(p=>e.commands.indexOf(c)>=p.first&&e.commands.indexOf(c)<p.first+p.count).name);
  }else{
   // A slim rectangle also catches a line crossing the board between endpoints.
   const dx=c.b.x-c.a.x,dy=c.b.y-c.a.y,n=Math.hypot(dx,dy)||1,pad=c.width/2;
   const ox=-dy/n*pad,oy=dx/n*pad;
   const stroke=[{x:c.a.x+ox,y:c.a.y+oy},{x:c.b.x+ox,y:c.b.y+oy},{x:c.b.x-ox,y:c.b.y-oy},{x:c.a.x-ox,y:c.a.y-oy}];
   assert.ok(area(clipPolygon(stroke,board))<1e-7,'a scenery line covers the playable board');
  }
 }
});
test('reported scene and individual prop bounds contain all geometry and strokes',()=>{
 const e=new Exterior({});
 // Extended water intentionally passes the camera crop; the near architecture
 // remains bounded independently, so its baked cache need not include water.
 assert.ok(e.bounds.left>=-1000&&e.bounds.right<=2000);
 assert.ok(e.bounds.top>=-200&&e.bounds.bottom<=1600);
 for(const prop of e.props.slice(1))assert.ok(prop.bounds.left>=-500&&prop.bounds.right<=2000&&prop.bounds.bottom<=1250);
 for(const prop of e.props){
  const expected={left:Infinity,top:Infinity,right:-Infinity,bottom:-Infinity};
  for(let i=prop.first;i<prop.first+prop.count;i++){
   const c=e.commands[i],pad=c.kind===1||c.stroke?c.width/2:0;
   for(const p of c.kind!==1?c.points:[c.a,c.b]){
    assert.ok(Number.isFinite(p.x)&&Number.isFinite(p.y));
    expected.left=Math.min(expected.left,p.x-pad);expected.right=Math.max(expected.right,p.x+pad);
    expected.top=Math.min(expected.top,p.y-pad);expected.bottom=Math.max(expected.bottom,p.y+pad);
   }
  }
  assert.deepEqual(prop.bounds,expected,prop.name);
  assert.ok(prop.bounds.left>=e.bounds.left&&prop.bounds.right<=e.bounds.right);
  assert.ok(prop.bounds.top>=e.bounds.top&&prop.bounds.bottom<=e.bounds.bottom);
 }
});
test('repeated drawing reuses deterministic preprojected geometry without projection calls',()=>{
 const calls=[],renderer={path(points,fill,stroke,width){calls.push([points,fill,stroke,width]);},line(a,b,color,width){calls.push([a,b,color,width]);}};
 const e=new Exterior(renderer),copy=new Exterior({});
 assert.deepEqual(e.commands,copy.commands);
 const project=P.project;
 try{
  P.project=()=>{throw Error('draw projected new geometry');};
  e.draw();const first=calls.slice();calls.length=0;e.draw();
  assert.equal(calls.length,e.commands.filter(c=>c.kind!==2).length);
  for(let i=0;i<calls.length;i++){
   assert.deepEqual(calls[i],first[i]);assert.equal(calls[i][0],first[i][0]);
  }
 }finally{P.project=project;}
});
test('foreground quay supports every original office foot at its unchanged contact height',()=>{
 const e=new RecordedExterior({}),q=e.boxes.find(b=>b.name==='front quay');
 const feet=[...[-2.8,.25,3.3,6.8].map(x=>[x-.12,4.77,x+.38,5.27]),...[-1.7,.7,3.1].map(y=>[6.8,y,7.22,y+.42])];
 assert.equal(q.z1,-91);
 for(const [x0,y0,x1,y1]of feet)assert.ok(x0>=q.x0&&x1<=q.x1&&y0>=q.y0&&y1<=q.y1,'footprint overhangs its supporting quay');
 assert.ok(Exterior.layout().canal.z<q.z1&&Exterior.layout().canal.z>q.z0);
});
test('seven solid exterior treads connect the quay to the unchanged office floor',()=>{
 const e=new RecordedExterior({}),s=Exterior.layout().stairs,treads=e.boxes.filter(b=>b.name==='entry stair');
 assert.equal(treads.length,7);assert.equal(treads[0].z0,-91);assert.equal(treads.at(-1).z1,0);
 assert.ok(Math.abs(treads.at(-1).y0-Exterior.layout().hall.y1)<1e-10);
 for(let i=0;i<treads.length;i++){
  const t=treads[i];assert.equal(t.z0,-91);assert.equal(t.x0,s.x0);assert.equal(t.x1,s.x1);
  assert.ok(t.y0>=5.2-1e-10,'new stairs intrude into the original floor');
  if(i)assert.ok(Math.abs(t.y1-treads[i-1].y0)<1e-10,'gap between treads');
  assert.ok(Math.abs(t.z1-(-91+(i+1)*13))<1e-10);
 }
});
test('all five canal cottages rest on the same solid west bank with two-storey warm windows',()=>{
 const e=new RecordedExterior({}),bank=e.boxes.find(b=>b.name==='left towpath');
 const cottages=e.boxes.filter(b=>b.name.startsWith('west cottage')&&b.z0===-91&&b.z1>20);
 assert.equal(cottages.length,5);
 for(const h of cottages){assert.equal(h.z0,bank.z1);assert.ok(h.x0>=bank.x0&&h.x1<=bank.x1&&h.y0>=bank.y0&&h.y1<=bank.y1);}
 const windows=e.commands.filter(c=>c.fill==='#efc875');assert.equal(windows.length,10);
});
test('textured bake replay retains exact world vertices and does not change projection',()=>{
 let faces=0;const e=new Exterior({poly(world){assert.ok(e.commands.some(c=>c.world===world));faces++;},path(){},line(){}});
 e.draw(false);assert.ok(faces>1000);
 for(const c of e.commands)if(c.kind===0)assert.deepEqual(c.points,c.world.map(p=>P.project(...p)));
});
test('garden cottages are entirely supported by the far bank and the bridge clears the boat route',()=>{
 const e=new RecordedExterior({}),bank=e.boxes.find(b=>b.name==='far bank');
 const homes=e.boxes.filter(b=>b.name.startsWith('garden cottage')&&b.z0===-91);
 assert.equal(homes.length,2);
 for(const h of homes)assert.ok(h.x0>=bank.x0&&h.x1<=bank.x1&&h.y0>=bank.y0&&h.y1<=bank.y1&&h.z0===bank.z1);
 const bridge=e.props.find(p=>p.name==='canal bridge'),commands=e.commands.slice(bridge.first,bridge.first+bridge.count);
 const front=Math.max(...commands.flatMap(c=>c.world.map(p=>p[1]))),Canal=require('./canal-life.js'),pose={};
 for(let t=0;t<168;t+=.125){
  Canal.sampleBoat(t,pose);const c=Math.cos(pose.heading),s=Math.sin(pose.heading);
  for(const [x,y]of Canal.layout().hull)assert.ok(pose.y+x*s+y*c>front,'boat reaches bridge masonry');
 }
});
test('optional cottage artwork is registered to the real east face without changing geometry',()=>{
 const transforms=[],draws=[],image={},r={images:{houseFront:image},path(){},line(){},ctx:{save(){},restore(){},transform(...v){transforms.push(v);},drawImage(...v){draws.push(v);}}};
 const e=new Exterior(r),faces=e.commands.filter(c=>c.kind===2);assert.equal(faces.length,5);e.draw();
 assert.equal(draws.length,5);
 for(let i=0;i<faces.length;i++){
  const f=faces[i],t=transforms[i];assert.deepEqual(t,[1,-.5,0,1,f.points[0].x,f.points[0].y]);
  assert.deepEqual(draws[i],[image,0,0,f.imageWidth,f.imageHeight]);
  assert.ok(Math.abs(f.points[1].x-(f.origin.x+f.imageWidth))<1e-8);
  assert.ok(Math.abs(f.points[1].y-(f.origin.y-f.imageWidth*.5))<1e-8);
  assert.ok(Math.abs(f.points[3].y-(f.origin.y+f.imageHeight))<1e-8);
 }
});

test('paper replay preserves open wheel centres and authored stroke widths',()=>{
 const calls=[],e=new Exterior({poly(world,fill,material){calls.push({kind:'poly',world,fill,material});},path(points,fill,stroke,width){calls.push({kind:'path',points,fill,stroke,width});},line(){}});
 e.draw();
 const wheels=e.commands.filter(c=>c.kind===0&&!c.fill&&c.stroke);
 assert.equal(wheels.length,2);
 for(const wheel of wheels){
  assert.ok(!calls.some(c=>c.kind==='poly'&&c.world===wheel.world),'an open wheel must never receive a texture fill');
  assert.deepEqual(calls.find(c=>c.points===wheel.points),{kind:'path',points:wheel.points,fill:null,stroke:wheel.stroke,width:wheel.width});
 }
 const framed=e.commands.filter(c=>c.kind===0&&c.fill&&c.stroke);
 assert.ok(framed.length>20);
 for(const face of framed){
  const fillIndex=calls.findIndex(c=>c.kind==='poly'&&c.world===face.world);
  assert.ok(fillIndex>=0);assert.deepEqual(calls[fillIndex+1],{kind:'path',points:face.points,fill:null,stroke:face.stroke,width:face.width});
 }
});

test('foreground furniture rests on the quay and keeps the entrance stair clear',()=>{
 class FurnitureContacts extends Exterior{
  planter(x,y,z,w,d,...rest){(this.contacts||(this.contacts=[])).push({type:'planter',x,y,z,w,d,name:this.current.name});super.planter(x,y,z,w,d,...rest);}
  bench(x,y,z,w){(this.contacts||(this.contacts=[])).push({type:'bench',x,y,z,w,d:.7,name:this.current.name});super.bench(x,y,z,w);}
 }
 const e=new FurnitureContacts({}),q=Exterior.layout().quay,s=Exterior.layout().stairs;
 const furniture=e.contacts.filter(c=>c.name==='quayside furniture');
 assert.equal(furniture.filter(c=>c.type==='planter').length,3);
 assert.equal(furniture.filter(c=>c.type==='bench').length,1);
 for(const c of furniture){
  assert.equal(c.z,q.z);assert.ok(c.x>=q.x0&&c.y>=q.y0&&c.x+c.w<=q.x1&&c.y+c.d<=q.y1);
  assert.ok(c.x+c.w<=s.x0||c.x>=s.x1||c.y+c.d<=s.y0||c.y>=s.y1,`${c.type} intrudes into stair`);
 }
});

test('the bench planter clears the lantern base and its complete visible silhouette',()=>{
 class FurnitureSilhouettes extends Exterior{
  planter(x,y,z,w,d,...rest){
   const first=this.commands.length;super.planter(x,y,z,w,d,...rest);
   (this.furnitureShapes||(this.furnitureShapes=[])).push({type:'planter',x,y,z,w,d,name:this.current.name,commands:this.commands.slice(first)});
  }
  lantern(x,y,z,h){
   const first=this.commands.length;super.lantern(x,y,z,h);
   (this.furnitureShapes||(this.furnitureShapes=[])).push({type:'lantern',x,y,z,h,name:this.current.name,commands:this.commands.slice(first)});
  }
 }
 const e=new FurnitureSilhouettes({}),near=e.furnitureShapes.filter(f=>f.name==='quayside furniture'&&f.x>0);
 const planter=near.find(f=>f.type==='planter'),lamp=near.find(f=>f.type==='lantern'),q=Exterior.layout().quay;
 assert.equal(planter.z,q.z);assert.equal(lamp.z,q.z);
 // Include the planter's overhanging rim and the lamp's full stone foot.
 const planterRight=planter.x+planter.w+.035,lampLeft=lamp.x-.115*1.3;
 assert.ok(lampLeft-planterRight>=.3,'lantern foot merges into the planter rim');
 assert.ok(lamp.x+.115*1.3<=q.x1&&lamp.y+.115*1.3<=q.y1);
 const silhouette=f=>{
  const commands=f.commands.filter(c=>c.kind!==3&&!/^rgba|^#[0-9a-f]{8}$/i.test(c.fill||''));
  let left=Infinity,right=-Infinity;
  for(const c of commands){const pad=c.kind===1||c.stroke?c.width/2:0;for(const p of c.points||[c.a,c.b]){left=Math.min(left,p.x-pad);right=Math.max(right,p.x+pad);}}
  return{left,right};
 };
 // Physical footprints alone missed the original collision: flowers and
 // lantern panes must also read as separate objects in the fixed camera.
 assert.ok(silhouette(lamp).left-silhouette(planter).right>=6,'flowers hide the lantern post or panes');
});

test('bench feet meet the quay and connect through solid brackets to the seat',()=>{
 class BenchContacts extends Exterior{
  bench(...args){const first=this.commands.length;this.inBench=true;super.bench(...args);this.inBench=false;this.benchCommands=this.commands.slice(first);}
  box(x0,y0,x1,y1,z0,z1,...colours){if(this.inBench)(this.benchBoxes||(this.benchBoxes=[])).push({x0,y0,x1,y1,z0,z1,colours});super.box(x0,y0,x1,y1,z0,z1,...colours);}
 }
 const e=new BenchContacts({}),q=Exterior.layout().quay,feet=e.benchBoxes.filter(b=>b.z0===q.z&&b.z1===q.z+3);
 assert.equal(feet.length,4);
 const brackets=e.benchBoxes.filter(b=>b.colours[0]==='#5a8973');assert.equal(brackets.length,2);
 const legs=e.benchCommands.filter(c=>c.kind===0&&c.fill==='#2d6659'&&c.world[0][2]===q.z+3);
 assert.equal(legs.length,4);
 for(const foot of feet){
  assert.ok(foot.x0>=q.x0&&foot.x1<=q.x1&&foot.y0>=q.y0&&foot.y1<=q.y1);
  const xx=(foot.x0+foot.x1)/2,yy=(foot.y0+foot.y1)/2;
  const leg=legs.find(c=>c.world.slice(0,2).every(p=>p[0]>=foot.x0&&p[0]<=foot.x1&&p[1]>=foot.y0&&p[1]<=foot.y1));
  assert.ok(leg,'foot has no attached upright');
  assert.ok(brackets.some(b=>xx>b.x0&&xx<b.x1&&yy>b.y0&&yy<b.y1&&leg.world[0][2]<=b.z0&&leg.world[2][2]>=b.z1),'leg does not reach a seat bracket');
 }
 const slats=e.benchBoxes.filter(b=>b.colours[0]==='#dda15c');assert.equal(slats.length,5);
 for(const slat of slats)for(const bracket of brackets)assert.ok(bracket.z1===slat.z0&&bracket.x0<slat.x1&&bracket.x1>slat.x0&&bracket.y0<slat.y1&&bracket.y1>slat.y0,'seat slat misses its supporting bracket');
});

test('both curved bench arms terminate on their own connected frame',()=>{
 class BenchGeometry extends Exterior{bench(...args){const first=this.commands.length;super.bench(...args);this.benchCommands=this.commands.slice(first);}}
 const e=new BenchGeometry({}),commands=e.benchCommands;
 const curves=commands.filter(c=>c.kind===1&&c.color==='#2e6c5b'&&c.width===6.2);
 const frames=[];
 for(let i=0;i<commands.length;i++){
  const c=commands[i];if(c.kind!==0||c.fill!=='#2d6659')continue;
  const side=commands[i+1];assert.equal(side.fill,'#214e47');
  frames.push([
   [(c.world[0][0]+c.world[1][0])/2,(side.world[0][1]+side.world[1][1])/2,c.world[0][2]],
   [(c.world[2][0]+c.world[3][0])/2,(side.world[2][1]+side.world[3][1])/2,c.world[2][2]]
  ]);
 }
 assert.equal(curves.length,28);
 const joins=(point,line)=>{
  const[a,b]=line,t=(point[2]-a[2])/(b[2]-a[2]);
  return t>=-1e-8&&t<=1+1e-8&&point.every((v,i)=>Math.abs(v-(a[i]+(b[i]-a[i])*t))<1e-8);
 };
 for(const offset of[0,14]){
  assert.ok(frames.some(f=>joins(curves[offset].world[0],f)),'front arm upright is disconnected');
  assert.ok(frames.some(f=>joins(curves[offset+13].world[1],f)),'rear arm terminates beside its back support');
 }
});

test('the canal-facing bench reveals its seat and keeps armrests below the back rail',()=>{
 class BenchGeometry extends Exterior{bench(...args){const first=this.commands.length;super.bench(...args);this.benchCommands=this.commands.slice(first);}}
 const e=new BenchGeometry({}),commands=e.benchCommands;
 const backs=commands.filter(c=>c.fill==='#ca894f'),seats=commands.filter(c=>c.fill==='#dda15c');
 const arms=commands.filter(c=>c.kind===1&&c.color==='#2e6c5b'&&c.width===6.2);
 const meanY=list=>list.flatMap(c=>c.world).reduce((sum,p)=>sum+p[1],0)/list.flatMap(c=>c.world).length;
 assert.ok(meanY(backs)<meanY(seats)-.2,'back boards stand in front of the seat and hide the arm uprights');
 const seatTop=Math.max(...seats.flatMap(c=>c.world.map(p=>p[2]))),railTop=Math.max(...backs.flatMap(c=>c.world.map(p=>p[2])));
 const armPoints=arms.flatMap(c=>c.world);
 assert.ok(Math.min(...armPoints.map(p=>p[2]))>=seatTop+10,'armrest lies against the seat');
 assert.ok(Math.max(...armPoints.map(p=>p[2]))<=railTop-10,'armrest reads as a handle on top of the back');
 for(const offset of[0,14])assert.ok(arms[offset].world[0][1]>arms[offset+13].world[1][1]+.4,'arm front is on the far side of the bench');
 const firstSeat=commands.indexOf(seats[0]),lastSeat=commands.indexOf(seats.at(-1));
 assert.ok(commands.indexOf(backs.at(-1))<firstSeat,'back boards must be painted behind the seat');
 const frontPosts=commands.filter(c=>c.fill==='#2d6659'&&c.world[2][2]-c.world[0][2]>30&&Math.abs(c.world[2][1]-c.world[0][1])<1e-9);
 assert.equal(frontPosts.length,2);
 for(const post of frontPosts)assert.ok(commands.indexOf(post)>lastSeat,'seat obscures the nearer floor-to-arm upright');
});

test('the foreground planter is painted after the farther bench legs',()=>{
 class FurnitureOrder extends Exterior{
  bench(...args){(this.order||(this.order=[])).push({kind:'bench',x:args[0]});super.bench(...args);}
  planter(...args){(this.order||(this.order=[])).push({kind:'planter',x:args[0]});super.planter(...args);}
 }
 const e=new FurnitureOrder({}),bench=e.order.findIndex(o=>o.kind==='bench'),planter=e.order.findIndex(o=>o.kind==='planter'&&o.x===1.45);
 assert.ok(bench>=0&&planter>bench,'far bench leg is painted across the closer planter');
});

test('foreground water wraps the quay without a visible cut face and ground glows remain coplanar',()=>{
 const e=new Exterior({}),water=e.props.find(p=>p.name==='canal water'),commands=e.commands.slice(water.first,water.first+water.count);
 assert.ok(commands.every(c=>c.world.every(p=>p[2]>=-120)),'water introduces a paper edge inside the extended reach');
 const l=Exterior.layout();assert.equal(l.frontCanal.y0,l.quay.y1);assert.equal(l.frontCanal.x1,l.quay.x1);assert.equal(l.frontCanal.y1,l.canal.y1);
 const glows=e.commands.filter(c=>c.kind===3&&c.aspect<1);assert.equal(glows.length,2);
 for(const c of glows){assert.ok(c.world.every(p=>Math.abs(p[2]-(l.quay.z+.1))<1e-8));assert.deepEqual(c.points,c.world.map(p=>P.project(...p)));}
 const shadows=e.commands.filter(c=>c.fill?.startsWith('rgba(76,57,45'));
 assert.ok(shadows.length>=7);for(const c of shadows){assert.equal(c.material,'none');assert.ok(c.world.every(p=>p[2]>l.quay.z&&p[2]<l.quay.z+1));}
});

test('garden roots are supported by soil beds while the gate and support path stay clear',()=>{
 class GardenContacts extends Exterior{
  gardenBed(x0,y0,x1,y1,z){(this.beds||(this.beds=[])).push({x0,y0,x1,y1,z});super.gardenBed(x0,y0,x1,y1,z);}
  gardenPlant(x,y,z,h,seed,flower){(this.plants||(this.plants=[])).push({x,y,z,h,name:this.current.name});super.gardenPlant(x,y,z,h,seed,flower);}
 }
 const e=new GardenContacts({}),plants=e.plants.filter(p=>p.name==='garden');
 assert.equal(e.beds.length,2);
 for(const b of e.beds){
  assert.ok(b.x0>7.22+.25,'bed obstructs the path beside a support');
  assert.ok(b.y1<=.45||b.y0>=1.55,'bed crosses the gate approach');
  assert.equal(b.z,Exterior.layout().quay.z);
 }
 for(const p of plants){
  assert.ok(e.beds.some(b=>p.x>b.x0&&p.x<b.x1&&p.y>b.y0&&p.y<b.y1&&Math.abs(p.z-(b.z+5.2))<1e-9),'plant root is not in the visible soil');
 }
 assert.ok(plants.some(p=>p.h<30)&&plants.some(p=>p.h>=30&&p.h<45)&&plants.some(p=>p.h>=45));
});
