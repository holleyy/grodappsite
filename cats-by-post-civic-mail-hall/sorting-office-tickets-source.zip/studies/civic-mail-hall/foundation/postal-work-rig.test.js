'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const P=require('./projection.js');
let Rig;try{Rig=require('./postal-work-rig.js');}catch{Rig={};}
test('two-link joints preserve both lengths at reachable palm and sole targets',()=>{
 assert.equal(typeof Rig.solveJoint,'function');const out=new Float64Array(3);
 for(const q of [[-30,0,16],[12,20,-25],[0,3,-28],[-36,2,14]]){
  Rig.solveJoint(0,0,0,...q,22,22,0,0,1,out);
  assert.ok(Math.abs(Math.hypot(...out)-22)<1e-8);
  assert.ok(Math.abs(Math.hypot(out[0]-q[0],out[1]-q[1],out[2]-q[2])-22)<1e-8);
 }
});
test('mesh corners use the board projection and reuse the original vertex storage',()=>{
 assert.equal(typeof Rig.Mesh,'function');const mesh=new Rig.Mesh(),refs=mesh.faces.map(f=>f.vertices);
 for(let i=0;i<100;i++){
  mesh.reset();mesh.box(-.53,2,0,.5,.6,58,.73,'ivory');
  assert.ok(mesh.count>=3);
  for(let j=0;j<mesh.count;j++){
   const f=mesh.faces[j];assert.equal(f.vertices,refs[j]);
   for(let k=0;k<f.count;k++){
    const o=k*3,p=P.project(f.vertices[o],f.vertices[o+1],f.vertices[o+2]);
    assert.equal(f.screen[k*2],p.x);assert.equal(f.screen[k*2+1],p.y);
   }
  }
 }
});

test('moving stock is lit from the room rather than turning with the robot',()=>{
 const mesh=new Rig.Mesh();
 function sample(yaw){
  mesh.reset();mesh.box(0,0,0,1,1,P.HW,yaw,'ivory');const faces={};
  for(let i=0;i<mesh.count;i++){
   const f=mesh.faces[i],v=f.vertices;let x=0,y=0,z=0;
   for(let k=0;k<f.count;k++){x+=v[k*3];y+=v[k*3+1];z+=v[k*3+2]/P.HW;}
   faces[[x,y,z].map(n=>Math.round(n/f.count*100)).join(',')]=f.colour;
  }return faces;
 }
 assert.deepEqual(sample(0),sample(Math.PI/2),'identical world-facing cube sides change light when local axes turn');
 mesh.reset();mesh.chamfer(0,0,0,1,1,P.HW,0,'ivory');
 assert.ok(new Set(mesh.faces.slice(0,mesh.count).map(f=>f.colour)).size>=4,'folded bevels lack their own light levels');
});

test('a raised sole has a wider softer floor shadow while planted wheels remain attached',()=>{
 const rig=new Rig({}),C=require('./postal-work-cycle.js'),s=C.createState(),draws=[],stack=[];
 rig.shadowTile={};
 const c={globalAlpha:1,save(){stack.push(this.globalAlpha);},restore(){this.globalAlpha=stack.pop();},transform(...m){this.matrix=m;},drawImage(){draws.push({alpha:this.globalAlpha,matrix:this.matrix});}};
 C.sample(0,s);s.robot.feet[0].z=0;s.robot.feet[1].z=8;rig.shadows(c,s);
 const feet=draws.filter(d=>d.matrix[4]===760+(s.robot.feet[0].x-s.robot.feet[0].y)*P.HW||d.matrix[4]===760+(s.robot.feet[1].x-s.robot.feet[1].y)*P.HW);
 assert.equal(feet.length,2);
 assert.ok(feet[1].alpha<feet[0].alpha*.7,'raised sole retains a hard planted shadow');
 assert.ok(Math.hypot(feet[1].matrix[0],feet[1].matrix[1])>Math.hypot(feet[0].matrix[0],feet[0].matrix[1]),'raised shadow fails to spread');
 for(let i=0;i<2;i++)assert.equal(feet[i].matrix[5],465+(s.robot.feet[i].x+s.robot.feet[i].y)*P.HH,'sole shadow is lifted off the floor');
 assert.equal(draws.length,7,'cart body and all four wheel contacts must be shaded');
});

test('the elbow follows continuous return and turn paths without entering the bench',()=>{
 const C=require('./postal-work-cycle.js'),rig=new Rig({}),s=C.createState(),prior=new Float64Array(6),U=P.HW;
 function intersects(a,b,c,x,y,z){
  let lo=0,hi=1;
  for(const[start,end,min,max]of[[a,x,-1.75+1e-7,-.95-1e-7],[b,y,.35+1e-7,3.60-1e-7],[c,z,1e-7,58-1e-7]]){
   const d=end-start;if(Math.abs(d)<1e-12){if(start<min||start>max)return false;continue;}
   const u=(min-start)/d,v=(max-start)/d;lo=Math.max(lo,Math.min(u,v));hi=Math.min(hi,Math.max(u,v));if(lo>hi)return false;
  }return true;
 }
 for(let frame=0;frame<=5200;frame++){
  C.sample(frame/100,s);rig.mesh.reset();rig.robot(s);
  for(let side=0;side<2;side++){
   const o=side*12+9,k=side*3,v=rig.links;
   if(frame)assert.ok(Math.hypot((v[o]-prior[k])*U,(v[o+1]-prior[k+1])*U,v[o+2]-prior[k+2])<3.2,'elbow jumps at '+s.time);
   prior[k]=v[o];prior[k+1]=v[o+1];prior[k+2]=v[o+2];
  }
  for(let f=0;f<rig.mesh.count;f++){
   const face=rig.mesh.faces[f],v=face.vertices;
   for(let k=0;k<face.count;k++){
    const a=k*3,b=((k+1)%face.count)*3;
    assert.ok(v[a]<=-.14,'arm enters board apron at '+s.time);
    assert.ok(!intersects(v[a],v[a+1],v[a+2],v[b],v[b+1],v[b+2]),'rig edge enters bench at '+s.time);
   }
  }
 }
});
