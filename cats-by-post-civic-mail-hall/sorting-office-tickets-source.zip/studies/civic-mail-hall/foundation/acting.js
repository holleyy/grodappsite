/* Pure Office paper presentation. No assets, renderer, clocks or rule changes. */
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else root.CivicActing=factory();
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  function create(BOARDANIM){
    const BA=BOARDANIM,A=BA.A,DX=[1,0,-1,0],DY=[0,1,0,-1],dirs={R:0,D:1,L:2,U:3};
    const defaults=BA.makeOut(),keys=Object.keys(defaults),names=[];
    for(const name of Object.keys(A))names[A[name]]=name.toLowerCase();
    const clamp=v=>v<0?0:v>1?1:v,ease=v=>{v=clamp(v);return v*v*(3-2*v);};
    const q=v=>Math.round(v*2)/2,q2=v=>Math.round(v*.5)*2,lerp=(a,b,t)=>a+(b-a)*t,fract=v=>v-Math.floor(v);
    const coat=c=>typeof c==='number'?c:(typeof c==='object'?coat(c.coat):c==='blue'?2:1);
    function finite(time){if(!Number.isFinite(time))throw new RangeError('Acting time must be finite seconds');}
    function resetBase(out){for(let k=0;k<keys.length;k++)out[keys[k]]=defaults[keys[k]];}

    /* makeOut() allocates all records once. sample mutates and returns that same
       object, with no frame allocations. Flat fields are BOARDANIM-compatible,
       plus takeoff (-1 or frame 0..3), takeoffSupported (0/1).
       All x/y/z values below are SOURCE WORLD UNITS (16 per tile).
       root: source pose and phase; terminalAge is -Infinity without a terminal.
       cat: explicit artwork anchor, root+(4,4) boxed and root otherwise; bodyDir
         and headDir remain independent. stretch is boxed stage 0/1/2; mirror
         matches the original blit (boxed false, TURN middle frame mirrored).
         frame selects takeoff art when active;
         pose names match BA enums otherwise. clipFloor requests floor-z=0 clip.
       box: ROOT anchor; artwork is drawn at (x+4,y+4), z; occupied carrier follows
         root, empty carrier uses boxX/Y. No occupied box under loose cat art.
       rim: ART anchor (boxX+4,boxY+4), z0; only the takeoff support rim, not basket.
       effects: tile targets (-1 absent); home occupancy only CURL/NAP/WAKE.
       base is private reusable BOARDANIM scratch; callers must not draw it.
       All public fields are rewritten even after a hidden/rewound sample. */
    function makeOut(){
      const out=BA.makeOut();out.takeoff=-1;out.takeoffSupported=0;out.base=BA.makeOut();
      out.root={visible:false,x:0,y:0,z:0,anim:A.HIDDEN,frame:0,phase:'hidden',terminalAge:-Infinity};
      out.cat={visible:false,coat:1,boxed:false,bodyDir:0,headDir:0,ears:0,eyes:0,bob:0,stretch:0,pose:'hidden',frame:0,x:0,y:0,z:0,mirror:false,clipFloor:false,supported:false};
      out.box={visible:false,occupied:false,x:0,y:0,z:0,dir:0,fold:-1,fade:0};
      out.rim={visible:false,kind:'carrier',x:0,y:0,z:0,coat:1};
      out.effects={hatchX:-1,hatchY:-1,hatchOpen:0,spinX:-1,spinY:-1,spin:0,bumpX:-1,bumpY:-1,bumpAge:-1,homeX:-1,homeY:-1,cushionOccupied:false,flapOpen:0,puzzled:false};
      return out;
    }
    // The rule trace still supplies every action and deadline. Its original
    // two-world-unit pixel snapping becomes large jumps at this scene's scale,
    // so sample floor travel continuously without changing those action fields.
    function glide(out,tr,now){
      if(out.anim===A.POP){
        const f=(now-(tr.rel-tr.pop))/tr.pop;
        out.z=-8+ease((f-.15)/.6)*8;return;
      }
      if(out.anim!==A.TRAVEL&&out.anim!==A.BOUNCE&&out.anim!==A.STOP)return;
      const k=Math.floor((now-tr.rel)/tr.tick);
      if(k<0||k>=tr.n||tr.homeKind==='flap'||tr.ev[k]===BA.EV_TUNNEL)return;
      const f=(now-tr.rel-k*tr.tick)/tr.tick,d=tr.d0[k],ev=tr.ev[k];
      const x0=tr.ox+tr.x0[k]*16+8,y0=tr.oy+tr.y0[k]*16+8;
      let x1=tr.ox+tr.x1[k]*16+8,y1=tr.oy+tr.y1[k]*16+8;
      if(tr.bn[k]){
        const F=Math.max(1,Math.round(tr.tick*BA.FPS)),b0=F>=4?1:0,fTurn=Math.min(.99,(b0+3)/F);
        const nudge=3*ease(f/.2),nx=x0+DX[d]*nudge,ny=y0+DY[d]*nudge;
        const g=F<4?(f-2/F)*F:(f-fTurn)/(1-fTurn),m=ease(g);
        out.x=lerp(nx,x1,m);out.y=lerp(ny,y1,m);return;
      }
      const turned=tr.d1[k]!==d&&ev===BA.EV_MOVED;
      // Straight tiles form one uninterrupted route. A real turn retains its
      // original arrival/looking/turning hold; basket approach retains support.
      let m=turned?ease(f/.6):clamp(f);
      if(ev!==BA.EV_MOVED){x1-=DX[d]*14;y1-=DY[d]*14;m=ease(f/.6);}
      out.x=lerp(x0,x1,m);out.y=lerp(y0,y1,m);
      out.bob=Math.sin(Math.PI*m)*.6;
    }
    // Study-local supported paper override. It deliberately has no art gate:
    // missing artwork must never change the accepted arrival clock.
    function paper(out,tr,now){
      if(tr.homeKind==='flap'||tr.n===0||tr.coat<1||tr.coat>2||(tr.end!==BA.END_HOME&&tr.end!==BA.END_WRONG))return;
      const j=tr.n-1,d=tr.d0[j],T=now-(tr.rel+tr.n*tr.tick);
      const hx=tr.ox+tr.x1[j]*16+8,hy=tr.oy+tr.y1[j]*16+8,bx=hx-DX[d]*14,by=hy-DY[d]*14;
      if(T<0){
        if(T<-tr.tick||tr.bn[j]||out.anim===A.HIDDEN||out.anim===A.POP)return;
        const u=ease((T+tr.tick)/(tr.tick*.6));
        out.x=lerp(tr.ox+tr.x0[j]*16+8,bx,u);out.y=lerp(tr.oy+tr.y0[j]*16+8,by,u);return;
      }
      const wrong=tr.end===BA.END_WRONG;
      if(!wrong&&now>=tr.napUntil){
        if(out.anim===A.WAKE)out.z=3;
        else if(out.anim===A.LEAVE)out.z+=Math.round(3*(1-clamp((now-tr.napUntil-BA.WAKE_LEN)/BA.LEAVE_LEN)));
        return;
      }
      if(T<.2){out.x=bx;out.y=by;return;}
      const fade=wrong?0:clamp((T-.75)/(1.2-.75)),slide=ease(fade);
      out.boxX=bx-Math.SQRT1_2*12*slide;out.boxY=by+Math.SQRT1_2*12*slide;out.boxFade=fade;
      out.boxFold=wrong||T<.45?0:T<.75?1+Math.floor((T-.45)*10+1e-6):T<1.2?4:-1;
      if(T>=.6){if(!wrong)out.z=3;return;}
      const mirrored=d===0||d===3,away=d===2||d===3,sx=mirrored?-2:2,u=clamp((T-.4)/(.6-.4));
      const tx=wrong?q2(hx+3):q2(hx+tr.homeDX),ty=wrong?q2(hy+3):q2(hy+tr.homeDY),startZ=away?-1:5,endZ=wrong?1:-1;
      out.x=q(lerp(bx+4+sx,tx+(mirrored?-3:3),u));out.y=q(lerp(by+4-sx,ty+(mirrored?3:-3),u));
      out.z=T<.4?startZ:Math.round(lerp(startZ,endZ,u)+Math.sin(u*Math.PI)*3+(1-u)**4);
      out.takeoff=T<.3?0:T<.4?1:T<.45?2:3;out.takeoffSupported=T<.4?1:0;
    }
    function sample(tr,time,out){
      finite(time);const now=time+1e-9; // Exactly one effective production epsilon.
      resetBase(out.base);BA.pose(tr,now,out.base);
      for(let k=0;k<keys.length;k++)out[keys[k]]=out.base[keys[k]];
      out.takeoff=-1;out.takeoffSupported=0;glide(out,tr,now);paper(out,tr,now);
      const visible=out.anim!==A.HIDDEN,terminal=tr.n>0&&(tr.end===BA.END_HOME||tr.end===BA.END_WRONG),T=terminal?now-(tr.rel+tr.n*tr.tick):-Infinity;
      const loose=out.takeoff>=0||out.anim===A.TURN||out.anim===A.CURL||out.anim===A.NAP||out.anim===A.WAKE||out.anim===A.LEAVE||out.anim===A.PUZZLED||out.anim===A.HOP;
      const boxed=visible&&!loose,r=out.root,c=out.cat,b=out.box,rim=out.rim,e=out.effects;
      let phase=names[out.anim];
      if(out.takeoff>=0)phase=out.takeoff===0?'crouch':out.takeoff===1?'push':'flight';
      else if(boxed)phase='boxed';else if(out.anim===A.TURN||out.anim===A.CURL)phase='settling';
      r.visible=visible;r.x=out.x;r.y=out.y;r.z=out.z;r.anim=out.anim;r.frame=out.frame;r.phase=phase;r.terminalAge=T;
      c.visible=visible;c.coat=tr.coat;c.boxed=boxed;c.bodyDir=out.dir;c.headDir=out.head;c.ears=out.ears;c.eyes=out.eyes;c.bob=out.bob;
      c.stretch=out.anim===A.STRETCH?Math.min(2,out.frame+1):0;c.pose=out.takeoff>=0?'takeoff':names[out.anim];c.frame=out.takeoff>=0?out.takeoff:out.frame;
      c.x=out.x+(boxed?4:0);c.y=out.y+(boxed?4:0);c.z=out.z;c.mirror=!boxed&&(out.dir===0||out.dir===3||(out.anim===A.TURN&&(out.frame&1)!==0));c.clipFloor=out.anim===A.POP;c.supported=out.takeoffSupported===1;
      b.visible=boxed||visible&&out.boxFold>=0;b.occupied=boxed;b.x=boxed?out.x:out.boxFold>=0?out.boxX:0;b.y=boxed?out.y:out.boxFold>=0?out.boxY:0;
      b.z=boxed?out.z:0;b.dir=boxed?out.dir:terminal?tr.d0[tr.n-1]:out.dir;b.fold=boxed?0:out.boxFold;b.fade=boxed?0:out.boxFade;
      rim.visible=visible&&out.takeoffSupported===1;rim.kind='carrier';rim.x=rim.visible?out.boxX+4:0;rim.y=rim.visible?out.boxY+4:0;rim.z=0;rim.coat=tr.coat;
      e.hatchX=out.anim===A.POP?tr.hx:-1;e.hatchY=out.anim===A.POP?tr.hy:-1;e.hatchOpen=out.hatchOpen;
      e.spinX=out.spinX;e.spinY=out.spinY;e.spin=out.spin;e.bumpX=out.bumpX;e.bumpY=out.bumpY;e.bumpAge=out.bumpAge;
      e.homeX=tr.n>0?tr.x1[tr.n-1]:-1;e.homeY=tr.n>0?tr.y1[tr.n-1]:-1;
      e.cushionOccupied=out.anim===A.CURL||out.anim===A.NAP||out.anim===A.WAKE;e.flapOpen=out.flapOpen;e.puzzled=out.anim===A.PUZZLED;
      return out;
    }

    /* hatch(levelHatch,traces,time,out): raw level hatch {x,y,dir,cats}, full
       global trace array. Optional catIds or first explicitly identifies global
       cats; otherwise infer contiguous first from a matching released trace.
       Before Send (empty traces) every cat waits. Unreleased Infinity traces
       retain their level coat. pop-start (rel-pop), not first movement, removes
       a head. n is visible count <=4; waiting is total; queue entries are ordered
       nearest-first and must draw in REVERSE order. queue x/y are ART anchors,
       hatch x/y are centre. open uses production 0/1/2 (closed/ajar/open).
       An entirely unreleased non-empty scene requires first/catIds, since the
       original empty trace does not yet store hatch identity. */
    function makeHatchOut(){
      const out={x:0,y:0,dir:0,open:0,n:0,waiting:0,queue:[],base:BA.makeOut()};
      for(let k=0;k<4;k++)out.queue.push({visible:false,id:-1,coat:1,x:0,y:0,z:.5,dir:0});return out;
    }
    function hatch(h,traces,time,out){
      finite(time);resetBase(out.base);const now=time+1e-9,d=typeof h.dir==='number'?h.dir:dirs[h.dir],ox=h.ox||0,oy=h.oy||0;
      out.x=ox+h.x*16+8;out.y=oy+h.y*16+8;out.dir=d;out.open=0;out.n=0;out.waiting=0;
      let first=h.first;
      if(first===undefined){first=0;for(let k=0;k<traces.length;k++)if(traces[k].rel!==Infinity&&traces[k].hx===h.x&&traces[k].hy===h.y){first=k;break;}}
      for(let k=0;k<4;k++){const q=out.queue[k];q.visible=false;q.id=-1;q.coat=1;q.x=0;q.y=0;q.z=.5;q.dir=d;}
      for(let k=0;k<h.cats.length;k++){
        const id=h.catIds?h.catIds[k]:first+k,tr=traces[id];
        if(tr&&now>=tr.rel-tr.pop){
          resetBase(out.base);BA.pose(tr,now,out.base);if(out.base.anim===A.POP&&out.base.hatchOpen>out.open)out.open=out.base.hatchOpen;
        }else{
          out.waiting++;
          if(out.n<4){const j=out.n++,q=out.queue[j];q.visible=true;q.id=id;q.coat=coat(h.cats[k]);q.x=out.x+DX[d]*(3-4*j);q.y=out.y+DY[d]*(3-4*j);q.z=.5;q.dir=d;}
        }
      }
      return out;
    }

    /* dog(levelDog,index,poses,ambientTime,out): resolve only real matching tile
       bumps (0<=age<.6). index controls fixed mirror/phase. x/y are the original
       dog ART anchor (tile centre+2). glyph is the original source-world Z rig;
       fade is dither progress, not opacity. It remains ambient even ear-up.
       poses may be Civic outputs or unchanged BOARDANIM outputs. No arrival
       epsilon is added to ambientTime. Use makeDogOut once per scene dog. */
    function makeDogOut(){return {x:0,y:0,z:0,frame:0,mirror:false,phase:0,earLift:0,bumpAge:-1,glyph:{visible:false,x:0,y:0,z:0,big:false,fade:0}};}
    function dog(d,index,poses,ambientTime,out){
      finite(ambientTime);const mirror=(index&1)===1,tt=ambientTime+index*1.7;
      out.x=(d.ox||0)+d.x*16+10;out.y=(d.oy||0)+d.y*16+10;out.z=0;out.mirror=mirror;out.phase=index*1.7;out.earLift=0;out.bumpAge=-1;
      for(let k=0;k<poses.length;k++){
        const p=poses[k].effects||poses[k];
        if(p.bumpX===d.x&&p.bumpY===d.y&&p.bumpAge>=0&&p.bumpAge<.6){out.earLift=1;if(out.bumpAge<0||p.bumpAge<out.bumpAge)out.bumpAge=p.bumpAge;}
      }
      const fl=Math.floor(fract(tt/12)*120);
      out.frame=out.earLift?3:fl>=60&&fl<63?2:fract(tt/1.5)<.34?1:0;
      const zt=fract(tt/3),g=out.glyph;g.visible=zt<.8;g.x=0;g.y=0;g.z=0;g.big=false;g.fade=0;
      if(g.visible){const k=zt/.8,big=k>.45,sxo=mirror?9-(big?4:3)-Math.round(k*2):-9+Math.round(k*2);g.x=out.x+sxo*.5;g.y=out.y-sxo*.5;g.z=6+Math.round(k*6);g.big=big;g.fade=k;}
      return out;
    }
    return {makeOut,sample,makeHatchOut,hatch,makeDogOut,dog};
  }
  return {create};
});
