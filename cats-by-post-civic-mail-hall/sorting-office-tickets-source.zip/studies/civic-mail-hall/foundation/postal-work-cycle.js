/* Pure, seekable postal work. Event tracks allocate once at module load;
 * sample() writes only into the state supplied by its caller. Yaw zero faces
 * +y; positive yaw turns toward +x. Hands[0,1] are left/right palm centres. */
(function(root,factory){
 const L=typeof module==='object'&&module.exports?require('./postal-work-layout.js'):root.CivicPostalLayout;
 const C=factory(L);if(typeof module==='object'&&module.exports)module.exports=C;root.CivicPostalCycle=C;
})(globalThis,function(L){
'use strict';
const PI=Math.PI,TAU=PI*2,W=L.worker,K=L.cart,Q=L.parcel;
function ease(u){return u<=0?0:u>=1?1:u*u*u*(u*(u*6-15)+10);}
function progress(t,a,b){return ease((t-a)/(b-a));}
function mix(a,b,u){return a+(b-a)*u;}
const moves=[
 [5,6,.70,.70,-PI/2,0,2],[6,8,.70,1.26,0,0,4],[8,9,1.26,1.26,0,-PI/2,2],
 [20,21,1.26,1.26,-PI/2,0,2],[21,23,1.26,1.65,0,0,4],
 [25.5,26,1.65,1.51,0,0,2],[27,31,1.51,2.46,0,0,8],
 [36,40,2.46,1.51,0,0,8],[41,42,1.51,1.51,0,-PI,4],
 [42,47,1.51,.70,-PI,-PI,8],[47,48,.70,.70,-PI,-PI/2,2]
];
function body(t,r){
 r.x=W.x;r.y=W.receivingY;r.yaw=-PI/2;
 for(let i=0;i<moves.length;i++){
  const m=moves[i];if(t<m[0])break;
  const u=progress(t,m[0],m[1]);r.y=mix(m[2],m[3],u);r.yaw=mix(m[4],m[5],u);if(t<m[1])break;
 }
 r.lean=.04;r.bob=0;r.headYaw=.025*Math.sin(TAU*t/L.period);
}
const initialFeet=[{x:W.x,y:W.receivingY-W.footOffset,yaw:-PI/2},{x:W.x,y:W.receivingY+W.footOffset,yaw:-PI/2}];
const steps=[[],[]],last=initialFeet.map(p=>({...p})),scratch={};
for(const m of moves){
 const duration=(m[1]-m[0])/m[6];
 for(let i=0;i<m[6];i++){
  const foot=i%2,side=foot===0?-1:1,start=m[0]+i*duration,end=start+duration;
  body(i>=m[6]-2?m[1]:Math.min(m[1],end+duration/2),scratch);
  const x=scratch.x+side*W.footOffset*Math.cos(scratch.yaw),y=scratch.y-side*W.footOffset*Math.sin(scratch.yaw);
  steps[foot].push(Object.freeze({start,end,x0:last[foot].x,y0:last[foot].y,yaw0:last[foot].yaw,x1:x,y1:y,yaw1:scratch.yaw}));
  last[foot].x=x;last[foot].y=y;last[foot].yaw=scratch.yaw;
 }
}
Object.freeze(steps[0]);Object.freeze(steps[1]);Object.freeze(steps);
function footAt(t,index,f){
 const first=initialFeet[index],events=steps[index];f.x=first.x;f.y=first.y;f.z=0;f.yaw=first.yaw;f.planted=true;
 for(let i=0;i<events.length;i++){
  const e=events[i];if(t<=e.start)break;
  if(t>=e.end){f.x=e.x1;f.y=e.y1;f.yaw=e.yaw1;continue;}
  const u=(t-e.start)/(e.end-e.start),v=ease(u),lift=Math.sin(PI*u);
  f.x=mix(e.x0,e.x1,v);f.y=mix(e.y0,e.y1,v);f.yaw=mix(e.yaw0,e.yaw1,v);f.z=W.footLift*lift*lift;f.planted=false;break;
 }
}
function cartAt(t,c){
 c.x=K.x;c.y=mix(K.loadY,K.dispatchY,progress(t,27,31))- (K.dispatchY-K.loadY)*progress(t,36,40);c.yaw=0;
 c.wheelAngle=(c.y-K.loadY)*L.floorUnit/K.wheelRadius;
}
function parcelAt(t,r,c,p){
 p.x=L.receiving.x;p.y=L.receiving.y;p.z=L.receiving.z;p.yaw=L.receiving.initialYaw;p.owner=L.owners.receiving;
 if(t<4)return;
 if(t<5){const u=progress(t,4,5);p.x=mix(L.receiving.x,W.x-Q.workReach,u);p.y=mix(L.receiving.y,W.receivingY,u);p.z=mix(58,Q.carryZ,u);p.owner=L.owners.held;return;}
 if(t<9){
  const reach=t<6?mix(Q.workReach,Q.carryReach,progress(t,5,6)):t<8?Q.carryReach:mix(Q.carryReach,Q.workReach,progress(t,8,9));
  p.x=r.x+Math.sin(r.yaw)*reach;p.y=r.y+Math.cos(r.yaw)*reach;p.z=Q.carryZ;p.yaw=r.yaw;p.owner=L.owners.held;return;
 }
 if(t<11){const u=progress(t,9,11);p.x=mix(W.x-Q.workReach,L.scale.x,u);p.y=L.scale.y;p.z=mix(Q.carryZ,L.scale.z,u);p.owner=L.owners.held;return;}
 if(t<19){p.x=L.scale.x;p.y=L.scale.y;p.z=L.scale.z;p.owner=L.owners.scale;return;}
 if(t<20){const u=progress(t,19,20);p.x=mix(L.scale.x,W.x-Q.workReach,u);p.y=L.scale.y;p.z=mix(L.scale.z,Q.carryZ,u);p.owner=L.owners.held;return;}
 if(t<23){const reach=mix(Q.workReach,Q.carryReach,progress(t,20,21));p.x=r.x+Math.sin(r.yaw)*reach;p.y=r.y+Math.cos(r.yaw)*reach;p.z=Q.carryZ;p.yaw=r.yaw;p.owner=L.owners.held;return;}
 p.yaw=0;
 if(t<25){const u=progress(t,23,25);p.x=K.x;p.y=mix(W.loadY+Q.carryReach,K.loadY+K.parcelOffset,u);p.z=mix(Q.carryZ,K.deck,u);p.owner=L.owners.held;return;}
 p.z=K.deck;
 if(t<32){p.x=c.x;p.y=c.y+K.parcelOffset;p.owner=L.owners.cart;return;}
 if(t<35){p.x=mix(K.x,L.returnBelt.x,progress(t,32,35));p.y=L.crossTransfer.dispatchY;p.owner=L.owners.dispatch;return;}
 if(t<47){p.x=L.returnBelt.x;p.y=mix(L.returnBelt.y1,L.returnBelt.y0,progress(t,42,47));p.owner=L.owners.belt;return;}
 if(t<49){p.x=mix(L.returnBelt.x,L.receiving.x,progress(t,47,49));p.y=L.receiving.y;p.owner=L.owners.cross;return;}
 p.x=L.receiving.x;p.y=L.receiving.y;p.yaw=mix(0,L.receiving.initialYaw,progress(t,49,51));p.owner=L.owners.receiving;
}
function machineAt(t,m){
 m.scaleLoad=progress(t,11,12)*(1-progress(t,19,20));
 m.lever=progress(t,15,16)*(1-progress(t,16,16.5));
 m.stampZ=mix(L.scale.stampRestZ,L.scale.stampContactZ,m.lever);
 m.bridge=progress(t,31,32)*(1-progress(t,35,36));
 // After each parcel leaves a roller section, that empty section rewinds.
 // These signed distances have a continuous zero seam, like the cart wheels.
 m.beltTravel=(L.returnBelt.y1-L.returnBelt.y0)*progress(t,42,47)*(1-progress(t,47,51));
 m.sideTravel=(K.x-L.returnBelt.x)*progress(t,32,35)*(1-progress(t,35,40));
 m.crossTravel=(L.receiving.x-L.returnBelt.x)*progress(t,47,49)*(1-progress(t,49,51));
 m.receivingYaw=L.receiving.initialYaw*(1-progress(t,4,5))+L.receiving.initialYaw*progress(t,49,51);
}
function target(h,x,y,z,grip,attachment){h.x=x;h.y=y;h.z=z;h.grip=grip;h.attachment=attachment;}
function blendHand(h,x,y,z,u,arch,forwardY){
 const v=ease(u);
 {
  // Approach and withdraw along the same rounded route: move away from the
  // shoulder low in the aisle, then rise before crossing the worktop edge.
  // A simple vertical arch passed close to the shoulder and flipped its IK.
  const reverse=arch===20?h.x<x:h.y>y,q=reverse?1-v:v,a=(1-q)*(1-q)*(1-q),b=3*(1-q)*(1-q)*q,c=3*(1-q)*q*q,d=q*q*q;
  const rx=reverse?x:h.x,ry=reverse?y:h.y,rz=reverse?z:h.z,tx=reverse?h.x:x,ty=reverse?h.y:y,tz=reverse?h.z:z;
  h.x=arch===20?a*rx+(b+c)*-.86+d*tx:(a+b)*rx+(c+d)*tx;
  h.y=arch===20?(a+b)*ry+(c+d)*ty:a*ry+(b+c)*forwardY+d*ty;
  h.z=(a+b)*rz+c*(tz+16)+d*tz;h.grip=0;h.attachment='none';
 }
}
function handsAt(t,r,c,p,m){
 const co=Math.cos(r.yaw),si=Math.sin(r.yaw),pc=Math.cos(p.yaw),ps=Math.sin(p.yaw);
 for(let i=0;i<2;i++){
  const h=r.hands[i],side=i===0?-1:1;
  const rx=r.x+side*.21*co+.07*si,ry=r.y-side*.21*si+.07*co,rz=40+r.bob;
  const px=p.x+side*Q.width*.5*pc,py=p.y-side*Q.width*.5*ps,pz=p.z+Q.gripZ;
  target(h,rx,ry,rz,0,'none');
  if(t>=2&&t<3.5){blendHand(h,px,py,pz,(t-2)/1.5,20);continue;}
  if(t>=3.5&&t<=11.4){target(h,px,py,pz,t<4?progress(t,3.5,4):t>11?1-progress(t,11,11.4):1,'parcel');continue;}
  if(t>11.4&&t<12){target(h,px,py,pz,0,'none');blendHand(h,rx,ry,rz,(t-11.4)/.6,20);continue;}
  if(i===1&&t>=14&&t<17){
   const control=L.scale.control,cx=control.x,cy=control.y,cz=control.z-control.travel*m.lever;
   if(t<14.7)blendHand(h,cx,cy,cz,(t-14)/.7,20);
   else if(t<=16.5)target(h,cx,cy,cz,t<15?progress(t,14.7,15):1-progress(t,16.3,16.5),'control');
   else{target(h,cx,cy,cz,0,'none');blendHand(h,rx,ry,rz,(t-16.5)/.5,20);}
   continue;
  }
  if(t>=17&&t<18.5){blendHand(h,px,py,pz,(t-17)/1.5,20);continue;}
  if(t>=18.5&&t<=25.3){target(h,px,py,pz,t<19?progress(t,18.5,19):t>25?1-progress(t,25,25.3):1,'parcel');continue;}
  if(t>25.3&&t<26){target(h,px,py,pz,0,'none');blendHand(h,rx,ry,rz,(t-25.3)/.7,8,r.y+.33);continue;}
  const hx=c.x+side*K.handleHalfWidth,hy=c.y+K.handleOffset,hz=K.handleZ;
  if(t>=26&&t<26.7){blendHand(h,hx,hy,hz,(t-26)/.7,4,r.y+.33);continue;}
  if(t>=26.7&&t<=40.3){target(h,hx,hy,hz,t<27?progress(t,26.7,27):t>40?1-progress(t,40,40.3):1,'handle');continue;}
  if(t>40.3&&t<41){target(h,hx,hy,hz,0,'none');blendHand(h,rx,ry,rz,(t-40.3)/.7,4,r.y+.33);}
 }
}
function createState(){
 const feet=[{x:0,y:0,z:0,yaw:0,planted:true},{x:0,y:0,z:0,yaw:0,planted:true}];
 const hands=[{x:0,y:0,z:0,grip:0,attachment:'none'},{x:0,y:0,z:0,grip:0,attachment:'none'}];
 const state={time:0,phase:'receive',robot:{x:0,y:0,yaw:0,lean:0,bob:0,headYaw:0,feet,hands,palms:hands},
  cart:{x:0,y:0,yaw:0,wheelAngle:0},parcel:{id:Q.id,x:0,y:0,z:0,yaw:0,owner:L.owners.receiving},
  machine:{scaleLoad:0,stampZ:0,lever:0,bridge:0,beltTravel:0,sideTravel:0,crossTravel:0,receivingYaw:0}};
 return sample(0,state);
}
function sample(time,out){
 const t=Number.isFinite(time)?((time%L.period)+L.period)%L.period:0;out.time=t;
 let phase=L.phases[0];for(let i=1;i<L.phases.length&&t>=L.phases[i].start;i++)phase=L.phases[i];out.phase=phase.name;
 const r=out.robot;body(t,r);footAt(t,0,r.feet[0]);footAt(t,1,r.feet[1]);
 r.bob=(r.feet[0].z+r.feet[1].z)*.06;
 cartAt(t,out.cart);parcelAt(t,r,out.cart,out.parcel);machineAt(t,out.machine);handsAt(t,r,out.cart,out.parcel,out.machine);
 return out;
}
return Object.freeze({createState,sample,footEvents:steps});
});
