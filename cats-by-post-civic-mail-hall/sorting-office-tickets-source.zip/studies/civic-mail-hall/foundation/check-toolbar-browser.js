'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'../../..'),out=path.join(root,'work/civic-finish/toolbar-final');fs.mkdirSync(out,{recursive:true});
const url=process.argv[2]||'http://127.0.0.1:8765/studies/civic-mail-hall/foundation/index.html';
const devices=[{name:'small-phone',w:320,h:568,dpr:2},{name:'phone',w:393,h:852,dpr:2},{name:'small-landscape',w:568,h:320,dpr:2},{name:'landscape',w:844,h:390,dpr:2}];
async function audit(config){
 const check=(v,m)=>{if(!v)throw Error(config.name+': '+m);};
 for(let i=0;i<200&&!window.__foundation?.ready;i++)await new Promise(r=>setTimeout(r,30));
 check(window.__foundation?.ready,'artwork not ready');
 const F=window.__foundation,R=F.renderer,S=F.session,byId=id=>document.getElementById(id);
 F.pause(true);F.motion(false);S.load(14);R.config.w=S.level.board.w;R.config.h=S.level.board.h;R.ambient=6.4;
 F.view('play');F.refresh();R.draw(S);
 const compact=()=>{
  const toolbar=document.querySelector('.scene-controls').getBoundingClientRect(),canvas=R.canvas.getBoundingClientRect();
  check(toolbar.bottom<=canvas.top+.01,'toolbar overlays scene');
  check(canvas.height>100,'scene collapsed');
  check(Math.abs(R.config.height-canvas.height)<.01,'renderer height differs from canvas');
  check(Math.abs(R.config.width-canvas.width)<.01,'renderer width differs from canvas');
  for(const el of document.querySelectorAll('.scene-controls button,.scene-controls label')){
   const r=el.getBoundingClientRect();check(r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight,'toolbar control clipped');
   const hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);check(hit===el||el.contains(hit),'toolbar control covered');
  }
  return{toolbar:[toolbar.left,toolbar.top,toolbar.width,toolbar.height],canvas:[canvas.left,canvas.top,canvas.width,canvas.height]};
 };
 const first=compact();
 F.view('structure');R.draw(S);check(getComputedStyle(document.querySelector('.scene-controls')).position==='absolute','Explore toolbar is no longer overlay');
 check(getComputedStyle(document.querySelector('aside')).display==='none','Explore sidebar visible');
 F.view('reference');check(getComputedStyle(R.canvas).display==='none','Reference displays scene');check(getComputedStyle(document.querySelector('.scene-controls')).display==='none','Reference displays toolbar');
 F.view('play');R.draw(S);const returned=compact();check(JSON.stringify(first)===JSON.stringify(returned),'return to Board changes geometry');
 return{name:config.name,first,returned,toolbarOutsideCanvas:true,exploreAndReferencePreserved:true};
}
const jobs=devices.map(d=>({url,device:(d.w*d.dpr)+'x'+(d.h*d.dpr)+'@'+d.dpr,wait:700,settle:30,js:'('+audit.toString()+')('+JSON.stringify(d)+')',out:path.join(out,d.name+'.png')}));
const jobsPath=path.join(out,'jobs.json');fs.writeFileSync(jobsPath,JSON.stringify(jobs,null,2));
const run=spawnSync(process.execPath,['tools/snap.js','--batch',jobsPath],{cwd:root,encoding:'utf8',timeout:120000,maxBuffer:4e6});
const log=(run.stdout||'')+(run.stderr||'');fs.writeFileSync(path.join(out,'browser.log'),log);process.stdout.write(log);
assert.equal(run.status,0,run.error?.message);assert.ok(!/setup error|page exception|page console\.(error|warning|assert)/.test(log));
const results=log.split('\n').filter(l=>l.startsWith('js -> ')).map(l=>JSON.parse(l.slice(6)));assert.equal(results.length,4);
fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({url,results},null,2));console.log('Compact toolbar: four viewport and view-transition cases pass.');
