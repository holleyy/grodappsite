'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process');
const H=`for(let i=0;i<200&&!window.__foundation?.ready;i++)await new Promise(r=>setTimeout(r,30));const check=(v,m)=>{if(!v)throw Error(m);};check(window.__foundation?.ready,'assets ready');const F=__foundation,R=F.renderer,S=F.session;F.pause(true);F.motion(true);
const capture=(draw,x,y,w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;const old=R.ctx;R.ctx=c.getContext('2d');R.ctx.translate(-x,-y);try{draw();}finally{R.ctx=old;}return c;};
const pixels=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const changed=(a,b)=>{let n=0;for(let i=0;i<a.length;i+=4)if(Math.abs(a[i]-b[i])+Math.abs(a[i+1]-b[i+1])+Math.abs(a[i+2]-b[i+2])+Math.abs(a[i+3]-b[i+3])>8)n++;return n;};`;
const jobs=[],url='http://127.0.0.1:8765/studies/civic-mail-hall/foundation/index.html?view=hall';
jobs.push({url,device:'1600x1200@1',wait:800,js:`(async()=>{${H}
 const actors=CivicRoomLife.layout();check(actors.length===32,'all room cats');
 const a=pixels(capture(()=>R.roomLife.draw(0,0),780,290,540,390)),b=pixels(capture(()=>R.roomLife.draw(0,1.3),780,290,540,390));
 const catPixels=changed(a,b);check(catPixels>100,'cubby motion is not visible');
 for(const actor of actors){const s=CivicRoomLife.sample(actor,1.3,CivicRoomLife.makeState());check(s.z===actor.z,'soles moved');}
 check(actors.find(a=>a.id==='gallery').z===182,'gallery contact');
 const x=1160,y=350,w=170,h=170;R.ambient=1.3;
 const cat=pixels(capture(()=>R.roomLife.draw(1,R.ambient),x,y,w,h));
 const front=pixels(capture(()=>R.architecture.drawLayer(R.architecture.layers[2]),x,y,w,h));
 const scene=pixels(capture(()=>R.architecture.draw(),x,y,w,h));
 let overlap=0,visible=0;for(let i=0;i<cat.length;i+=4)if(cat[i+3]>180){if(front[i+3]===255){overlap++;check(Math.abs(scene[i]-front[i])+Math.abs(scene[i+1]-front[i+1])+Math.abs(scene[i+2]-front[i+2])<=3,'cat paints over foreground railing');}else visible++;}
 check(overlap>30,'no real railing occlusion');check(visible>100,'gallery cat hidden entirely');

 R.draw(S);return{case:'grounded moving cats and occlusion',catPixels,railPixels:overlap,visibleCatPixels:visible};})()`,out:'work/civic-life/hall.png'});
jobs.push({url,device:'786x1300@2',wait:800,js:`(async()=>{${H}
 R.ambient=6.4;F.motion(false);F.view('play');S.load(3);F.refresh();R.draw(S);const time=R.ambient;
 const before=R.canvas.toDataURL();F.pause(false);await new Promise(r=>setTimeout(r,450));F.pause(true);R.draw(S);check(R.ambient===time,'off clock changed');check(R.canvas.toDataURL()===before,'frozen scenery pixels changed');
 document.getElementById('preview').click();F.pause(false);await new Promise(r=>setTimeout(r,650));F.pause(true);check(S.elapsed>.3,'motion off stopped the delivery');check(R.ambient===time,'delivery advanced scenery');
 reduced.dispatchEvent(new MediaQueryListEvent('change',{matches:false}));check(R.motion,'preference clearing did not enable motion');
 F.pause(false);await new Promise(r=>setTimeout(r,250));F.pause(true);check(R.ambient>time,'enabled ambient clock stopped');
 reduced.dispatchEvent(new MediaQueryListEvent('change',{matches:true}));check(!R.motion,'reduced motion did not freeze scenery');const reducedTime=R.ambient;F.pause(false);await new Promise(r=>setTimeout(r,250));F.pause(true);check(R.ambient===reducedTime,'reduced motion clock changed');
 S.load(3);F.refresh();F.view('structure');F.view('reference');F.view('play');check(!R.motion,'view switching reset motion choice');R.draw(S);return{case:'motion off and reduced motion',deliveryContinued:true,viewPreference:true};})()`,out:'work/civic-life/phone.png'});
jobs.push({url,device:'1440x1000@1',wait:800,js:`(async()=>{${H}
 const states=R.roomLife.states.slice(),boat=R.canal.pose,postal=R.postal.state,mesh=R.postal.rig.mesh;
 const create=document.createElement,linear=R.ctx.createLinearGradient,radial=R.ctx.createRadialGradient,project=CivicProjection.project;
 try{document.createElement=()=>{throw Error('new canvas in frame');};R.ctx.createLinearGradient=R.ctx.createRadialGradient=()=>{throw Error('new gradient in frame');};CivicProjection.project=()=>{throw Error('new projected point in life frame');};for(let i=0;i<90;i++){R.roomLife.draw(0,i/9);R.roomLife.draw(1,i/9);R.canal.draw(i*2);R.postal.drawUnderCats(i/6);R.postal.draw(i/6);}}finally{document.createElement=create;R.ctx.createLinearGradient=linear;R.ctx.createRadialGradient=radial;CivicProjection.project=project;}
 check(R.canal.pose===boat&&R.postal.state===postal&&R.postal.rig.mesh===mesh,'life replaced reusable objects');for(let i=0;i<states.length;i++)check(states[i]===R.roomLife.states[i],'cat state replaced');
 // The occluder patches intentionally end inside scenery. Their seams must
 // reconstruct the unsplit static hall, and every live pose must fit its patch.
 const arch=R.architecture,full=document.createElement('canvas');full.width=1600;full.height=1100;
 const fc=full.getContext('2d');fc.translate(0,150);const p=new CivicArchitecture.Painter(fc,R.images,R.assets),ex=new CivicExterior(p);
 ex.draw(false);for(const method of ['foundation','walls','stair','cabinet','cabinetLips','galleryLower','counter','galleryUpper','details'])arch[method](p);
 const layered=capture(()=>{for(const l of arch.layers)arch.drawLayer(l);},0,-150,1600,1100);
 const direct=pixels(full),split=pixels(layered);let seamPixels=0,seamError=0;
 // Sample just outside/inside patch boundaries, excluding anti-aliased edges
 // with low alpha. Independent 1x and cached 2x draws allow small AA variance.
 for(const l of arch.layers.slice(1)){const b=l.bounds;for(let yy=b.top-2;yy<=b.bottom+2;yy++)for(let xx=b.left-2;xx<=b.right+2;xx++){
  if(xx>b.left+2&&xx<b.right-2&&yy>b.top+2&&yy<b.bottom-2)continue;
  const i=((yy+150)*1600+xx)*4;if(direct[i+3]<250||split[i+3]<250)continue;seamPixels++;
  const err=Math.abs(direct[i]-split[i])+Math.abs(direct[i+1]-split[i+1])+Math.abs(direct[i+2]-split[i+2]);if(err>70)seamError++;
 }}check(seamPixels>3000&&seamError/seamPixels<.06,'occluder patch introduced a visible seam');
 for(const actor of CivicRoomLife.layout()){if(actor.id==='desk')continue;const b=arch.layers[actor.group===0?1:2].bounds,pt=CivicProjection.project(actor.x,actor.y,actor.z);
  for(const [name,width] of [[actor.pose,actor.width],[actor.alternate,actor.alternateWidth]]){const rect=R.assets.acting.sprites[name].rect;check(pt.x-width/2>b.left&&pt.x+width/2<b.right&&pt.y-width*rect[3]/rect[2]*1.022>b.top&&pt.y+5<b.bottom,'live pose outside occluder patch');}
 }
 let bytes=0;for(const layer of arch.layers)bytes+=layer.canvas.width*layer.canvas.height*4;
 check(bytes<64*1024*1024,'static cache memory exceeded 64MiB');check(R.architecture.bakes===1&&R.postal.bakes===1,'extra bakes');
 F.view('play');S.load(3);F.refresh();const times=[];for(let i=0;i<40;i++){R.ambient=i/30;const start=performance.now();R.draw(S);R.ctx.getImageData(0,0,1,1);times.push(performance.now()-start);}times.sort((a,b)=>a-b);
 R.gray=true;R.ambient=6.4;R.draw(S);return{case:'reuse and browser draw cost',staticMiB:bytes/1048576,medianMs:times[20],p95Ms:times[38],bakes:R.architecture.bakes};})()`,out:'work/civic-life/grayscale.png'});
const sheet=`(()=>{const times=[0,1.3,26.9,29.6],postalTimes=[3,15.5,29,34],sheet=document.createElement('canvas');sheet.width=960;sheet.height=690;const c=sheet.getContext('2d');c.fillStyle='#f5f0e3';c.fillRect(0,0,960,690);c.font='14px sans-serif';for(let i=0;i<4;i++){const t=times[i];R.ambient=t;const a=capture(()=>R.architecture.draw(),1150,345,190,170);c.drawImage(a,i*240,24,240,215);const b=capture(()=>R.architecture.draw(),800,340,235,175);c.drawImage(b,i*240,250,240,179);const d=capture(()=>{R.ambient=postalTimes[i];R.architecture.draw();R.postal.draw(postalTimes[i]);},410,300,360,300);c.drawImage(d,i*240,454,224,200);c.fillStyle='#365b5b';c.fillText(t.toFixed(1)+' seconds',i*240+12,18);c.fillText('Clerk: '+postalTimes[i].toFixed(1)+' seconds',i*240+12,677);}return sheet.toDataURL('image/png');})()`;
jobs.push({url,device:'1600x1200@1',wait:800,js:`(async()=>{${H}window.__lifeSheet=()=>${sheet};return 'gallery, cubby and clerk sequence';})()`,png:'__lifeSheet()',out:'work/civic-life/motion-sequence.png'});
jobs.push({url,device:'1600x1200@1',wait:800,js:`(async()=>{${H}R.ambient=36;R.draw(S);const a=pixels(capture(()=>R.canal.draw(0),100,330,300,300)),b=pixels(capture(()=>R.canal.draw(36),100,330,300,300));const n=changed(a,b);check(n>150,'boat/water did not visibly move');return{case:'canal passage',changedPixels:n};})()`,out:'work/civic-life/canal-passage.png'});
fs.mkdirSync('work/civic-life',{recursive:true});fs.writeFileSync('work/civic-life/browser-jobs.json',JSON.stringify(jobs));
const r=spawnSync(process.execPath,['tools/snap.js','--batch','work/civic-life/browser-jobs.json'],{encoding:'utf8',maxBuffer:3e6,timeout:240000});
const log=(r.stdout||'')+(r.stderr||'');fs.writeFileSync('work/civic-life/browser.log',log);console.log(log);assert.equal(r.status,0);assert.ok(!/setup error|page exception|page console\.(error|warning|assert)|png expression failed/.test(log));console.log(jobs.length,'life browser cases passed');
