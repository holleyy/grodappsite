'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
let C,L;try{C=require('./postal-work-cycle.js');L=require('./postal-work-layout.js');}catch{}
const ready=()=>assert.equal(typeof C?.sample,'function','the connected postal cycle is missing');
const near=(a,b,e=1e-8)=>assert.ok(Math.abs(a-b)<e,`${a} != ${b}`);
function numbers(o,result=[],prefix=''){
 for(const k of Object.keys(o)){const v=o[k],key=prefix+k;if(typeof v==='number')result.push([key,v]);else if(v&&typeof v==='object'&&k!=='palms')numbers(v,result,key+'.');}return result;
}
function point(o,x,y,z){near(o.x,x);near(o.y,y);near(o.z,z);}

test('the parcel completes every receiving, processing, delivery and return beat',()=>{
 ready();const s=C.createState();
 const checkpoints=[
  [0,'receive','receiving',-1.18,.68,58],[4,'lift-received','held',-1.18,.68,58],
  [11,'release-scale','scale',-1.18,1.26,64],[19,'lift-processed','held',-1.18,1.26,64],
  [25,'release-cart','cart',-.53,2.17,58],[31,'deploy-bridge','cart',-.53,3.12,58],
  [35,'retract-bridge','return-belt',-1.55,3.12,58],[47,'cross-receive','cross-transfer',-1.55,.68,58],
  [49,'rotate-receiving','receiving',-1.18,.68,58],[51,'settle','receiving',-1.18,.68,58]
 ];
 for(const[t,phase,owner,x,y,z]of checkpoints){C.sample(t,s);assert.equal(s.phase,phase);assert.equal(s.parcel.owner,owner);point(s.parcel,x,y,z);}
});

test('seek sampling is deterministic and preserves all nested state identities',()=>{
 ready();const a=C.createState(),b=C.createState(),refs=[a.robot,a.robot.feet,a.robot.feet[0],a.robot.feet[1],a.robot.hands,a.robot.hands[0],a.robot.hands[1],a.cart,a.parcel,a.machine];
 for(const o of refs)Object.seal(o);Object.seal(a);
 for(const t of[0,1.3,4.9,22,34.5,48,51.9,-.5,1000,NaN,Infinity]){
  assert.equal(C.sample(t,a),a);C.sample(t,b);assert.deepEqual(a,b);
  assert.deepEqual([a.robot,a.robot.feet,a.robot.feet[0],a.robot.feet[1],a.robot.hands,a.robot.hands[0],a.robot.hands[1],a.cart,a.parcel,a.machine].map((v,i)=>v===refs[i]),refs.map(()=>true));
 }
});

test('all continuous targets meet at phase boundaries and the physical repeat seam',()=>{
 ready();const a=C.createState(),b=C.createState();
 for(const t of[0,...L.phases.map(p=>p.end)]){
  C.sample(t-1e-7,a);C.sample(t+1e-7,b);
  const aa=numbers(a).filter(([k])=>k!=='time'),bb=numbers(b).filter(([k])=>k!=='time');
  for(let i=0;i<aa.length;i++)near(aa[i][1],bb[i][1],1e-4);
 }
 for(let i=0;i<104;i++){const t=i*.5;C.sample(t,a);C.sample(t+52,b);assert.deepEqual(a,b);}
});

test('a planted sole never slides and every swing has another supporting sole',()=>{
 ready();const a=C.createState(),b=C.createState();let swings=0,turns=0;
 C.sample(0,a);
 for(let i=1;i<=12480;i++){
  C.sample(i/240,b);assert.ok(b.robot.feet.some(f=>f.planted),'worker is airborne');
  for(let f=0;f<2;f++){
   const p=a.robot.feet[f],q=b.robot.feet[f];
   if(p.planted&&q.planted){point(q,p.x,p.y,0);near(q.yaw,p.yaw);}
   if(!q.planted){assert.ok(q.z>0);swings++;if(Math.abs(b.robot.yaw-a.robot.yaw)>1e-6)turns++;}
   assert.ok(q.x>=-.85&&q.x<=-.21&&q.y>.35&&q.y<2.80);
  }
  C.sample(i/240,a);
 }
 assert.ok(swings>1000);assert.ok(turns>100,'turns must place feet successively');
});

test('attached palms remain on parcel sides, handle and stamp control within arm reach',()=>{
 ready();const s=C.createState();let parcel=0,handle=0,control=0;
 for(let i=0;i<=6240;i++){
  C.sample(i/120,s);const r=s.robot,p=s.parcel,co=Math.cos(r.yaw),si=Math.sin(r.yaw);
  for(let j=0;j<2;j++){
   const h=r.hands[j],side=j===0?-1:1;
   if(h.attachment==='parcel'){point(h,p.x+side*.13*Math.cos(p.yaw),p.y-side*.13*Math.sin(p.yaw),p.z+7);parcel++;}
   if(h.attachment==='handle'){point(h,s.cart.x+side*.18,s.cart.y-.41,68);handle++;}
   if(h.attachment==='control'){point(h,-.95,1.40,69-4*s.machine.lever);control++;}
   const sx=r.x+si*r.lean+side*.18*co,sy=r.y+co*r.lean-side*.18*si,sz=56+r.bob;
   assert.ok(Math.hypot((h.x-sx)*L.floorUnit,(h.y-sy)*L.floorUnit,h.z-sz)<=44+1e-7,'palm is beyond rigid arms at '+s.time);
   if(h.x<-.95&&h.y>=.35&&h.y<=3.6)assert.ok(h.z>=58,'palm crosses the bench body');
  }
 }
 assert.ok(parcel>100&&handle>100&&control>20);
});

test('the same parcel is always held or fully supported, including bridge crossings and rotation',()=>{
 ready();const s=C.createState();let bridgeFrames=0;
 for(let i=0;i<=10400;i++){
  C.sample(i/200,s);const p=s.parcel;
  assert.equal(p.id,'office-parcel');assert.ok(p.z>=58&&p.x+.184<-.14);
  if(p.owner==='held'){assert.ok(s.robot.hands.every(h=>h.attachment==='parcel'&&h.grip===1));continue;}
  if(p.owner==='scale'){point(p,-1.18,1.26,64);continue;}
  near(p.z,58);
  if(p.owner==='cart'){near(p.x,s.cart.x);near(p.y,s.cart.y-.13);}
  else if(p.owner==='dispatch-transfer'){
   near(s.cart.y,3.25);near(s.machine.bridge,1);near(p.y,3.12);assert.ok(p.x>=-1.55&&p.x<=-.53);bridgeFrames++;
  }else if(p.owner==='return-belt'){near(p.x,-1.55);assert.ok(p.y>=.68&&p.y<=3.12);}
  else if(p.owner==='cross-transfer'){near(p.y,.68);assert.ok(p.x>=-1.55&&p.x<=-1.18);}
  else {assert.equal(p.owner,'receiving');point(p,-1.18,.68,58);assert.ok(Math.SQRT2*.13<.21);}
 }
 assert.ok(bridgeFrames>500);
});

test('wheel rotation follows signed travel and bridge retraction precedes reverse motion',()=>{
 ready();const s=C.createState();
 C.sample(27,s);near(s.cart.y,2.30);near(s.cart.wheelAngle,0);
 C.sample(31,s);near(s.cart.y,3.25);near(s.cart.wheelAngle,.95*(380/6)/5.5);
 let previous=s.cart.wheelAngle;
 for(let i=1;i<=100;i++){C.sample(36+i*.04,s);assert.ok(s.cart.wheelAngle<=previous);near(s.machine.bridge,0);previous=s.cart.wheelAngle;}
 near(s.cart.wheelAngle,0);near(s.cart.y,2.30);
});

test('grip opening and closing also remains continuous inside the named beats',()=>{
 ready();const a=C.createState(),b=C.createState();
 for(const t of[3.5,11.4,14.7,16.3,16.5,18.5,25.3,25.5,26.7,40.3,48]){
  C.sample(t-1e-7,a);C.sample(t+1e-7,b);
  for(let i=0;i<2;i++)for(const key of['x','y','z','grip'])near(a.robot.hands[i][key],b.robot.hands[i][key],1e-4);
 }
});

test('unattached bench reaches withdraw clear of the shoulder before lifting',()=>{
 ready();const s=C.createState(),U=L.floorUnit;
 for(let i=0;i<=52000;i++){
  C.sample(i/1000,s);const r=s.robot,si=Math.sin(r.yaw),co=Math.cos(r.yaw);
  for(let k=0;k<2;k++){
   const side=k?1:-1,h=r.hands[k],sx=r.x+si*r.lean+side*.18*co,sy=r.y+co*r.lean-side*.18*si;
   assert.ok(Math.hypot((h.x-sx)*U,(h.y-sy)*U,h.z-56-r.bob)>=14.5,'palm approaches shoulder singularity at '+s.time);
  }
 }
});
