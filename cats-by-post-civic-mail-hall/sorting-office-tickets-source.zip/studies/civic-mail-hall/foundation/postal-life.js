/* One connected postal job. Static receiving surfaces and the live rig consume
 * the same layout; all motion is sampled from the renderer's ambient clock. */
(function(root,factory){
 const node=typeof module==='object'&&module.exports;
 const Postal=factory(node?require('./postal-work-layout.js'):root.CivicPostalLayout,node?require('./postal-work-cycle.js'):root.CivicPostalCycle,node?require('./postal-work-rig.js'):root.CivicPostalRig);
 if(node)module.exports=Postal;root.CivicPostal=Postal;
})(globalThis,function(L,Cycle,Rig){
'use strict';
class Postal{
 static layout(){return L;}
 static createState(){return Cycle.createState();}
 static sample(t,out){return Cycle.sample(t,out);}
 constructor(renderer){this.r=renderer;this.state=Cycle.createState();this.rig=new Rig(renderer);this.bakes=0;}
 bake(){this.rig.bake();this.bakes++;}
 drawUnderCats(t){
  const s=Cycle.sample(t,this.state),m=this.rig.mesh,c=this.r.ctx;
  m.reset();
  // Visible rotating intake disk (a low octagonal paper turntable).
  m.disk(L.receiving.x,L.receiving.y,57.5,L.receiving.radius,.5,s.machine.receivingYaw,'teal');
  // A needle is carried by the scale face, not a floating dial graphic.
  const angle=-.65+s.machine.scaleLoad*1.3,x=-.988,y=1.26,z=58.5;
  m.strut(x,y,z,x,y+Math.sin(angle)*.07,z+Math.cos(angle)*4,1,'ink');
  // Press platen and lever use their actual contact heights.
  m.box(-1.18,1.26,s.machine.stampZ,.20,.20,3,0,'brass');
  m.strut(L.scale.x,L.scale.y,s.machine.stampZ+3,L.scale.x,L.scale.y,109,3,'brass');
  const control=L.scale.control;m.box(control.x,control.y,control.z-s.machine.lever*control.travel-3,.09,.09,3,0,'teal');
  // Bridge rotates about the bench edge; its free end lands exactly on cart.
  const a=(1-s.machine.bridge)*Math.PI/2,xx=-.95+.17*Math.cos(a),zz=58+.17*L.floorUnit*Math.sin(a);
  m.vertex(0,-.95,2.97,58);m.vertex(1,xx,2.97,zz);m.vertex(2,xx,3.27,zz);m.vertex(3,-.95,3.27,58);m.face(0,1,2,3,'#e4c58e');
  m.strut(-.95,2.97,58,xx,2.97,zz,1.8,'brass');m.strut(-.95,3.27,58,xx,3.27,zz,1.8,'brass');
  // Witness strips move with each driven belt section beneath the parcel.
  for(let i=0;i<13;i++){const yy=.55+((i*.21-s.machine.beltTravel)%2.73+2.73)%2.73;m.strut(-1.69,yy,58.08,-1.41,yy,58.08,.8,'paper');}
  for(let i=0;i<4;i++){
   const dispatchX=-1.70+((i*.18-s.machine.sideTravel)%.72+.72)%.72;
   const intakeX=-1.70+((i*.18+s.machine.crossTravel)%.72+.72)%.72;
   m.strut(dispatchX,2.98,58.08,dispatchX,3.26,58.08,.8,'paper');
   m.strut(intakeX,.54,58.08,intakeX,.82,58.08,.8,'paper');
  }
  if(s.parcel.owner!==L.owners.held&&s.parcel.owner!==L.owners.cart)this.rig.parcel(s);
  m.draw(c,this.rig.pattern);
 }
 draw(t){Cycle.sample(t,this.state);this.rig.draw(this.state);}
}
Postal.drawStations=function(p){
 const brass={top:'#e7ca8a',left:'#b88f49',right:'#9f773e'},teal={top:'#60867a',left:'#3c665e',right:'#2c514d'};
 p.box(-1.71,.52,.32,2.76,55,3,'teal',teal);
 p.box(-1.71,.52,.76,.32,55,3,'teal',teal);p.box(-1.71,2.96,.76,.32,55,3,'teal',teal);
 for(let i=0;i<13;i++)p.line3([-1.69,.64+i*.22,57.9],[-1.41,.64+i*.22,57.9],'#dfc38b',2.6);
 p.box(-1.36,1.06,.36,.40,58,4,'teal',teal);p.box(-1.37,1.05,.38,.42,62,2,'oak',brass);
 p.box(-1.375,1.18,.045,.16,64,43,'teal',teal);p.box(-1.375,1.18,.29,.16,104,3,'teal',teal);
 p.box(-1.1,1.32,.20,.16,56,2,'teal',teal);p.box(-.99,1.36,.08,.08,58,7,'oak',brass);
 // Small recessed gauge on the near vertical casing.
 p.face('y',1.39,-.989,61,c=>{c.fillStyle='#f3e6be';c.fillRect(0,0,15,6);c.fillStyle='#749080';for(let i=0;i<5;i++)c.fillRect(2+i*2.5,1,1,2);});
};
return Postal;
});
