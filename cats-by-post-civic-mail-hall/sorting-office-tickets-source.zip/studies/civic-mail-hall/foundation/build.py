from pathlib import Path
import re,json,base64,hashlib
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
rules=(HERE/'vendor/sim/10_rules.js').read_text()
exports=re.search(r'module\.exports\s*=\s*(\{[\s\S]*?\});',rules).group(1)
levels=[l for l in json.loads((HERE/'vendor/data/levels.json').read_text())['levels'] if not l.get('room') or l['room']=='office']
assert len(levels)==15
assets=json.loads((HERE/'assets/rects.json').read_text())
for name in ['cats','pieces']:
 assets[name]['src']='data:image/webp;base64,'+base64.b64encode((HERE/'assets'/f'{name}.webp').read_bytes()).decode()
assets={k:assets[k] for k in ['cats','pieces']}
assets['acting']=json.loads((HERE/'assets/acting.json').read_text())
assets['acting']['src']='data:image/webp;base64,'+base64.b64encode((HERE/'assets/acting.webp').read_bytes()).decode()
for name in ['materials','decor','fronts']:
 assets[name]=json.loads((HERE/'assets/architecture'/f'{name}.json').read_text())
 assets[name]['src']='data:image/webp;base64,'+base64.b64encode((HERE/'assets/architecture'/f'{name}.webp').read_bytes()).decode()
assets['houseFront']={'src':'data:image/webp;base64,'+base64.b64encode((HERE/'assets/house-front.webp').read_bytes()).decode()}
assets['backdrop']={'src':'data:image/webp;base64,'+base64.b64encode((HERE/'assets/backdrop.webp').read_bytes()).decode()}
reference='data:image/webp;base64,'+base64.b64encode((HERE.parent/'assets/scenery.webp').read_bytes()).decode()
code='\n'.join([rules,'const OfficeRules = '+exports+';', (HERE/'vendor/sim/12_boardanim.js').read_text(), 'const OfficeLevels='+json.dumps(levels)+';', 'const FoundationAssets='+json.dumps(assets)+';', 'const FoundationReference='+json.dumps(reference)+';',*[ (HERE/f).read_text() for f in ['projection.js','postal-work-layout.js','session.js','acting.js','backdrop.js','exterior.js','room-life.js','canal-life.js','postal-work-cycle.js','postal-work-rig.js','postal-life.js','office-details.js','architecture.js','pieces.js','ticket-rack.js','scenery-cache.js','renderer.js','app.js']]])
shell=(HERE/'shell.html').read_text().replace('__STYLE__',(HERE/'style.css').read_text()).replace('__CODE__',code)
(HERE/'index.html').write_text(shell)
print('Foundation HTML',len(shell.encode()),'bytes SHA256',hashlib.sha256(shell.encode()).hexdigest())
