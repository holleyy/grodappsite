'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),Cache=require('./scenery-cache.js');
function rig(){
 const created=[],calls=[];
 global.document={createElement(){const canvas={width:1,height:1},ctx={setTransform(...args){calls.push(['bake-transform',...args]);},drawImage(...args){calls.push(['bake',...args]);}};canvas.getContext=()=>ctx;created.push(canvas);return canvas;}};
 const r={cam:{scale:1.25,tx:-12.75,ty:8.25},dpr:2,ctx:{canvas:{width:800,height:600},save(){},restore(){},setTransform(...args){calls.push(['draw-transform',...args]);},drawImage(...args){calls.push(['draw',...args]);}}};
 return{r,cache:new Cache(r),created,calls};
}
test('prepared scenery reuses visible pixels at exact device coordinates without steady-frame allocations',()=>{
 const {r,cache,created,calls}=rig(),source={};cache.draw(source,-100,-50,500,300);assert.equal(cache.bakes,1);assert.equal(created.length,1);assert.equal(cache.bytes,800*600*4);
 const entry=cache.entries.get(source);assert.equal(entry.canvas.getContext('2d').imageSmoothingQuality,'high');
 global.document.createElement=()=>{throw Error('allocation on steady frame');};for(let i=0;i<120;i++)cache.draw(source,-100,-50,500,300);
 assert.equal(cache.bakes,1);assert.equal(cache.entries.get(source),entry);
 assert.deepEqual(calls.filter(c=>c[0]==='draw-transform').at(-1),['draw-transform',1,0,0,1,0,0]);
 assert.deepEqual(calls.filter(c=>c[0]==='draw').at(-1),['draw',entry.canvas,0,0]);
 assert.equal(calls.filter(c=>c[0]==='bake').length,1);
});
test('view changes rebuild each existing surface once and retain its canvas',()=>{
 const {r,cache}=rig(),source={};cache.draw(source,20,30,100,80);const entry=cache.entries.get(source),canvas=entry.canvas;
 for(const change of[()=>r.cam.tx+=.5,()=>r.cam.scale=1.6,()=>r.dpr=1,()=>r.ctx.canvas.width=400]){const n=cache.bakes;change();cache.draw(source,20,30,100,80);cache.draw(source,20,30,100,80);assert.equal(cache.bakes,n+1);assert.equal(entry.canvas,canvas);assert.equal(cache.bytes,canvas.width*canvas.height*4);}
 const s=r.cam.scale*r.dpr,tx=r.cam.tx*r.dpr,ty=r.cam.ty*r.dpr;assert.equal(entry.left,Math.floor(20*s+tx));assert.equal(entry.top,Math.floor(30*s+ty));
});
test('offscreen surfaces use a one-pixel sentinel and become visible after panning',()=>{
 const {r,cache,calls}=rig(),source={};cache.draw(source,2000,2000,10,10);assert.equal(cache.bytes,4);assert.equal(calls.length,0);
 r.cam.tx=-2500;r.cam.ty=-2500;cache.draw(source,2000,2000,10,10);assert.ok(cache.entries.get(source).visible);assert.equal(calls.filter(c=>c[0]==='bake').length,1);
});

test('explicit scenery rebakes can release obsolete source surfaces and reset backing accounting',()=>{
 const {cache}=rig(),a={},b={};cache.draw(a,0,0,200,200);cache.draw(b,0,0,200,200);const old=[...cache.entries.values()];assert.ok(cache.bytes>8);cache.clear();assert.equal(cache.entries.size,0);assert.equal(cache.bytes,0);for(const e of old)assert.equal(e.canvas.width*e.canvas.height,1);cache.draw(a,0,0,200,200);assert.equal(cache.entries.size,1);
});
