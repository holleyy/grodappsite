'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Rack=require('./ticket-rack.js'),BA=require('./vendor/sim/12_boardanim.js'),Acting=require('./acting.js').create(BA);
const levels=require('./vendor/data/levels.json').levels.filter(l=>!l.room).slice(0,15);
test('edit preview and launch transitions show each later cat once, in postal order',()=>{
 for(const [cats,frames] of [[['ginger','blue','ginger'],[4,4,1,0]],[['blue','ginger','blue'],[5,5,2,0]]]){
  const h={x:2,y:1,dir:'R',cats,first:0},state=Acting.makeHatchOut();
  Acting.hatch(h,[],0,state);assert.equal(Rack.count(state,true),2);assert.equal(Rack.frame(state,true),frames[0]);
  const traces=cats.map((coat,i)=>Object.assign(BA.makeTrace(8),{rel:.3+i*.6,pop:.3,hx:2,hy:1,hatchDir:1,coat:coat==='blue'?2:1}));
  for(const [i,t] of [0,.6,1.2].entries()){
   Acting.hatch(h,traces,t,state);assert.equal(Rack.count(state,false),2-i);assert.equal(Rack.frame(state,false),frames[i+1]);
  }
 }
});
test('every Office preview reserves the full box for its first cat; rack stays outside hatch and crossing lanes',()=>{
 const b=Rack.layout();assert.ok(b.x0>=0&&b.x1<.14&&b.y0>.86&&b.y1<=1);
 assert.ok(b.x1<.32&&b.y0>.68,'clears both central travel corridors');
 let hatches=0,queues=0;
 for(const l of levels)for(const h of l.hatches){const state=Acting.hatch(h,[],0,Acting.makeHatchOut());assert.equal(Rack.count(state,true),h.cats.length-1);hatches++;if(h.cats.length>1)queues++;}
 assert.equal(hatches,18);assert.equal(queues,9);
});
test('single-cat hatches have no unnecessary empty furniture',()=>{
 const rack=new Rack({ctx:{drawImage(){throw Error('single-cat rack drawn');}}});
 rack.draw({x:0,y:1,cats:['ginger']},null,true);
});
