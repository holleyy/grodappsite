'use strict';
// Real Office layouts, DOM controls and visible touch targets in the built page.
// tools/snap.js device dimensions are physical pixels; the matrix below is CSS.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {createHash}=require('node:crypto'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'../../..');
const expected=require('./vendor/data/levels.json').levels.filter(l=>!l.room||l.room==='office');
const expectedIds=['1-1','1-2','1-3','1-4','1-5','2-1','2-2','2-3','2-4','2-5','2-6','2-7','2-8','2-9','2-10'];
assert.deepEqual(expected.map(l=>l.id),expectedIds);
const options={out:'work/civic-postal/office-fit',url:'http://127.0.0.1:8765/studies/civic-mail-hall/foundation/index.html'};
for(let i=2;i<process.argv.length;i++){
 const arg=process.argv[i];
 if(arg==='--jobs-only')options.jobsOnly=true;
 else if(arg==='--out'||arg==='--url')options[arg.slice(2)]=process.argv[++i];
 else throw Error('Unknown option '+arg);
}
const devices=[
 {name:'small-phone',width:320,height:568,dpr:2},
 {name:'phone',width:393,height:852,dpr:2},
 {name:'small-landscape',width:568,height:320,dpr:2},
 {name:'landscape',width:844,height:390,dpr:2},
 {name:'desktop',width:1280,height:900,dpr:1}
];

async function auditViewport(config,expected,representativeOnly){
 const check=(value,message)=>{if(!value)throw Error(config.name+': '+message);};
 for(let i=0;i<200&&!window.__foundation?.ready;i++)await new Promise(resolve=>setTimeout(resolve,30));
 check(window.__foundation?.ready,'artwork did not become ready');
 const F=window.__foundation,R=F.renderer,S=F.session,P=CivicProjection;
 const byId=id=>document.getElementById(id);
 F.pause(true);F.motion(false);R.ambient=6.4;
 check(innerWidth===config.width&&innerHeight===config.height,'unexpected CSS viewport '+innerWidth+' × '+innerHeight);
 check(JSON.stringify(OfficeLevels)===JSON.stringify(expected),'built Office data differs from the pinned source');
 const records=JSON.stringify(OfficeLevels),bakes=R.architecture.bakes;
 const paint=()=>{F.refresh();R.draw(S);};
 const centre=el=>{const r=el.getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2};};
 const inViewport=p=>p.x>=0&&p.x<innerWidth&&p.y>=0&&p.y<innerHeight;
 const exposed=el=>{
  const r=el.getBoundingClientRect(),p=centre(el),hit=document.elementFromPoint(p.x,p.y);
  return r.width>0&&r.height>0&&inViewport(p)&&(hit===el||el.contains(hit));
 };
 const scrolledControls=new Set();
 function reach(el){
  check(!!el,'missing control');
  if(!exposed(el)){scrolledControls.add(el.id||el.dataset.type);el.scrollIntoView({block:'nearest',inline:'nearest'});}
  check(exposed(el),'covered or unreachable control '+(el.id||el.dataset.type));
  check(!el.disabled,'disabled control '+(el.id||el.dataset.type));
 }
 function click(el){reach(el);el.click();paint();}
 function load(index){
  const el=byId('level');reach(el);el.value=String(index);el.dispatchEvent(new Event('change',{bubbles:true}));paint();
  check(S.index===index&&S.level.id===expected[index].id,'picker selected the wrong delivery');
  check(S.mode==='edit'&&S.chutes.length===0,'picker did not clear the previous route');
  check(R.config.w===S.level.board.w&&R.config.h===S.level.board.h,'renderer kept the previous board dimensions');
  check(R.config.zoom===1&&R.config.panX===0&&R.config.panY===0,'picker did not reset the camera');
 }
 function tap(x,y){
  const p=F.cell(x,y);
  check(document.elementFromPoint(p.x,p.y)===R.canvas,'pointer target is covered at '+S.level.id+' '+x+','+y);
  for(const type of ['pointerdown','pointerup'])R.canvas.dispatchEvent(new PointerEvent(type,{pointerId:1,pointerType:'touch',clientX:p.x,clientY:p.y,bubbles:true}));
  paint();
 }
 function select(type){click(document.querySelector('#tray button[data-type="'+type+'"]'));check(S.selected===type,'tray did not select '+type);}
 // A separating-axis check rejects any positive-area overlap between the board
 // diamond and visible controls; centre-only picking would miss partial cover.
 function overlap(a,b){
  for(const polygon of [a,b])for(let i=0;i<polygon.length;i++){
   const p=polygon[i],q=polygon[(i+1)%polygon.length],ax=-(q.y-p.y),ay=q.x-p.x;
   const aa=a.map(p=>p.x*ax+p.y*ay),bb=b.map(p=>p.x*ax+p.y*ay);
   if(Math.max(...aa)<=Math.min(...bb)+1e-5||Math.max(...bb)<=Math.min(...aa)+1e-5)return false;
  }
  return true;
 }
 let centreSamples=0,visibleSamples=0,fitPasses=0;
 function fitAndPick(){
  const B=S.level.board,rect=R.canvas.getBoundingClientRect();
  const screen=p=>{const q=P.toScreen(p,R.cam);return{x:q.x+rect.left,y:q.y+rect.top};};
  const board=P.corners(B.w,B.h).map(screen);
  const visible=p=>p.x>=rect.left-.01&&p.x<=rect.right+.01&&p.y>=rect.top-.01&&p.y<=rect.bottom+.01&&inViewport(p);
  for(const p of board)check(visible(p),'board corner clipped on '+S.level.id);
  for(const el of document.querySelectorAll('header,aside,footer,.scene-controls button,.scene-controls label,#hall-play')){
   const r=el.getBoundingClientRect();if(r.width<=0||r.height<=0||getComputedStyle(el).visibility==='hidden')continue;
   const box=[{x:r.left,y:r.top},{x:r.right,y:r.top},{x:r.right,y:r.bottom},{x:r.left,y:r.bottom}];
   check(!overlap(board,box),'board covered by '+(el.id||el.tagName)+' on '+S.level.id);
  }
  for(let y=0;y<B.h;y++)for(let x=0;x<B.w;x++){
   const p=F.cell(x,y),picked=R.cellAt(p.x,p.y);
   check(picked?.x===x&&picked?.y===y,'cell round trip failed on '+S.level.id+' '+x+','+y);centreSamples++;
   for(const [u,v] of [[.5,.5],[.04,.04],[.96,.04],[.96,.96],[.04,.96]]){
    const q=screen(P.project(x+u,y+v));
    check(visible(q),'cell clipped on '+S.level.id+' '+x+','+y);
    check(document.elementFromPoint(q.x,q.y)===R.canvas,'cell covered on '+S.level.id+' '+x+','+y);visibleSamples++;
   }
  }
  fitPasses++;
 }
 const postal=CivicPostal.layout();let postalMaxX=-Infinity,postalVertices=0;
 paint();
 if(R.postal.rig?.mesh?.faces){
  // A moving rig's screen rectangle includes empty corners. Check its actual
  // world vertices instead; elevation projects them further behind the board.
  const period=postal.period||60;
  for(let frame=0;frame<=240;frame++){
   R.ambient=frame*period/240;R.postal.draw(R.ambient);
   const mesh=R.postal.rig.mesh;
   for(let faceIndex=0;faceIndex<mesh.count;faceIndex++){
    const face=mesh.faces[faceIndex];
    for(let i=0;i<face.count;i++){
     const x=face.vertices[i*3],z=face.vertices[i*3+2];
     check(Number.isFinite(x)&&Number.isFinite(z),'postal rig has a non-finite vertex');
     check(z>=-1e-7,'postal rig vertex is below its floor');
     postalMaxX=Math.max(postalMaxX,x);postalVertices++;
    }
   }
  }
  check(postalVertices>0,'postal rig did not expose any vertices');
 }else{
  const b=postal.bounds;check(!!b,'postal rig has no declared complete screen envelope');
  for(const x of [b.left,b.right])for(const y of [b.top,b.bottom])postalMaxX=Math.max(postalMaxX,P.unproject(x,y).x);
 }
 check(postalMaxX<=-.14,'postal artwork enters the reserved board apron: '+postalMaxX);R.ambient=6.4;
 const sheet=document.createElement('canvas'),panelW=400,panelH=260,columns=3;
 sheet.width=columns*panelW;sheet.height=10*panelH;
 const ctx=sheet.getContext('2d');ctx.fillStyle='#f5f0e3';ctx.fillRect(0,0,sheet.width,sheet.height);
 let panels=0;
 function capture(label){
  if(representativeOnly)return;
  const x=panels%columns*panelW,y=Math.floor(panels/columns)*panelH;
  const scale=Math.min((panelW-16)/R.canvas.width,(panelH-40)/R.canvas.height);
  const w=R.canvas.width*scale,h=R.canvas.height*scale;
  ctx.fillStyle='#304f50';ctx.font='14px sans-serif';ctx.fillText(S.level.id+' · '+S.level.board.w+' × '+S.level.board.h+' · '+label,x+10,y+21);
  ctx.drawImage(R.canvas,x+(panelW-w)/2,y+30+(panelH-40-h)/2,w,h);
  ctx.strokeStyle='#c9cbbd';ctx.strokeRect(x+.5,y+.5,panelW-1,panelH-1);panels++;
 }
 const cases=[],indices=representativeOnly?[14]:expected.map((_,i)=>i);
 click(byId('play'));
 for(const index of indices){
  load(index);fitAndPick();capture('idle');
  const L=S.level,B=L.board,occupied=[...L.hatches,...L.baskets,...(L.dogs||[])];
  const free=[];for(let y=0;y<B.h;y++)for(let x=0;x<B.w;x++)if(!occupied.some(p=>p.x===x&&p.y===y))free.push({x,y});
  check(free.length>0,'no free placement cell');
  const type=['plain','ginger','blue'].find(type=>L.tray[type]>0),testCell=free[0],trayBefore=JSON.stringify(S.tray);
  select(type);
  for(const direction of ['U','R','D','L']){tap(testCell.x,testCell.y);check(S.chutes.length===1&&S.chutes[0].dir===direction,'place/rotate '+direction+' failed');}
  tap(testCell.x,testCell.y);check(S.chutes.length===0&&JSON.stringify(S.tray)===trayBefore,'remove did not return inventory');
  for(const cell of occupied){tap(cell.x,cell.y);check(S.chutes.length===0,'occupied cell accepted a turntable');}
  for(const solution of L.solution){
   select(solution.type);
   for(let i=0;i<=['U','R','D','L'].indexOf(solution.dir);i++)tap(solution.x,solution.y);
  }
  check(JSON.stringify(S.chutes)===JSON.stringify(L.solution),'placed route differs from the stored route');
  const sendInitiallyVisible=exposed(byId('send'));
  click(byId('send'));check(S.mode==='running'&&S.sim.tick===1,'Send did not dispatch the route');
  check(byId('level').disabled,'picker remains enabled during dispatch');
  click(byId('send'));check(S.mode==='edit'&&S.chutes.length===L.solution.length,'Stop lost the route');
  click(byId('send'));check(S.mode==='running','second dispatch failed');
  S.step(1.2);paint();fitAndPick();capture('post in motion');
  for(let i=0;i<1000&&S.mode==='running';i++)S.step(.3);
  S.step(2);paint();
  check(S.mode==='won'&&S.sim.delivered===S.sim.n,'original route did not win '+L.id);
  const delivered=S.sim.delivered;
  click(byId('reset'));check(S.mode==='edit'&&S.chutes.length===0,'Reset did not clear the route');
  check(JSON.stringify(S.tray)===JSON.stringify({plain:L.tray.plain|0,ginger:L.tray.ginger|0,blue:L.tray.blue|0}),'Reset did not restore inventory');
  click(byId('plus'));click(byId('plus'));check(R.config.zoom>1,'zoom controls did not zoom');
  R.canvas.dispatchEvent(new KeyboardEvent('keydown',{key:'0',bubbles:true}));paint();
  check(R.config.zoom===1&&R.config.panX===0&&R.config.panY===0,'keyboard fit did not reset the camera');
  click(byId('structure'));check(R.config.mode==='explore'&&getComputedStyle(document.querySelector('aside')).display==='none','Explore did not free the viewport');
  click(byId('hall-play'));check(R.config.mode==='play'&&getComputedStyle(document.querySelector('aside')).display!=='none','Explore return did not restore play');
  fitAndPick();check(R.architecture.bakes===bakes,'changing deliveries rebaked the architecture');
  cases.push({id:L.id,w:B.w,h:B.h,cells:B.w*B.h,delivered,sendInitiallyVisible,placed:true,won:true,reset:true,exploreReturn:true});
 }
 check(JSON.stringify(OfficeLevels)===records,'UI interactions mutated original level data');
 check(representativeOnly||panels===30,'contact sheet omitted a level or state');
 // Leave the full viewport capture in a meaningful active state. This also
 // exercises the actual Watch button rather than assigning a solution here.
 click(byId('preview'));check(S.mode==='running','Watch control did not dispatch');S.step(1.2);paint();fitAndPick();
 window.__officeFitContactSheet=sheet;
 return{kind:representativeOnly?'viewport':'matrix',name:config.name,css:[innerWidth,innerHeight],dpr:devicePixelRatio,
  cases,centreSamples,visibleSamples,fitPasses,postalMaxX,postalVertices,bakes:R.architecture.bakes,
  scrolledControls:[...scrolledControls],boardCanvas:{width:R.config.width,height:R.config.height},title:document.title};
}

const out=path.resolve(root,options.out);fs.mkdirSync(out,{recursive:true});
const jobs=[];
for(const device of devices)for(const representativeOnly of [false,true]){
 const job={url:options.url,device:(device.width*device.dpr)+'x'+(device.height*device.dpr)+'@'+device.dpr,wait:750,settle:30,
  js:'('+auditViewport.toString()+')('+JSON.stringify(device)+','+JSON.stringify(expected)+','+representativeOnly+')',
  out:path.join(out,device.name+(representativeOnly?'-viewport.png':'-all-levels.png'))};
 if(!representativeOnly)job.png='window.__officeFitContactSheet.toDataURL("image/png")';
 jobs.push(job);
}
const jobsPath=path.join(out,'jobs.json');fs.writeFileSync(jobsPath,JSON.stringify(jobs,null,2));
if(options.jobsOnly){console.log(jobs.length+' capture jobs written to '+jobsPath);process.exit(0);}
const html=path.join(__dirname,'index.html'),hash=()=>createHash('sha256').update(fs.readFileSync(html)).digest('hex');
const before=hash(),started=new Date().toISOString();
const run=spawnSync(process.execPath,['tools/snap.js','--batch',jobsPath],{cwd:root,encoding:'utf8',maxBuffer:8e6,timeout:300000});
const log=(run.stdout||'')+(run.stderr||'');fs.writeFileSync(path.join(out,'browser.log'),log);
const results=log.split('\n').filter(line=>line.startsWith('js -> ')).map(line=>JSON.parse(line.slice(6)));
const matrices=results.filter(result=>result.kind==='matrix');
const report={started,finished:new Date().toISOString(),htmlSHA256:before,htmlUnchanged:hash()===before,status:run.status,
 error:run.error?.message||null,viewportCount:matrices.length,levelDeviceCases:matrices.reduce((n,r)=>n+r.cases.length,0),
 centreSamples:matrices.reduce((n,r)=>n+r.centreSamples,0),visibleSamples:matrices.reduce((n,r)=>n+r.visibleSamples,0),results};
fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));
console.log(log);assert.equal(run.status,0,run.error?.message||'capture process failed');
assert.ok(!/setup error|page exception|page console\.(error|warning|assert)|png expression failed/.test(log),'browser reported a failed assertion; see '+path.join(out,'browser.log'));
assert.equal(results.length,jobs.length,'missing browser results');assert.equal(report.levelDeviceCases,75);assert.ok(report.htmlUnchanged,'built page changed during the run');
console.log('Office fit passed: 75 level/device cases, '+report.centreSamples+' centre round trips, '+report.visibleSamples+' visible target probes. Report: '+path.join(out,'report.json'));
