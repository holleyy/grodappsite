'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const P=require('./projection.js'),A=require('./architecture.js');
let Life;try{Life=require('./room-life.js');}catch{Life={};}
test('all thirty cubby cats and both room cats have real support contacts',()=>{
 assert.equal(typeof Life.layout,'function');
 const actors=Life.layout(),cubbies=actors.filter(a=>a.group===0);
 assert.equal(cubbies.length,30);assert.equal(actors.length,32);
 assert.equal(cubbies.filter(a=>a.coat==='ginger').length,15);
 for(const a of cubbies)assert.equal(a.z,24+a.row*34+3);
 const bench=A.layout().solids.find(s=>s.name==='counter');assert.equal(actors.find(a=>a.id==='desk').z,bench.z1);
 const tops=[],p=new Proxy({ctx:{save(){},clip(){},restore(){}},box(x,y,w,d,z,h){if(x===-3&&y===-2)tops.push(z+h);}}, {get(o,k){return o[k]||(()=>{});}});
 new A({}).galleryLower(p);
 assert.equal(actors.find(a=>a.id==='gallery').z,Math.max(...tops),'gallery cat must sit on the drawn deck');
});
test('room actor samples retain full bodies and keep their soles fixed while moving',()=>{
 assert.equal(typeof Life.makeState,'function');
 for(const actor of Life.layout()){
  const out=Life.makeState();let min=Infinity,max=-Infinity,alternate=false;
  for(let i=0;i<600;i++){
   assert.equal(Life.sample(actor,i*.17,out),out);
   assert.equal(out.z,actor.z);assert.equal(out.x,actor.x);assert.equal(out.y,actor.y);
   assert.ok(out.scaleY>=.96&&out.scaleY<=1.04);
   assert.ok(out.mix>=0&&out.mix<=1);assert.ok(!out.pose.includes('bust')&&!out.alternate.includes('bust'));
   assert.ok(Number.isFinite(out.scaleY));min=Math.min(min,out.scaleY);max=Math.max(max,out.scaleY);alternate||=out.mix>.9;
  }
  assert.ok(max-min>.03,actor.id+' does not breathe');assert.ok(alternate,actor.id+' never changes pose');
 }
});
test('ambient samples are repeatable, seekable and independently staggered',()=>{
 assert.equal(typeof Life.makeState,'function');
 const actors=Life.layout(),a=Life.makeState(),b=Life.makeState();
 for(const actor of actors){Life.sample(actor,7.3,a);Life.sample(actor,100,b);Life.sample(actor,7.3,b);assert.deepEqual(b,a);Life.sample(actor,7.3+actor.period,b);assert.ok(Math.abs(a.scaleY-b.scaleY)<1e-10);assert.ok(Math.abs(a.mix-b.mix)<1e-10);}
 const phases=actors.map(actor=>Life.sample(actor,0,Life.makeState()).scaleY.toFixed(5));assert.ok(new Set(phases).size>20);
});
test('static architecture brackets cubby and gallery cats with the correct occluders',()=>{
 const order=[],bounds={left:0,top:0,right:10,bottom:10};
 const a=new A({scenery:{draw(image){order.push(image);}},ambient:4,postal:{drawUnderCats(time){assert.equal(time,4);order.push('postal');}},roomLife:{draw(group,time){assert.equal(time,4);order.push('cats'+group);}}});
 a.cache='base';a.bounds=bounds;a.layers=['base','middle','front'].map(canvas=>({canvas,bounds}));a.draw();
 assert.deepEqual(order,['base','cats0','middle','postal','cats1','front']);
});
