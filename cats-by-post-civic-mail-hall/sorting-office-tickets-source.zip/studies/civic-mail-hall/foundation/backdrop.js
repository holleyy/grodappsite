/* The distant town is a single paper illustration. All nearby banks, houses
 * and physical contacts are projected in CivicExterior, outside this layer. */
(function(root){
'use strict';
const BOUNDS=Object.freeze({left:-800,top:-1100,right:2450,bottom:1600});
class Backdrop{
 constructor(renderer){this.r=renderer;this.canvas=null;this.foreground=null;this.bakes=0;this.bounds=BOUNDS;}
 bake(){
  if(this.r.scenery)this.r.scenery.clear();
  const b=this.bounds,cvs=document.createElement('canvas');cvs.width=2300;cvs.height=1911;
  const c=cvs.getContext('2d'),sx=cvs.width/(b.right-b.left),sy=cvs.height/(b.bottom-b.top);
  c.setTransform(sx,0,0,sy,-b.left*sx,-b.top*sy);
  c.fillStyle='#428c85';c.fillRect(b.left,b.top,b.right-b.left,b.bottom-b.top);
  // The distant gardens retain their colour and depth. Near banks and the
  // continuous foreground canal cover their base, without a green fog matte.
  c.drawImage(this.r.images.backdrop,-800,-1420,3250,2166.6667);
  // Low cream paper clouds frame the roof without moving in reduced motion.
  for(const [x,y,w] of [[120,-94,140],[1510,-65,165]]){
   c.save();c.translate(x,y);c.shadowColor='#8e687632';c.shadowBlur=5;c.shadowOffsetY=4;
   c.beginPath();c.moveTo(-w/2,0);c.quadraticCurveTo(-w*.45,-15,-w*.3,-12);c.bezierCurveTo(-w*.32,-31,-w*.09,-38,0,-23);c.bezierCurveTo(w*.14,-42,w*.3,-26,w*.3,-13);c.quadraticCurveTo(w*.45,-14,w/2,0);c.closePath();c.fillStyle='#f7ddbb';c.fill();c.shadowColor='transparent';c.strokeStyle='#fff0d485';c.lineWidth=1;c.stroke();c.restore();
  }
  this.canvas=cvs;this.bakeForeground();this.bakes++;
 }
 bakeForeground(){
  // A nearby cottage roof clips the lower-right frame. Its faces share the
  // hall projection and never cross the playable board, even at 6 by 4.
  const b={left:650,top:880,right:1800,bottom:1580},cvs=document.createElement('canvas');cvs.width=1150;cvs.height=700;
  const c=cvs.getContext('2d');c.translate(-b.left,-b.top);
  const p=new CivicArchitecture.Painter(c,this.r.images,this.r.assets),x0=10,xm=12.7,x1=15.4,y0=5.6,y1=10.8,eave=-35,ridge=28;
  p.poly([[x0,y0,eave],[xm,y0,ridge],[xm,y1,ridge],[x0,y1,eave]],'#ce7962','terracotta');
  p.poly([[xm,y0,ridge],[x1,y0,eave],[x1,y1,eave],[xm,y1,ridge]],'#b46756','terracotta');
  for(let j=0;j<=7;j++){const y=y0+(y1-y0)*j/7;p.line3([x0,y,eave],[xm,y,ridge],'#f4bc9270',1.8);p.line3([xm,y,ridge],[x1,y,eave],'#df9b7c70',1.8);}
  for(let i=1;i<6;i++){const t=i/6;p.line3([x0+(xm-x0)*t,y0,eave+(ridge-eave)*t],[x0+(xm-x0)*t,y1,eave+(ridge-eave)*t],'#93554455',1);p.line3([xm+(x1-xm)*t,y0,ridge+(eave-ridge)*t],[xm+(x1-xm)*t,y1,ridge+(eave-ridge)*t],'#834f4355',1);}
  p.line3([xm,y0,ridge],[xm,y1,ridge],'#edb48d',6);
  p.box(11.8,7.2,.42,.45,8,82,'brick');p.box(11.72,7.12,.58,.61,83,10,'stone');
  p.poly([[11.87,7.2,93.1],[12.14,7.2,93.1],[12.14,7.52,93.1],[11.87,7.52,93.1]],'#674c3c','none');
  this.foreground={canvas:cvs,bounds:b};
 }
 draw(){
  if(!this.canvas)return;const r=this.r,b=this.bounds,c=r.ctx;
  // Tall room overviews can see beyond the detailed canal cache. Continue
  // the same quiet water stock instead of revealing a rectangular diorama.
  c.fillStyle='#428c85';c.fillRect(-r.cam.tx/r.cam.scale,-r.cam.ty/r.cam.scale,r.config.width/r.cam.scale,r.config.height/r.cam.scale);
  if(-r.cam.ty/r.cam.scale<b.top){c.fillStyle='#f4aba5';c.fillRect(-r.cam.tx/r.cam.scale,-r.cam.ty/r.cam.scale,r.config.width/r.cam.scale,b.top+r.cam.ty/r.cam.scale+1);}
  this.r.scenery.draw(this.canvas,b.left,b.top,b.right-b.left,b.bottom-b.top);
 }
 drawForeground(){
  const r=this.r,c=r.ctx,f=this.foreground,s=r.cam.scale,bottom=(r.config.height-r.cam.ty)/s;
  if(f)this.r.scenery.draw(f.canvas,f.bounds.left,f.bounds.top+Math.max(0,bottom-1110),1150,700);
 }
}
Backdrop.layout=()=>BOUNDS;root.CivicBackdrop=Backdrop;
if(typeof module==='object'&&module.exports)module.exports=Backdrop;
})(globalThis);
