/* Fixed, projected paper architecture. Build once after artwork loads; the
 * live frame only composites the cached layer beneath the original pieces. */
(function(root,factory){
 const P=typeof module==='object'&&module.exports?require('./projection.js'):root.CivicProjection;
 const L=typeof module==='object'&&module.exports?require('./postal-work-layout.js'):root.CivicPostalLayout;
 const A=factory(P,L);if(typeof module==='object'&&module.exports)module.exports=A;root.CivicArchitecture=A;
})(globalThis,function(P,L){
'use strict';
const palette={stone:{top:'#f8ead2',left:'#dfc8ab',right:'#bea48b'},oak:{top:'#dbb17e',left:'#ba845d',right:'#91664e'},teal:{top:'#86aaa0',left:'#467c75',right:'#2b5756'},brick:{top:'#dda28b',left:'#c2826b',right:'#9f6458'}};
function tint(hex,target,amount){const a=parseInt(hex.slice(1),16),b=parseInt(target.slice(1),16);return '#'+[16,8,0].map(s=>Math.round(((a>>s)&255)*(1-amount)+((b>>s)&255)*amount).toString(16).padStart(2,'0')).join('');}
// The gallery support row clears both the cabinet front and stair landing.
const galleryFront=-.15,gallerySupportY=galleryFront-.16;
const stairs=Array.from({length:12},(_,i)=>({x0:-2.91,x1:-1.78,y0:4.65-(i+1)*.4,y1:4.65-i*.4,bottom:i*15,top:(i+1)*15}));
const extents=[[-5.85,6,-85],[-5.85,-4.7,120],[7.8,-5,145],[7.5,5.6,-105],[-3.3,-2.4,375],[7.4,-2.4,375],[-3.3,5.2,365]];
const points=extents.map(v=>P.project(...v));
const bounds={left:Math.min(...points.map(p=>p.x))-36,right:Math.max(...points.map(p=>p.x))+36,top:Math.min(...points.map(p=>p.y))-32,bottom:Math.max(...points.map(p=>p.y))+32};
const layout={floor:{x0:-3,y0:-2,x1:7.2,y1:5.2},galleryZ:180,landingY:-.15,stairs,bounds,extents,
 solids:[{name:'west wall',x0:-3.2,x1:-3,y0:-2.2,y1:5.2,z0:0,z1:365},{name:'rear wall',x0:-3,x1:7.2,y0:-2.2,y1:-2,z0:0,z1:310},{name:'gallery',x0:-3,x1:7.2,y0:-2,y1:galleryFront,z0:164,z1:232},{name:'stairs',x0:-2.91,x1:-1.78,y0:-.15,y1:4.65,z0:0,z1:220},{name:'counter',x0:L.bench.x0,x1:L.bench.x1,y0:L.bench.y0,y1:L.bench.y1,z0:0,z1:L.bench.top},{name:'sorting cabinet',x0:.3,x1:6.8,y0:-1.95,y1:-.55,z0:0,z1:151}]};

class Painter{
 constructor(c,images,assets){this.ctx=c;this.images=images;this.assets=assets;this.patterns={};}
 path(points,fill,stroke,width=1){const c=this.ctx;c.beginPath();points.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));c.closePath();if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=width;c.stroke();}}
 line(a,b,colour='#ae8c5c',width=1){const c=this.ctx;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);c.strokeStyle=colour;c.lineWidth=width;c.stroke();}
 shadow(x,y,rx,ry,alpha=.13){const c=this.ctx;c.save();c.translate(x,y);c.scale(rx,ry);const g=c.createRadialGradient(0,0,0,0,0,1);g.addColorStop(0,'#403b35');g.addColorStop(.4,'#403b35b0');g.addColorStop(1,'#403b3500');c.globalAlpha*=alpha;c.fillStyle=g;c.fillRect(-1,-1,2,2);c.restore();}
 label(text,p,colour='#496b64',size=12){const c=this.ctx;c.font=size+'px Georgia,serif';c.textAlign='center';c.fillStyle=colour;c.fillText(text,p.x,p.y);}
 sprite(sheet,index,x,bottom,width){const r=this.assets[sheet].rects[index];this.ctx.drawImage(this.images[sheet],...r,x-width/2,bottom-width*r[3]/r[2],width,width*r[3]/r[2]);}
 material(name){
  if(this.patterns[name])return this.patterns[name];
  const meta=this.assets.materials;if(!meta||!this.images.materials)return null;
  const key=name==='stone'?'ivory':name==='brick'?'terracotta':name;
  const r=meta.materials?.[key]?.atlasRect;if(!r)return null;
  const q=r,t=document.createElement('canvas');t.width=t.height=256;const tc=t.getContext('2d');tc.drawImage(this.images.materials,...q,0,0,256,256);
  // Use the authored fibres as albedo variation. Their photographed yellow
  // stock must not tint every painted face; lighting is a separate bake.
  const pixels=tc.getImageData(0,0,256,256),data=pixels.data;let mean=0;
  for(let i=0;i<data.length;i+=4)mean+=data[i]*.2126+data[i+1]*.7152+data[i+2]*.0722;
  mean/=256*256;for(let i=0;i<data.length;i+=4){const v=Math.max(72,Math.min(184,128+(data[i]*.2126+data[i+1]*.7152+data[i+2]*.0722-mean)*2.2));data[i]=data[i+1]=data[i+2]=v;}tc.putImageData(pixels,0,0);
  return this.patterns[name]=this.ctx.createPattern(t,'repeat');
 }
 poly(vertices,fill,material='stone',stroke){
  const c=this.ctx,pts=vertices.map(v=>P.project(...v)),xs=pts.map(p=>p.x),ys=pts.map(p=>p.y),x0=Math.min(...xs),y0=Math.min(...ys),x1=Math.max(...xs),y1=Math.max(...ys);
  let face=fill;
  if(material!=='none'&&/^#[0-9a-f]{6}$/i.test(fill)){
   const flat=vertices.every(v=>Math.abs(v[2]-vertices[0][2])<.01),g=c.createLinearGradient(x0,y0,x0+(x1-x0)*.25,y1||y0+1);
   g.addColorStop(0,tint(fill,'#fff4df',flat?.065:.11));g.addColorStop(.38,fill);g.addColorStop(1,tint(fill,'#314f55',flat?.035:.12));face=g;
  }
  this.path(pts,face,stroke,.7);
  const pattern=this.material(material);if(pattern){c.save();c.clip();c.globalCompositeOperation='soft-light';c.globalAlpha=.58;c.fillStyle=pattern;
   c.fillRect(x0-1,y0-1,x1-x0+2,y1-y0+2);c.restore();}
 }
 surfaceLight(x,y,z,rx,ry,colour='#ffe5ae',alpha=.22){
  const c=this.ctx,o=P.project(x,y,z);c.save();c.transform(P.HW,P.HH,-P.HW,P.HH,o.x,o.y);c.scale(rx,ry);
  const g=c.createRadialGradient(0,0,0,0,0,1);g.addColorStop(0,colour);g.addColorStop(.3,colour+'a0');g.addColorStop(1,colour+'00');c.globalAlpha=alpha;c.fillStyle=g;c.fillRect(-1,-1,2,2);c.restore();
 }
 box(x,y,w,h,z,height,mat='stone',custom){
  const q=custom||palette[mat],t=z+height;
  if(z===0&&height>=10){const c=this.ctx;c.save();c.shadowColor='#413b3438';c.shadowBlur=6;c.shadowOffsetY=1.5;this.path([[x,y,z],[x+w,y,z],[x+w,y+h,z],[x,y+h,z]].map(v=>P.project(...v)),'#51433324');c.restore();}
  this.poly([[x+w,y,z],[x+w,y+h,z],[x+w,y+h,t],[x+w,y,t]],q.right,mat);
  this.poly([[x,y+h,z],[x+w,y+h,z],[x+w,y+h,t],[x,y+h,t]],q.left,mat);
  this.poly([[x,y,t],[x+w,y,t],[x+w,y+h,t],[x,y+h,t]],q.top,mat);
  // Cut-card bevels stay inside the accepted prism. No new lip can lift a
  // supported parcel, interrupt a tread or change the floor's contact plane.
  if(height>=2&&w*P.HW>3&&h*P.HW>3){
   const edge=Math.min(1.05,height*.19),drop=Math.min(2.1,height*.28),c=this.ctx;c.save();c.lineJoin='round';
   this.line3([x,y+h,t-.2],[x+w,y+h,t-.2],'#fff4df8c',edge);
   this.line3([x+w,y,t-.2],[x+w,y+h,t-.2],'#f4e7d065',edge*.8);
   this.line3([x,y+h,t-drop],[x+w,y+h,t-drop],'#514b4930',.65);
   this.line3([x+w,y,t-drop],[x+w,y+h,t-drop],'#34464b38',.65);c.restore();
  }
 }
 line3(a,b,color,width=1){this.line(P.project(...a),P.project(...b),color,width);}
 face(axis,start,fixed,zTop,fn){const c=this.ctx,p=axis==='x'?P.project(start,fixed,zTop):P.project(fixed,start,zTop);c.save();c.transform(1,axis==='x'?.5:-.5,0,1,p.x,p.y);fn(c);c.restore();}
 cutout(name,x,y,z,width,sy=1){const a=this.assets.acting?.sprites[name];if(!a)return;const p=P.project(x,y,z),r=a.rect,h=width*r[3]/r[2]*sy;this.ctx.drawImage(this.images.acting,...r,p.x-width/2,p.y-h,width,h);}
 decor(name,x,y,w,h){const q=this.assets.decor?.sprites[name]?.atlasRect;if(q)this.ctx.drawImage(this.images.decor,...q,x,y,w,h);}
 front(name,x,y,w,h){const q=this.assets.fronts?.sprites[name]?.atlasRect;if(q)this.ctx.drawImage(this.images.fronts,...q,x,y,w,h);}
 brickWall(axis,start,fixed,width,height){
  this.face(axis,start,fixed,height,c=>{const W=width*P.HW,rowH=15;
   c.beginPath();c.rect(0,0,W,height);c.clip();
   c.fillStyle='#dcaa8138';c.fillRect(0,0,W,height);
   for(let row=0;row<height/rowH;row++)for(let col=-1;col<W/30;col++){
    const x=col*30+(row%2)*15,y=row*rowH;c.fillStyle=['#f5c29c23','#703e2e12','#eec09b1c','#8d4b3713'][(row*7+col+5)%4];c.fillRect(Math.max(0,x+.8),y+1,Math.min(29,W-Math.max(0,x+.8)),13.4);
    c.strokeStyle='#ecc5a545';c.lineWidth=.6;c.strokeRect(x+.5,y+.5,29.4,14.5);
   }
  });
 }
 arch(c,x,y,w,h){const r=w/2;c.beginPath();c.moveTo(x,y+h);c.lineTo(x,y+r);c.arc(x+r,y+r,r,Math.PI,Math.PI*2);c.lineTo(x+w,y+h);c.closePath();}
 window(axis,start,fixed,width,zTop,height){
  this.face(axis,start,fixed,zTop,c=>{
   const W=width*P.HW,H=height;
   if(height>180&&this.images.fronts){const iw=H*465/1119;c.save();c.shadowColor='#66503333';c.shadowBlur=3;c.shadowOffsetY=2;this.front('archedWindow',(W-iw)/2,0,iw,H);c.restore();return;}
   c.save();c.translate(2.5,3);this.arch(c,0,0,W,H);c.fillStyle='#5b443b44';c.fill();c.restore();
   this.arch(c,0,0,W,H);const frame=c.createLinearGradient(0,0,W,H);frame.addColorStop(0,'#fff1d0');frame.addColorStop(.45,'#eac99a');frame.addColorStop(1,'#c8a36e');c.fillStyle=frame;c.fill();
   this.arch(c,7,8,W-14,H-15);c.fillStyle='#97774a';c.fill();
   c.save();this.arch(c,10,11,W-20,H-21);c.clip();
   const glass=c.createLinearGradient(0,0,0,H);glass.addColorStop(0,'#b8d9d5');glass.addColorStop(.38,'#e1e8d8');glass.addColorStop(.7,'#94c3b8');glass.addColorStop(1,'#5a9e99');c.fillStyle=glass;c.fillRect(0,0,W,H);
   for(let k=0;k<6;k++){const xx=k*W/5-12,hh=17+(k*17)%29,yy=H*.48;c.fillStyle=['#d1c6b3','#d7b6a2','#b7c6b6'][k%3];c.fillRect(xx,yy-hh,23,hh);c.beginPath();c.moveTo(xx-2,yy-hh);c.lineTo(xx+11,yy-hh-13);c.lineTo(xx+25,yy-hh);c.closePath();c.fillStyle='#9caeb0';c.fill();c.fillStyle='#f6e5b7';c.fillRect(xx+5,yy-hh+7,5,8);}
   c.fillStyle='#e6eee161';for(let k=0;k<9;k++)c.fillRect((k*31)%W,H*.61+k*6,17+(k%3)*7,1.5);
   c.fillStyle='#fff8df25';c.beginPath();c.moveTo(W*.2,0);c.lineTo(W*.38,0);c.lineTo(W*.05,H);c.lineTo(-W*.1,H);c.fill();c.beginPath();c.moveTo(W*.8,0);c.lineTo(W*.87,0);c.lineTo(W*.5,H);c.lineTo(W*.43,H);c.fill();
   c.strokeStyle='#e8bc72';c.lineWidth=3.4;for(const x of [W/3,W*2/3]){c.beginPath();c.moveTo(x,0);c.lineTo(x,H);c.stroke();}for(const y of [W*.51,H*.48,H*.72]){c.beginPath();c.moveTo(0,y);c.lineTo(W,y);c.stroke();}
   c.strokeStyle='#fff1c7';c.lineWidth=1;for(const x of [W/3-1,W*2/3-1]){c.beginPath();c.moveTo(x,0);c.lineTo(x,H);c.stroke();}c.restore();
   this.arch(c,10,11,W-20,H-21);c.strokeStyle='#f5dba6';c.lineWidth=1.2;c.stroke();
   c.fillStyle='#e7cfaa';c.fillRect(-3,H-4,W+6,8);c.fillStyle='#fff0d2';c.fillRect(-3,H-4,W+6,2);
   for(let k=0;k<9;k++){const a=Math.PI+k*Math.PI/8,xx=W/2+Math.cos(a)*(W/2-3),yy=W/2+Math.sin(a)*(W/2-3);c.beginPath();c.moveTo(xx,yy);c.lineTo(W/2+Math.cos(a)*(W/2+1),W/2+Math.sin(a)*(W/2+1));c.strokeStyle='#c4a176';c.lineWidth=.7;c.stroke();}
  });
 }
 column(x,y,height){
  this.poly([[x-.17,y-.17,.02],[x+.19,y-.17,.02],[x+.19,y+.2,.02],[x-.17,y+.2,.02]],'#72593424','none');
  this.box(x-.15,y-.15,.3,.3,0,10,'stone');this.box(x-.105,y-.105,.21,.21,10,height-19,'teal');
  this.box(x-.16,y-.16,.32,.32,height-9,9,'stone');
  this.line3([x-.09,y+.11,17],[x-.09,y+.11,height-15],'#9cb9a66b',1.2);
 }
 brace(x,y,axis,sign,z){
  const a=axis==='x'?[[x,y,z-46],[x+sign*.82,y,z],[x,y,z]]:[[x,y,z-46],[x,y+sign*.82,z],[x,y,z]];
  this.poly(a,'#345f59','teal');const p0=P.project(...a[0]),p1=P.project(...a[1]),p2=P.project(...a[2]),c=this.ctx;
  c.beginPath();c.moveTo(p0.x,p0.y);c.quadraticCurveTo(p2.x+(p1.x-p2.x)*.12,p2.y+22,p1.x,p1.y);c.strokeStyle='#8ba89b';c.lineWidth=3;c.stroke();
 }
 rail(axis,start,fixed,length,z){
  const at=(u,h)=>axis==='x'?[start+u,fixed,z+h]:[fixed,start+u,z+h];
  this.line3(at(0,13),at(length,13),'#94734e',3.3);this.line3(at(0,42),at(length,42),'#b28c59',4.7);this.line3(at(0,44),at(length,44),'#f1d5a1',1.7);
  const n=Math.ceil(length/.23);for(let i=0;i<=n;i++){const u=i*length/n;this.line3(at(u,12),at(u,42),'#c7a674',2.7);this.line3(at(u,13),at(u,40),'#f0d7aa',.8);}
  for(let u=0;u<=length+.01;u+=Math.max(.8,length/4)){this.line3(at(u,0),at(u,48),'#9c703a',5);this.line3(at(u,0),at(u,48),'#d9ae61',3.2);const p=P.project(...at(u,50));this.ctx.beginPath();this.ctx.arc(p.x,p.y,4.2,0,Math.PI*2);this.ctx.fillStyle='#e9bd64';this.ctx.fill();this.ctx.beginPath();this.ctx.arc(p.x-1.2,p.y-1.3,1.4,0,Math.PI*2);this.ctx.fillStyle='#fff0ae';this.ctx.fill();}
 }
 plant(x,y,z,size=1,hanging=false){
  const p=P.project(x,y,z),c=this.ctx;this.shadow(p.x,p.y,13*size,4*size,.13);
  this.box(x-.12*size,y-.12*size,.24*size,.24*size,z,13*size,'stone');
  c.save();c.translate(p.x,p.y-13*size);c.scale(size,size);
  const n=hanging?13:9;for(let i=0;i<n;i++){const a=-Math.PI*.95+i*.74,rr=13+(i%3)*4,ex=Math.cos(a)*rr,ey=hanging?i*5-4:Math.sin(a)*rr-8;c.beginPath();c.moveTo(0,0);c.quadraticCurveTo(ex*.7-10,ey-14,ex,ey);c.quadraticCurveTo(ex*.7+7,ey-6,0,0);c.fillStyle=['#6f8e45','#98a74f','#b8bb66','#819f50'][i%4];c.fill();c.beginPath();c.moveTo(0,0);c.lineTo(ex,ey);c.strokeStyle='#d0d28a77';c.lineWidth=.7;c.stroke();}c.restore();
 }
 parcel(x,y,z,w=.35,h=.32,height=18){this.poly([[x-.02,y-.02,z+.01],[x+w+.035,y-.02,z+.01],[x+w+.035,y+h+.035,z+.01],[x-.02,y+h+.035,z+.01]],'#72593424','none');this.box(x,y,w,h,z,height,'oak',{top:'#e9c38c',left:'#c69a64',right:'#b58b5c'});this.poly([[x+w*.44,y,z+height+.2],[x+w*.57,y,z+height+.2],[x+w*.57,y+h,z+height+.2],[x+w*.44,y+h,z+height+.2]],'#f5dfad');this.poly([[x+w*.44,y+h,z],[x+w*.57,y+h,z],[x+w*.57,y+h,z+height],[x+w*.44,y+h,z+height]],'#ead29f');}
 lamp(x,y,top){
  const c=this.ctx,p=P.project(x,y,top-43);this.line3([x,y,top],[x,y,top-32],'#a37e43',1.8);
  const glow=c.createRadialGradient(p.x,p.y+4,0,p.x,p.y+4,42);glow.addColorStop(0,'#ffe99d50');glow.addColorStop(1,'#ffe99d00');c.fillStyle=glow;c.fillRect(p.x-42,p.y-38,84,84);
  c.beginPath();c.moveTo(p.x-16,p.y);c.quadraticCurveTo(p.x-13,p.y-17,p.x,p.y-19);c.quadraticCurveTo(p.x+13,p.y-17,p.x+16,p.y);c.closePath();const g=c.createLinearGradient(p.x-16,p.y,p.x+16,p.y);g.addColorStop(0,'#b97d24');g.addColorStop(.5,'#f7d075');g.addColorStop(1,'#cd9638');c.fillStyle=g;c.fill();c.beginPath();c.ellipse(p.x,p.y,16,4,0,0,Math.PI*2);c.fillStyle='#fff1b6';c.fill();c.strokeStyle='#e4b350';c.lineWidth=1.4;c.stroke();
 }
}

class Architecture{
 static layout(){return layout;}
 constructor(renderer){this.r=renderer;this.cache=null;this.bakes=0;this.bounds=bounds;}
 drawLayer(layer){const b=layer.bounds;this.r.scenery.draw(layer.canvas,b.left,b.top,b.right-b.left,b.bottom-b.top);}
 draw(){
  if(!this.cache)this.bake();const r=this.r;
  if(this.exteriorLayer)this.drawLayer(this.exteriorLayer);
  this.drawLayer(this.layers[0]);r.roomLife.draw(0,r.ambient);
  this.drawLayer(this.layers[1]);r.postal.drawUnderCats(r.ambient);r.roomLife.draw(1,r.ambient);
  this.drawLayer(this.layers[2]);
 }
 // Assets and layout are immutable after renderer.load(). A caller replacing
 // either must call bake() explicitly; camera and level changes reuse the cache.
 bake(){
  if(this.r.scenery)this.r.scenery.clear();
  const r=this.r,ex=typeof CivicExterior==='function'?new CivicExterior(r):null;
  const eb=ex?ex.props.filter(p=>p.name!=='canal water').reduce((b,p)=>({left:Math.min(b.left,p.bounds.left),top:Math.min(b.top,p.bounds.top),right:Math.max(b.right,p.bounds.right),bottom:Math.max(b.bottom,p.bounds.bottom)}),{left:Infinity,top:Infinity,right:-Infinity,bottom:-Infinity}):null;
  // Frame the complete Office and its approach; distant banks may continue
  // beyond the viewport. Their much wider cache must not shrink the game.
  this.bounds={left:-160,right:1580,top:-145,bottom:1110};
  const make=(b,paint,scale=2)=>{
   const canvas=document.createElement('canvas');canvas.width=Math.ceil((b.right-b.left)*scale);canvas.height=Math.ceil((b.bottom-b.top)*scale);
   const c=canvas.getContext('2d');c.setTransform(scale,0,0,scale,-b.left*scale,-b.top*scale);c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';
   paint(new Painter(c,r.images,r.assets));return{canvas,bounds:b};
  };
  // Only the scenery crossing a live actor needs a separate draw. Bake the
  // rest into the base once, instead of blitting two almost-empty hall layers.
  const cubbies={left:818,top:335,right:1228,bottom:632};
  const gallery={left:1158,top:411,right:1238,bottom:483};
  const outside=(p,holes,paint)=>{const c=p.ctx;c.save();for(const b of holes){c.beginPath();c.rect(-2000,-2000,6000,6000);c.rect(b.left,b.top,b.right-b.left,b.bottom-b.top);c.clip('evenodd');}paint(p);c.restore();};
  const middle=p=>{this.cabinetLips(p);this.galleryLower(p);this.counter(p);};
  const front=p=>{this.galleryUpper(p);this.details(p);};
  this.exteriorLayer=ex?make({left:eb.left-4,top:eb.top-4,right:eb.right+4,bottom:eb.bottom+4},p=>{ex.r=p;ex.draw(false);},1.25):null;
  this.layers=[
   make(bounds,p=>{this.foundation(p);this.walls(p);this.stair(p);this.cabinet(p);outside(p,[cubbies],middle);outside(p,[cubbies,gallery],front);}),
   make(cubbies,p=>{middle(p);outside(p,[gallery],front);}),
   make(gallery,front)
  ];
  this.cache=this.layers[0].canvas;this.bakes++;
 }
 foundation(p){
  const f=layout.floor;
  p.shadow(810,892,555,112,.055);
  for(const x of [-2.8,.25,3.3,6.8]){p.box(x-.12,4.77,.5,.5,-91,10,'stone');p.box(x,4.9,.25,.25,-81,64,'stone');}
  for(const y of [-1.7,.7,3.1]){p.box(6.8,y,.42,.42,-91,10,'stone');p.box(6.89,y+.1,.23,.23,-81,64,'stone');}
  for(const x of [-2.8,.25,3.3,6.8]){
   if(x<6.8)p.poly([[x+.12,5.03,-65],[x+.86,5.03,-18],[x+1.02,5.03,-18],[x+.12,5.03,-75]],'#b58a4c','oak');
   if(x>-2.8)p.poly([[x+.12,5.03,-65],[x-.62,5.03,-18],[x-.78,5.03,-18],[x+.12,5.03,-75]],'#c29654','oak');
  }
  p.box(f.x0,f.y0,f.x1-f.x0,f.y1-f.y0,-18,18,'stone');
  // Exposed corrugated core under the front cut edges.
  p.face('x',-3,5.2,-5,c=>{c.fillStyle='#c09d68';c.fillRect(0,0,10.2*P.HW,9);c.strokeStyle='#efdab0';c.lineWidth=1.2;for(let i=0;i<10.2*P.HW;i+=12){c.beginPath();c.moveTo(i,0);c.lineTo(i+6,8);c.lineTo(i+12,0);c.stroke();}});
  p.face('y',5.2,7.2,-5,c=>{c.fillStyle='#b48e5f';c.fillRect(0,0,7.2*P.HW,9);c.strokeStyle='#dec299';c.lineWidth=1.2;for(let i=0;i<7.2*P.HW;i+=12){c.beginPath();c.moveTo(i,0);c.lineTo(i+6,8);c.lineTo(i+12,0);c.stroke();}});
  for(let x=-3;x<7.2;x+=.5)for(let y=-2;y<5.2;y+=.5){const shade=((Math.round(x*2)*7+Math.round(y*2)*13+200)%5)*.012;p.poly([[x,y,.05],[Math.min(x+.5,7.2),y,.05],[Math.min(x+.5,7.2),Math.min(y+.5,5.2),.05],[x,Math.min(y+.5,5.2),.05]],'rgba(170,126,77,'+shade+')','none');}
  for(let x=-3;x<=7.2;x+=.5)p.line3([x,-2,.1],[x,5.2,.1],'#c9b28b3b',.65);
  for(let y=-2;y<=5.2;y+=.5)p.line3([-3,y,.1],[7.2,y,.1],'#c9b28b3b',.65);
  // Window light is on the apron, beneath the separate board layer.
  const floorContext=p.ctx;floorContext.save();p.path([[f.x0,f.y0,.2],[f.x1,f.y0,.2],[f.x1,f.y1,.2],[f.x0,f.y1,.2]].map(v=>P.project(...v)));floorContext.clip();
  for(const y of [.4,2.7,4.8]){
   const c=p.ctx;c.save();c.shadowColor='#fff1c836';c.shadowBlur=11;p.poly([[-2.8,y-.9,.2],[-2.8,y+.1,.2],[1.4,y+1.9,.2],[1.4,y+.9,.2]],'#fff4d228','none');c.restore();
  }
  floorContext.restore();
 }
 walls(p){
  p.box(-3.2,-2.2,.2,7.4,0,310,'brick');p.brickWall('y',5.2,-3,7.2,310);
  // An actual arched opening reveals the canal scenery already behind it.
  const c=p.ctx;c.save();
  p.face('x',-2.6,-1.985,145,c=>p.arch(c,0,0,1.5*P.HW,145));
  c.rect(-500,-500,2600,2000);
  c.clip('evenodd');p.box(-3,-2.2,10.2,.2,0,310,'brick');p.brickWall('x',-3,-2,10.2,310);c.restore();
  p.box(-3.01,-2,.08,7.2,0,28,'stone');p.box(-3,-2.01,.4,.08,0,28,'stone');p.box(-1.1,-2.01,8.3,.08,0,28,'stone');
  for(const start of [4.94,2.65,.36])p.window('y',start,-2.985,1.87,274,235);
  for(const start of [-2.65,-.65,1.35,3.35,5.35])p.window('x',start,-1.975,1.18,296,97);
  p.face('x',.68,-1.96,288,()=>p.decor('postEarly',0,0,34,45));p.face('x',4.69,-1.96,288,()=>p.decor('catsByPost',0,0,34,44));
  p.face('x',-3,-1.96,178,c=>{const g=c.createLinearGradient(0,0,0,78);g.addColorStop(0,'#5a382633');g.addColorStop(1,'#5a382600');c.fillStyle=g;c.fillRect(0,0,10.2*P.HW,78);});
  p.box(-3.22,-2.25,.24,7.5,306,10,'stone');p.box(-3.2,-2.25,10.5,.25,306,10,'stone');
  // The west civic gable sits above the tall windows.
  p.poly([[-3.01,4.95,312],[-3.01,2.2,426],[-3.01,-.65,312]],'#bd7659','brick');
  p.line3([-2.99,4.99,313],[-2.99,2.2,428],'#eed5a8',8);p.line3([-2.99,2.2,428],[-2.99,-.69,313],'#eed5a8',8);
  p.face('x',-2.6,-1.965,145,c=>{p.arch(c,0,0,1.5*P.HW,145);c.strokeStyle='#f0d9ae';c.lineWidth=8;c.stroke();p.arch(c,3,4,1.5*P.HW-6,141);c.strokeStyle='#b9a077';c.lineWidth=1;c.stroke();});
  p.box(-2.68,-2.3,1.66,.3,-6,6,'stone');
  p.box(-2.68,-2.05,1.66,.34,0,5,'stone');p.box(-1.13,-1.98,.07,.72,5,108,'teal');
  for(const y of [-1.95,5.0]){p.box(-3.13,y-.1,.34,.3,0,321,'stone');p.box(-3.19,y-.16,.46,.42,312,11,'stone');}
  p.box(6.98,-2.15,.32,.36,0,316,'stone');
 }
 stair(p){
  // Solid treads and two folded teal stringers meet the upper landing exactly.
  for(let i=stairs.length-1;i>=0;i--){const s=stairs[i];p.box(s.x0,s.y0,s.x1-s.x0,s.y1-s.y0,0,s.top,'stone');p.line3([s.x0,s.y1,s.top],[s.x1,s.y1,s.top],'#fff3d6',1.5);p.line3([s.x0,s.y1,s.top-2],[s.x1,s.y1,s.top-2],'#b89b7355',.7);}
  for(const x of [-2.94,-1.75])p.poly([[x,-.15,181],[x,4.65,1],[x,4.65,-6],[x,-.15,166]],'#436e65','teal');
  for(const x of [-2.9,-1.79]){
   p.line3([x,-.15,224],[x,4.65,44],'#aa7d3b',4.4);p.line3([x,-.15,226],[x,4.65,46],'#f5d591',1.4);
   for(let i=0;i<=12;i++){const y=4.65-i*.4,z=i*15;p.line3([x,y,z+2],[x,y,z+44],'#c69b54',3);}
  }
  p.box(-2.94,-.65,1.2,.5,168,12,'stone');
 }
 cabinet(p){
  const x=.3,y=-1.95,w=6.5,front=-.55;
  p.box(x,y,w,1.4,0,12,'stone');p.box(x,y,w,1.4,12,126,'oak');
  const cols=10,rows=3,cw=(w-.22)/cols,rh=34;
  for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){
   const xx=x+.11+col*cw,z=24+row*rh,ginger=col<cols/2;
   p.poly([[xx,front+.012,z],[xx+cw-.07,front+.012,z],[xx+cw-.07,front+.012,z+rh-4],[xx,front+.012,z+rh-4]],ginger?'#963f32':'#334f69',ginger?'terracotta':'teal');
   p.poly([[xx,front+.02,z],[xx+cw-.07,front+.02,z],[xx+cw-.07,front-.18,z+6],[xx+.08,front-.18,z+6]],ginger?'#c77753':'#68829a');
   p.poly([[xx,front+.02,z],[xx+.08,front-.18,z+6],[xx+.08,front-.18,z+rh-5],[xx,front+.02,z+rh-4]],ginger?'#743d30':'#293d52');
   p.face('x',xx,front+.013,z+rh-4,c=>{const g=c.createLinearGradient(0,0,0,14);g.addColorStop(0,'#263c4466');g.addColorStop(1,'#263c4400');c.fillStyle=g;c.fillRect(0,0,(cw-.07)*P.HW,14);});
  }
  p.box(x-.1,y-.08,w+.2,1.56,138,8,'stone');p.box(x-.14,y-.1,w+.28,1.6,146,4,'oak');
  p.face('x',x,front+.05,19,c=>{for(let i=0;i<6;i++){const xx=i*w*P.HW/6+7;c.fillStyle='#d3a269';c.fillRect(xx,0,w*P.HW/6-14,11);c.strokeStyle='#aa7f49';c.lineWidth=.7;c.strokeRect(xx,0,w*P.HW/6-14,11);c.fillStyle='#e9c06f';c.fillRect(xx+20,3,12,3);}});
 }
 cabinetLips(p){
  const cw=6.28/10,front=-.55;
  for(let row=0;row<3;row++)for(let col=0;col<10;col++){
   const xx=.41+col*cw,z=24+row*34;
   p.box(xx,front-.035,cw-.07,.075,z,3,'oak');
   p.face('x',xx+cw*.35,front+.045,z+2.7,c=>{c.fillStyle='#f2e1b6';c.fillRect(0,0,14,2.3);c.fillStyle='#a18a66';c.fillRect(4,.8,6,.5);});
  }
 }
 counter(p){
  const b=L.bench,w=b.x1-b.x0,d=b.y1-b.y0;
  p.box(b.x0+.04,b.y0+.07,w-.08,d-.14,0,8,'stone');
  p.box(b.x0+.06,b.y0+.08,w-.12,d-.16,8,b.top-14,'oak');
  p.face('y',b.y1-.09,b.x1-.055,b.top-8,c=>{const W=(d-.18)*P.HW,H=31,g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'#aa7955');g.addColorStop(.2,'#c49b73');g.addColorStop(1,'#af8260');c.fillStyle=g;c.fillRect(0,0,W,H);for(let i=0;i<5;i++){const x=i*W/5+4;c.strokeStyle='#89654d';c.lineWidth=.8;c.strokeRect(x,3,W/5-8,25);c.strokeStyle='#e7caa17a';c.beginPath();c.moveTo(x,28);c.lineTo(x+W/5-8,28);c.stroke();c.fillStyle='#efd3a1';c.fillRect(x+W/10-8,8,8,2);}});
  p.box(b.x0,b.y0,w,d,b.top-6,4,'stone');p.box(b.x0,b.y0,w,d,b.top-2,2,'oak');
  if(typeof CivicPostal==='function')CivicPostal.drawStations(p);
  if(typeof CivicOfficeDetails!=='undefined')CivicOfficeDetails.drawCounter(p,L);
 }
 galleryLower(p){
  for(const x of [-2.78,-.35,2.08,4.51,6.94]){p.column(x,gallerySupportY,176);p.brace(x,gallerySupportY,'x',1,169);if(x>-.4)p.brace(x,gallerySupportY,'x',-1,169);}
  p.box(-3,-2,10.2,galleryFront+2,166,14,'stone');p.box(-3,-2,10.2,galleryFront+2,180,2,'oak');
  for(let x=-2.8;x<7.2;x+=.32)p.line3([x,-2,182.2],[x,galleryFront,182.2],'#aa805336',.7);
  const c=p.ctx;c.save();p.path([[-3,-2,182.3],[7.2,-2,182.3],[7.2,galleryFront,182.3],[-3,galleryFront,182.3]].map(v=>P.project(...v)));c.clip();
  for(const x of [-1.675,.875,3.425,5.975])p.surfaceLight(x,-1.25,182.3,1.04,.78,'#ffe5ad',.31);c.restore();
  // Short contact falloff along the rear deck joint, on the deck itself.
  for(let k=0;k<5;k++)p.poly([[-3,-2+k*.045,182.4],[7.2,-2+k*.045,182.4],[7.2,-1.955+k*.045,182.4],[-3,-1.955+k*.045,182.4]],'rgba(48,63,61,'+(.065-k*.011)+')','none');
 }
 galleryUpper(p){
  // Parcels rest on the deck behind the structural posts and front railing.
  p.parcel(-.8,-1.62,182,.5,.45,23);p.parcel(-.25,-1.55,182,.36,.34,18);p.parcel(-.72,-1.58,205,.34,.33,19);
  p.parcel(4.7,-1.5,182,.45,.45,25);p.parcel(5.16,-1.45,182,.38,.38,18);
  if(typeof CivicOfficeDetails!=='undefined')CivicOfficeDetails.drawGallery(p);
  // Back gallery upper posts and glazed roof bays have explicit joint heights.
  for(const x of [-2.8,-.35,2.1,4.55,7.0]){p.box(x-.095,galleryFront-.19,.19,.19,182,129,'teal');p.box(x-.15,galleryFront-.25,.3,.3,300,8,'stone');p.brace(x,galleryFront-.12,'x',1,300);if(x>0)p.brace(x,galleryFront-.12,'x',-1,300);}
  p.box(-3,galleryFront-.26,10.2,.28,306,12,'teal');p.box(-3,galleryFront-.29,10.2,.34,318,5,'stone');
  for(let i=0;i<4;i++){
   const x=-2.95+i*2.55,mid=x+1.275,right=x+2.55,back=-2.28,front=galleryFront+.05,base=324,peak=365;
   p.poly([[x,back,base],[mid,back,peak],[mid,front,peak],[x,front,base]],'#9dc6c2','stone');
   p.poly([[mid,back,peak],[right,back,base],[right,front,base],[mid,front,peak]],'#c2dbd1','stone');
   p.poly([[x,front,base],[mid,front,peak],[right,front,base]],'#b1d3ce','stone');
   for(const u of [.25,.5,.75]){
    const lx=x+(mid-x)*u,rx=mid+(right-mid)*u;
    p.line3([lx,back,base+(peak-base)*u],[lx,front,base+(peak-base)*u],'#e9dab4',2);
    p.line3([rx,back,peak-(peak-base)*u],[rx,front,peak-(peak-base)*u],'#e9dab4',2);
   }
   const yy=back+(front-back)*.52;p.line3([x,yy,base],[mid,yy,peak],'#e4cf9e',1.6);p.line3([mid,yy,peak],[right,yy,base],'#e4cf9e',1.6);
   p.poly([[mid+.2,back+.12,peak-6.4],[mid+.38,back+.12,peak-12.2],[right-.27,front-.14,base+8.7],[right-.45,front-.14,base+14.5]],'#fff9df32','none');
   for(const edge of [[[x,front,base],[mid,front,peak]],[[mid,front,peak],[right,front,base]],[[x,front,base],[right,front,base]],[[mid,back,peak],[mid,front,peak]]])p.line3(...edge,'#f4dfb3',5.7);
   p.line3([mid,front,peak],[mid,front,base],'#bd995f',2);for(const u of [.25,.5,.75]){p.line3([x+(mid-x)*u,front,base+(peak-base)*u],[x+(mid-x)*u,front,base],'#c8a96d',1.7);p.line3([mid+(right-mid)*u,front,peak-(peak-base)*u],[mid+(right-mid)*u,front,base],'#c8a96d',1.7);}
   p.line3([x+.13,back+.17,base+5],[mid-.12,back+.17,peak-3],'#f9ffe660',2);
   p.lamp(mid,-1.25,306);
  }
  p.rail('x',-1.75,galleryFront+.03,8.75,182);p.rail('y',-1.87,-2.8,1.68,182);
  p.plant(2.0,galleryFront-.02,182,1.25,true);p.plant(-2.52,-1.28,182,.9);
 }
 details(p){
  // The title and clock are printed on vertical card planes, never billboards.
  p.face('y',3.86,-2.94,414,c=>{
   const W=3.35*P.HW,H=W*415/670;p.decor('plaque',0,0,W,H);c.textAlign='center';c.fillStyle='#3d5350';c.font='bold 18px Georgia,serif';c.fillText('Sorting Office',W/2,H*.69);c.font='9px Georgia,serif';c.fillText('C A T S   B Y   P O S T',W/2,H*.81);
  });
  p.face('x',3.06,galleryFront+.15,211,c=>{
   const cx=60*258/513,cy=60*262/525;p.decor('clock',0,0,60,60);c.beginPath();c.moveTo(cx-11,cy-13);c.lineTo(cx,cy);c.lineTo(cx+12,cy-5);c.strokeStyle='#40524b';c.lineWidth=2.2;c.stroke();c.beginPath();c.arc(cx,cy,2,0,Math.PI*2);c.fillStyle='#b08b47';c.fill();
  });
  p.plant(6.94,-1.25,0,.95);p.parcel(6.52,-.08,0,.38,.38,22);p.parcel(6.58,-.04,22,.3,.3,18);
 }
}
Architecture.Painter=Painter;return Architecture;
});
