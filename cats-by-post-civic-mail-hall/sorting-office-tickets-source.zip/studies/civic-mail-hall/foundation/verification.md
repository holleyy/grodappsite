# Sorting Office warm paper and canal · 12 November 2026

The approved finish preserves the accepted floor, board, supports and working postal job. Neutralised paper grain, directional face lighting, cut edges, local lamp pools and softer contact shadows add material volume. The complete supported bench/throw assembly moves +0.25 y. Compact Board controls now occupy their own row. Window light is clipped to the real floor perimeter.

Canal contact bands follow the banks, currents move coherently, reflections correspond to actual town window groups, and the boat reflection stays on the water plane. Wake reach and opacity follow travel speed. The route, berth, 168-second period and independent scenery clock remain unchanged.

- **70 focused Node tests pass**, including new support, orientation-lighting, sole-shadow, shoreline, wake, deterministic seek and water-boundary checks.
- **75 Office level/device cases pass** across CSS 320×568,393×852,568×320,844×390 and 1280×900. Real controls place/rotate/remove, dispatch/stop/reset and solve every original Office delivery; Explore returns correctly. 4,590 cell-centre round trips and 22,950 visible target probes pass. The complete moving rig stays outside the board.
- **18 assembled Chromium cases pass**: 5 ambient/layer/motion checks, 7 architecture/camera checks, 2 floor/arrow regressions and 4 compact-toolbar/view-transition checks. Motion-off/reduced-motion freeze scenery while deliveries continue. Static caches bake once, stay below 64MiB, and their split edges reconstruct the full scene. Live scenery allocation guards pass.
- The changed rig additionally passed 4 postal Chromium cases: 521 frames retain exactly one parcel, 260 guarded frames create no canvases/gradients/projected points, and the visible grips and releases remain intact. These ran after the rig/material change and before final canal assembly; the final combined life checks also cover all moving systems.
- The canal additionally passed 3 close/motion Chromium cases, including 336 allocation-guarded draws. No physical-device performance claim is made from software Chromium timings.

HTML SHA-256: `3c6a873d33b8cacefd32a56c46d3c68b51256eaa61a67ed11b6db5cf85ff8bbc` (6,962,538 bytes). Captures and machine-readable results: `docs/review-images/sorting-office-finish/`. Fresh whole-change review found no unresolved material findings. A clean source extraction rebuilds byte-identical HTML and passes all 70 focused tests; evidence is in `docs/rooms/progress/sorting-office-finish.md`.

The separate adapter build `web-8e8b4e764f5f` passes 791 relevant current-main tests, 45 Office delivery wins over three viewport types, native picking/progress and chapter-return checks. Independent review reproduces the build and passes 29 adapter/fidelity/camera tests. It is prepared against current-main game presentation interfaces for user review. It is not merged or substituted for the live main game. This standalone source keeps its pinned original 15 Office records. Physical iPhone/Safari and Swift/Metal qualification remain unverified. Earlier canonical 1084-test results below belong to their dated checkpoints; they are not claimed as a fresh current-main adapter result.

Historical checkpoint records follow.

# Sorting Office postal work · 12 November 2026

This checkpoint completes the connected step4 postal job and keeps the scene identified as Sorting Office. It adds a projected paper robot, trolley and working receive/scale/stamp/dispatch stations; a lower, narrower bench supplies the clear work aisle. A staff bench, folded throw, ledger, mug and task lamp add a modest cosy finish. Existing canal life is preserved.

- **63 focused Node tests pass**, including exact surfaces/grips, fixed stance feet, rigid links, signed wheel distance, bridge docking, full parcel support, seek/loop continuity, physical bench clearance and mesh storage reuse. Initial missing-cycle/rig tests failed before implementation. The dense elbow/bench regressions also failed on the faulty reach/return before the hand path and bend direction were corrected.
- **1,084 canonical tests pass** freshly (486.09s). Canonical/native/Lantern source, level data and accepted board/piece rules are unchanged.
- **75 Office level/device cases pass** across CSS 320×568,393×852,568×320,844×390 and 1280×900: all original routes placed through real canvas handlers and won through Send, with Reset/Stop/Explore return. 4,590 centre round trips and 22,950 visibility probes pass; every Send control is initially visible. Optional Watch scrolls within the landscape sidebar. These are Chromium DOM/pointer checks, not physical touch tests.
- The full moving rig stays outside the board over241 sampled poses per viewport:275,676 active mesh vertices checked per job, max worldx−0.225789 and allz≥0. All15 original Office records match current canonical main: six5×3, two5×4, seven6×4. Later chapters reach10×8 and are not covered by this room.
- **18 further Chromium cases pass**:4 postal work,5 ambient life/occlusion/freeze, 7 architecture/camera and2 floor/arrow.521 frames draw exactly one parcel; all sampled work-stage parcels remain visibly rendered and clamps visibly open/close. Motion off and reduced motion retain their poses while deliveries continue.214 floor seam samples and8 arrow headings retain alignment.
-260 guarded work frames create no canvases, gradients or projected point objects and retain nested state/mesh storage. Architecture bakes once (31.28MiB raw cache). Coloured paper stocks bake once; live faces use a single textured fill. The unused fleet cutout is no longer embedded.
- Isolated software-Chromium forced-readback comparison at1440×1000,50 measured frames after10 warmups: preceding contact checkpoint median29.5ms/p9571.2ms; current build median33.5ms/p9556.7ms. These timings are diagnostic software rendering, not physical-device frame rates.

A clean source-archive extraction rebuilds byte-identical HTML and passes all63 focused tests. The optional art-master archive remains byte-identical to the preceding checkpoint.

Current HTML SHA-256: `3bc7ed281c60ae2394c241144fe36de92daddc4afac0859b54d453924021be4e` (6,953,512 bytes). Review: `docs/rooms/progress/sorting-office-postal-review.md`. Captures and machine-readable fit results: `docs/review-images/sorting-office-postal/`.

The small-screen Board toolbar can cover part of the background helper; the puzzle and dispatch controls stay unobscured. Explore office shows the complete work scene. Physical iPhone/Safari, sustained device performance and Swift/Metal remain unverified. Pages-domain browsing is blocked in this environment; publication is checked through Pages Actions and repository bytes matching this locally tested HTML.

The records below describe earlier archived checkpoints, including their then-open step4 work and original hashes.

# Civic contact correction · 12 November 2026

The floating-pillar report was a real column/cabinet intersection: bases had z=0 but sat inside the cabinet and painted over its front. The support row now sits on exposed floor at y=-0.31. The widened gallery, upper posts, roof/rail and attached details share a front edge at y=-0.15; deck height182 is unchanged. The upstairs sleeper moves along the supported deck so the relocated post does not hide its face. Local contact shadows reinforce the planted bases.

The upper parcel report was a foreground-order error. Boxes now draw behind structural posts and railing; the three-box stack is repositioned into a clear gallery bay. Each base parcel rests on the deck, and the upper parcel fits entirely on its supporting box. Support shadows follow the same projected planes.

Two meaningful regressions first failed on the original faults: column/cabinet intersection and boxes painting over posts. They cover all5 floor/structure contacts, cabinet/stair/counter/board clearance, parcel footprints, stack support, post clearance and front-to-back order. All52 focused Node tests pass after the fixes. All12 fresh Chromium cases pass:5 life/occlusion/reduced-motion and7 desktop/phone/landscape/whole-hall/picking cases. Close-up captures verify both reported contacts. A focused independent geometry/visual review found no blocker. Canonical rules, board/piece rendering and their previously qualified traces are unchanged.

**Step4 is not complete.** This build contains ambient cats and a parked manifest routine. Remaining working-postal-life tasks are in `docs/rooms/progress/civic-step-4-next.md`: a proven receive→process→dispatch route, real walking/pushing components, parcel grips/releases, rolling wheels and working receiving/processing surfaces. Water/boat work from step5 was brought forward; further atmosphere work waits for that cycle.

A clean source extraction rebuilds byte-identical HTML and passes all52 focused tests.

Current HTML SHA-256: `d8836b8ec2f32dd2a40fb1f81a01e346e903074fbd4de041da11491ba0cb0977` (7,248,094 bytes). Historical study records below retain their original hashes and qualifications. Physical iPhone/Safari and Swift/Metal remain unverified.

# Civic life 04 verification · 12 November 2026

The gallery cat rests at the actual deck height182 behind the front railing. All30 cubby cats and the desk/gallery cats use full-body authored poses with fixed soles, breathing and staggered wake/turn cycles. A grounded postal helper checks a manifest; a parcel boat docks, travels and returns through gently moving canal reflections. No new art or gameplay rules are introduced.

- All50 focused Node tests pass; all1084 unchanged canonical tests pass (689.10s).
- Five life-browser cases pass: changing cat pixels, actual rail occlusion, postal component masks, frozen motion-off/reduced-motion pixels with continuing deliveries, allocation traps, complete pose envelopes, static patch seams, canal passage and distinct clerk action frames.
- Seven architecture cases and five controls/rules cases pass, including phone, small-phone and landscape,1192 cell centres, gestures, all15 stored wins and300ms cadence.
- Both board regressions pass:214 seam samples and all8 centred/projected arrow headings.
- One fresh whole-change review found no Critical/Important issue. Its Minor evidence gap was fixed: the refreshed motion sheet shows separate postal lift/check/return samples. No recursive review was performed.
- Static architecture caches occupy31.28MiB, down from53.56MiB before splitting off only actor occluders. New life draw paths reuse state and allocate no canvases, gradients or projected points. The fair software-Chromium forced-readback benchmark at1440×1000 measured baseline median19.6ms/p9543.2ms and life25.8ms/42.8ms; these are not physical-device frame rates.
- A clean source-ZIP extraction rebuilt byte-identical HTML and passed all50 focused tests.
- Final HTML SHA-256: `69aaf5499268d66190301762c538cb5634eb2d1a588df9185941878ee963bcdd` (7,247,463 bytes).

Review images: `docs/review-images/civic-life/`. Review report: `docs/rooms/progress/civic-life-review.md`. Source/offline archives are rebuilt for this phase. The optional six art masters remain unchanged. Physical iPhone/Safari, sustained GPU performance and Swift/Metal remain unverified. Pages-domain browsing is blocked here; deployment is verified through Pages Actions and published repository bytes against the locally tested HTML.

Historical checkpoint records follow.

# Civic architecture 03 verification · 12 November 2026

## Cat revision 04

The sorting cabinet changes from 13 cats in 18 openings to 30 cats in 30 openings: 15 ginger and 15 blue. Every cubby uses a full sitting, crouching or sleeping pose, with a shelf contact shadow and the lip in front of its paws. The desk's cropped carrier bust is replaced by the existing full sitting pose, grounded at countertop z=74 with a contact shadow.

Fresh checks: all 32 focused Node tests and all 7 architecture browser cases pass. Captures inspect the desk/cubby contacts close up, full hall, 393×650 phone play and grayscale; small-phone/landscape fit and all-level picking remain covered. Only cached scenery placement changes; gameplay, character animation, board/picking, assets and projection are unchanged. No new art or per-frame geometry is introduced.

Current HTML SHA-256: `81d2c4b08f58fd2f56c082f83186db6edebcf99f26d446dad2afc770a7e72a7f` (7,229,515 bytes). Offline/source packages are rebuilt for this revision. Historical qualifications below describe their original checkpoints.

## Architecture revision 03

- Captured the accepted alignment baseline before changing rendering. The hall uses the unchanged board projection and normal play camera, with new bounds only for Explore.
- 32 focused Node tests pass, including fixed maximum-board footprint, stair/deck contact, board clearance, all exterior face/stroke bounds, deterministic cached geometry, continuous dock-to-door access and supported town houses. Architecture geometry and browser integration checks first failed before implementation; the two independent review fixes also have red→green tests.
- Seven Chromium architecture cases pass: desktop, 393×650 phone, 320×568 small phone and 568×320 landscape whole-hall fit; Board/Explore return with all 15 levels picking correctly; one static bake across all board sizes; phone/desktop play and grayscale captures.
- Five existing Chromium controls/rules cases pass again after the review fixes: four viewport sizes, 1,192 total cell centres, placement/rotation/removal, gestures, anchored zoom/pan and all 15 stored wins at 300 ms cadence.
- Both floor/arrow regressions pass after the final geometry fixes: 214 rendered seam samples and eight centred/projected arrow headings.
- All 35 acting browser cases passed with the new hall before the final static quay/bank fixes. Those fixes change no acting code or anchors.
- All 1,084 canonical tests passed freshly this stage (467.98 seconds). Canonical game source and assets are unchanged.
- Independent review and its single fix pass are recorded in `docs/rooms/progress/civic-architecture-review.md`. Phone, full hall and grayscale captures are under `docs/review-images/civic-architecture/`.
- Source extraction rebuilds byte-identical HTML and passes all 32 focused tests. Final HTML SHA-256: `c002d642b0d6fc683aed6e582b038ba20f59a58b7e18c100ab6600e1623f59c6` (7,229,216 bytes).

This qualifies the isolated browser architecture preview. Canal water and background postal details are still static. Physical iPhone/Safari, sustained device/GPU performance and the Swift/Metal port remain unverified. Direct browsing of the published Pages domain is blocked in this environment; deployment is checked through Pages Actions and published repository bytes, with the same HTML tested locally.

## Alignment revision 03

- Reproduced both reported faults before the fix: the first sampled seam missed its projected edge, and the placed arrow centroid missed its face centre.
- Two new Chromium regressions now pass: 214 rendered seam samples and centred mass/bounds plus correct heading for launch and placed arrows in all four directions.
- All 22 focused Node tests and the five existing Chromium controls/rules cases pass again, including four viewport sizes and all 15 stored solutions.
- All 35 existing acting browser cases pass again. Fresh source-archive extraction rebuilds byte-identical HTML.
- Phone capture and independent geometric/visual review approve the flat surface and registered arrows. The camera, picking, rules, character anchors and acting adapter are unchanged.
- Updated HTML SHA-256: `717539a02598098073cd30c4bd573339077218d56079f09754a12ec675c84d41`.

## Previous piece-stage qualification

- 22 focused Node tests pass. The acting suite loads the actual production paper-arrival, dog and cat-registration functions as independent VM oracles. Both coats, four approaches, exact boundaries, wrong/correct, bounced terminal, head lead, stuck, wake/leave, repeated/rewound samples and hatch/dog reducers are covered.
- 1,084 existing game tests pass (543.66 seconds). Canonical source and accepted projection are unchanged.
- Five Chromium controls cases pass: 298 cell centres across 15 Office layouts at each of 393×852, 320×568, 568×320 and 1440×1000 CSS pixels; real placement/rotation/removal, gesture separation, anchored zoom, pan picking and view switching. All 15 stored solutions win at 300 ms cadence.
- 35 additional Chromium cases pass: both coats/four approaches at supported push, flight and nap; crouch/clearance/fold/flat/wrong samples; actual multi-hatch opening and queue reduction; a real dog bump; phone presentation; grayscale; motion-off preserves the delivery clock and freezes decorative time. No console or asset-load errors.
- Visual comparison of all eight approach/coat sequences verifies consistent character identity and separate carrier, cat and basket-front layering. Generated row fragments were excluded from atlas crop bounds. Small-phone layout exposes Send, status and Watch controls.
- Seven byte-identical vendored inputs pin the tested rules, sampler, levels and production oracles independently of newer canonical code. Scoped packaging review approved the pins and fresh archive bytes.
- Fresh source ZIP extraction builds the exact HTML and passes all 22 Node tests. HTML SHA-256: `5c3a75475c261d718eb7739d1db4ab4970cc12313dd32edc29f7a303fa774972`.
- Independent adapter review approved after the scratch-state reuse Minor was fixed and re-reviewed. Whole-change review approved the piece integration and package with no Critical or Important findings. Its documentation suggestion was resolved by replacing the old phase1 verification with this record.

These checks qualify this browser piece study. At that earlier checkpoint the hall architecture, postal work routines, canal motion and physical-device budgets were still later stages. Art has 44 authored components with documented transformed/interpolated transitions; it does not claim a separately painted frame for every animation state.

The accepted phase1 foundation remains available in its separately named archive. Its earlier verification should not be confused with the current piece build.
