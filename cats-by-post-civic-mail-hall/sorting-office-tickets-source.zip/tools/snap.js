#!/usr/bin/env node
// Headless-Chrome capture for review: emulates a device size and pixel ratio, loads the
// page, runs optional setup JS, then saves either the screen (--screen) or the page's
// own logical canvas at an integer zoom (--canvas k, via __so.snap).
//
//   node tools/snap.js --url "http://127.0.0.1:8765/sorting_office.html?demo" \
//        --device 1179x2556@3 --js "__so.pause(true); __so.seek(600)" --canvas 2 --out shots/demo.png
//
// Needs Google Chrome (macOS path below, or CHROME=/path/to/chrome) and a server on --url.
// Several captures can share one browser: pass --batch file.json with [{url, device, js, canvas | png, out}, ...].
// png: a JS expression returning a PNG data URL, e.g. "__so.cropWorld(64, 16, 160, 96, 20, 6)".
// After each capture it prints the page's console errors and warnings and any uncaught exceptions.
const { spawn } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');

const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const PORT = 9300 + Math.floor(Math.random() * 500);
const args = process.argv.slice(2), opt = {};
for (let i = 0; i < args.length; i += 2) opt[args[i].replace(/^--/, '')] = args[i + 1];
const jobs = opt.batch ? JSON.parse(fs.readFileSync(opt.batch, 'utf8')) : [opt];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function json(url, method) {
  let last = null;
  for (let i = 0; i < 150; i++) { try { const r = await fetch(url, { method }); return await r.json(); } catch (e) { last = e; await sleep(100); } }
  throw new Error('no devtools at ' + url + ': ' + (last && (last.cause ? last.cause.message : last.message)));
}

async function main() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'snap-'));
  const chrome = spawn(CHROME, ['--headless=new', '--remote-debugging-port=' + PORT, '--user-data-dir=' + dir, '--hide-scrollbars',
    '--disable-gpu', '--no-first-run', '--no-default-browser-check', 'about:blank'], { stdio: 'ignore' });
  try {
    const target = await json(`http://127.0.0.1:${PORT}/json/new?about:blank`, 'PUT');
    const ws = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
    let id = 0; const pending = new Map(), events = [];
    ws.onmessage = (m) => { const d = JSON.parse(m.data); if (d.id && pending.has(d.id)) { pending.get(d.id)(d); pending.delete(d.id); } else events.push(d); };
    const send = (method, params = {}) => new Promise((r) => { const k = ++id; pending.set(k, r); ws.send(JSON.stringify({ id: k, method, params })); });
    await send('Page.enable'); await send('Runtime.enable');
    for (const job of jobs) {
      const [wh, dprS] = (job.device || '1280x800@1').split('@'), [W, H] = wh.split('x').map(Number), dpr = Number(dprS || 1);
      await send('Emulation.setDeviceMetricsOverride', { width: Math.round(W / dpr), height: Math.round(H / dpr), deviceScaleFactor: dpr, mobile: dpr > 1 && W < 2000 });
      const url = job.url + (job.url.includes('?') ? '&' : '?') + '_=' + Date.now();
      events.length = 0;
      await send('Page.navigate', { url });
      for (let i = 0; i < 100 && !events.some((e) => e.method === 'Page.loadEventFired'); i++) await sleep(50);
      await sleep(Number(job.wait || 300));
      if (job.js) {
        const r = await send('Runtime.evaluate', { expression: job.js, awaitPromise: true, returnByValue: true });
        if (r.result && r.result.exceptionDetails) console.error('setup error:', JSON.stringify(r.result.exceptionDetails.exception && r.result.exceptionDetails.exception.description));
        else if (r.result && r.result.result && r.result.result.value !== undefined) console.log('js ->', JSON.stringify(r.result.result.value));
      }
      await sleep(Number(job.settle || 100));
      let png;
      if (job.png) {                               // any JS expression that returns a PNG data URL
        const r = await send('Runtime.evaluate', { expression: job.png, returnByValue: true });
        if (!r.result.result || typeof r.result.result.value !== 'string') { console.error('png expression failed', JSON.stringify(r.result)); continue; }
        png = Buffer.from(r.result.result.value.split(',')[1], 'base64');
      } else if (job.canvas) {
        const r = await send('Runtime.evaluate', { expression: `__so.snap(${Number(job.canvas)})`, returnByValue: true });
        png = Buffer.from(r.result.result.value.split(',')[1], 'base64');
      } else {
        const r = await send('Page.captureScreenshot', { format: 'png' });
        png = Buffer.from(r.result.data, 'base64');
      }
      const out = job.out || 'shot.png';
      fs.mkdirSync(path.dirname(path.resolve(out)), { recursive: true });
      fs.writeFileSync(out, png);
      console.log('saved', out, png.length, 'bytes');
      // the page's console errors, warnings and uncaught exceptions since it loaded
      for (const e of events) {
        if (e.method === 'Runtime.exceptionThrown') console.log('page exception:', e.params.exceptionDetails.exception ? e.params.exceptionDetails.exception.description : e.params.exceptionDetails.text);
        else if (e.method === 'Runtime.consoleAPICalled' && (e.params.type === 'error' || e.params.type === 'warning' || e.params.type === 'assert'))
          console.log('page console.' + e.params.type + ':', e.params.args.map((a) => a.value !== undefined ? a.value : a.description).join(' '));
      }
    }
    ws.close();
  } finally { chrome.kill(); }
}
main().catch((e) => { console.error(e); process.exit(1); });
