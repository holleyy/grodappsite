/* Registered paper components. Simulation coordinates stay in source16wu;
 * every visible floor contact passes through the accepted Civic projection. */
(function(root){
'use strict';
const P=CivicProjection,DX=[1,0,-1,0],DY=[0,1,0,-1],DIR=['R','D','L','U'];
const clamp=v=>Math.max(0,Math.min(1,v)),ease=v=>{v=clamp(v);return v*v*(3-2*v);};
class Pieces{
 constructor(renderer){this.r=renderer;this.c=renderer.ctx;this.motion=true;this.carriers=this.bakeCarriers();}
 point(x,y,z=0){return P.project(x/16,y/16,z*P.HW/16);}
 asset(name,x,bottom,width,mirror=false,sy=1,alpha=1,front=false){
  const c=this.c,a=this.r.assets.acting.sprites[name];if(!a)throw Error('Missing piece '+name);
  const q=a.rect,h=width*q[3]/q[2]*sy;
  c.save();c.globalAlpha*=alpha;c.translate(x,bottom);if(mirror)c.scale(-1,1);
  if(front){c.beginPath();c.moveTo(-width/2,-h*.52);if(name==='basket-ginger')c.quadraticCurveTo(0,h*.06,width/2,-h*.52);else{c.lineTo(0,-h*.19);c.lineTo(width/2,-h*.52);}c.lineTo(width/2,2);c.lineTo(-width/2,2);c.closePath();c.clip();}
  c.drawImage(this.r.images.acting,q[0],q[1],q[2],q[3],-width/2,-h,width,h);c.restore();
 }
 anchored(name,x,y,width,u,v,mirror=false,sy=1){
  const a=this.r.assets.acting.sprites[name],h=width*a.rect[3]/a.rect[2]*sy;
  const anchorX=mirror?1-u:u;this.asset(name,x+(.5-anchorX)*width,y+(1-v)*h,width,mirror,sy);
 }
 ellipse(x,y,rx,ry,fill,stroke){const c=this.c;c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}}
 arrow(x,y,d,z,fill){
  // The arrow's area centroid AND its projected bounding-box centre are zero.
  // Tail + shaft half-width = 1 balances the tip in both projected axes;
  // head width balances the triangle's mass against the rectangular shaft.
  const tail=.82,shaft=.18,shoulder=-.15;
  const head=3*shaft*(tail*tail-shoulder*shoulder)/((1-shoulder)*(2*shoulder+1)),size=.26;
  const shape=[[1,0],[shoulder,-head],[shoulder,-shaft],[-tail,-shaft],[-tail,shaft],[shoulder,shaft],[shoulder,head]];
  const points=shape.map(([u,v])=>P.project(x+.5+size*(DX[d]*u-DY[d]*v),y+.5+size*(DY[d]*u+DX[d]*v),z));
  this.r.path(points,fill);
 }
 table(t,spin){
  const c=this.c,base=P.centre(t.x,t.y),p=P.project(t.x+.5,t.y+.5,3),colour=t.type==='ginger'?'#d9913f':t.type==='blue'?'#627f9e':'#467e7b';
  this.r.shadow(base.x,base.y+2,30,13,.15);
  const wall=c.createLinearGradient(p.x-30,p.y,p.x+30,p.y+15);wall.addColorStop(0,'#b99b6c');wall.addColorStop(.5,'#ead5a7');wall.addColorStop(1,'#b29464');
  this.ellipse(base.x,base.y,30,15,wall);this.ellipse(p.x,p.y,30,15,'#f4dfb5','#bca16d');this.ellipse(p.x,p.y,25,12.5,colour);
  const turn=spin*.25;
  for(let i=0;i<12;i++){const a=i*Math.PI/6+turn,x=p.x+27.4*Math.cos(a),y=p.y+13.6*Math.sin(a);if(t.type==='ginger'){c.strokeStyle='#9d5a2d';c.lineWidth=2.6;c.beginPath();c.moveTo(x-1,y-1);c.lineTo(x+1,y+1);c.stroke();}else if(t.type==='blue')this.ellipse(x,y,1.35,.7,'#f7edd3');}
  // Rim, face and printed arrow share one raised plane and centre.
  this.arrow(t.x,t.y,OfficeRules.GR_DIR[t.dir],3,'#fff0cf');
  if(t.locked){this.ellipse(p.x+22,p.y+12,7,5,'#f7e7c3','#aa874d');c.strokeStyle='#667a72';c.lineWidth=1.5;c.beginPath();c.arc(p.x+22,p.y+8,2.5,Math.PI,0);c.stroke();c.fillStyle='#667a72';c.fillRect(p.x+19.5,p.y+8,5,4);}
 }
 hatch(h,state){
  const d=OfficeRules.GR_DIR[h.dir],p=P.centre(h.x,h.y),lo=.14,hi=.86;
  const corners=[[lo,lo],[hi,lo],[hi,hi],[lo,hi]],floor=corners.map(v=>P.project(h.x+v[0],h.y+v[1]));
  this.r.path(floor,'#274d51','#ead6ad',5);
  const theta=state.open===2?1.25:state.open===1?.55:0;
  const lid=corners.map(v=>{let x=v[0],y=v[1],dist;if(d===0){dist=x-lo;x=lo+dist*Math.cos(theta);}else if(d===2){dist=hi-x;x=hi-dist*Math.cos(theta);}else if(d===1){dist=y-lo;y=lo+dist*Math.cos(theta);}else{dist=hi-y;y=hi-dist*Math.cos(theta);}return P.project(h.x+x,h.y+y,dist*P.HW*Math.sin(theta));});
  this.r.path(lid,theta?'#d1b37e':'#cebc94','#f5e4be',2.7);
  if(!theta)this.arrow(h.x,h.y,d,0,'#456e6d');
  // Printed portrait tickets remain ordered nearest release first.
  for(let k=state.n-1;k>=0;k--){const coat=state.queue[k].coat===2?'blue':'ginger';const q=P.project(h.x+.5-DX[d]*(.45+k*.22),h.y+.5-DY[d]*(.45+k*.22));this.ellipse(q.x,q.y-8,10,6,'#f6e7c7','#c4ae83');this.asset(coat+'-bust-front',q.x,q.y-9,17);}
  if(state.waiting>4)this.r.label('+'+(state.waiting-4),{x:p.x,y:p.y-30},'#52716b',9);
 }
 hatchFront(h){const pts=[P.project(h.x+.14,h.y+.86),P.project(h.x+.86,h.y+.86),P.project(h.x+.86,h.y+.14)];this.c.beginPath();this.c.moveTo(pts[0].x,pts[0].y);this.c.lineTo(pts[1].x,pts[1].y);this.c.lineTo(pts[2].x,pts[2].y);this.c.strokeStyle='#efdbb2';this.c.lineWidth=4;this.c.stroke();}
 dog(d,index,state){const p=P.centre(d.x,d.y),frame=this.motion||state.earLift?state.frame:0;this.r.shadow(p.x,p.y+16,31,11,.14);this.asset('dog-'+frame,p.x,p.y+22,80,!!state.mirror);if(this.motion&&!state.earLift){const t=state.glyph;if(t.visible){this.c.save();this.c.globalAlpha=1-t.fade;this.r.label('z',{x:p.x+24,y:p.y-35-t.z*2},'#8a9d99',t.big?14:10);this.c.restore();}}}
 // Bake the same square paper shell for occupied, empty and folding boxes.
 // Its floor root and near rim stay fixed while the scored walls collapse.
 bakeCarriers(){
  const frames=[];
  for(let d=0;d<4;d++)for(let fold=0;fold<=4;fold++)for(let front=0;front<2;front++){
   const canvas=document.createElement('canvas');canvas.width=256;canvas.height=192;
   const c=canvas.getContext('2d');c.scale(2,2);c.translate(64,56);
   const height=[27,21,14,8,3][fold],spread=[7,8,10,12,14][fold];
   const point=(x,y,z=0)=>({x:(x-y)*32,y:(x+y)*16+4-z});
   const A=point(-.5,-.5),B=point(.5,-.5),C=point(.5,.5),D=point(-.5,.5);
   const a=point(-.5,-.5,height),b=point(.5,-.5,height),cc=point(.5,.5,height),dd=point(-.5,.5,height);
   const trace=pts=>{c.beginPath();c.moveTo(pts[0].x,pts[0].y);for(let i=1;i<pts.length;i++)c.lineTo(pts[i].x,pts[i].y);c.closePath();};
   // These are real layered card panels: directional face shading, fibres and
   // a separate cut edge. The bake carries that relief into every fold state.
   const face=(pts,light,dark,grain=true)=>{
    const ys=pts.map(p=>p.y),top=Math.min(...ys),bottom=Math.max(...ys);
    const shade=c.createLinearGradient(-24,top,18,bottom+8);shade.addColorStop(0,light);shade.addColorStop(.25,light);shade.addColorStop(1,dark);
    trace(pts);c.fillStyle=shade;c.fill();
    if(grain){c.save();c.clip();
     for(let i=0;i<1650;i++){
      const hash=((i+17)*2654435761)>>>0,x=(hash%193)/2-48,y=((hash>>>10)%173)/2-52;
      c.fillStyle=i%3?'rgba(255,238,196,.13)':'rgba(96,58,28,.14)';c.fillRect(x,y,.3+(i%3)*.13,.35+(i%2)*.2);
     }
     c.strokeStyle='rgba(104,64,31,.09)';c.lineWidth=.32;
     for(let i=0;i<90;i++){const x=((i*37)%89)-44,y=((i*19)%83)-48;c.beginPath();c.moveTo(x,y);c.lineTo(x+1+(i%3)*.55,y-.2);c.stroke();}c.restore();}
   };
   const line=(x,y,u,v,colour,width)=>{c.strokeStyle=colour;c.lineWidth=width;c.beginPath();c.moveTo(x,y);c.lineTo(u,v);c.stroke();};
   const edge=(p,q,width=2)=>{
    const lowerP={x:p.x,y:p.y+width},lowerQ={x:q.x,y:q.y+width};
    face([p,q,lowerQ,lowerP],'#d5ad74','#a87744',false);
    const length=Math.hypot(q.x-p.x,q.y-p.y),n=Math.ceil(length/1.65);
    for(let k=0;k<n;k++){const u=(k+.3)/n,x=p.x+(q.x-p.x)*u,y=p.y+(q.y-p.y)*u;line(x,y+.45,x+.1,y+width-.2,'rgba(119,77,38,.48)',.42);}
    line(p.x,p.y,q.x,q.y,'#f0d6a4',.6);
   };
   const flap=(p,q,dx,dy,light,dark)=>{
    const farP={x:p.x+dx,y:p.y+dy},farQ={x:q.x+dx,y:q.y+dy};
    face([p,q,farQ,farP],light,dark);
    edge(farP,farQ);edge(q,farQ,1.2);
    line(p.x,p.y,q.x,q.y,'#956a3c',1.2);line(p.x,p.y-.6,q.x,q.y-.6,'#e3c18b',.65);
   };
   if(!front){
    // Back panels and outward folded flaps expose the darker uncoated interior.
    face([A,B,b,a],'#af8554','#745132');face([A,D,dd,a],'#bf9765','#87613c');
    flap(a,b,spread,-spread*.5,'#d7b582','#b68a54');
    flap(a,dd,-spread,-spread*.5,'#e3c391','#bf9766');
    face([A,B,C,D],'#af8656','#795334');
    // The floor seam is visible once the cat leaves, without a separate empty sprite.
    line(-15,4,15,4,'#bb925c',3);line(-15,3.3,15,3.3,'#d6b987',.6);
   }
   face([D,C,cc,dd],'#d1aa74','#ac7b47');face([B,C,cc,b],'#bd8d55','#946335');
   // Compressed bottom folds and the rounded paper-wrapped corner give the
   // carrier weight. Soft under-flap shadows belong to its walls, not the cat.
   line(D.x,D.y-1,C.x,C.y-1,'#a77944',1.5);line(B.x,B.y-1,C.x,C.y-1,'#886033',1.5);
   line(cc.x,cc.y+1,C.x,C.y-1,'#e4be87',1.7);line(C.x+1,cc.y+2,C.x+1,C.y-1,'#ac7a42',.65);
   c.save();trace([D,C,cc,dd]);c.clip();line(dd.x,dd.y+2.8,cc.x,cc.y+2.8,'rgba(103,66,31,.20)',4.5);c.restore();
   c.save();trace([B,C,cc,b]);c.clip();line(b.x,b.y+2.8,cc.x,cc.y+2.8,'rgba(87,53,24,.22)',4.5);c.restore();
   flap(dd,cc,-spread,spread*.5+1.25,'#e4c28c','#bd905a');
   flap(b,cc,spread,spread*.5+1.25,'#d9b47d','#af7d47');
   // Fold scores, a narrow paper tape repair and a small pasted postal ticket.
   line(dd.x,dd.y,cc.x,cc.y,'#e0bf8b',.9);line(b.x,b.y,cc.x,cc.y,'#dfbb81',.8);
   if(fold<3){
    const left=d===1||d===2,sign=left?-1:1,x=sign*13,y=13.5-height*.5;
    c.save();c.translate(x,y);c.transform(1,sign*-.5,0,1,0,0);
    c.fillStyle='rgba(244,218,166,.36)';c.fillRect(-2,-height*.28,4,height*.58);
    c.fillStyle='rgba(77,48,25,.18)';c.fillRect(-6.6,-3.5,14,8);
    c.fillStyle='#f1e2bf';c.fillRect(-7,-4,14,8);c.strokeStyle='#fbedd0';c.lineWidth=.45;c.strokeRect(-7,-4,14,8);
    line(-4,-1,2,-1,'#786b52',.6);line(-4,1,4,1,'#94846a',.45);c.fillStyle='#966d43';c.fillRect(3,-2.8,2,2);c.restore();
   }
   frames.push(canvas);
  }
  return frames;
 }
 carrier(x,y,d,fold=0,fade=0,front=false){
  if(fold<0||fade>=1)return;const p=this.point(x,y),c=this.c;
  const frame=this.carriers[(d*5+Math.min(4,Math.max(0,fold)))*2+(front?1:0)];
  if(!front)this.r.shadow(p.x,p.y+11,32,11,.12*(1-fade));
  c.save();c.globalAlpha*=1-fade;c.drawImage(frame,p.x-64,p.y-56,128,96);c.restore();
 }
 boxed(o,tr,now){
  const p=this.point(o.x,o.y,o.z),ground=this.point(o.x,o.y),c=this.c,coat=tr.coat===2?'blue':'ginger';
  c.save();if(o.anim===BOARDANIM.A.POP){c.beginPath();c.rect(ground.x-65,ground.y-160,130,175);c.clip();}
  c.save();c.translate(0,p.y-ground.y-(o.bob||0));this.carrier(o.x,o.y,o.dir);
  const rear=o.head===2||o.head===3,mirror=o.head===0||o.head===3;
  let face=rear?'bust-rear':'bust-front';if(o.ears===BOARDANIM.EARS_BACK)face=rear?'bump-rear':'bump-front';else if(this.motion&&o.eyes&&!rear)face='blink';
  const lean=o.head!==o.dir?((o.head-o.dir+4)%4===1?3:-3):0;
  const breath=this.motion&&o.anim===BOARDANIM.A.IDLE?Math.sin(now*2)*.008:0;
  this.asset(coat+'-'+face,ground.x+lean,ground.y+3,48,mirror,1+(o.anim===BOARDANIM.A.STRETCH?.05:breath));
  this.carrier(o.x,o.y,o.dir,0,0,true);c.restore();c.restore();
 }
 basket(b,front=false){const p=P.centre(b.x,b.y);if(!front)this.r.shadow(p.x,p.y+18,35,12,.12);this.asset('basket-'+b.coat,p.x,p.y+26,91,false,.78,1,front);}
 // Physical anchor for each authored crouch/push is its hind sole, rather than
 // the whole sprite's bounding-box bottom. Flight uses those same sole roots.
 loose(o,tr,now){
  const c=this.c,coat=tr.coat===2?'blue':'ginger',A=BOARDANIM.A;
  const j=tr.n-1,T=now-(tr.rel+tr.n*tr.tick),d=j>=0?tr.d0[j]:o.dir;
  const rear=d===2||d===3,mirror=d===0||d===3;
  if(o.takeoff>=0){
    const hx=tr.ox+tr.x1[j]*16+8,hy=tr.oy+tr.y1[j]*16+8,bx=hx-DX[d]*14,by=hy-DY[d]*14;
    const base=this.point(bx,by),target=this.point(hx+(tr.end===BOARDANIM.END_WRONG?3:tr.homeDX),hy+(tr.end===BOARDANIM.END_WRONG?3:tr.homeDY));
    const u=clamp((T-.4)/.2),v=ease(u),sx=base.x,sy=base.y-2;
    const tx=target.x,ty=target.y-3;
    const x=sx+(tx-sx)*v,y=sy+(ty-sy)*v-Math.sin(u*Math.PI)*22;
    this.r.shadow(base.x+(target.x-base.x)*v,base.y+10+(target.y-base.y)*v,23,8,.11);
    const pose=o.takeoff===0?'crouch':o.takeoff===1?'push':'push';
    const name=coat+'-'+pose+'-'+(rear?'rear':'front');
    // Sole positions are authored metadata for the component master. The
    // departing feet stay on the carrier's interior until clearance at.4s.
    const anchorU=rear?.63:pose==='crouch'?.84:.94,anchorV=rear?.90:pose==='crouch'?.88:.75;
    // Blend from supported hind soles to the body's floor centre for landing.
    const au=anchorU+(.5-anchorU)*v,av=anchorV+(1-anchorV)*v;
    this.anchored(name,x,y,67,au,av,mirror,1);
    if(o.takeoffSupported)this.carrier(o.boxX,o.boxY,d,0,0,true);
    return;
  }
  const p=this.point(o.x,o.y,o.z),dir=o.dir,back=dir===2||dir===3,flip=dir===0||dir===3;
  if(o.anim===A.NAP){const breath=this.motion?Math.sin(now*Math.PI/1.5)*.012:0;this.asset(coat+'-nap',p.x,p.y+13,62,false,1+breath);}
  else if(o.anim===A.CURL){const amount=(o.frame+1)/3;this.asset(coat+(o.frame>=1?'-nap':'-puzzled'),p.x,p.y+13,62,false,1-.05*(1-amount));}
  else if(o.anim===A.PUZZLED){this.asset(coat+'-puzzled',p.x,p.y+15,52,false);if(this.motion&&Math.floor(now*2)%2===0)this.r.label('?',{x:p.x+20,y:p.y-38},'#a27640',16);}
  else if(o.anim===A.WAKE){this.asset(coat+(o.frame===0?'-nap':o.frame===1?'-wake':'-puzzled'),p.x,p.y+13,o.frame===0?62:57,flip);}
  else if(o.anim===A.LEAVE){this.asset(coat+'-walk-'+(back?'rear':'front')+'-'+(o.frame&1),p.x,p.y+15,65,flip);}
  else{this.asset(coat+'-'+(back?'crouch-rear':'puzzled'),p.x,p.y+13,back?65:53,flip);}
 }
}
root.CivicPieces=Pieces;
})(globalThis);
