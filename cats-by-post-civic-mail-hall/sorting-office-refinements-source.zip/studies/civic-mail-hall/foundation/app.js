'use strict';
const $=id=>document.getElementById(id);
const session=CivicSession.create(OfficeRules,BOARDANIM,OfficeLevels);
const renderer=new CivicRenderer($('scene'),FoundationAssets);
const statusText={edit:'Place your turntables, then send the post.',running:'The post is on its way.',won:'Everyone delivered. Time for a well-earned nap.',lost:'This route needs another look. Edit the turntables and try again.'};
let lastMode='',lastNow=null,reference=false,selectedCell=null;
const names={plain:'Any cat',ginger:'Ginger',blue:'Blue'};
OfficeLevels.forEach((L,i)=>{$('level').add(new Option(L.id+' · '+L.title,String(i)));});
for(const type of ['plain','ginger','blue']){const b=document.createElement('button');b.dataset.type=type;b.onclick=()=>{session.select(type);refresh();};$('tray').appendChild(b);}
function refresh(){
 $('level').value=String(session.index);$('level').disabled=session.mode==='running';$('goal').textContent=session.level.idea;
 for(const b of $('tray').children){b.textContent=names[b.dataset.type]+' · '+session.tray[b.dataset.type];b.setAttribute('aria-pressed',String(session.selected===b.dataset.type));b.disabled=session.mode==='running';}
 $('queue').textContent=session.level.hatches.map((h,i)=>'In '+(i+1)+': '+h.cats.map(c=>typeof c==='string'?c:c.coat).join(' → ')).join('   ·   ');
 $('send').textContent=session.mode==='running'?'Stop / edit route':'Send the post →';$('reset').disabled=session.mode==='running';$('hint').disabled=session.mode==='running';
 $('status').textContent=statusText[session.mode];lastMode=session.mode;
}
function view(mode){reference=mode==='reference';document.body.classList.toggle('reference',reference);document.body.classList.toggle('explore',mode==='structure');$('reference-image').hidden=!reference;for(const id of ['play','structure','reference'])$(id).setAttribute('aria-pressed',String(id===mode));renderer.resize();if(!reference)renderer.fit(mode==='structure'?'explore':'play');}
$('reference-image').src=FoundationReference;
$('play').onclick=()=>view('play');$('structure').onclick=()=>view('structure');$('reference').onclick=()=>view('reference');
$('hall-play').onclick=()=>view('play');
$('level').onchange=()=>{session.load(+$('level').value);renderer.config.w=session.level.board.w;renderer.config.h=session.level.board.h;renderer.selected=null;selectedCell=null;renderer.fit(renderer.config.mode);refresh();};
$('send').onclick=()=>{session.send();refresh();};$('reset').onclick=()=>{session.reset();session.clear();refresh();};$('hint').onclick=()=>{session.hint();refresh();};
$('preview').onclick=()=>{session.load(session.index);session.chutes=session.level.solution.map(p=>({...p}));for(const p of session.chutes)session.tray[p.type]--;session.send();refresh();};
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
function motion(on){renderer.motion=on;$('motion').setAttribute('aria-pressed',String(on));$('motion').textContent=on?'Motion on':'Motion off';}
motion(!reduced.matches);$('motion').onclick=()=>motion(!renderer.motion);reduced.addEventListener('change',e=>motion(!e.matches));
$('guides').onchange=()=>renderer.guides=$('guides').checked;
$('minus').onclick=()=>renderer.zoom(-.15,renderer.config.width/2,renderer.config.height/2);$('plus').onclick=()=>renderer.zoom(.15,renderer.config.width/2,renderer.config.height/2);
const pointers=new Map();let gesture=false,moved=false,pinchDistance=0,pinchX=0,pinchY=0,lastEmptyTap=-1000;
function pair(){const p=[...pointers.values()];return{distance:Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y),x:(p[0].x+p[1].x)/2,y:(p[0].y+p[1].y)/2};}
const canvas=$('scene');
canvas.addEventListener('pointerdown',e=>{pointers.set(e.pointerId,{x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY});if(pointers.size===1){gesture=false;moved=false;}if(pointers.size===2){gesture=true;const p=pair();pinchDistance=p.distance;pinchX=p.x;pinchY=p.y;}try{canvas.setPointerCapture(e.pointerId);}catch{}});
canvas.addEventListener('pointermove',e=>{const old=pointers.get(e.pointerId);if(!old)return;const dx=e.clientX-old.x,dy=e.clientY-old.y;old.x=e.clientX;old.y=e.clientY;if(Math.hypot(old.x-old.startX,old.y-old.startY)>8)moved=true;
 if(pointers.size>=2){const p=pair(),r=canvas.getBoundingClientRect();renderer.drag(p.x-pinchX,p.y-pinchY);if(pinchDistance>0&&p.distance>0){const zoom=Math.max(.7,Math.min(2.5,renderer.config.zoom*p.distance/pinchDistance)),pan=CivicProjection.zoomAt(renderer.config,{x:p.x-r.left,y:p.y-r.top},zoom);Object.assign(renderer.config,pan,{zoom});renderer.cam=CivicProjection.camera(renderer.config);}pinchDistance=p.distance;pinchX=p.x;pinchY=p.y;}
 else if(e.pointerType==='mouse'&&moved)renderer.drag(dx,dy);
});
function release(e,cancelled=false){const p=pointers.get(e.pointerId);if(!p)return;pointers.delete(e.pointerId);if(!cancelled&&!gesture&&!moved){const cell=renderer.cellAt(e.clientX,e.clientY);if(cell){selectedCell=cell;renderer.selected=cell;session.tap(cell.x,cell.y);refresh();}else{const now=performance.now();if(now-lastEmptyTap<300)renderer.fit(renderer.config.mode);lastEmptyTap=now;}}if(!pointers.size){gesture=false;moved=false;}}
canvas.addEventListener('pointerup',e=>release(e));canvas.addEventListener('pointercancel',e=>release(e,true));
canvas.addEventListener('wheel',e=>{e.preventDefault();const r=canvas.getBoundingClientRect();renderer.zoom(-Math.sign(e.deltaY)*.1,e.clientX-r.left,e.clientY-r.top);},{passive:false});
window.addEventListener('keydown',e=>{if(['SELECT','INPUT','TEXTAREA','BUTTON'].includes(e.target.tagName))return;if(e.key==='g'||e.key==='G'){renderer.gray=!renderer.gray;return;}if(e.key==='0'){renderer.fit(renderer.config.mode);return;}if(e.key===' '){e.preventDefault();session.send();refresh();return;}if(e.key.toLowerCase()==='h'){session.hint();refresh();return;}if(['1','2','3'].includes(e.key)){session.select(['plain','ginger','blue'][+e.key-1]);refresh();return;}if(!selectedCell)selectedCell={x:0,y:0};if(e.key==='ArrowLeft')selectedCell.x=Math.max(0,selectedCell.x-1);else if(e.key==='ArrowRight')selectedCell.x=Math.min(session.level.board.w-1,selectedCell.x+1);else if(e.key==='ArrowUp')selectedCell.y=Math.max(0,selectedCell.y-1);else if(e.key==='ArrowDown')selectedCell.y=Math.min(session.level.board.h-1,selectedCell.y+1);else if(e.key==='Enter')session.tap(selectedCell.x,selectedCell.y);else return;e.preventDefault();renderer.selected=selectedCell;refresh();});
window.addEventListener('blur',()=>{lastNow=null;pointers.clear();gesture=false;moved=false;});
document.addEventListener('visibilitychange',()=>lastNow=null);
let paused=false;
function frame(now){if(lastNow!==null&&!paused&&!document.hidden){const dt=Math.min(.25,(now-lastNow)/1000);session.step(dt);if(renderer.motion)renderer.ambient+=dt;}lastNow=now;if(lastMode!==session.mode)refresh();if(!reference)renderer.draw(session);requestAnimationFrame(frame);}
window.__foundation={session,renderer,pause:value=>paused=!!value,ready:false,view,motion,refresh,cell:(x,y)=>renderer.screenCell(x,y)};
renderer.load().then(()=>{window.__foundation.ready=true;refresh();view(new URLSearchParams(location.search).get('view')==='hall'?'structure':'play');requestAnimationFrame(frame);}).catch(e=>{$('status').textContent=e.message;console.error(e);});
